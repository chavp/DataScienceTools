import {
    HttpException,
    HttpStatus,
    Injectable,
} from '@nestjs/common'
import { ISurveyorLineModel } from './interface/model.interface'
import {
    forkJoin,
    from,
    Observable,
    of,
} from 'rxjs'
import { ISurveyorLineRepository } from './interface/repository.interface'
import { IFullDuplexWebSocket } from '../../adapter/notification/interfaces/socket.interface'
import { ILineAdapter } from '../../adapter/line/interface/line.interface'
import {
    concatMap,
    delay,
    filter,
    map,
    mergeMap,
    throwIfEmpty,
    toArray,
} from 'rxjs/operators'
import * as _ from 'lodash'
import { IUpdateSurveyorLineValidator } from './interface/validator.interface'
import { ISurveyorLineService } from './interface/service.interface'
import { UploadSurveyorLineValidator } from '../../controller/rest/validator/surveyor-line.validator'
import { ISurveyorRepository } from '../surveyor/interface/repository.interface'
import { ISurveyorModel } from '../surveyor/interface/model.interface'

@Injectable()
export class SurveyorLineService implements ISurveyorLineService {

    constructor(
        private readonly _surveyorLineRepository: ISurveyorLineRepository,
        private readonly _socketAdapter: IFullDuplexWebSocket,
        private readonly _lineAdapter: ILineAdapter,
        private readonly _surveyorRepository: ISurveyorRepository,
    ) {
    }

    public getAll(): Observable<any> {
        return this._surveyorLineRepository.find()
    }

    public getRegisteredGroup(): Observable<ISurveyorLineModel> {
        return this._surveyorLineRepository.find().pipe(
            filter(model => !_.isEmpty(model.getSurveyorId())),
        )
    }

    public getById(id: string): Observable<ISurveyorLineModel> {
        return this._surveyorLineRepository.find({ _id: id }).pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `surveyor-line not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
            map((result: ISurveyorLineModel) => {
                // Coding Here...
                return result
            }),
        )
    }

    public update(id: string, input: IUpdateSurveyorLineValidator): Observable<ISurveyorLineModel> {
        return this._surveyorLineRepository.find({ _id: id }).pipe(
            map((result) => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `Profile not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }
                return result
            }),
            map((surveyorLine: ISurveyorLineModel) => {
                surveyorLine.setAddress(input.getAddress())
                surveyorLine.setCompanyName(input.getCompanyName())
                surveyorLine.setCompanyPhone(input.getCompanyPhone())
                surveyorLine.setId(input.getGroupLineId())
                surveyorLine.setGroupName(input.getGroupName())
                surveyorLine.setPartnerCompany(input.getCompanyName())
                surveyorLine.setServiceArea(input.getServiceArea())
                return surveyorLine
            }),
            mergeMap((surveyorLine: ISurveyorLineModel) => {
                return this._surveyorLineRepository.update(surveyorLine).pipe(
                    map((result: boolean) => {
                        if (result) {
                            return surveyorLine
                        }
                    }),
                )
            }),
        )
    }

    public surveyorFileMap(input: UploadSurveyorLineValidator[]): Observable<any> {
        return from(input).pipe(
            delay(50),
            concatMap(item => {
                return forkJoin([
                    this._surveyorLineRepository.getById(item.id),
                    this._surveyorRepository.getById(item.surveyorCode),
                    of(item),
                ])
            }),
            toArray(),
            concatMap((result: Array<[ ISurveyorLineModel, ISurveyorModel, UploadSurveyorLineValidator ]>) => {
                return from(result)
            }),
            concatMap(each => {
                const group = each[0]
                const surveyor = each[1]
                const inputRecord = each[2]
                group.setCompanyName(surveyor.getName())
                group.setSurveyorId(surveyor.getId())
                group.setUpdatedDate(new Date())
                group.setGroupName(inputRecord.groupName)

                return this._surveyorLineRepository.update(group).pipe(
                    map(() => group),
                )
            }),
        )
    }

}
