import { Test, TestingModule } from '@nestjs/testing'
import { SurveyorLineService } from './surveyor-line.service'

describe('SurveyorLineService', () => {
  let service: SurveyorLineService

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [SurveyorLineService],
    }).compile()

    service = module.get<SurveyorLineService>(SurveyorLineService)
  })

  it('should be defined', () => {
    expect(service).toBeDefined()
  })
})
