import { ISurveyorLineModel } from './model.interface'
import { IRepository } from '../../../common/interface/repository.interface'
import { Observable } from 'rxjs'

export interface ISurveyorLineRepository extends IRepository<ISurveyorLineModel> {
    find(filter?: any): Observable<ISurveyorLineModel>

    save(model: ISurveyorLineModel): Observable<any>

    update(model: ISurveyorLineModel): Observable<boolean>

    getById(id: string): Observable<ISurveyorLineModel>

    getBySurveyorId(id: string): Observable<ISurveyorLineModel>
}
