import { IEntity } from '../../../common/interface/entity.interface'

export interface ISurveyorLineModel extends IEntity {
    getAddress(): string

    getCompanyName(): string

    getCompanyPhone(): string

    getGroupName(): string

    getPartnerCompany(): string

    getServiceArea(): IServiceAreaSchema

    getSurveyorId(): string

    setAddress(address: string): void

    setCompanyName(companyName: string): void

    setCompanyPhone(companyPhone: string): void

    setGroupName(groupName: string): void

    setPartnerCompany(partnerCompany: string): void

    setServiceArea(serviceArea: IServiceAreaSchema): void

    setSurveyorId(surveyorId: string): void

    setStatus(status: 'join' | 'leave'): void

    getStatus(): 'join' | 'leave'

    getCreatedDate(): Date

    getUpdatedDate(): Date

    setUpdatedDate(date: Date): void

}

export interface IServiceAreaSchema {
    province: string
    district: string[]
}
