import { IServiceAreaSchema } from './model.interface'

export interface IUpdateSurveyorLineValidator {
    getAddress(): string

    getGroupLineId(): string

    getCompanyName(): string

    getCompanyPhone(): string

    getGroupName(): string

    getPartnerCompany(): string

    getServiceArea(): IServiceAreaSchema
}
