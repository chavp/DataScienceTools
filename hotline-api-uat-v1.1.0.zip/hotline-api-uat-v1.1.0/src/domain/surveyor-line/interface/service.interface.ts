import { Observable } from 'rxjs'
import { ISurveyorLineModel } from './model.interface'
import {
    IUpdateSurveyorLineValidator,
} from './validator.interface'
import { UploadSurveyorLineValidator } from '../../../controller/rest/validator/surveyor-line.validator'

export interface ISurveyorLineService {
    getAll(): Observable<ISurveyorLineModel>

    getRegisteredGroup(): Observable<ISurveyorLineModel>

    getById(id: string): Observable<ISurveyorLineModel>

    update(id: string, input: IUpdateSurveyorLineValidator): Observable<ISurveyorLineModel>

    surveyorFileMap(input: UploadSurveyorLineValidator[]): Observable<any>

}
