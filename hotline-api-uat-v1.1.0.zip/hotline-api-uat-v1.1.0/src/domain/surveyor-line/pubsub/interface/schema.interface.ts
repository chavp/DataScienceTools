import { IServiceAreaSchema } from '../../interface/model.interface'

export interface IUpdateSurveyorEventSchema {
    // incidentNo: string
    // callerName: string
    // contactNo: string
    // place: string
    // surveyorNo: string

    surveyorId: string
    address: string
    groupLineId: string
    companyName: string
    companyPhone: string
    groupName: string
    partnerCompany: string
    serviceArea: IServiceAreaSchema
}
