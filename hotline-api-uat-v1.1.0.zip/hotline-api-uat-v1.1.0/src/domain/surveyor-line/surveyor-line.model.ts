import { Entity } from '../../common/entity'
import {
    ISurveyorLineModel,
    IServiceAreaSchema,
} from './interface/model.interface'

export class SurveyorLineModel extends Entity implements ISurveyorLineModel {
    private _address: string
    private _companyName: string
    private _companyPhone: string
    private _groupName: string
    private _partnerCompany: string
    private _serviceArea: IServiceAreaSchema
    private _surveyor: string
    private _status: 'join' | 'leave'
    private readonly _createdDate: Date
    private _updatedDate: Date

    constructor() {
        super()
        this._status = 'join'
        this._createdDate = new Date()
        this._updatedDate =  new Date()
    }

    public getAddress(): string {
        return this._address
    }

    public getCompanyName(): string {
        return this._companyName
    }

    public getCompanyPhone(): string {
        return this._companyPhone
    }

    public getGroupName(): string {
        return this._groupName
    }

    public getPartnerCompany(): string {
        return this._partnerCompany
    }

    public getServiceArea(): IServiceAreaSchema {
        return this._serviceArea
    }

    public getSurveyorId(): string {
        return this._surveyor
    }

    public setAddress(address: string): void {
        this._address = address
    }

    public setCompanyName(companyName: string): void {
        this._companyName = companyName
    }

    public setCompanyPhone(companyPhone: string): void {
        this._companyPhone = companyPhone
    }

    public setGroupName(groupName: string): void {
        this._groupName = groupName
    }

    public setPartnerCompany(partnerCompany: string): void {
        this._partnerCompany = partnerCompany
    }

    public setServiceArea(serviceArea: IServiceAreaSchema) {
        this._serviceArea = serviceArea
    }

    public setSurveyorId(surveyor: string): void {
        this._surveyor = surveyor
    }

    public setStatus(status: 'join' | 'leave'): void {
        this._status = status
    }

    public getStatus(): 'join' | 'leave' {
        return this._status
    }

    public getCreatedDate(): Date {
        return new Date(this._createdDate)
    }

    public getUpdatedDate(): Date {
        return new Date(this._updatedDate)
    }

    public setUpdatedDate(date: Date): void {
        this._updatedDate = new Date(date)
    }

}
