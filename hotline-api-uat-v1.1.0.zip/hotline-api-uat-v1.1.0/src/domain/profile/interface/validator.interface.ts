import { UserRolesEnum } from '../../../repository/profile/profile.schema'

export interface ICreateProfileValidator {
    getId(): string
    getName(): string
}

export interface IUpdateProfileValidator {
    getName(): string
    getRoles(): UserRolesEnum[]
    getUpdatedBy(): string
    setUpdatedBy(name: string): void
}
