import { IEntity } from '../../../common/interface/entity.interface'
import { UserRolesEnum } from '../../../repository/profile/profile.schema'
export interface IProfileModel extends IEntity {
    getName(): string
    getRoles(): UserRolesEnum[]
    getCreatedAt(): Date
    getUpdatedAt(): Date
    getUpdatedBy(): string
    getSessionId(): string

    setName(name: string): void
    setRoles(roles: UserRolesEnum[]): void
    setCreatedAt(createdAt: Date): void
    setUpdatedAt(updatedAt: Date): void
    setUpdatedBy(updatedBy: string): void
    setSessionId(sessionId: string): void

}
