import { Observable } from 'rxjs'
import { IProfileModel } from './model.interface'
import { IUpdateProfileValidator } from './validator.interface'

export interface IProfileService {
    getById(id: string): Observable<any>

    getAll(): Observable<IProfileModel>

    save(input: ICreateProfile): Observable<IProfileModel>

    update(id: string, input: IUpdateProfileValidator): Observable<IProfileModel>

    updateSession(id: string, sessionId: string): Observable<boolean>
}

export interface ICreateProfile {
    id: string
    name: string
}

export interface ISessionService {
    get(id: string): Observable<any>

    findByUser(userId): Observable<any>
}
