
import { Observable } from 'rxjs'
import { IProfileModel } from './model.interface'
import { IRepository } from '../../../common/interface/repository.interface'

export interface IProfileRepository extends IRepository<IProfileModel> {
    find(filter?: any): Observable<IProfileModel>
    save(model: IProfileModel): Observable<{id: string}>
    update(model: IProfileModel): Observable<boolean>
}
