import { ProfileModel } from '../profile.model'
import { plainToClass } from 'class-transformer'
import { UserRolesEnum } from '../../../repository/profile/profile.schema'

describe('ProfileModel', () => {
    let model: ProfileModel = null

    beforeEach(() => {
        model = plainToClass(ProfileModel, {
            id: 'siruv02',
            name: 'sleeping',
            role: ['admin', 'agent'],
            createdAt: '2019/12/30',
            updatedAt: '2019/12/30',
            updatedBy: 'Jc',
        })
    })

    it( 'profile model', () => {
        model.setId('sisisisi01')
        expect(model.getId()).toEqual('sisisisi01')
        model.setName('prateep')
        expect(model.getName()).toEqual('prateep')
        // model.setRoles([UserRolesEnum.ADMIN, UserRolesEnum.AGENT])
        model.setRoles([UserRolesEnum.ADMIN, UserRolesEnum.AGENT])
        expect(model.getRoles()).toEqual([UserRolesEnum.ADMIN, UserRolesEnum.AGENT])
        model.setCreatedAt(new Date('2019/12/30'))
        expect(model.getCreatedAt()).toEqual(new Date('2019/12/30'))
        model.setUpdatedAt(new Date('2018/11/11'))
        expect(model.getUpdatedAt()).toEqual(new Date('2018/11/11'))
        model.setUpdatedBy('Jc')
        expect(model.getUpdatedBy()).toEqual('Jc')
    })
})
