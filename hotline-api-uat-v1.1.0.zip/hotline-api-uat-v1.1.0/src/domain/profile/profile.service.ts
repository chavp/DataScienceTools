import {
    ICreateProfile,
    IProfileService,
} from './interface/service.interface'
import { IProfileRepository } from './interface/repository.interface'
import { ProfileModel } from './profile.model'
import {
    forkJoin,
    from,
    Observable,
    of,
} from 'rxjs'
import { IProfileModel } from './interface/model.interface'
import {
    ICreateProfileValidator,
    IUpdateProfileValidator,
} from './interface/validator.interface'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import {
    flatMap,
    map,
    mergeMap,
    reduce,
    take,
    tap,
    throwIfEmpty,
} from 'rxjs/operators'
import * as _ from 'lodash'
import { UserRolesEnum } from '../../repository/profile/profile.schema'
import { IPermissionRepository } from '../permission/interface/repository.interface'
import { IPermissionModel } from '../permission/interface/model.interface'
import { PermissionEnum } from '../common/interface/permission-enum'

export class ProfileService implements IProfileService {

    constructor(
        private readonly _profileRepository: IProfileRepository,
        private readonly _permissionRepository: IPermissionRepository,
    ) {

    }

    public getAll(): Observable<IProfileModel> {
        return this._profileRepository.find().pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `incident not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
        )
    }

    public getById(id: string): Observable<any> {
        return this._profileRepository.find({ _id: id }).pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `Profile id : ${id} not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
            mergeMap((result: IProfileModel) => {
                const roles = result.getRoles()

                return forkJoin([
                    of(result),
                    this.getPermission(roles),
                ])
            }),
            map((result: any[]) => {
                return {
                    role: result[0],
                    permission: result[1],
                }
            }),
        )
    }

    private getPermission(roles: UserRolesEnum[]): Observable<any> {
        if (roles.length === 0) {
            return of(null)
        }

        const permission = []
        return of(roles).pipe(
            flatMap(role => role),
            mergeMap(data => {
                return this._permissionRepository.find({ _id: data }).pipe(
                    map((model) => {
                        if (_.isNil(model)) {
                            throw new HttpException(
                                `permission not found`,
                                HttpStatus.NOT_FOUND,
                            )
                        }

                        return model
                    }),
                    reduce((acc, model) => {
                        acc.push(model)
                        return acc
                    }, permission),
                )
            }),
        )
    }

    public save(input: ICreateProfile): Observable<IProfileModel> {
        const model = new ProfileModel()
        model.setId(input.id)
        model.setName(input.name)
        model.setCreatedAt(new Date())

        return of(model).pipe(
            mergeMap(() => {
                return this._profileRepository.save(model)
            }),
            mergeMap((result) => {
                return this._profileRepository.find({ _id: result.id })
            }),
        )
    }

    public update(id: string, input: IUpdateProfileValidator): Observable<IProfileModel> {
        return this._profileRepository.find({ _id: id }).pipe(
            map((result) => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `Profile not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }

                return result
            }),
            map((profile: IProfileModel) => {
                if (!_.isNil(input.getName())) {
                    profile.setName(input.getName())
                }
                if (!_.isNil(input.getRoles())) {
                    profile.setRoles(input.getRoles())
                }
                if (!_.isNil(input.getUpdatedBy())) {
                    profile.setUpdatedBy(input.getUpdatedBy())
                }
                profile.setUpdatedAt(new Date())

                return profile
            }),
            mergeMap((profile: IProfileModel) => {
                return this._profileRepository.update(profile).pipe(
                    map((result) => {
                        if (result === true) {
                            return profile
                        }
                    }),
                )
            }),
        )
    }

    public updateSession(id: string, sessionId: string): Observable<boolean> {
        return this._profileRepository.find({ _id: id }).pipe(
            map((result) => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `Profile not found`,
                        HttpStatus.BAD_REQUEST,
                    )
                }
                return result
            }),
            map(model => {
                model.setSessionId(sessionId)
                return model
            }),
            mergeMap(model => {
                return this._profileRepository.update(model)
            }),
        )
    }
}
