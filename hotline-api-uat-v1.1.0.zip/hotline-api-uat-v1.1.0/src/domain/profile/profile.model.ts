import { Entity } from '../../common/entity'
import { IProfileModel } from './interface/model.interface'
import { UserRolesEnum } from '../../repository/profile/profile.schema'
import * as _ from 'lodash'

export class ProfileModel extends Entity implements IProfileModel {
    private _name: string
    private _roles: UserRolesEnum[]
    private _createdAt: Date
    private _updatedAt: Date
    private _updatedBy: string
    private _sessionId: string

    constructor() {
        super()
        this._roles = []
    }

    public getCreatedAt(): Date {
        return this._createdAt
    }

    public getName(): string {
        return this._name
    }

    public getRoles(): UserRolesEnum[] {
        return _.slice(this._roles)
    }

    public getUpdatedAt(): Date {
        return this._updatedAt
    }

    public getUpdatedBy(): string {
        return this._updatedBy
    }

    public setCreatedAt(createdAt: Date): void {
        this._createdAt = createdAt
    }

    public setName(name: string): void {
        this._name = name
    }

    public setRoles(roles: UserRolesEnum[]): void {
        // this.assertTrue(!_.includes(this._roles, roles), 'Cannot add duplicated roles')
        this._roles = roles
    }

    public setUpdatedAt(updatedAt: Date): void {
        this._updatedAt = updatedAt
    }

    public setUpdatedBy(updatedBy: string): void {
        this._updatedBy = updatedBy
    }

    public getSessionId(): string {
        return this._sessionId
    }
    public setSessionId(sessionId: string): void {
        this._sessionId = sessionId
    }
}
