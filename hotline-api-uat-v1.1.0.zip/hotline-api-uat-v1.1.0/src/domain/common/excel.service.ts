import { Observable, of } from 'rxjs'
import { utils as xlsxUtils, read } from 'xlsx'

import { IExcelService } from './interface/excel.service.interface'

export abstract class ExcelService<O> implements IExcelService<O> {
    public abstract serialize(rowObject: any): O

    public batchSerialize(rows: O[]): O[] {
        return rows
    }

    public parse(buffer: Buffer, requireColumns?: string[]): O[] {
        const workBook = read(buffer, { type: 'buffer'})
        const targetSheet = workBook.Sheets[workBook.SheetNames[0]]
        const excelRows = xlsxUtils.sheet_to_json(targetSheet).map(row => this.serialize(row))
        return this.batchSerialize(excelRows)
    }

    public reverseParse(schemas: O[]): string {
        return ''
    }
}
