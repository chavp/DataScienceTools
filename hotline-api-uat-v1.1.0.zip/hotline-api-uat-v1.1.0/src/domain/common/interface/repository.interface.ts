import { IRepository } from '../../../common/interface/repository.interface'
import { ISmsLogModel } from './common.interface'
import { Observable } from 'rxjs'

export interface ISmsLogRepository extends IRepository<ISmsLogModel> {
    save(model: ISmsLogModel): Observable<{ id: string }>

    find(filter?: any): Observable<ISmsLogModel>
}
