import {IEntity} from '../../../common/interface/entity.interface'

export interface ISmsValidator {
    getReceiver(): string

    getMessage(): string

    getIncidentNo(): string

    setSender(sender: string): void
}

export interface ISmsLogModel extends IEntity {
    getIncidentNo(): string
    setIncidentNo(no: string): void
    getContactNo(): string
    setContactNo(no: string): void

    getMessage(): string
    setMessage(message: string): void

    getSender(): string
    setSender(sender: string): void

    getCreatedTime(): Date

}
