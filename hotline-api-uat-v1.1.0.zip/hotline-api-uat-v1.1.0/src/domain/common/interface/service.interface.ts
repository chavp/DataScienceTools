import {Observable} from 'rxjs'
import {
    ISmsLogModel,
    ISmsValidator,
} from './common.interface'

export interface ICommonService {
    healthCheck(): string
    sendSms(input: ISmsValidator): Observable<any>
    getSms(incidentNo: string): Observable<ISmsLogModel>
}
