import { Observable } from 'rxjs'

export interface IExcelService<O> {
    serialize(rowObject: any): O
    batchSerialize(rows: O[]): O[]
    parse(buffer: Buffer): O[]
    reverseParse(schemas: O[]): string
}
