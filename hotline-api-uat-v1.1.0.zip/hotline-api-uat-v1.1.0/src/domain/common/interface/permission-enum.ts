export enum PermissionEnum {
    INCIDENT = 'incident',
    LINE = 'line',
    REPORT = 'report',
    RECORDER = 'recorder',
    SURVEYOR = 'surveyor',
    MANAGEMENT = 'management',
}
