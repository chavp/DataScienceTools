import {ProviderName} from '../../provider'
import {ICommonService} from './interface/service.interface'
import {Observable} from 'rxjs'
import {ISmsLogRepository} from './interface/repository.interface'
import {IIncidentRepository} from '../incident/interface'
import {
    ISmsLogModel,
    ISmsValidator,
} from './interface/common.interface'
import {map, mergeMap, throwIfEmpty} from 'rxjs/operators'
import {HttpException, HttpStatus} from '@nestjs/common'
import {SmsLogModel} from './sms-log.model'
import {ISmsAdapter} from '../../adapter/sms/interface/adaper.interface'

const {} = ProviderName

export class CommonService implements ICommonService {
    constructor(
        private readonly _smsLogRepository: ISmsLogRepository,
        private readonly _incidentRepository: IIncidentRepository,
        private readonly _smsAdapter: ISmsAdapter,
    ) {

    }

    public healthCheck(): string {
        return '200'
    }

    public sendSms(input: ISmsValidator): Observable<any> {
        const incidentNo = input.getIncidentNo()
        return this._incidentRepository.find({_id: incidentNo}).pipe(
            throwIfEmpty(() => {
                throw new HttpException(`Cannot find incident`, HttpStatus.BAD_REQUEST)
            }),
            mergeMap(() => {
                return this._smsAdapter.send(`AXA HOTLINE`, input.getReceiver(), input.getMessage())
            }),
            map(() => {
                const model = new SmsLogModel()
                model.setContactNo(input.getReceiver())
                model.setIncidentNo(input.getIncidentNo())
                model.setMessage(input.getMessage())
                model.setSender('Agent')
                return model
            }),
            mergeMap(model => this._smsLogRepository.save(model)),
        )
    }

    public getSms(incidentNo: string): Observable<ISmsLogModel> {
        const query = {
            incidentNo,
        }
        return this._smsLogRepository.find(query).pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `Sms not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
        )
    }

}
