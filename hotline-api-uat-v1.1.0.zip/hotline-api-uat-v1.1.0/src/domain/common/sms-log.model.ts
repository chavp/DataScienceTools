import {Entity} from '../../common/entity'
import {ISmsLogModel} from './interface/common.interface'

export class SmsLogModel extends Entity implements ISmsLogModel {
    private _incidentNo: string
    private _contactNo: string
    private _message: string
    private readonly _createdTime: Date
    private _createdBy: string

    constructor() {
        super()
        this._createdTime = new Date()
    }
    getContactNo(): string {
        return this._contactNo
    }

    getCreatedTime(): Date {
        return new Date(this._createdTime)
    }

    getIncidentNo(): string {
        return this._incidentNo
    }

    getMessage(): string {
        return this._message
    }

    getSender(): string {
        return this._createdBy
    }

    setContactNo(no: string): void {
        this._contactNo = no
    }

    setIncidentNo(no: string): void {
        this._incidentNo = no
    }

    setMessage(message: string): void {
        this._message = message
    }

    setSender(sender: string): void {
        this._createdBy = sender
    }

}
