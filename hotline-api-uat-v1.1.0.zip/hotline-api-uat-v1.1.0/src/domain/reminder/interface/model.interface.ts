import { IEntity } from '../../../common/interface/entity.interface'

export interface IReminderModel extends IEntity {
    getIncidentNo(): string

    getRegistration(): string

    getNote(): string

    getRemindTime(): Date

    getStatus(): 'read' | 'unread'

    getAgent(): string

    getCreatedAt(): Date

    getType(): 'manual' | 'appointment'

    setIncidentNo(incidentId: string): void

    setRegistration(registration: string): void

    setNote(note: string): void

    setRemindTime(time: Date): void

    setStatus(status: 'read' | 'unread'): void

    setAgent(agent: string): void

    setNotify(notify: boolean): void

    isNotified(): boolean

    setType(type: 'manual' | 'appointment'): void
}
