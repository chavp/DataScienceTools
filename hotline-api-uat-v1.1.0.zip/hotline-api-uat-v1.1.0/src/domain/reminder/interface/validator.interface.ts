export interface ISaveReminderValidator {
    getIncidentNo(): string

    setIncidentNo(incidentNo: string): void

    getRegistration(): string

    setRegistration(registration: string): void

    getNote(): string

    setNote(note: string): void

    getRemindTime(): number

    setRemindTime(remindTime: number): void

    getAgent(): string

    setAgent(agent: string): void
}

export interface IReadReminderValidator {
    getStatus(): 'read' | 'unread'

    getAgent(): string

    setAgent(agent: string): void
}
