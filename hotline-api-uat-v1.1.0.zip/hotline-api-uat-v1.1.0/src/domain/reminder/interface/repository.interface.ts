import { IRepository } from '../../../common/interface/repository.interface'
import { IReminderModel } from './model.interface'
import { Observable } from 'rxjs'

export interface IReminderRepository extends IRepository<IReminderModel> {
    getById(id: string): Observable<IReminderModel>
    find(dateFilter: Date): Observable<IReminderModel>
    save(model: IReminderModel): Observable<{id: string}>
    update(model: IReminderModel): Observable<boolean>
    getIncidentNo(id: string): Observable<IReminderModel>
    getByIncidentNo(id: string): Observable<IReminderModel>
    delete(id: string): Observable<boolean>
}
