import { Observable } from 'rxjs'
import { IReminderModel } from './model.interface'
import {
    ReadReminderValidator,
    SaveReminderValidator,
} from '../../../controller/rest/validator/reminder.validator'

export interface IReminderService {
    getAll(): Observable<IReminderModel>
    find(date: Date): Observable<IReminderModel>
    save(model: SaveReminderValidator): Observable<{id: string}>
    update(id: string, model: ReadReminderValidator): Observable<boolean>
    getById(id: string): Observable<IReminderModel>
}
