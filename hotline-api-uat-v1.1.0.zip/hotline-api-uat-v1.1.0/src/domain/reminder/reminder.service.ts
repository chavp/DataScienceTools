import { IReminderService } from './interface/service.interface'
import { IReminderRepository } from './interface/repository.interface'
import {
    forkJoin,
    from,
    Observable,
} from 'rxjs'
import { IReminderModel } from './interface/model.interface'
import {
    IIncidentModel,
    IIncidentRepository,
} from '../incident/interface'
import {
    concatMap,
    delay,
    filter,
    map,
    mergeMap,
    reduce,
    tap,
    toArray,
} from 'rxjs/operators'
import * as _ from 'lodash'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import { ReminderModel } from './reminder.model'
import {
    IWebSocketAdapter,
    ReminderEvent,
} from '../../adapter/notification/interfaces/socket.interface'
import {
    ReadReminderValidator,
    SaveReminderValidator,
} from '../../controller/rest/validator/reminder.validator'
import * as Moment from 'moment'

export class ReminderService implements IReminderService {
    constructor(
        private readonly _reminderRepository: IReminderRepository,
        private readonly _incidentRepository: IIncidentRepository,
        private readonly _webSocketAdapter: IWebSocketAdapter,
    ) {

    }

    public getAll(): Observable<IReminderModel> {
        return this._reminderRepository.list(1, 0).pipe(
            map(result => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `Reminder not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }
                return result
            }),
        )
    }

    public find(date: Date): Observable<IReminderModel> {
        return this._reminderRepository.find(date)
    }

    public save(input: SaveReminderValidator): Observable<any> {
        const incidentId = input.getIncidentNo()
        return this.checkIncident(incidentId).pipe(
            mergeMap((incident) => {
                let registration
                if (!_.isNil(incident.getPolicy())) {
                    registration = incident.getPolicy().registration
                } else {
                    registration = null
                }

                const reminderModel = new ReminderModel()
                reminderModel.setAgent(input.getAgent())
                reminderModel.setIncidentNo(incidentId)
                reminderModel.setNote(input.getNote())
                reminderModel.setRegistration(registration)
                reminderModel.setRemindTime(new Date(input.getRemindTime()))
                reminderModel.setStatus('unread')
                reminderModel.setType('manual')

                return this._reminderRepository.save(reminderModel)
            }),
        )
    }

    public update(id: string, input: ReadReminderValidator): Observable<any> {
        const unreadReminder = {
            total: 0,
        }

        return this.checkReminder(id).pipe(
            mergeMap((reminder) => {
                reminder.setStatus(input.getStatus())
                return this._reminderRepository.update(reminder)
            }),
            mergeMap(() => {
                const filterDate = new Date()
                // return this._reminderRepository.list(1, 0).pipe()
                return this._reminderRepository.find(filterDate)
            }),
            filter((reminder: IReminderModel) => {
                const capTime = Moment().add(1, 'h')
                return reminder.getStatus() === 'unread' && Moment(reminder.getRemindTime()).isBefore(capTime)
            }),
            toArray(),
            concatMap((reminders: IReminderModel[]) => {
                // console.log(`reminders.length: `, reminders.length)
                return this._webSocketAdapter.sendMessage(ReminderEvent.MESSAGE_TOTAL, { total: reminders.length}).pipe(
                    map(() => reminders),
                )
            }),
            concatMap( reminders => from(reminders)),
            delay(50),
            concatMap(reminder => {
                reminder.setNotify(true)
                return this._reminderRepository.update(reminder)
            }),
        )
    }

    private checkIncident(id: string): Observable<IIncidentModel> {
        return this._incidentRepository.find({_id: id}).pipe(
            map(result => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `Incident not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }

                return result
            }),
        )
    }

    private checkReminder(id: string): Observable<IReminderModel> {
        return this._reminderRepository.getById(id).pipe(
            map(result => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `Reminder not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }
                return result
            }),
        )
    }

    public getById(id: string): Observable<IReminderModel> {
        return this._reminderRepository.getIncidentNo(id)
    }
}
