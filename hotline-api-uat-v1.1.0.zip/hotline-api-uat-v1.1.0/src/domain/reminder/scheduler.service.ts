import { IRunnable } from '../../common/interface/runnable.interface'
import { IReminderRepository } from './interface/repository.interface'
import {
    IWebSocketAdapter,
    ReminderEvent,
} from '../../adapter/notification/interfaces/socket.interface'
import { interval } from 'rxjs'
import * as Moment from 'moment'
import {
    concatMap,
    delay,
    filter,
    map,
    mergeMap,
    tap,
    toArray,
} from 'rxjs/operators'
import { IReminderModel } from './interface/model.interface'
import { IMessageSchema } from '../../adapter/notification/interfaces/schema.interface'

export class SchedulerService implements IRunnable {
    constructor(
        private readonly _reminderRepository: IReminderRepository,
        private readonly _webSocket: IWebSocketAdapter,
    ) {

    }

    public run(): void {
        console.log(`Notification Service Start`)
        interval(10000).pipe(
            concatMap(() => {
                return this._reminderRepository.list(1, 0).pipe(
                    delay(50),
                )
            }),
            filter((model: IReminderModel) => {
                // const capTime = Moment().add(1, 'h')
                const capTime = Moment()
                return !model.isNotified() && Moment(model.getRemindTime()).isBefore(capTime)
            }),
            // tap(r => {console.log(r)}),
            mergeMap((model: IReminderModel) => {
                console.log(`New Reminder: ${model.getNote()}`)
                let remind = model.getRemindTime().getTime()
                if (model.getType() === 'appointment') {
                    remind = model.getRemindTime().getTime() + (60 * 60 * 1000)
                }

                const socketSchema: IMessageSchema = {
                    agent: model.getAgent(),
                    id: model.getId(),
                    incidentNo: model.getIncidentNo(),
                    note: model.getNote(),
                    status: model.getStatus(),
                    registration: model.getRegistration(),
                    remindTime: remind,
                    createdAt: model.getCreatedAt().getTime(),
                }
                return this._webSocket.sendMessage(ReminderEvent.NEW_MESSAGE, socketSchema).pipe(
                    map(() => model),
                )
            }),
            // tap(r => {console.log(r)}),
            mergeMap((model: IReminderModel) => {
                model.setNotify(true)
                return this._reminderRepository.update(model)
            }),
            mergeMap(() => {
                const filterDate = new Date()
                return this._reminderRepository.find(filterDate).pipe(
                    filter((model) => {
                        const capTime = Moment().add(1, 'h')
                        return model.getStatus() === 'unread' && Moment(model.getRemindTime()).isBefore(capTime)
                        // return Moment(model.getRemindTime()).isBefore(capTime)
                    }),
                    toArray(),
                    mergeMap((reminders) => {
                        // console.log(`reminders.length :: `, reminders)
                        return this._webSocket.sendMessage(ReminderEvent.MESSAGE_TOTAL, {total: reminders.length})
                    }),
                )
            }),
        ).subscribe()
    }
}
