import { IReminderModel } from './interface/model.interface'
import { Entity } from '../../common/entity'

export class ReminderModel extends Entity implements IReminderModel {
    private _incidentNo: string
    private _registration: string
    private _note: string
    private _remindTime: Date
    private _status: 'read' | 'unread'
    private _agent: string
    private _notified: boolean
    private readonly _createdAt: Date
    private _type: 'manual' | 'appointment'

    constructor() {
        super()
        this._createdAt = new Date()
        this._notified = false
    }

    public getAgent(): string {
        return this._agent
    }

    public getIncidentNo(): string {
        return this._incidentNo
    }

    public getNote(): string {
        return this._note
    }

    public getRegistration(): string {
        return this._registration
    }

    public getRemindTime(): Date {
        return new Date(this._remindTime)
    }

    public getStatus(): 'read' | 'unread' {
        return this._status
    }

    public getCreatedAt(): Date {
        return this._createdAt
    }

    public setAgent(agent: string): void {
        this._agent = agent
    }

    public setIncidentNo(incidentId: string): void {
        this._incidentNo = incidentId
    }

    public setNote(note: string): void {
        this._note = note
    }

    public setRegistration(registration: string): void {
        this._registration = registration
    }

    public setRemindTime(time: Date): void {
        this._remindTime = time
    }

    public setStatus(status: 'read' | 'unread'): void {
        this._status = status
    }

    public isNotified(): boolean {
        return !!this._notified
    }

    public setNotify(notify: boolean): void {
        this._notified = notify
    }

    public getType(): 'manual' | 'appointment' {
        return this._type
    }

    public setType(type: 'manual' | 'appointment'): void {
        this._type = type
    }

}
