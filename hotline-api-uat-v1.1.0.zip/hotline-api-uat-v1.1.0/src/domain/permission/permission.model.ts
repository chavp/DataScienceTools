import { Entity } from '../../common/entity'
import { IPermissionModel } from './interface/model.interface'
import { PermissionEnum } from '../common/interface/permission-enum'
import * as _ from 'lodash'

export class PermissionModel extends Entity implements IPermissionModel {
    private _permission: PermissionEnum[]

    constructor() {
        super()
    }

    public getPermission(): PermissionEnum[] {
        return _.slice(this._permission)
    }

    public setPermission(permission: PermissionEnum[]): void {
        this._permission = permission
    }
}
