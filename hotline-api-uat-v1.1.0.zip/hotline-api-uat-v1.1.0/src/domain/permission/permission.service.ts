import { IPermissionService } from './interface/service.interface'
import { IPermissionRepository } from './interface/repository.interface'
import { IPermissionModel } from './interface/model.interface'
import { Observable } from 'rxjs'
import { PermissionEnum } from '../common/interface/permission-enum'
import {
    map,
    mergeMap,
    throwIfEmpty,
} from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import { PermissionValidate } from '../../controller/rest/validator/permission.validator'

export class PermissionService implements IPermissionService {
    constructor(
        private readonly _permissionRepository: IPermissionRepository,
    ) {

    }

    public getById(id: string): Observable<IPermissionModel> {
        return this._permissionRepository.find({_id: id}).pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `Permission not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
        )
    }

    public getAll(): Observable<IPermissionModel> {
        return this._permissionRepository.find().pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `Permission not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
        )
    }

    public update(id: string, input: PermissionValidate): Observable<boolean> {
        return this.checkPermission(id).pipe(
            map((result: IPermissionModel) => {
                result.setPermission(input.getPermission())

                return result
            }),
            mergeMap((model: IPermissionModel) => {
                return this._permissionRepository.update(model).pipe(
                    map((result: boolean) => {
                        return result
                    }),
                )
            }),
        )
    }

    private checkPermission(id: string): Observable<IPermissionModel> {
        return this._permissionRepository.find({_id: id}).pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `Permission not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
            map((result: IPermissionModel) => {
                return result
            }),
        )
    }
}
