import { IRepository } from '../../../common/interface/repository.interface'
import { IPermissionModel } from './model.interface'
import { Observable } from 'rxjs'

export interface IPermissionRepository extends IRepository<IPermissionModel> {
    find(filter?: any): Observable<IPermissionModel>

    update(model: IPermissionModel): Observable<boolean>
}
