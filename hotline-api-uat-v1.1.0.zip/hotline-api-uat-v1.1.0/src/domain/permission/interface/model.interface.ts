import { PermissionEnum } from '../../common/interface/permission-enum'
import { IEntity } from '../../../common/interface/entity.interface'

export interface IPermissionModel extends IEntity {
    getPermission(): PermissionEnum[]
    setPermission(permission: PermissionEnum[]): void
}
