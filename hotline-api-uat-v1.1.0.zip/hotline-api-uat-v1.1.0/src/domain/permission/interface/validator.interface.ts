import { PermissionEnum } from '../../common/interface/permission-enum'

export interface IPermissionValidator {
    getPermission(permission: PermissionEnum[])
}
