import { Observable } from 'rxjs'
import { IPermissionModel } from './model.interface'
import { PermissionValidate } from '../../../controller/rest/validator/permission.validator'

export interface IPermissionService {
    getById(id: string): Observable<IPermissionModel>

    getAll(): Observable<IPermissionModel>

    update(id: string, input: PermissionValidate): Observable<boolean>
}
