import { AbstractSubscriber } from '../../../../pubsub/abstract.subscriber'
import {
    Observable,
    of,
} from 'rxjs'
import { IRecorderQARepository } from '../../interface/recorderQA.repository.interface'
import { IManagementQAEventSchema } from '../interface/schema.interface'
import { IRecorderQAModel } from '../../interface/recorderQA.model.interface'
import {
    filter,
    flatMap,
    map,
    mergeMap,
} from 'rxjs/operators'
import { IManagementQAModel } from '../../../managementQA/interface/model.interface'
import { IManagementQARepository } from '../../../managementQA/interface/repository.interface'
import { ManagementQAModel } from '../../../managementQA/managementQA.model'
import { QaRecorder } from '../../../../pubsub/event.enum'

export class ManagementQAQuerySubscriber extends AbstractSubscriber {
    constructor(
        private readonly _recorderQARepository: IRecorderQARepository,
    ) {
        super(QaRecorder.RECORDER_QA_MANAGEMENT)
    }

    public onEventPublished(topic: string, data: Buffer): Observable<any> {
        const jsonData: IManagementQAEventSchema = JSON.parse(data.toString('utf8'))
        const newId = jsonData.id

        return this._recorderQARepository.find({'QA.id': newId}).pipe(
            mergeMap((result: IRecorderQAModel) => {
                return this.replaceQA(result.getQA(), jsonData).pipe(
                    map((replaceData) => {
                        result.setQA(replaceData)
                        return this._recorderQARepository.update(result)
                    }),
                )
            }),
        )
    }

    private replaceQA(oldData: IManagementQAModel[], currentData: IManagementQAEventSchema): Observable<IManagementQAModel[]> {
        return of(oldData).pipe(
            flatMap((x) => x),
            filter((result: IManagementQAModel) => result.getId() === currentData.id),
            map((qa: IManagementQAModel) => {
                // qa.setMaxScore(currentData.maxScore)
                qa.setQuestion(currentData.question)
                return oldData
            }),
        )
    }
}

export class SaveManagementQAQuerySubscriber extends AbstractSubscriber {
    constructor(
        private readonly _recorderQARepository: IRecorderQARepository,
        private readonly _managementQARepository: IManagementQARepository,
    ) {
        super(QaRecorder.RECORDER_SAVE_QA_MANAGEMENT)
    }

    public onEventPublished(topic: string, data: Buffer): Observable<any> {
        const jsonData: IManagementQAEventSchema = JSON.parse(data.toString('utf8'))
        const newId = jsonData.id
        const newQuestion = jsonData.question
        const newMaxScore = jsonData.maxScore

        return this._recorderQARepository.find({$where: 'this.QA.length > 0'}).pipe(
            map((result: IRecorderQAModel) => {
                const newQA = new ManagementQAModel()
                newQA.setId(newId)
                newQA.setQuestion(newQuestion)
                newQA.setValue(0)
                newQA.setMaxScore(newMaxScore)

                const qa = result.getQA()
                qa.push(newQA)

                result.setQA(qa)
                return this._recorderQARepository.update(result)
            }),
        )
    }
}
