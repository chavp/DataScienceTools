export interface IManagementQAEventSchema {
    id: string
    question: string
    maxScore: number
}
