export interface IRecorderFilter {
    id?: string,
    startTime?: number,
    endTime?: number,
    source?: string,
    destination?: string,
    callType?: string,
    duration?: number,
    score?: number,
    limit?: number,
    page?: number,
}
