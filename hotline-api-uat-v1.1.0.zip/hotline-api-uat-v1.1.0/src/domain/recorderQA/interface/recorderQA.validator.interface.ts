export interface IUpdateRecorderQAValidator {
    getId(): string

    getComment(): string

    getQA(): IQA[]
}

export interface IQA {
    id: string
    question: string
    score: number
}
