import { IRecorderQAModel } from './recorderQA.model.interface'
import { Observable } from 'rxjs'
import {
    IUpdateRecorderQAValidator,
} from './recorderQA.validator.interface'
import { IRecorderFilter } from './recorder.filter'
import { IRecorderQADto } from '../../../controller/rest/dto/recorderQA.dto'
import { UpdateRecorderQAValidator } from '../../../controller/rest/validator/recorderQA.validator'

export interface IRecorderQAService {
    getById(id: string): Observable<IRecorderQAModel>

    getAll(): Observable<IRecorderQAModel>

    update(id: string, model: UpdateRecorderQAValidator): Observable<IRecorderQAModel>

    find(recorderFilter: IRecorderFilter): Observable<IRecorderQAModel>

    export(sheetName: string, data: IRecorderQADto[]): Observable<any>

    getDecodedAudioFile(recorderId: string): Observable<string>
}
