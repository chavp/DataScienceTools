import { IEntity } from '../../../common/interface/entity.interface'
import { IManagementQAModel } from '../../managementQA/interface/model.interface'

export interface IRecorderQAModel extends IEntity {
    getComment(): string
    setComment(comment: string): void

    getQA(): IManagementQAModel[]
    setQA(QA: IManagementQAModel[]): void

    getCreatedAt(): Date
    setCreatedAt(createdAt: Date): void

    getUpdatedAt(): Date
    setUpdatedAt(updatedAt: Date): void

    getDirection(): string
    setDirection(direction: string): void

    getDuration(): number
    setDuration(duration: number): void

    getExpiryTimestamp(): Date
    setExpiryTimestamp(expiryTimestamp: Date): void

    getFileName(): string
    setFileName(fileName: string): void

    getLocalEntryPoint(): string
    setLocalEntryPoint(localEntryPoint: string): void

    getLocalParty(): string
    setLocalParty(localParty: string): void

    getPortName(): string
    setPortName(portName: string): void

    getRemoteParty(): string
    setRemoteParty(remoteParty: string): void

    getPortId(): string
    setPortId(portId: string): void

    getServiceId(): string
    setServiceId(serviceId: string): void

    getSource(): string
    setSource(direction: number, localParty: string, remoteParty: string): void

    getDestination(): string
    setDestination(direction: number, localParty: string, remoteParty: string): void

    getCallType(): string
    setCallType(direction: number, localParty: string, remoteParty: string): void
}
