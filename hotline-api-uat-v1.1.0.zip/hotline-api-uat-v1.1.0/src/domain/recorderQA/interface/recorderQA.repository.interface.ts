import { Observable } from 'rxjs'
import { IRecorderQAModel } from './recorderQA.model.interface'
import { IRepository } from '../../../common/interface/repository.interface'

export interface IRecorderQARepository extends IRepository<IRecorderQAModel> {
    find(filter?: any): Observable<IRecorderQAModel>

    save(model: IRecorderQAModel): Observable<{ id: string }>

    update(model: IRecorderQAModel): Observable<boolean>
}
