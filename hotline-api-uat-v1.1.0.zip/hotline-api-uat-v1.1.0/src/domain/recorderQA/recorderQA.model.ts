import { Entity } from '../../common/entity'
import { IRecorderQAModel } from './interface/recorderQA.model.interface'
import { IManagementQAModel } from '../managementQA/interface/model.interface'
import * as _ from 'lodash'

export class RecorderQAModel extends Entity implements IRecorderQAModel {
    private _comment: string
    private _QA: IManagementQAModel[]
    private _createdAt: Date
    private _updatedAt: Date
    private _direction: string
    private _duration: number
    private _expiryTimestamp: Date
    private _fileName: string
    private _localEntryPoint: string
    private _localParty: string
    private _portName: string
    private _remoteParty: string
    private _portId: string
    private _serviceId: string
    private _source: string
    private _destination: string
    private _callType: string

    constructor() {
        super()
        this._QA = []
    }

    public getComment(): string {
        return this._comment
    }

    public getQA(): IManagementQAModel[] {
        return this._QA
    }

    public getCreatedAt(): Date {
        if (_.isNil(this._createdAt)) {
            return null
        }
        return new Date(this._createdAt)
    }

    public getUpdatedAt(): Date {
        if (_.isNil(this._updatedAt)) {
            return null
        }
        return new Date(this._updatedAt)
    }

    public setComment(comment: string): void {
        this._comment = comment
    }

    public setQA(QA: IManagementQAModel[]): void {
        this._QA = QA
    }

    public setCreatedAt(createdAt: Date): void {
        this._createdAt = createdAt
    }

    public setUpdatedAt(updatedAt: Date): void {
        this._updatedAt = updatedAt
    }

    public getDirection(): string {
        return this._direction
    }

    public getDuration(): number {
        return this._duration
    }

    public getExpiryTimestamp(): Date {
        if (_.isNil(this._expiryTimestamp)) {
            return null
        }
        return new Date(this._expiryTimestamp)
    }

    public getFileName(): string {
        return this._fileName
    }

    public getLocalEntryPoint(): string {
        return this._localEntryPoint
    }

    public getLocalParty(): string {
        return this._localParty
    }

    public getPortId(): string {
        return this._portId
    }

    public getPortName(): string {
        return this._portName
    }

    public getRemoteParty(): string {
        return this._remoteParty
    }

    public getServiceId(): string {
        return this._serviceId
    }

    public getSource(): string {
        return this._source
    }

    public getDestination(): string {
        return this._destination
    }

    public getCallType(): string {
        return this._callType
    }

    public setDirection(direction: string): void {
        this._direction = direction
    }

    public setDuration(duration: number): void {
        this._duration = duration
    }

    public setExpiryTimestamp(expiryTimestamp: Date): void {
        this._expiryTimestamp = expiryTimestamp
    }

    public setFileName(fileName: string): void {
        this._fileName = fileName
    }

    public setLocalEntryPoint(localEntryPoint: string): void {
        this._localEntryPoint = localEntryPoint
    }

    public setLocalParty(localParty: string): void {
        this._localParty = localParty
    }

    public setPortId(portId: string): void {
        this._portId = portId
    }

    public setPortName(portName: string): void {
        this._portName = portName
    }

    public setRemoteParty(remoteParty: string): void {
        this._remoteParty = remoteParty
    }

    public setServiceId(serviceId: string): void {
        this._serviceId = serviceId
    }

    public setSource(direction: number, localParty: string, remoteParty: string): void {
        if (direction === 1) {
            this._source = localParty
        } else if (direction === 0) {
            this._source = remoteParty
        } else {
            this._source = localParty
        }
    }

    public setDestination(direction: number, localParty: string, remoteParty: string): void {
        if (direction === 1) {
            this._destination = remoteParty
        } else if (direction === 0) {
            this._destination = localParty
        } else {
            this._destination = remoteParty
        }
    }

    public setCallType(direction: number, localParty: string, remoteParty: string): void {
        if (localParty.length <= 7 && remoteParty.length <= 7) {
            this._callType = 'internal'
        } else if (direction === 1) {
            this._callType = 'outgoing'
        } else if (direction === 0) {
            this._callType = 'incoming'
        } else {
            this._callType = 'internal'
        }
    }

}
