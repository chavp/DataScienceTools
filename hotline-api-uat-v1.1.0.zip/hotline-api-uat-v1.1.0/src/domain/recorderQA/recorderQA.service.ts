import { IRecorderQAService } from './interface/recorderQA.service.interface'
import { IRecorderQARepository } from './interface/recorderQA.repository.interface'
import {
    forkJoin,
    from,
    interval,
    Observable,
    of,
} from 'rxjs'
import { IRecorderQAModel } from './interface/recorderQA.model.interface'
import {
    catchError,
    concatMap,
    filter,
    flatMap,
    map,
    mergeMap,
    reduce,
    tap,
    throwIfEmpty,
} from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import * as _ from 'lodash'
import { IRecorderFilter } from './interface/recorder.filter'
import { IRecorderAdapter } from '../../adapter/recorder/interface/recoder.interface'
import { IRecorderQADto } from '../../controller/rest/dto/recorderQA.dto'
import { ManagementQAModel } from '../managementQA/managementQA.model'
import { IManagementQARepository } from '../managementQA/interface/repository.interface'
import { IManagementQAModel } from '../managementQA/interface/model.interface'
import * as xls from 'excel4node'
import moment = require('moment')
import { UpdateRecorderQAValidator } from '../../controller/rest/validator/recorderQA.validator'
import { RecorderQAModel } from './recorderQA.model'
import { IAudioDownloadAdapter } from '../../adapter/audio-download/interface/adapter.interface'
import { IAudioDecoder } from '../../common/interface/audio-decoder.interface'
import { IAudioTranscoder } from '../../common/interface/audio-transcoder'

export class RecorderQAService implements IRecorderQAService {
    constructor(
        private readonly _recorderQARepository: IRecorderQARepository,
        private readonly _recorderAdapter: IRecorderAdapter,
        private readonly _managementQA: IManagementQARepository,
        private readonly _audioDownloadAdapter: IAudioDownloadAdapter,
        private readonly _audioDecoder: IAudioDecoder,
        private readonly _ffmpegTranscoder: IAudioTranscoder,
    ) {
        interval(300000).pipe(
            concatMap(() => {
                console.log('emit recorder')
                return this._recorderAdapter.getRecorder().pipe(
                    // flatMap(x => x),
                    map((res: any) => {
                        // const model = JSON.parse(JSON.stringify(res))
                        const model = JSON.parse(JSON.stringify(res.row))
                        const data = new RecorderQAModel()
                        data.setId(model.id.toString())
                        data.setDirection(model.direction.toString())
                        data.setDuration(_.toNumber(model.duration))
                        data.setExpiryTimestamp(new Date(model.expiryTimestamp))
                        data.setFileName(model.filename)
                        data.setLocalEntryPoint(model.localEntryPoint)
                        data.setLocalParty(model.localParty)
                        data.setPortName(model.portName)
                        data.setRemoteParty(model.remoteParty)
                        data.setCreatedAt(new Date(model.timestamp))
                        data.setPortId(_.get(model, 'port_id', ''))
                        data.setServiceId(_.get(model, 'service_id', ''))
                        data.setSource(model.direction, model.localParty, model.remoteParty)
                        data.setDestination(model.direction, model.localParty, model.remoteParty)
                        data.setCallType(model.direction, model.localParty, model.remoteParty)
                        return data
                    }),
                    mergeMap((model: IRecorderQAModel) => {
                        return this._recorderQARepository.find({_id: model.getId()}).pipe(
                            throwIfEmpty(() => {
                                throw new HttpException('Cannot find recorder', HttpStatus.NOT_FOUND)
                            }),
                            catchError(() => {
                                return this._recorderQARepository.save(model)
                            }),
                        )
                    }),
                )
            }),
        ).subscribe()
    }

    public getAll(): Observable<IRecorderQAModel> {
        return this._recorderQARepository.find().pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `recorder not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
        )
    }

    public getById(id: string): Observable<IRecorderQAModel> {
        const query = {
            _id: id,
        }
        return this._recorderQARepository.find(query).pipe(
            map(result => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `recorder not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }
                return result
            }),
        )
    }

    public update(id: string, input: UpdateRecorderQAValidator): Observable<IRecorderQAModel> {
        return this._recorderQARepository.find({_id: id}).pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `Recorder id: ${id} not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
            map((result) => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `recorder not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }
                return result
            }),
            map((recorderQA: IRecorderQAModel) => {
                if (!_.isNil(input.getComment())) {
                    recorderQA.setComment(input.getComment())
                }
                recorderQA.setUpdatedAt(new Date())
                return recorderQA
            }),
            mergeMap((recorderQA: IRecorderQAModel) => {
                const inputQA = input.getQA()
                const QA = []
                return of(inputQA).pipe(
                    flatMap((x) => x),
                    mergeMap((qa) => {
                        return this.checkQA(qa.id).pipe(
                            mergeMap((result: IManagementQAModel) => {
                                if (_.toNumber(qa.score) > result.getMaxScore()) {
                                    throw new HttpException(
                                        `Question ${result.getId()}, score must be less than maxScore(${result.getMaxScore()})`,
                                        HttpStatus.BAD_REQUEST,
                                    )
                                }

                                const modelManagement = new ManagementQAModel()
                                modelManagement.setId(result.getId())
                                modelManagement.setQuestion(result.getQuestion())
                                modelManagement.setMaxScore(result.getMaxScore())

                                modelManagement.setValue(qa.score)

                                QA.push(modelManagement)
                                return forkJoin([
                                    of(QA),
                                    of(recorderQA),
                                ])
                            }),
                        )
                    }),
                )
            }),
            map((result: any[]) => {
                const qa = result[0]
                const recorderQA = result[1] as IRecorderQAModel

                recorderQA.setQA(qa)
                return recorderQA
            }),
            mergeMap((recorderQA: IRecorderQAModel) => {
                return this._recorderQARepository.update(recorderQA).pipe(
                    map((result) => {
                        if (result === true) {
                            return recorderQA
                        }
                    }),
                )
            }),
        )
    }

    private checkQA(id: string): Observable<IManagementQAModel> {
        return this._managementQA.find({_id: id}).pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `Recorder id: ${id} not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
            map((result: IManagementQAModel) => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `QA id: ${id} not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }
                return result
            }),
        )
    }

    public find(recorderFilter: IRecorderFilter): Observable<IRecorderQAModel> {
        const andFilter = []

        if ((!_.isNil(recorderFilter.startTime)) && (!_.isNil(recorderFilter.endTime))) {
            andFilter.push({
                createdAt: {
                    $gte: new Date(recorderFilter.startTime),
                    $lte: new Date(recorderFilter.endTime),
                },
            })
        }

        if (!_.isNil(recorderFilter.id)) {
            const regExp = new RegExp(recorderFilter.id)
            andFilter.push({
                _id: regExp,
            })
        }

        if (!_.isNil(recorderFilter.source)) {
            const regExp = new RegExp(recorderFilter.source)
            andFilter.push({
                source: regExp,
            })
        }

        if (!_.isNil(recorderFilter.destination)) {
            const regExp = new RegExp(recorderFilter.destination)
            andFilter.push({
                destination: regExp,
            })
        }

        if (!_.isNil(recorderFilter.callType)) {
            andFilter.push({
                callType: recorderFilter.callType,
            })
        }

        if (!_.isNil(recorderFilter.duration)) {
            andFilter.push({
                duration: {
                    $gte: recorderFilter.duration,
                },
            })
        }

        andFilter.push({
            $expr: {
                $eq: [{$strLenCP: '$localParty'}, 4],
            },
        })

        andFilter.push({
            $or: [
                {localParty: /^18/},
                {localParty: '8333'},
            ],
        })

        // const limitFilter = {
        //     limit: null,
        //     page: null,
        // }
        // if (!_.isNil(recorderFilter.limit)) {
        //     limitFilter.limit = recorderFilter.limit
        // }
        // if (!_.isNil(recorderFilter.page)) {
        //     limitFilter.page = recorderFilter.page
        // }

        let mongoFilter = {}
        mongoFilter = {
            $and: andFilter,
        }

        return this._recorderQARepository.find(mongoFilter).pipe(
            mergeMap((result: IRecorderQAModel) => {
                if (!_.isNil(recorderFilter.score)) {
                    let total = 0
                    const qa = result.getQA()
                    _.forEach(qa, (o) => {
                        const score = o.getValue() || 0
                        total = total + score
                    })

                    return of(result).pipe(
                        filter(() => total >= recorderFilter.score),
                        map((data: IRecorderQAModel) => {
                            return data
                        }),
                    )
                }
                return of(result)
            }),
        )
    }

    public export(sheetName: string, data: IRecorderQADto[]): Observable<any> {
        return from(data).pipe(
            reduce((content: any[], record: IRecorderQADto) => {
                let totalScore = ''
                if (!_.isNil(record.totalScore)) {
                    totalScore = record.totalScore.toString()
                }

                let duration = ''
                if (!_.isNil(record.duration)) {
                    duration = record.duration.toString()
                }

                content.push({
                    'ID': record.id || '',
                    'Call Date': moment(new Date(record.createdAt)).format('DD/MM/YYYY HH:mm') || '',
                    'Source': record.source || '',
                    'Destination': record.destination || '',
                    'Call Type': record.callType || '',
                    'Duration': duration,
                    'TotalScore': totalScore,
                    'Comment': record.comment || '',
                })

                return content
            }, []),
            map((content: any[]) => {
                const workbook = new xls.Workbook()
                const worksheet = workbook.addWorksheet(sheetName)
                const headers = RecorderQAService._getContentKeys(_.last(content))

                for (let col = 1, index = 0; col <= _.size(headers); col++, index++) {
                    worksheet.cell(1, col).string(headers[index])
                }

                for (let row = 2, recordRow = 0; row <= (_.size(content) + 1); row++, recordRow++) {
                    for (let col = 1, recordCol = 0; col <= _.size(headers); col++, recordCol++) {
                        const x = recordRow
                        const y = headers[recordCol]
                        worksheet.cell(row, col).string(content[x][y])
                    }
                }

                return workbook
            }),
        )
    }

    private static _getContentKeys(record) {
        return _.keys(record)
    }

    public getDecodedAudioFile(recorderId: string): Observable<string> {
        const query = {
            _id: recorderId,
        }
        //
        // const fname = 'e_110503_1806.wav'
        //
        // return this._audioDownloadAdapter.getFile(`/${fname}`).pipe(
        //     mergeMap((buffer: Buffer) => {
        //         return this._audioDecoder.decodeBuffer(buffer)
        //     }),
        //     mergeMap(({decodedFile}: { decodedFile: string }) => {
        //         return this._ffmpegTranscoder.transcode(decodedFile, 'mp3')
        //     }),
        // )

        return this._recorderQARepository.find(query).pipe(
            tap(result => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `recorder not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }
            }),
            mergeMap(model => {
                let fileName = model.getFileName()
                const split = fileName.split('/')
                const last = split.pop()
                split.push(`e_${last}`)
                fileName = _.join(split, '/')
                return this._audioDownloadAdapter.getFile(`/${fileName}`)
            }),
            mergeMap((buffer: Buffer) => {
                return this._audioDecoder.decodeBuffer(buffer)
            }),
            mergeMap(({decodedFile}: { decodedFile: string }) => {
                return this._ffmpegTranscoder.transcode(decodedFile, 'mp3')
            }),
        )
    }
}
