import {ICiscoDashboardService} from './interface/service.interface'
import {IOdbcInterface} from '../../adapter/odbc/interface/odbc.interface'
import {Observable, of} from 'rxjs'
import {flatMap, map, mergeMap, tap} from 'rxjs/operators'
import * as moment from 'moment'
import {IConfig} from '../../common/interface/config.interface'
import * as _ from 'lodash'

export class CiscoDashboardService implements ICiscoDashboardService {
    constructor(
        private readonly _config: IConfig,
        private readonly _odbcAdapter: IOdbcInterface,
    ) {
    }

    public getAgent(): Observable<any> {
        const data = {
            th: {
                name : this._config.CiscoSkill.th.name.split(','),
                keyword : this._config.CiscoSkill.th.keyword.split(','),
            },
            en: {
                name : this._config.CiscoSkill.en.name.split(','),
                keyword : this._config.CiscoSkill.en.keyword.split(','),
            },
        }

        const result = {
            total: 0,
            staff_th: 0,
            staff_en: 0,
            avail_th: 0,
            avail_en: 0,
            aux: [],
            acw: [],
            agent: [],
        }

        let state = ''
        let reasoncode = ''
        let skillth = 0
        let skillen = 0
        let allskill = ''
        return this._odbcAdapter.getAgent(this._config.CiscoSkill.team).pipe(
            mergeMap( agents1 => {
                return this._odbcAdapter.getAgentQueue(this._config.CiscoSkill.team).pipe(
                    map( agents2 => {
                        return ({agents1, agents2})
                    }),
                )
            }),
            map( ({agents1, agents2}) => {
                agents1.forEach((agent1) => {
                    if (agent1.eventtype !== 7) {
                        state = ''
                        reasoncode = ''
                        skillth = 0
                        skillen = 0
                        allskill = ''
                        result.total = result.total + 1

                        // status
                        switch (agent1.eventtype) {
                            case 2:
                                state = 'Notready'
                                result.aux.push(agent1.resourceloginid)
                                switch (agent1.reasoncode) {
                                    case 1:
                                        reasoncode = 'Work'
                                        break
                                    case 2:
                                        reasoncode = 'Meeting'
                                        break
                                    case 3:
                                        reasoncode = 'Training'
                                        break
                                    case 4:
                                        reasoncode = 'Toilet'
                                        break
                                    case 32761:
                                        reasoncode = 'Non ACD'
                                        break
                                    case 32762:
                                        reasoncode = 'Calling'
                                        break
                                    case 32763:
                                        reasoncode = 'Not Response'
                                        break
                                    default:
                                        reasoncode = agent1.reasoncode
                                        break
                                }
                                break
                            case 3:
                                state = 'Ready'
                                break
                            case 4:
                                state = 'Reserved'
                                break
                            case 5:
                                state = 'Talking'
                                break
                            case 6:
                                state = 'Wrapup'
                                result.acw.push(agent1.resourceloginid)
                                break
                            default:
                                state = ''
                                break
                        }

                        // time
                        const now = moment(new Date())
                        const eventTime = moment(agent1.eventdatetime)
                        // const diffM = moment.duration(now.diff(eventTime)).asMinutes
                        const diff = moment.duration(now.diff(eventTime)).as('seconds')
                        const mm = Math.floor(((diff / (60 * 60)) - 7) * 60)
                        const ss = (('0' + Math.floor(diff % 60)).slice(-2))
                        const agentTime = mm + ':' + ss

                        agents2.forEach((agent2) => {
                            if (agent2.resourceloginid === agent1.resourceloginid) {
                                if (data.th.name.indexOf('CSQ_' + agent2.skillname) >= 0) {
                                    agent2.skillname = data.th.keyword[data.th.name.indexOf('CSQ_' + agent2.skillname)]
                                    skillth = 1
                                } else if (data.en.name.indexOf('CSQ_' + agent2.skillname) >= 0) {
                                    agent2.skillname = data.en.keyword[data.en.name.indexOf('CSQ_' + agent2.skillname)]
                                    skillen = 1
                                }
                                allskill = allskill + ',' + agent2.skillname
                            }
                        })

                        allskill = allskill.substring(1, allskill.length)

                        if (skillth === 1) {
                            result.staff_th = result.staff_th + 1
                            if (state === 'Ready') { result.avail_th = result.avail_th + 1 }
                        }
                        if (skillen === 1) {
                            result.staff_en = result.staff_en + 1
                            if (state === 'Ready') { result.avail_en = result.avail_en + 1 }
                        }

                        result.agent.push({
                            id: result.total.toString(),
                            agent_code: agent1.resourceloginid,
                            name: agent1.resourcename,
                            status: state,
                            reason: reasoncode,
                            time: agentTime,
                            skill: allskill,
                        })
                    }
                })

                return result
            }),
        )
    }

    public getQueue(): Observable < any > {
        const filter = {
            th: this._config.CiscoSkill.th.name.split(','),
            en: this._config.CiscoSkill.en.name.split(','),
        }

        const result = {
            th: {
                count: 0,
                callswaiting: 0,
                abandon: 0,
                inbound: 0,
                totalcalls: 0,
                oldesttime: 0,
                avgtalktime: 0,
            },
            en: {
                count: 0,
                callswaiting: 0,
                abandon: 0,
                inbound: 0,
                totalcalls: 0,
                oldesttime: 0,
                avgtalktime: 0,
            },
        }

        return this._odbcAdapter.getQueue().pipe(
            flatMap(x => x),
            map((model: any) => {
                if (filter.th.includes(model.csqname)) {
                    result.th.count = result.th.count + 1,
                        result.th.callswaiting = result.th.callswaiting + _.toNumber(model.callswaiting),
                        result.th.abandon = result.th.abandon + _.toNumber(model.callsabandoned),
                        result.th.inbound = result.th.inbound + _.toNumber(model.callshandled),
                        result.th.totalcalls = result.th.totalcalls + _.toNumber(model.callsabandoned) + _.toNumber(model.callshandled),
                        result.th.avgtalktime = result.th.avgtalktime + _.toNumber(model.avgtalkduration)
                    if (result.th.oldesttime < _.toNumber(model.oldestcontact)) { result.th.oldesttime = _.toNumber(model.oldestcontact) }
                } else if (filter.en.includes(model.csqname)) {
                    result.en.count = result.en.count + 1,
                        result.en.callswaiting = result.en.callswaiting + _.toNumber(model.callswaiting)
                    result.en.abandon = result.en.abandon + _.toNumber(model.callsabandoned)
                    result.en.inbound = result.en.inbound + _.toNumber(model.callshandled)
                    result.en.totalcalls = result.en.totalcalls + _.toNumber(model.callsabandoned) + _.toNumber(model.callshandled)
                    result.en.avgtalktime = result.en.avgtalktime + _.toNumber(model.avgtalkduration)
                    if (result.en.oldesttime < _.toNumber(model.oldestcontact)) { result.en.oldesttime = _.toNumber(model.oldestcontact) }
                }
                return result
            }),
            mergeMap(models => {
                return of(models)
            }),
        )
    }
}
