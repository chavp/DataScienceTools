import {Observable} from 'rxjs'

export interface ICiscoDashboardService {
    getAgent(): Observable<any>

    getQueue(): Observable<any>
}
