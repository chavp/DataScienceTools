import { IServiceAreaSchema } from '../../interface/model.interface'

export interface IUpdateSurveyorEventSchema {
    surveyorId: string
    address: string
    companyName: string
    companyPhone: string
    groupName: string
    partnerCompany: string
    serviceArea: Map<string, IServiceAreaSchema>
}
