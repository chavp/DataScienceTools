import { AbstractDomainEvent } from '../../../../pubsub/abstract.domain-event'
import { IUpdateSurveyorEventSchema } from '../interface/schema.interface'
import { ISurveyorModel } from '../../interface/model.interface'

export class SurveyorEvent extends AbstractDomainEvent<ISurveyorModel, IUpdateSurveyorEventSchema> {

    constructor(topic: string, data: ISurveyorModel) {
        super(topic, data)
    }

    public serialize(model: ISurveyorModel): IUpdateSurveyorEventSchema {
        return {
            surveyorId: model.getId(),
            address: model.getAddress(),
            companyName: model.getName(),
            companyPhone: model.getPhone(),
            groupName: model.getGroupName(),
            partnerCompany: model.getPartnerCompany(),
            serviceArea: model.getServiceArea(),
        }
    }
}
