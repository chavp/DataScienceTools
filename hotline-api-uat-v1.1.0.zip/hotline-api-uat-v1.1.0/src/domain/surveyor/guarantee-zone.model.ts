import { Entity } from '../../common/entity'
import { IGuaranteeZoneModel } from './interface/model.interface'

export class GuaranteeZoneModel extends Entity implements IGuaranteeZoneModel {

    private readonly _provinceEN: string
    private readonly _provinceTH: string
    private readonly _districtEN: string
    private readonly _districtTH: string
    private _guaranteeMinute: number

    constructor() {
        super()
    }

    public getDistrictEN(): string {
        return this._districtEN
    }

    public getDistrictTH(): string {
        return this._districtTH
    }

    public getGuaranteeMinute(): number {
        return this._guaranteeMinute
    }

    public getProvinceEN(): string {
        return this._provinceEN
    }

    public getProvinceTH(): string {
        return this._provinceTH
    }

    public setGuaranteeMinute(guarantee: number): void {
        this._guaranteeMinute = guarantee
    }

}
