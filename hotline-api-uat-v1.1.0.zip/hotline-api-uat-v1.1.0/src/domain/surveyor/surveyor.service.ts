import {
    ISurveyorInput,
    ISurveyorService,
} from './interface/service.interface'
import { ISurveyorModel } from './interface/model.interface'
import {
    forkJoin,
    from,
    Observable,
    of,
} from 'rxjs'
import { ISurveyorRepository } from './interface/repository.interface'
import {
    catchError,
    concatMap,
    map,
    mergeMap,
    toArray,
} from 'rxjs/operators'
import * as _ from 'lodash'
import { SurveyorModel } from './surveyor.model'
import { IExcelService } from '../common/interface/excel.service.interface'
import {
    IMessageModel,
    IMessageRepository,
} from '../message/interface'
import { ISurveyorLineRepository } from '../surveyor-line/interface/repository.interface'

export class SurveyorService implements ISurveyorService {
    constructor(
        private readonly _surveyorRepository: ISurveyorRepository,
        private readonly _surveyorExcelService: IExcelService<ISurveyorInput>,
        private readonly _messageRepository: IMessageRepository,
        private readonly _surveyorLineRepository: ISurveyorLineRepository,
    ) {

    }

    public listByLocation(province: string, district: string): Observable<ISurveyorModel> {
        return this._surveyorRepository.listByLocation({
            province,
            district,
        }).pipe(
            catchError(() => {
                return this._surveyorRepository.list()
            }),
        )
    }

    public listAll(): Observable<ISurveyorModel> {
        return this._surveyorRepository.list(1, 0)
    }

    public uploadAndReplace(buffer: Buffer): Observable<any> {

        const surveyorsInputs = this._surveyorExcelService
            .parse(buffer)

        const existingSurveyors$ = this._surveyorRepository
            .list(0, 0)
            .pipe(
                toArray(),
            )

        const saveSurveyors = (surveyors: ISurveyorModel[]) => {
            return from(surveyors)
                .pipe(
                    mergeMap(surveyor => this._surveyorRepository.upsert(surveyor)),
                    toArray(),
                )
        }

        const removeNotExistsSurveyors = (surveyorsToUpsertIds: string[]) => {
            const surveyorsIdToRemove$ = this._surveyorRepository.list(1, 0)
                .pipe(
                    map(surveyor => surveyor.getId()),
                    toArray(),
                    map(surveyorIds => {
                        return _.difference<string>(surveyorIds, surveyorsToUpsertIds)
                    }),
                )

            return surveyorsIdToRemove$
                .pipe(
                    mergeMap(surveyorIds => from(surveyorIds)),
                    concatMap(surveyorId => this._surveyorRepository.removeById(surveyorId)),
                    toArray(),
                )
        }

        return removeNotExistsSurveyors(surveyorsInputs.map(surveyorsInput => surveyorsInput.clientPSEAId))
            .pipe(
                concatMap(() => {
                    return forkJoin(
                        of(surveyorsInputs),
                        existingSurveyors$,
                    )
                }),
                map(([ inputs, existingSurveyors ]) => {
                    const existingSurveyorMap = new Map<string, ISurveyorModel>()
                    existingSurveyors.forEach(surveyor => existingSurveyorMap.set(surveyor.getId(), surveyor))
                    return inputs.map(surveyorsInput => {
                        const targetModel = existingSurveyorMap.has(surveyorsInput.clientPSEAId) ?
                            existingSurveyorMap.get(surveyorsInput.clientPSEAId) :
                            new SurveyorModel() as unknown as ISurveyorModel

                        targetModel.setId(surveyorsInput.clientPSEAId)
                        targetModel.setRemark(surveyorsInput.remark)
                        targetModel.setCompanyInitial(surveyorsInput.companyInitial)
                        targetModel.setOwnerName(surveyorsInput.ownerName)
                        targetModel.setOwnerPhone(surveyorsInput.ownerPhone)
                        targetModel.setAddress(surveyorsInput.address)
                        targetModel.setName(surveyorsInput.companyName)
                        targetModel.setPhone(surveyorsInput.companyPhone)
                        targetModel.setCondition(surveyorsInput.condition)
                        targetModel.setServiceTypeDesc(surveyorsInput.serviceTypeDesc)

                        surveyorsInput.serviceArea.forEach(area => {
                            targetModel.addServiceArea(area)
                        })

                        return targetModel
                    })
                }),
                concatMap(surveyors => saveSurveyors(surveyors)),
            )
    }

    public getLatestMessage(surveyorId: string, max: number = 100): Observable<IMessageModel> {
        return this._surveyorLineRepository.getBySurveyorId(surveyorId).pipe(
            mergeMap(surveyor => {
                return this._messageRepository.listLatestFromGroupId(surveyor.getId(), max)
            }),
        )

    }

}
