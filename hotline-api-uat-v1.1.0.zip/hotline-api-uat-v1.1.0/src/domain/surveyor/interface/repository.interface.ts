import { IRepository } from '../../../common/interface/repository.interface'
import {
    IGuaranteeZoneModel,
    ISurveyorModel,
} from './model.interface'
import { Observable } from 'rxjs'

export interface ISurveyorFilterSchema {
    province?: string
    district?: string
}

export interface ISurveyorRepository extends IRepository<ISurveyorModel> {
    getById(id: string): Observable<ISurveyorModel>

    listByLocation(filter: ISurveyorFilterSchema): Observable<ISurveyorModel>

    update(model: ISurveyorModel): Observable<boolean>

    upsert(model: ISurveyorModel): Observable<boolean>

    getByAssignJob(jobId: string): Observable<ISurveyorModel>

    removeById(id: string): Observable<boolean>
}

export interface IGuaranteeZoneRepository extends IRepository<IGuaranteeZoneModel> {
    getById(id: string): Observable<IGuaranteeZoneModel>

    listByProvinceTH(provinceNameTH: string): Observable<IGuaranteeZoneModel>

    listByProvinceEN(provinceNameEN: string): Observable<IGuaranteeZoneModel>
}
