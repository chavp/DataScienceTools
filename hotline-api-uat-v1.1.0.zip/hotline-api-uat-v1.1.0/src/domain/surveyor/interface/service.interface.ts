import { Observable } from 'rxjs'
import { ISurveyorModel } from './model.interface'
import { IMessageModel } from '../../message/interface'

export interface ISurveyorService {
    listByLocation(province: string, district: string): Observable<ISurveyorModel>
    listAll(): Observable<ISurveyorModel>
    getLatestMessage(surveyorId: string, max: number): Observable<IMessageModel>
    uploadAndReplace(buffer: Buffer): Observable<any>
}

export interface ISurveyorServiceAreaInput {
    province: string
    district: string[]
}

export interface ISurveyorInput {
    clientPSEAId: string,
    serviceTypeDesc: string
    condition: string
    serviceArea: ISurveyorServiceAreaInput[],
    companyName: string
    companyPhone: string
    ownerName: string
    ownerPhone: string
    remark: string
    address: string
    companyInitial: string
}
