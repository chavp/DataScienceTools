import { IEntity } from '../../../common/interface/entity.interface'

export interface ISurveyorModel extends IEntity {
    getName(): string

    getCompanyInitial(): string

    setCompanyInitial(initial: string): void

    getOwnerName(): string

    setOwnerName(ownerName: string): void

    getPhone(): string

    getOwnerPhone(): string

    setOwnerPhone(phone: string): void

    getRemark(): string

    setRemark(remark: string): void

    getServiceArea(): Map<string, IServiceAreaSchema>

    getAssignedJob(): string[]

    getClosedJobs(): string[]

    addAssignJob(id: string): void

    addCloseJob(jobId: string): void

    removeAssignJob(jobId: string): void

    setCondition(condition: string): void

    addServiceArea(serviceArea: IServiceAreaSchema): void

    setServiceTypeDesc(serviceTypeDesc: string): void

    setPhone(phone: string): void

    setName(name: string): void

    getAddress(): string

    setAddress(address: string): void

    getPartnerCompany(): string

    getGroupName(): string
}

export interface IServiceAreaSchema {
    province: string
    district: string[]
}

export interface IGuaranteeZoneModel extends IEntity {
    getProvinceTH(): string

    getDistrictTH(): string

    getProvinceEN(): string

    getDistrictEN(): string

    getGuaranteeMinute(): number

    setGuaranteeMinute(guarantee: number): void
}
