import { ExcelService } from '../../common/excel.service'
import { ISurveyorInput, ISurveyorServiceAreaInput } from '../interface/service.interface'
import * as _ from 'lodash'

export class SurveyorExcelService extends ExcelService<ISurveyorInput> {
    constructor() {
        super()
    }

    public serialize(rowObject: any): ISurveyorInput {

        const districtSeparator = /[;\\n]/g

        const getCleanedValue = (target: any, fieldName: string) => {
            return target[fieldName] ? target[fieldName].toString().trim() : ''
        }

        const splitAndCleanValue = (stringValue: string, separatorRegExp: RegExp) => {
            return stringValue.split(separatorRegExp).map(term => term.trim())
        }

        return {
            clientPSEAId: getCleanedValue(rowObject, 'client-psea-id'),
            serviceTypeDesc: getCleanedValue(rowObject, 'service-type-desc'),
            condition: getCleanedValue(rowObject, 'condition'),
            serviceArea: [
                {
                    province: getCleanedValue(rowObject, 'service-area-province'),
                    district: splitAndCleanValue(getCleanedValue(rowObject, 'service-area-district'), districtSeparator),
                },
            ],
            companyName: getCleanedValue(rowObject, 'company-name'),
            companyPhone: getCleanedValue(rowObject, 'company-phone'),
            ownerName: getCleanedValue(rowObject, 'owner-name'),
            ownerPhone: getCleanedValue(rowObject, 'owner-phone'),
            remark: getCleanedValue(rowObject, 'remark'),
            address: getCleanedValue(rowObject, 'address'),
            companyInitial: getCleanedValue(rowObject, 'company-initial'),
        }
    }

    public batchSerialize(rows: ISurveyorInput[]): ISurveyorInput[] {
        const mergeServiceArea = (originalValues: ISurveyorServiceAreaInput[], targetValues: ISurveyorServiceAreaInput[]) => {
            const originMap = new Map<string, ISurveyorServiceAreaInput>()
            originalValues.forEach(val => originMap.set(val.province, val))
            targetValues.forEach(value => {
                const mergedDistrict = originMap.has(value.province) ?
                    originMap.get(value.province).district.concat(value.district) :
                    value.district
                const deduplicateDistricts = _.uniq(mergedDistrict)
                originMap.set(value.province, {province: value.province, district: deduplicateDistricts})
            })
            return Array.from(originMap.values())
        }

        const map = new Map<string, ISurveyorInput>()
        rows.forEach(row => {
            if (map.has(row.clientPSEAId)) {
                const previousRow = map.get(row.clientPSEAId)
                previousRow.serviceArea = mergeServiceArea(previousRow.serviceArea, row.serviceArea)
                map.set(row.clientPSEAId, previousRow)
            } else {
                map.set(row.clientPSEAId, row)
            }
        })

        return Array.from(map.values())
    }
}
