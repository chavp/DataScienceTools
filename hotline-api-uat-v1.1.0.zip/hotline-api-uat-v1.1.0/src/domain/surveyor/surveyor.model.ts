import * as _ from 'lodash'
import { Entity } from '../../common/entity'
import {
    IServiceAreaSchema,
    ISurveyorModel,
} from './interface/model.interface'

export class SurveyorModel extends Entity implements ISurveyorModel {
    private _name: string
    private readonly _partnerCompany: string
    private _serviceTypeDesc: string
    private _condition: string
    private _phone: string
    private _address: string
    private _ownerName: string
    private _ownerPhone: string
    private _remark: string
    private readonly _groupName: string
    private _companyInitial: string
    private readonly _serviceArea: Map<string, IServiceAreaSchema>
    private readonly _assignedJob: string[]
    private readonly _closedJob: string[]

    constructor() {
        super()
        this._serviceArea = new Map<string, IServiceAreaSchema>()
        this._closedJob = []
        this._assignedJob = []
    }

    public addCloseJob(jobId: string): void {
        this.assertTrue(!_.includes(this._closedJob, jobId), 'Cannot add duplicated job Id')
        _.remove(this._assignedJob, item => item === jobId)
        this._closedJob.push(jobId)
    }

    public getClosedJobs(): string[] {
        return _.slice(this._closedJob)
    }

    public getAssignedJob(): string[] {
        return _.slice(this._assignedJob)
    }

    public getName(): string {
        return this._name
    }

    public getPhone(): string {
        return this._phone
    }

    public getServiceArea(): Map<string, IServiceAreaSchema> {
        return new Map(this._serviceArea)
    }

    public addAssignJob(id: string): void {
        this.assertTrue(!_.includes(this._assignedJob, id), 'Cannot add duplicated job Id')
        this._assignedJob.push(id)
    }

    public removeAssignJob(jobId: string): void {
        _.remove(this._assignedJob, item => item === jobId)
    }

    public getCompanyInitial(): string {
        return this._companyInitial
    }

    public setCompanyInitial(initial: string): void {
        this._companyInitial = initial
    }

    public getOwnerName(): string {
        return this._ownerName
    }

    public setOwnerName(ownerName: string): void {
        this._ownerName = ownerName
    }

    public getOwnerPhone(): string {
        return this._ownerName
    }

    public setOwnerPhone(phone: string): void {
        this._ownerPhone = phone
    }

    public getRemark(): string {
        return this._remark
    }

    public setRemark(remark: string): void {
        this._remark = remark
    }

    public setCondition(condition: string): void {
        this._condition = condition
    }

    public addServiceArea(serviceArea: IServiceAreaSchema): void {
        this._serviceArea.set(serviceArea.province, serviceArea)
    }

    public setServiceTypeDesc(serviceTypeDesc: string): void {
        this._serviceTypeDesc = serviceTypeDesc
    }

    public setName(name: string): void {
        this._name = name
    }

    public setPhone(phone: string): void {
        this._phone = phone
    }

    public getAddress(): string {
        return this._address
    }

    public setAddress(address: string): void {
        this._address = address
    }

    public getPartnerCompany(): string {
        return this._partnerCompany
    }

    public getGroupName(): string {
        return this._groupName
    }
}
