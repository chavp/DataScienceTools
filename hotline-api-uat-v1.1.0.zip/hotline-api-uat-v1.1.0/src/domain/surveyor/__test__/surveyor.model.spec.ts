import { plainToClass } from 'class-transformer'
import { SurveyorModel } from '../surveyor.model'

describe('Surveyor Model', () => {

    let model: SurveyorModel = null

    beforeEach(() => {
        model = plainToClass(SurveyorModel, {
            _id: 'something',
            _name: 'name',
            _assignedJob: ['AAAA'],
            _closedJob: [],
        })
    })

    it('should contain a job', () => {
        expect(model.getAssignedJob().length).toEqual(1)
    })
    it('should be able to remove assigned job', () => {
        model.removeAssignJob('AAAA')
        expect(model.getAssignedJob().length).toEqual(0)
    })

})
