import { AbstractDomainEvent } from '../../../../pubsub/abstract.domain-event'
import { IMessageModel } from '../../interface'
import {
    IMessageTextEventSchema,
} from '../schema/message-text.schema'
import { MessagingEvent } from '../../../../pubsub/event.enum'

export class MessageSendIndividualMessageEvent extends AbstractDomainEvent<IMessageModel, IMessageTextEventSchema> {
    constructor(data: IMessageModel) {
        super(MessagingEvent.MESSAGE_AGENT_SENT_TO_USER, data)
    }

    public serialize(model: IMessageModel): IMessageTextEventSchema {
        // TODO implement this
        return {
            group: '',
            id: '',
            incidentNo: '',
            sender: '',
            senderName: '',
            text: '',
            timeStamp: 0,

        }
    }

}
