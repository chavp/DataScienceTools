import { AbstractSubscriber } from '../../../../pubsub/abstract.subscriber'
import {
    IWebSocketAdapter,
    ReminderEvent,
} from '../../../../adapter/notification/interfaces/socket.interface'
import {
    DomainEvent,
    LineEvent,
} from '../../../../pubsub/event.enum'
import { Observable } from 'rxjs'
import { ILineProfileEventSchema } from '../../../line/pubsub/interface/line-profile.schema'

export class LineUserFollowedSubscriber extends AbstractSubscriber {
    constructor(
        private readonly _socketAdapter: IWebSocketAdapter,
    ) {
        super(LineEvent.LINE_BOT_FOLLOWED)
    }

    public onEventPublished(topic: DomainEvent, buffer: Buffer): Observable<any> {
        const payload: ILineProfileEventSchema = JSON.parse(buffer.toString('utf8'))
        const data = {
            lineId: payload.lineId,
            pictureUrl: payload.pictureUrl,
            phone: payload.phone,
            name: payload.name,
        }

        return this._socketAdapter.sendMessage(ReminderEvent.LINE_BOT_FOLLOWED, data)
    }

}
