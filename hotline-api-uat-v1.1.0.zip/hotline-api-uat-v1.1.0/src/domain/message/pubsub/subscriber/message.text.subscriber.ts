import { AbstractSubscriber } from '../../../../pubsub/abstract.subscriber'
import {
    DomainEvent,
    LineEvent,
} from '../../../../pubsub/event.enum'
import {
    iif,
    Observable,
    of,
} from 'rxjs'
import { IMessageRepository } from '../../interface'
import {
    concatMap,
    map,
    mergeMap,
} from 'rxjs/operators'
import { IReceiveTextEventSchema } from '../../../line/pubsub/interface/receiveTextEvent.schema'
import { MessageModel } from '../../message.model'
import {
    IWebSocketAdapter,
    ReminderEvent,
} from '../../../../adapter/notification/interfaces/socket.interface'
import * as _ from 'lodash'
import { ContentTypeEnum } from '../../../../repository/message/message.schema'
import {
    IDirectMessageSchema,
    IGroupMessageSchema,
} from '../schema/message-text.schema'

export class MessageTextSubscriber extends AbstractSubscriber {
    constructor(
        private readonly _messageRepository: IMessageRepository,
        private readonly _socketAdapter: IWebSocketAdapter,
    ) {
        super(LineEvent.LINE_RECEIVE_TEXT)
    }

    public onEventPublished(topic: DomainEvent, buffer: Buffer): Observable<any> {
        const payload: IReceiveTextEventSchema = JSON.parse(buffer.toString('utf8'))
        const content = {
            id: payload.id,
            text: payload.text,
        }

        const directSocketSchema: IDirectMessageSchema = {
            id: payload.lineId,
            displayName: payload.senderName,
            picPath: payload.picPath,
            incidentNo: payload.incidentNo,
            isRegister: payload.isRegister,
            message: [ {
                id: payload.id,
                sender: !_.isNil(payload.sender) ? 'user' : 'agent',
                senderName: payload.senderName,
                receiver: payload.receiver,
                type: ContentTypeEnum.TEXT,
                content,
                timeStamp: payload.timeStamp,
            } ],
        }

        return of(payload).pipe(
            concatMap((result) => {
                let group = null
                if (!_.isNil(payload.group)) {
                    group = payload.group
                }

                const messageModel = new MessageModel()
                messageModel.setContent(content)
                messageModel.setGroup(group)
                messageModel.setSender(result.sender)
                messageModel.setTimeStamp(new Date(result.timeStamp))
                messageModel.setIncidentNo(result.incidentNo)
                messageModel.setSenderName(result.senderName)
                messageModel.setType(ContentTypeEnum.TEXT)
                messageModel.setReceiver(result.receiver)

                return this._messageRepository.save(messageModel).pipe(
                    map((message) => {
                        const groupSocketSchema: IGroupMessageSchema = {
                            content: {
                                image: null,
                                location: {
                                    address: null,
                                    latitude: null,
                                    longitude: null,
                                    title: null,
                                },
                                stickerId: null,
                                text: payload.text,
                                type: ContentTypeEnum.TEXT,
                                header: null,
                            },
                            from: {
                                id: payload.lineId,
                                name: payload.senderName,
                                sender: !_.isNil(payload.sender) ? 'user' : 'agent',
                            },
                            messageId: message.id,
                            timeStamp: payload.timeStamp,
                            groupId: payload.group,
                        }
                        return groupSocketSchema
                    }),
                )
            }),
            concatMap((groupSchema: IGroupMessageSchema) => {
                    if (_.isNil(payload.group)) {
                        return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_USER, directSocketSchema)

                    } else {
                        return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_GROUP, groupSchema)
                    }
                },
            ),
        )
    }
}
