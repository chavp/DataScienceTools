import { AbstractSubscriber } from '../../../../pubsub/abstract.subscriber'
import {
    DomainEvent,
    LineEvent,
} from '../../../../pubsub/event.enum'
import {
    iif,
    Observable,
    of,
} from 'rxjs'
import { IReceiveImageEventSchema } from '../../../line/pubsub/interface/receiveImageEvent.schema'
import { IMessageRepository } from '../../interface'
import {
    concatMap,
    map,
    mergeMap,
} from 'rxjs/operators'
import { MessageModel } from '../../message.model'
import * as _ from 'lodash'
import {
    IWebSocketAdapter,
    ReminderEvent,
} from '../../../../adapter/notification/interfaces/socket.interface'
import { ContentTypeEnum } from '../../../../repository/message/message.schema'
import {
    IDirectMessageSchema,
    IGroupMessageSchema,
} from '../schema/message-text.schema'

export class MessageImageSubscriber extends AbstractSubscriber {
    constructor(
        private readonly _messageRepository: IMessageRepository,
        private readonly _socketAdapter: IWebSocketAdapter,
    ) {
        super(LineEvent.LINE_RECEIVE_IMAGE)
    }

    public onEventPublished(topic: DomainEvent, buffer: Buffer): Observable<any> {
        const payload: IReceiveImageEventSchema = JSON.parse(buffer.toString('utf8'))
        const content = {
            id: payload.id,
            name: payload.name,
            path: payload.path,
        }

        const directSocketSchema: IDirectMessageSchema = {
            id: payload.lineId,
            displayName: payload.senderName,
            picPath: payload.picPath,
            incidentNo: payload.incidentNo,
            isRegister: payload.isRegister,
            message: [{
                id: payload.id,
                sender: !_.isNil(payload.sender) ? 'user' : 'agent',
                senderName: payload.senderName,
                receiver: payload.receiver,
                type: ContentTypeEnum.TEXT,
                content,
                timeStamp: payload.timeStamp,
            }],
        }

        return of(payload).pipe(
            concatMap((result) => {
                let group = null
                if (!_.isNil(payload.group)) {
                    group = payload.group
                }

                const messageModel = new MessageModel()
                messageModel.setContent(content)
                messageModel.setGroup(group)
                messageModel.setSender(result.sender)
                messageModel.setTimeStamp(new Date(result.timeStamp))
                messageModel.setIncidentNo(result.incidentNo)
                messageModel.setSenderName(result.senderName)
                messageModel.setType(ContentTypeEnum.IMAGE)
                messageModel.setReceiver(result.receiver)

                return this._messageRepository.save(messageModel).pipe(
                    map((message) => {
                        const groupSocketSchema: IGroupMessageSchema = {
                            content: {
                                type: ContentTypeEnum.IMAGE,
                                image: payload.path,
                                location: {
                                    address: null,
                                    latitude: null,
                                    longitude: null,
                                    title: null,
                                },
                                stickerId: null,
                                text: null,
                                header: null,
                            },
                            from: {
                                id: payload.lineId,
                                name: payload.senderName,
                                sender: !_.isNil(payload.sender) ? 'user' : 'agent',
                            },
                            messageId: message.id,
                            timeStamp: payload.timeStamp,
                            groupId: payload.group,
                        }
                        return groupSocketSchema
                    }),
                )
            }),
            mergeMap((groupSchema: IGroupMessageSchema) => {
                return iif(() => _.isNil(payload.group),
                    this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_USER, directSocketSchema),
                    this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_GROUP, groupSchema),
                )
            }),
        )
    }
}
