import { AbstractSubscriber } from '../../../../pubsub/abstract.subscriber'
import {
    iif,
    Observable,
    of,
} from 'rxjs'
import { IMessageRepository } from '../../interface'
import { LineEvent } from '../../../../pubsub/event.enum'
import {
    concatMap,
    map,
    mergeMap,
} from 'rxjs/operators'
import { MessageModel } from '../../message.model'
import { IReceiveLocationEventSchema } from '../../../line/pubsub/interface/receiveLocationEvent.schema'
import * as _ from 'lodash'
import {
    IWebSocketAdapter,
    ReminderEvent,
} from '../../../../adapter/notification/interfaces/socket.interface'
import { ContentTypeEnum } from '../../../../repository/message/message.schema'
import {
    IDirectMessageSchema,
    IGroupMessageSchema,
} from '../schema/message-text.schema'

export class MessageLocationSubscriber extends AbstractSubscriber {
    constructor(
        private readonly _messageRepository: IMessageRepository,
        private readonly _socketAdapter: IWebSocketAdapter,
    ) {
        super(LineEvent.LINE_RECEIVE_LOCATION)
    }

    public onEventPublished(topic: string, data: Buffer): Observable<any> {
        const jsonData: IReceiveLocationEventSchema = JSON.parse(data.toString('utf8'))
        const content = {
            id: jsonData.id,
            title: jsonData.title,
            address: jsonData.address,
            latitude: jsonData.latitude,
            longitude: jsonData.longitude,
        }

        const directSocketSchema: IDirectMessageSchema = {
            id: jsonData.lineId,
            displayName: jsonData.senderName,
            picPath: jsonData.picPath,
            incidentNo: jsonData.incidentNo,
            isRegister: jsonData.isRegister,
            message: [{
                id: jsonData.id,
                sender: !_.isNil(jsonData.sender) ? 'user' : 'agent',
                senderName: jsonData.senderName,
                receiver: jsonData.receiver,
                type: ContentTypeEnum.LOCATION,
                content,
                timeStamp: jsonData.timeStamp,
            }],
        }

        return of(jsonData).pipe(
            concatMap((result) => {
                let group = null
                if (!_.isNil(jsonData.group)) {
                    group = jsonData.group
                }

                const messageModel = new MessageModel()
                messageModel.setContent(content)
                messageModel.setGroup(group)
                messageModel.setSender(result.sender)
                messageModel.setTimeStamp(new Date(result.timeStamp))
                messageModel.setIncidentNo(result.incidentNo)
                messageModel.setSenderName(result.senderName)
                messageModel.setType(ContentTypeEnum.LOCATION)
                messageModel.setReceiver(result.receiver)

                return this._messageRepository.save(messageModel).pipe(
                    map((message) => {
                        const groupSocketSchema: IGroupMessageSchema = {
                            content: {
                                type: ContentTypeEnum.LOCATION,
                                image: null,
                                location: {
                                    address: jsonData.address,
                                    latitude: jsonData.latitude,
                                    longitude: jsonData.longitude,
                                    title: jsonData.title,
                                },
                                stickerId: null,
                                text: null,
                                header: null,
                            },
                            from: {
                                id: jsonData.lineId,
                                name: jsonData.senderName,
                                sender: !_.isNil(jsonData.sender) ? 'user' : 'agent',
                            },
                            messageId: message.id,
                            timeStamp: jsonData.timeStamp,
                            groupId: jsonData.group,
                        }
                        return groupSocketSchema
                    }),
                )
            }),
            mergeMap((groupSchema: IGroupMessageSchema) => {
                // if (_.isNil(jsonData.group)) {
                //     if (jsonData.isRegister === true) {
                //         return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_USER, directSocketSchema)
                //     } else {
                //         return of({})
                //     }
                // } else {
                //     return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_GROUP, groupSchema)
                // }
                return iif(() => _.isNil(jsonData.group),
                    this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_USER, directSocketSchema),
                    this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_GROUP, groupSchema),
                )
            }),
        )
    }
}
