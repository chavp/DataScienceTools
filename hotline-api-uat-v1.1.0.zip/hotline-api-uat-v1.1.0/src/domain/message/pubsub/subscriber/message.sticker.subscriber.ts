import { AbstractSubscriber } from '../../../../pubsub/abstract.subscriber'
import { IMessageRepository } from '../../interface'
import {
    DomainEvent,
    LineEvent,
} from '../../../../pubsub/event.enum'
import {
    iif,
    Observable,
    of,
} from 'rxjs'
import { IReceiveStickerEventSchema } from '../../../line/pubsub/interface/receiveStickerEvent.schema'
import {
    concatMap,
    map,
    mergeMap,
} from 'rxjs/operators'
import { MessageModel } from '../../message.model'
import * as _ from 'lodash'
import {
    IWebSocketAdapter,
    ReminderEvent,
} from '../../../../adapter/notification/interfaces/socket.interface'
import { ContentTypeEnum } from '../../../../repository/message/message.schema'
import {
    IDirectMessageSchema,
    IGroupMessageSchema,
} from '../schema/message-text.schema'

export class MessageStickerSubscriber extends AbstractSubscriber {
    constructor(
        private readonly _messageRepository: IMessageRepository,
        private readonly _socketAdapter: IWebSocketAdapter,
    ) {
        super(LineEvent.LINE_RECEIVE_STICKER)
    }

    public onEventPublished(topic: DomainEvent, buffer: Buffer): Observable<any> {
        const payload: IReceiveStickerEventSchema = JSON.parse(buffer.toString('utf8'))
        const content = {
            id: payload.id,
            stickerId: payload.stickerId,
            packageId: payload.packageId,
        }

        const directSocketSchema: IDirectMessageSchema = {
            id: payload.lineId,
            displayName: payload.senderName,
            picPath: payload.picPath,
            incidentNo: payload.incidentNo,
            isRegister: payload.isRegister,
            message: [{
                id: payload.id,
                sender: !_.isNil(payload.sender) ? 'user' : 'agent',
                senderName: payload.senderName,
                receiver: payload.receiver,
                type: ContentTypeEnum.STICKER,
                content,
                timeStamp: payload.timeStamp,
            }],
        }

        return of(payload).pipe(
            concatMap((result) => {
                let group = null
                if (!_.isNil(payload.group)) {
                    group = payload.group
                }

                const messageModel = new MessageModel()
                messageModel.setContent(content)
                messageModel.setGroup(group)
                messageModel.setSender(result.sender)
                messageModel.setTimeStamp(new Date(result.timeStamp))
                messageModel.setIncidentNo(result.incidentNo)
                messageModel.setSenderName(result.senderName)
                messageModel.setType(ContentTypeEnum.STICKER)
                messageModel.setReceiver(result.receiver)

                return this._messageRepository.save(messageModel).pipe(
                    map((message) => {
                        const groupSocketSchema: IGroupMessageSchema = {
                            content: {
                                image: null,
                                location: {
                                    address: null,
                                    latitude: null,
                                    longitude: null,
                                    title: null,
                                },
                                stickerId: payload.stickerId,
                                text: null,
                                type: ContentTypeEnum.STICKER,
                                header: null,
                            },
                            from: {
                                id: payload.lineId,
                                name: payload.senderName,
                                sender: !_.isNil(payload.sender) ? 'user' : 'agent',
                            },
                            messageId: message.id,
                            timeStamp: payload.timeStamp,
                            groupId: payload.group,
                        }
                        return groupSocketSchema
                    }),
                )
            }),
            mergeMap((groupSchema: IGroupMessageSchema) => {
                // if (_.isNil(payload.group)) {
                //     if (payload.isRegister === true) {
                //         return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_USER, directSocketSchema)
                //     } else {
                //         return of({})
                //     }
                // } else {
                //     return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_GROUP, groupSchema)
                // }
                return iif(() => _.isNil(payload.group),
                    this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_USER, directSocketSchema),
                    this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_GROUP, groupSchema),
                )
            }),
        )
    }
}
