import { AbstractSubscriber } from '../../../../pubsub/abstract.subscriber'
import { IMessageRepository } from '../../interface'
import { SurveyorEvent } from '../../../../pubsub/event.enum'
import {
    forkJoin,
    Observable,
    of,
} from 'rxjs'
import { IUpdateSurveyorCaseEventSchema } from '../../../surveyor-case/pubsub/interface/schema.interface'
import {
    concatMap,
    defaultIfEmpty,
    delay,
    filter,
    map,
    mergeMap,
    take,
    tap,
} from 'rxjs/operators'
import { MessageModel } from '../../message.model'
import { ContentTypeEnum } from '../../../../repository/message/message.schema'
import {
    IWebSocketAdapter,
    ReminderEvent,
} from '../../../../adapter/notification/interfaces/socket.interface'
import * as _ from 'lodash'
import {
    IDirectMessageSchema,
    IGroupMessageSchema,
} from '../schema/message-text.schema'
import { ISurveyorLineRepository } from '../../../surveyor-line/interface/repository.interface'
import { ISurveyorLineModel } from '../../../surveyor-line/interface/model.interface'
import {
    ILineProfileModel,
    ILineProfileRepository,
} from '../../../line/interface'
import { ILineAdapter } from '../../../../adapter/line/interface/line.interface'
import { IConfig } from '../../../../common/interface/config.interface'
import { IAuthService } from '../../../../common/interface/auth.interface'
import { ISurveyorCaseArriveBuilder } from '../../../surveyor-case/interface/builder.confirmArrive.interface'
import { IGuaranteeZoneRepository } from '../../../surveyor/interface/repository.interface'
import { IGuaranteeZoneModel } from '../../../surveyor/interface/model.interface'
import { ICaseNotArriveEventSchema } from '../../../surveyor-case/pubsub/interface/case-not-arrive-interface'
import { IFlexPayloadSchema } from '../../interface/schema.interface'

export class UpdateSurveyorAssignmentSubscriber extends AbstractSubscriber {
    constructor(
        private readonly _config: IConfig,
        private readonly _socketAdapter: IWebSocketAdapter,
        private readonly _lineAdepter: ILineAdapter,
        private readonly _auth: IAuthService,
        private readonly _messageRepository: IMessageRepository,
        private readonly _surveyorLineRepository: ISurveyorLineRepository,
        private readonly _lineProfileRepository: ILineProfileRepository,
        private readonly _surveyorCaseArriveBuilder: ISurveyorCaseArriveBuilder,
        private readonly _guaranteeZoneRepository: IGuaranteeZoneRepository,
    ) {
        super(SurveyorEvent.UPDATE_SURVEYOR_ASSIGNMENT)
    }

    public onEventPublished(topic: string, data: Buffer): Observable<any> {
        const payload: IUpdateSurveyorCaseEventSchema = JSON.parse(data.toString('utf8'))
        console.log(SurveyorEvent.UPDATE_SURVEYOR_ASSIGNMENT, payload)
        let guarantee = true
        let pushFlexId = null
        let pushMsgId = null
        return this._surveyorLineRepository.getBySurveyorId(payload.surveyorNo).pipe(
            mergeMap((result: ISurveyorLineModel) => {
                const messageToGroup = 'Reserved ' + payload.id
                const lastAssignment = _.last(payload.surveyorAssignment)

                const boxMessageGroup: ICaseNotArriveEventSchema = {
                    lineId: result.getId(),
                    surveyorId: result.getSurveyorId(),
                    caseNo: payload.id,
                    companyNo: payload.surveyorNo,
                    employeeName: _.get(lastAssignment, 'name', ''),
                    employeePhone: _.get(lastAssignment, 'phone', ''),
                    timeSchedule: null,
                    type: null,
                }
                return forkJoin([
                    this._lineAdepter.pushMessage(result.getId(), messageToGroup).pipe(
                        tap(r => {
                                console.log('send to group : ' + result.getId())
                            }),
                        mergeMap((pushResult) => {
                            pushMsgId = _.get(pushResult, 'x-line-request-id', null)
                            const content = {
                                id: pushMsgId,
                                text: 'Reserved ' + payload.id,
                            }
                            const messageModel = new MessageModel()
                            messageModel.setContent(content)
                            messageModel.setGroup(result.getId())
                            messageModel.setSender(null)
                            messageModel.setTimeStamp(new Date(payload.timestamp))
                            messageModel.setSenderName(null)
                            messageModel.setType(ContentTypeEnum.TEXT)
                            messageModel.setIncidentNo(payload.incidentNo)

                            return this._messageRepository.save(messageModel).pipe(
                                map(() => result),
                            )

                        }),
                        mergeMap(() => {
                                return this._guaranteeZoneRepository.listByProvinceTH(payload.province)
                            }),
                        map((guaranteeZone: IGuaranteeZoneModel) => guaranteeZone),
                        filter((guaranteeZone: IGuaranteeZoneModel) => {
                                return guaranteeZone && payload.district === guaranteeZone.getDistrictTH()
                            }),
                        defaultIfEmpty(null),
                        map((res) => {
                                let confWord = `ยืนยันการถึงที่หมายภายใน 30 นาที`
                                if (_.isNil(res)) {
                                    confWord = `ยืนยันการถึงที่หมาย`
                                    guarantee = false
                                }
                                return confWord
                            }),
                        concatMap((confirmWord: string) => {
                            return this._surveyorCaseArriveBuilder.groupLineFlex(boxMessageGroup, confirmWord).pipe(
                                concatMap((flex) => {
                                    return this._lineAdepter.pushFlexMessage(result.getId(), flex).pipe(
                                        map((pushResult) => {
                                            return ({pushResult, confirmWord})
                                        }),
                                    )
                                }),
                            )
                        }),
                        mergeMap(({pushResult, confirmWord}) => {
                                pushFlexId = _.get(pushResult, 'x-line-request-id', null)
                                const employeeName = _.get(lastAssignment, 'name', '')
                                const content: IFlexPayloadSchema = {
                                    id: pushFlexId,
                                    header: confirmWord,
                                    text: `หมายเลขบริษัทสำรวจภัย: ${payload.surveyorNo}\nชื่อเจ้าหน้าที่สำรวจภัย: ${employeeName}`,
                                }

                                const groupSocketSchema: IGroupMessageSchema = {
                                    content: {
                                        image: null,
                                        location: {
                                            address: null,
                                            latitude: null,
                                            longitude: null,
                                            title: null,
                                        },
                                        stickerId: null,
                                        text: `หมายเลขบริษัทสำรวจภัย: ${payload.surveyorNo}\\nชื่อเจ้าหน้าที่สำรวจภัย: ${employeeName}`,
                                        type: ContentTypeEnum.FLEX,
                                        header: confirmWord,
                                    },
                                    from: {
                                        id: null,
                                        name: null,
                                        sender: 'agent',
                                    },
                                    messageId: pushFlexId,
                                    timeStamp: payload.timestamp,
                                    groupId: result.getId(),
                                }

                                const messageModel = new MessageModel()
                                messageModel.setContent(content)
                                messageModel.setGroup(result.getId())
                                messageModel.setSender(null)
                                messageModel.setTimeStamp(new Date(payload.timestamp))
                                messageModel.setSenderName(null)
                                messageModel.setType(ContentTypeEnum.FLEX)
                                messageModel.setIncidentNo(payload.incidentNo)

                                return forkJoin([
                                    this._messageRepository.save(messageModel),
                                    this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_GROUP, groupSocketSchema),
                                ])
                            }),
                    ),
                    this._sendMessageToCustomer(result, payload),
                ]).pipe(
                    map(() => result),
                )
            }),
            mergeMap((result: ISurveyorLineModel) => {
                const groupSocketSchema: IGroupMessageSchema = {
                    content: {
                        image: null,
                        location: {
                            address: null,
                            latitude: null,
                            longitude: null,
                            title: null,
                        },
                        stickerId: null,
                        text: 'Reserved ' + payload.id,
                        type: ContentTypeEnum.TEXT,
                        header: null,
                    },
                    from: {
                        id: null,
                        name: null,
                        sender: 'agent',
                        // sender: !_.isNil(null) ? 'user' : 'agent',
                    },
                    groupId: result.getId(),
                    messageId: pushMsgId,
                    timeStamp: new Date(payload.timestamp).getTime(),
                }

                return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_GROUP, groupSocketSchema)
            }),
        )
    }

    private _sendMessageToCustomer(surveyorLine: ISurveyorLineModel, schema: IUpdateSurveyorCaseEventSchema): Observable<any> {
        const query = {
            incidentNo: schema.incidentNo,
        }
        let messageToCustomer = 'เจ้าหน้าที่สำรวจภัยจะไปถึงคุณภายในเวลา 30 นาทีค่ะ / The surveyor will arrive to you within 30 minutes.'
        let confirmWord = `ยืนยันการถึงที่หมายภายใน 30 นาที`
        const timeStamp = schema.timestamp

        return this._lineProfileRepository.find(query).pipe(
            take(1),
            mergeMap((res: ILineProfileModel) => {
                return forkJoin([
                    of(res),
                    this._guaranteeZoneRepository.listByProvinceTH(schema.province).pipe(
                        map((guaranteeZone: IGuaranteeZoneModel) => guaranteeZone),
                        filter((guaranteeZone: IGuaranteeZoneModel) => {
                            return guaranteeZone && schema.district === guaranteeZone.getDistrictTH()
                        }),
                        defaultIfEmpty(null),
                    ),
                ])
            }),
            map((res: any[]) => {
                const profile = res[0] as ILineProfileModel
                const guarantee = res[1] as IGuaranteeZoneModel

                if (_.isNil(guarantee)) {
                    confirmWord = 'ยืนยันการถึงที่หมาย'
                    messageToCustomer = 'เจ้าหน้าที่สำรวจภัยจะไปถึงคุณโดยเร็วที่สุดค่ะ / The surveyor will reach you as soon as possible.'
                }

                return profile
            }),
            concatMap((res: ILineProfileModel) => {
                return this._lineAdepter.pushMessage(res.getId(), messageToCustomer).pipe(
                    tap(r => {
                        console.log('send to customer : ' + res.getId())
                    }),
                    mergeMap((pushResult) => {
                        const pushFlexId = _.get(pushResult, 'x-line-request-id', null)
                        const content = {
                            id: pushFlexId,
                            text: messageToCustomer,
                        }
                        const messageModel = new MessageModel()
                        messageModel.setContent(content)
                        messageModel.setGroup(null)
                        messageModel.setSender(null)
                        messageModel.setTimeStamp(new Date(timeStamp))
                        messageModel.setSenderName(null)
                        messageModel.setType(ContentTypeEnum.TEXT)
                        messageModel.setIncidentNo(res.getIncidentNo())

                        return this._messageRepository.save(messageModel).pipe(
                            map(() => {
                                return ({pushResult, messageModel})
                            }),
                        )
                    }),
                    mergeMap(({pushResult, messageModel}) => {
                        const pushFlexId = _.get(pushResult, 'x-line-request-id', null)
                        const directSocketSchema: IDirectMessageSchema = {
                            id: res.getId(),
                            displayName: res.getDisplayName(),
                            picPath: res.getPictureUrl(),
                            incidentNo: res.getIncidentNo(),
                            isRegister: res.getIsRegister(),
                            message: [{
                                id: messageModel.getId(),
                                sender: 'agent',
                                senderName: null,
                                receiver: res.getId(),
                                type: ContentTypeEnum.TEXT,
                                content: {
                                    id: pushFlexId,
                                    text: messageToCustomer,
                                },
                                timeStamp: new Date(timeStamp).getTime(),
                            }],
                        }
                        return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_USER, directSocketSchema).pipe(
                            map(() => res),
                        )
                    }),
                )
            }),
            delay(3000),
            concatMap((lineProfile: ILineProfileModel) => {
                const lastAssignment = _.last(schema.surveyorAssignment)
                const boxMessageUser: ICaseNotArriveEventSchema = {
                    lineId: lineProfile.getId(),
                    surveyorId: surveyorLine.getSurveyorId(),
                    caseNo: schema.id,
                    companyNo: schema.surveyorNo,
                    employeeName: _.get(lastAssignment, 'name', ''),
                    employeePhone: _.get(lastAssignment, 'phone', ''),
                    type: null,
                    timeSchedule: null,
                }
                return this._surveyorCaseArriveBuilder.userLineFlex(boxMessageUser, confirmWord).pipe(
                    delay(1000),
                    concatMap(flex => {
                        return this._lineAdepter.pushFlexMessage(lineProfile.getId(), flex).pipe(
                            mergeMap((pushResult) => {
                                const flexId = _.get(pushResult, 'x-line-request-id', null)
                                const content: IFlexPayloadSchema = {
                                    id: flexId,
                                    header: confirmWord,
                                    text: `หมายเลขบริษัทสำรวจภัย: ${schema.surveyorNo}\nชื่อเจ้าหน้าที่สำรวจภัย: ${lastAssignment.name}`,
                                }
                                const message = new MessageModel()
                                message.setContent(content)
                                message.setGroup(null)
                                message.setSender(null)
                                message.setTimeStamp(new Date(timeStamp))
                                message.setSenderName(null)
                                message.setType(ContentTypeEnum.FLEX)
                                message.setReceiver('user')
                                message.setIncidentNo(lineProfile.getIncidentNo())

                                return this._messageRepository.save(message).pipe(
                                    mergeMap((result) => {
                                        const directSocketSchema: IDirectMessageSchema = {
                                            id: lineProfile.getId(),
                                            displayName: lineProfile.getDisplayName(),
                                            picPath: lineProfile.getPictureUrl(),
                                            incidentNo: lineProfile.getIncidentNo(),
                                            isRegister: lineProfile.getIsRegister(),
                                            message: [
                                                {
                                                    id: result.id,
                                                    sender: 'agent',
                                                    senderName: null,
                                                    receiver: lineProfile.getId(),
                                                    type: ContentTypeEnum.FLEX,
                                                    content,
                                                    timeStamp: new Date(timeStamp).getTime(),
                                                },
                                            ],
                                        }
                                        return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_USER, directSocketSchema)
                                    }),
                                )
                            }),
                        )
                    }),
                )
            }),
        )
    }
}
