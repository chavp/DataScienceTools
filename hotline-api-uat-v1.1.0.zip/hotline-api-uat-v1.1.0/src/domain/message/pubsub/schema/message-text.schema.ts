import { IMapMessageDto } from '../../../../controller/rest/dto/line-profile.dto'
import { ContentTypeEnum } from '../../../../repository/message/message.schema'

export interface IMessageTextEventSchema {
    id: string,
    text: string,
    sender: string,
    group: string,
    timeStamp: number,
    incidentNo: string,
    senderName: string,
}

export interface IDirectMessageSchema {
    id: string
    displayName: string
    picPath: string
    message: IMapMessageDto[]
    incidentNo: string
    isRegister: boolean
}

export interface IGroupMessageSchema {
    messageId: string
    from: ISenderSchema
    groupId: string
    content: IGroupMessageContent
    timeStamp: number
}

export interface IGroupMessageContent {
    image: string
    location: ILocationSchema
    stickerId: string
    text: string
    header: string
    type: ContentTypeEnum
}

export interface ILocationSchema {
    address: string
    latitude: number
    longitude: number
    title: string
}

export interface ISenderSchema {
    id: string
    name: string
    sender: string
}

export interface ISurveyorArriveGroupSchema {
    lineId: string,
    surveyorId: string,
    caseNo: string,
    companyNo: string,
    employeeName: string,
}

export interface ISurveyorArriveUserSchema {
    lineId: string,
    surveyorId: string,
    caseNo: string,
    companyNo: string,
    employeeName: string,
    employeePhone: string,
}
