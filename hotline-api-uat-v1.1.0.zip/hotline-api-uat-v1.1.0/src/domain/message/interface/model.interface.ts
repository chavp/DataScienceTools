import { IEntity } from '../../../common/interface/entity.interface'
import { ContentTypeEnum } from '../../../repository/message/message.schema'
import { IMessageContentSchema } from './schema.interface'

export interface IMessageModel extends IEntity {
    getSender(): string

    getReceiver(): string

    getGroup(): string

    getContent(): IMessageContentSchema

    getTimeStamp(): Date

    getRead(): boolean

    getIncidentNo(): string

    getSenderName(): string

    getType(): ContentTypeEnum

    setSender(sender: string): void

    setReceiver(receiver: string): void

    setGroup(group: string): void

    setContent(content: IMessageContentSchema): void

    setTimeStamp(timeStamp: Date): void

    setRead(read: boolean): void

    setIncidentNo(incidentNo: string): void

    setSenderName(senderName: string): void

    setType(type: ContentTypeEnum): void
}
