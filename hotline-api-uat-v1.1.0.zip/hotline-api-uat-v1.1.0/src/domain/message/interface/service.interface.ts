import { Observable } from 'rxjs'
import { ISendMessageValidator } from './validator.interface'
import { IMessageModel } from './model.interface'

export interface IMessageService {

    sendGroupMessage(input: ISendMessageValidator): Observable<{id: string}>

    sendDirectMessage(input: ISendMessageValidator): Observable<{ id: string }>

    getLatestMessageFromGroupId(groupId: string): Observable<IMessageModel>

    getLatestMessageFromUserId(userId: string): Observable<IMessageModel>

    readMessageByIncidentNo(incidentNo: string): Observable<boolean>
}
