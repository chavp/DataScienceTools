export interface ISendMessageValidator {
    getMessage(): string

    getReceiver(): string

    getSenderName(): string

    setSenderName(name: string): void
}
