export type IMessageContentSchema = IMessagePayloadSchema | IStickerPayloadSchema | ILocationPayloadSchema | IImagePayloadSchema

export interface IMessagePayloadSchema {
    id: string
    text: string
}

export interface IStickerPayloadSchema {
    id: string
    stickerId: string
    packageId: string

}

export interface ILocationPayloadSchema {
    id: string
    title: string
    address: string
    latitude: number
    longitude: number
}

export interface IImagePayloadSchema {
    id: string
    name: string
    path: string
}

export interface IFlexPayloadSchema {
    id: string
    header: string
    text: string
}
