import { Observable } from 'rxjs'
import { IRepository } from 'common/interface/repository.interface'
import { IMessageModel } from './model.interface'

export interface IMessageRepository extends IRepository<IMessageModel> {
    save(model: IMessageModel): Observable<{id: string}>

    update(model: IMessageModel): Observable<boolean>

    // getByLineId(id: string): Observable<IMessageModel>

    find(filter?: any): Observable<IMessageModel>

    listLatestFromGroupId(id: string, limit?: number): Observable<IMessageModel>

    listDirectLatestBySenderOrReceiver(id: string, limit?: number): Observable<IMessageModel>

    listDirectLatestByIncidentNo(id: string, limit?: number): Observable<IMessageModel>

    getTotalUnreadMessageById(id: string): Observable<number>

    getTotalUnreadMessageBySenderOrReceiver(sender: string): Observable<number>

    listGroupMessage(groupId: string): Observable<IMessageModel>
}
