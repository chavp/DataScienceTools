import { IMessageService } from './interface/service.interface'
import { Observable } from 'rxjs'
import {
    IMessageModel,
    IMessageRepository,
} from './interface'
import { ISendMessageValidator } from './interface/validator.interface'
import { ISurveyorLineRepository } from '../surveyor-line/interface/repository.interface'
import {
    concatMap,
    map,
    mergeMap,
    take,
} from 'rxjs/operators'
import { MessageModel } from './message.model'
import { ContentTypeEnum } from '../../repository/message/message.schema'
import { IMessagePayloadSchema } from './interface/schema.interface'
import { IPublisher } from '../../pubsub/interface/publisher.interface'
import { ILineAdapter } from '../../adapter/line/interface/line.interface'
import * as _ from 'lodash'
import { ILineProfileRepository } from '../line/interface'
import { MessageSendGroupMessageEvent } from './pubsub/event/message-send-group-message-event'
import { MessageSendIndividualMessageEvent } from './pubsub/event/message-send-individual-message-event'
import {
    IWebSocketAdapter,
    ReminderEvent,
} from '../../adapter/notification/interfaces/socket.interface'
import {
    IDirectMessageSchema,
    IGroupMessageSchema,
} from './pubsub/schema/message-text.schema'

export class MessageService implements IMessageService {
    constructor(
        private readonly _messageRepository: IMessageRepository,
        private readonly _surveyorLineRepository: ISurveyorLineRepository,
        private readonly _publisher: IPublisher<IMessageModel>,
        private readonly _lineAdapter: ILineAdapter,
        private readonly _lineProfileRepository: ILineProfileRepository,
        private readonly _socketAdapter: IWebSocketAdapter,
    ) {
    }

    public sendGroupMessage(input: ISendMessageValidator): Observable<{ id: string }> {
        return this._surveyorLineRepository.getBySurveyorId(input.getReceiver()).pipe(
            concatMap(surveyor => {
                return this._lineAdapter.pushMessage(surveyor.getId(), input.getMessage()).pipe(
                    map(pushResult => {
                        return ({ surveyor, pushResult })
                    }),
                )
            }),
            map(({ surveyor, pushResult }) => {

                const content: IMessagePayloadSchema = {
                    id: _.toString(pushResult.id),
                    text: input.getMessage(),
                }

                const messageModel = new MessageModel()
                messageModel.setContent(content)
                messageModel.setGroup(surveyor.getId())
                messageModel.setSender(null)
                messageModel.setTimeStamp(new Date())
                messageModel.setIncidentNo(null)
                messageModel.setSenderName(input.getSenderName())
                messageModel.setType(ContentTypeEnum.TEXT)
                messageModel.setReceiver(input.getReceiver())

                return ({ messageModel, surveyor })
            }),
            mergeMap(({ messageModel, surveyor }) => {
                const groupSocketSchema: IGroupMessageSchema = {
                    content: {
                        image: null,
                        location: {
                            address: null,
                            latitude: null,
                            longitude: null,
                            title: null,
                        },
                        stickerId: null,
                        text: input.getMessage(),
                        type: ContentTypeEnum.TEXT,
                        header: null,
                    },
                    from: {
                        id: null,
                        name: input.getSenderName(),
                        sender: 'agent',
                    },
                    messageId: messageModel.getId(),
                    timeStamp: new Date().getTime(),
                    groupId: surveyor.getId(),
                }

                return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_GROUP, groupSocketSchema).pipe(
                    map(() => messageModel),
                )
            }),
            concatMap(model => {
                const domainEvent = new MessageSendGroupMessageEvent(model)
                this._publisher.publish(domainEvent)
                return this._messageRepository.save(model).pipe(
                    map(({ id }) => {
                        model.setId(id)
                        return model
                    }),
                )
            }),
            map((model) => {
                return { id: model.getId() }
            }),
        )
    }

    public sendDirectMessage(input: ISendMessageValidator): Observable<{ id: string }> {
        return this._lineProfileRepository.getByLineId(input.getReceiver()).pipe(
            concatMap(lineProfile => {
                return this._lineAdapter.pushMessage(lineProfile.getId(), input.getMessage()).pipe(
                    map((pushResult => {
                        return ({ lineProfile, pushResult })
                    })),
                )
            }),
            map(({ lineProfile, pushResult }) => {

                const content: IMessagePayloadSchema = {
                    id: _.toString(pushResult.id),
                    text: input.getMessage(),
                }

                const messageModel = new MessageModel()
                messageModel.setContent(content)
                messageModel.setGroup(null)
                messageModel.setSender(null)
                messageModel.setTimeStamp(new Date())
                messageModel.setIncidentNo(lineProfile.getIncidentNo())
                messageModel.setSenderName(input.getSenderName())
                messageModel.setType(ContentTypeEnum.TEXT)
                messageModel.setReceiver(lineProfile.getId())

                return ({ messageModel, pushResult, lineProfile })
            }),
            mergeMap(({ messageModel, pushResult, lineProfile }) => {
                const msg: IMessagePayloadSchema = {
                    id: _.toString(pushResult.id),
                    text: input.getMessage(),
                }

                const directSocketSchema: IDirectMessageSchema = {
                    id: input.getReceiver(),
                    displayName: lineProfile.getDisplayName(),
                    picPath: lineProfile.getPictureUrl(),
                    incidentNo: messageModel.getIncidentNo(),
                    isRegister: lineProfile.getIsRegister(),
                    message: [{
                        id: messageModel.getId(),
                        sender: 'agent',
                        senderName: input.getSenderName(),
                        receiver: input.getReceiver(),
                        type: ContentTypeEnum.TEXT,
                        content: msg,
                        timeStamp: new Date().getTime(),
                    } ],
                }

                return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_USER, directSocketSchema).pipe(
                    map(() => messageModel),
                )
            }),
            concatMap(model => {
                const domainEvent = new MessageSendIndividualMessageEvent(model)
                this._publisher.publish(domainEvent)
                return this._messageRepository.save(model).pipe(
                    map(({ id }) => {
                        model.setId(id)
                        return model
                    }),
                )
            }),
            map((model) => {
                return { id: model.getId() }
            }),
        )
    }

    public getLatestMessageFromGroupId(groupId: string): Observable<IMessageModel> {
        return this._messageRepository.listGroupMessage(groupId).pipe(
            take(1),
        )
    }

    public getLatestMessageFromUserId(userId: string): Observable<IMessageModel> {
        return undefined
    }

    public readMessageByIncidentNo(incidentNo: string): Observable<boolean> {
        const msgFilter = {
            incidentNo,
        }
        return this._messageRepository.find(msgFilter).pipe(
            mergeMap((message: IMessageModel) => {
                message.setRead(true)
                return this._messageRepository.update(message)
            }),
        )
    }

}
