import { Entity } from '../../common/entity'
import { IMessageModel } from './interface'
import { ContentTypeEnum } from '../../repository/message/message.schema'
import { IMessageContentSchema } from './interface/schema.interface'

export class MessageModel extends Entity implements IMessageModel {
    private _sender: string
    private _receiver: string
    private _group: string
    private _content: IMessageContentSchema
    private _timeStamp: Date
    private _read: boolean
    private _incidentNo: string
    private _senderName: string
    private _type: ContentTypeEnum

    constructor() {
        super()
        this._timeStamp = new Date()
    }

    public getContent(): IMessageContentSchema {
        return this._content
    }

    public getGroup(): string {
        return this._group
    }

    public getRead(): boolean {
        return this._read
    }

    public getReceiver(): string {
        return this._receiver
    }

    public getSender(): string {
        return this._sender
    }

    public getTimeStamp(): Date {
        return this._timeStamp
    }

    public getType(): ContentTypeEnum {
        return this._type
    }

    public setContent(content: IMessageContentSchema): void {
        this._content = content
    }

    public setGroup(group: string): void {
        this._group = group
    }

    public setRead(read: boolean): void {
        this._read = read
    }

    public setReceiver(receiver: string): void {
        this._receiver = receiver
    }

    public setSender(sender: string): void {
        this._sender = sender
    }

    public setTimeStamp(timeStamp: Date): void {
        this._timeStamp = timeStamp
    }

    public getIncidentNo(): string {
        return this._incidentNo
    }

    public getSenderName(): string {
        return this._senderName
    }

    public setIncidentNo(incidentNo: string): void {
        this._incidentNo = incidentNo
    }

    public setSenderName(senderName: string): void {
        this._senderName = senderName
    }

    public setType(type: ContentTypeEnum): void {
        this._type = type
    }

}
