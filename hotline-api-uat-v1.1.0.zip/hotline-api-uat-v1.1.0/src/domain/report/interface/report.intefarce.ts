import { Observable } from 'rxjs'

export interface IReportService {
    searchIncident(filter): Observable<any>

    exportSearchExcel(sheetName: string, model: any): Observable<any>

    getAll(): Observable<any>
}
