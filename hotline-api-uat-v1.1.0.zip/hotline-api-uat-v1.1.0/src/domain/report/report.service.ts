import {
    IIncidentLogRepository,
    IIncidentModel,
    IIncidentRepository,
} from '../incident/interface'
import {
    forkJoin,
    from,
    Observable,
    of,
} from 'rxjs'
import {
    catchError,
    map,
    mergeMap,
    reduce,
    tap,
    throwIfEmpty,
    toArray,
} from 'rxjs/operators'
import * as _ from 'lodash'
import * as moment from 'moment'
import * as xls from 'excel4node'
import { IReportService } from './interface/report.intefarce'
import { WorkFlowEnum } from '../../repository/incident/log.schema'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'

export class ReportService implements IReportService {
    constructor(
        private readonly _incidentRepository: IIncidentRepository,
        private readonly _incidentLogRepository: IIncidentLogRepository,
    ) {
    }

    // TODO FIX this into model access style
    public searchIncident(filter): Observable<any> {
        const incidentFilter = filter.filter
        const incidentSorting = filter.sorting
        return this._incidentRepository.filter(incidentFilter,  incidentSorting).pipe(
            mergeMap( data => {
                return this._formatData(of(data))
            }),
        )
    }

    public exportSearchExcel(sheetName: string, model: any): Observable<any> {
        return from(model).pipe(
            reduce((content: any[], record: any) => {
                let insuredInjured = ''
                if (!_.isNil(record.insuredInjured.toString())) {
                    insuredInjured = record.insuredInjured.toString()
                }

                let insuredDeath = ''
                if (!_.isNil(record.insuredDeath.toString())) {
                    insuredDeath = record.insuredDeath.toString()
                }

                let thirdInsuredInjured = ''
                if (!_.isNil(record.thirdInsuredInjured.toString())) {
                    thirdInsuredInjured = record.thirdInsuredInjured.toString()
                }

                let thirdInsuredDeath = ''
                if (!_.isNil(record.thirdInsuredDeath.toString())) {
                    thirdInsuredDeath = record.thirdInsuredDeath.toString()
                }

                content.push({
                    'incidentNo': _.get(record, 'incidentNo', ''),
                    'claimNo': _.get(record, 'claimNo', ''),
                    'type': _.get(record, 'type', ''),
                    'subType': _.get(record, 'subType', ''),
                    'motorClaimType': record.motorClaimType,
                    'ชื่อผู้แจ้งอุบัติเหตุ': record.callerName,
                    'เบอร์ติดต่อผู้แจ้งอุบัติเหตุ': record.contactNo,
                    'วันที่เกิดเหตุ': record.lossInformationDate,
                    'เวลาที่เกิดเหตุ': record.lossInformationTime,
                    'วันที่รับแจ้ง': record.createdDate,
                    'เวลาที่รับแจ้ง': record.createdTime,
                    'เวลาที่ขานลูกค้า': record.agentRespondedCustomer,
                    'เวลาที่จ่ายงานเซอร์เวย์': record.surveyorAcceptedJob,
                    'เวลาที่ถึงที่เกิดเหตุ': record.surveyorArrived,
                    'สถานที่เกิดเหตุ': record.lossInformationLocation,
                    'ลักษณะการเกิดเหตุ': record.lossInformationDetail,
                    'ชื่อ_นามสกุลผู้เอาประกันภัย': record.insured,
                    'ชื่อคนขับรถคันที่เกิดเหตุ': record.driverName,
                    'ทะเบียนรถ ป.': record.registration,
                    'ยี่ห้อรถ_รุ่นนรถ': record.makeModel,
                    'กรมธรรม์เลขที่': record.policyNo,
                    'Agent': record.agent,
                    'วันเริ่มต้นความคุ้มครอง': record.periodFrom,
                    'วันหมดอายุ': record.periodTo,
                    'ประเภทประกันภัย': record.coverageType,
                    'เลขที่ตัวถัง': record.chassis,
                    'บริษัทผู้สำรวจภัย': record.surveyorCompany,
                    'บริษัทรถยก': record.towCompanyName,
                    'ชื่อผู้สำรวจภัย': '',
                    'หมายเลขโทรศัพท์': '',
                    'เลขที่อ้างอิงของผู้สำรวจภัย': '',
                    'จำนวนคนบาดเจ็บ รถ ป.' : insuredInjured,
                    'จำนวนคนตาย รถ ป.': insuredDeath,
                    'จำนวนคนเจ็บ รถ ค.': thirdInsuredInjured,
                    'จำนวนคนตาย รถ ค.': thirdInsuredDeath,
                    'Note': record.note,
                    'Status': record.status,
                })
                return content
            }, []),
            map(content => {
                const workbook = new xls.Workbook()
                const worksheet = workbook.addWorksheet(sheetName)
                const headers = ReportService._getContentKeys(_.last(content))

                for (let col = 1, index = 0; col <= _.size(headers); col++, index++) {
                    worksheet.cell(1, col).string(headers[index])
                }

                for (let row = 2, recordRow = 0; row <= (_.size(content) + 1); row++, recordRow++) {
                    for (let col = 1, recordCol = 0; col <= _.size(headers); col++, recordCol++) {
                        const x = recordRow
                        const y = headers[recordCol]
                        worksheet.cell(row, col).string(content[x][y])
                    }
                }

                return workbook
            }),
        )
    }

    private static _getContentKeys(record) {
        return _.keys(record)
    }

    public getAll(): Observable<any> {
        return this._incidentRepository.reportFindAll().pipe(
            map((data) => data),
            toArray(),
            mergeMap( data => {
                return this._formatData(data)
            }),
        )
    }

    private _formatData(data: any): Observable<any> {
        return from(data).pipe(
            mergeMap((model: IIncidentModel) => {
                return forkJoin([
                    this._incidentLogRepository.getReportById(model.getId()).pipe(
                        throwIfEmpty(() => {
                            throw new HttpException(`Incident Log Not Found`, HttpStatus.NOT_FOUND)
                        }),
                        map((result) => {
                            if (_.isNil(result)) {
                                return null
                            }
                        }),
                        catchError(() => {
                            return of(null)
                        }),
                    ),
                    of(model),
                ])
            }),
            map(res => {
                return {
                    logIncident: res[0],
                    incident: res[1],
                }
            }),
            reduce((content: any, record: any) => {
                const secondSubType = _.get(record, 'incident._incidentType.subType.id', '')
                const thirdSubType = _.get(record, 'incident._incidentType.subType.subType.id', '')

                let agentRespondedCustomer
                let surveyorArrived
                let surveyorAcceptedJob
                let customerCallDate
                if (!_.isNil(record.logIncident)) {
                    agentRespondedCustomer = _.findLast(record.logIncident._logs, {
                        _workFlow: WorkFlowEnum.AGENT_RESPONDED_CUSTOMER,
                    })
                    surveyorArrived = _.findLast(record.logIncident._logs, {
                        _workFlow: WorkFlowEnum.SURVEYOR_ACCEPTED_JOB,
                    })
                    surveyorAcceptedJob = _.findLast(record.logIncident._logs, {
                        _workFlow: WorkFlowEnum.SURVEYOR_ACCEPTED_JOB,
                    })
                    customerCallDate = _.findLast(record.logIncident._logs, {
                        _workFlow: WorkFlowEnum.CUSTOMER_CALLED_AGENT,
                    })
                }
                let agentRespondedCustomerDate
                if (!_.isEmpty(agentRespondedCustomer)) {
                    agentRespondedCustomerDate = moment(agentRespondedCustomer._createdDate).format('DD/MM/YYYY HH:mm.ss')
                } else {
                    agentRespondedCustomerDate = ''
                }
                let surveyorAcceptedJobDate
                if (!_.isEmpty(surveyorAcceptedJob)) {
                    surveyorAcceptedJobDate = moment(surveyorAcceptedJob._createdDate).format('DD/MM/YYYY HH:mm.ss')
                } else {
                    surveyorAcceptedJobDate = ''
                }
                let surveyorArrivedDate
                if (!_.isEmpty(surveyorArrived)) {
                    surveyorArrivedDate = moment(surveyorArrived._createdDate).format('DD/MM/YYYY HH:mm.ss')
                } else {
                    surveyorArrivedDate = ''
                }

                let callDate = ''
                let callTime = ''
                if (!_.isEmpty(customerCallDate)) {
                    callDate = moment(customerCallDate._createdDate).format('DD/MM/YYYY')
                    callTime = moment(customerCallDate._createdDate).format('HH:mm.ss')
                }

                let lossDate = ''
                let lossTime = ''
                if (!_.isNil(record.incident._lossInformation) && !_.isNil(record.incident._lossInformation.dateTime)) {
                    lossDate = moment(_.get(record, 'incident._lossInformation.dateTime', '')).format('DD/MM/YYYY')
                    lossTime = moment(_.get(record, 'incident._lossInformation.dateTime', '')).format('HH:mm.ss')
                }

                let periodFrom = ''
                if (!_.isNil(record.incident._policy) && !_.isNil(record.incident._policy.period_from)) {
                // if (!_.isEmpty(_.get(record, 'incident._policy.period_from', ''))) {
                    periodFrom = moment(_.get(record, 'incident._policy.period_from', '')).format('DD/MM/YYYY')
                }

                let periodTo = ''
                if (!_.isNil(record.incident._policy) && !_.isNil(record.incident._policy.period_to)) {
                // if (!_.isEmpty(_.get(record, 'incident._policy.period_to', ''))) {
                    periodTo = moment(_.get(record, 'incident._policy.period_to', '')).format('DD/MM/YYYY')
                }

                let surveyorCompany = ''
                if (!_.isNil(record.incident._surveyor) && !_.isNil(record.incident._surveyor.name)) {
                    surveyorCompany = record.incident._surveyor.name
                }

                content.push({
                    incidentNo: _.get(record, 'incident._id', ''),
                    claimNo: _.get(record, 'incident._claimNo', ''),
                    type: _.get(record, 'incident._incidentType.id', ''),
                    subType: secondSubType,
                    motorClaimType: thirdSubType,
                    callerName: _.get(record, 'incident._callerName', ''),
                    contactNo: _.get(record, 'incident._contactNo', ''),
                    lossInformationDate: lossDate,
                    lossInformationTime: lossTime,
                    createdDate: callDate,
                    createdTime: callTime,
                    agentRespondedCustomer: agentRespondedCustomerDate,
                    surveyorAcceptedJob: surveyorAcceptedJobDate,
                    surveyorArrived: surveyorArrivedDate,
                    lossInformationLocation: _.get(record, 'incident._lossInformation.location', ''),
                    lossInformationDetail: _.get(record, 'incident._lossInformation.detail', ''),
                    insured: _.get(record, 'incident._policy.insured', ''),
                    driverName: _.get(record, 'incident._driverName', ''),
                    registration: _.get(record, 'incident._policy.registration', ''),
                    makeModel: _.get(record, 'incident._policy.make_model', ''),
                    policyNo: _.get(record, 'incident._policy.policy_no', ''),
                    agent: _.get(record, 'incident._createBy', ''),
                    periodFrom,
                    periodTo,
                    coverageType: _.get(record, 'incident._policy.coverage_type', ''),
                    chassis: _.get(record, 'incident._policy.chassis', ''),
                    surveyorCompany,
                    towCompanyName: _.get(record, 'incident._towCompany.name', ''),
                    surveyorName: '',
                    surveyorPhone: '',
                    surveyorNo: '',
                    insuredInjured: _.get(record, 'incident._insured.injured', ''),
                    insuredDeath: _.get(record, 'incident._insured.death', ''),
                    thirdInsuredInjured: _.get(record, 'incident._thirdInsured.injured', ''),
                    thirdInsuredDeath: _.get(record, 'incident._thirdInsured.death', ''),
                    note: _.get(record, 'incident._note', ''),
                    status: _.get(record, 'incident._status.id', ''),
                })
                return content
            }, []),
            mergeMap(model => {
                return from(model)
            }),
        )
    }
}
