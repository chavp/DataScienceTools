import {Entity} from '../../common/entity'
import {ITemplateModel} from './interface/model.interface'

export class TemplateModel extends Entity implements ITemplateModel {
    private _message: string
    private _name: string
    constructor(
        message: string,
    ) {
        super()
        this.setMessage(message)
    }

    public getMessage(): string {
        return this._message
    }

    public getName(): string {
        return this._name
    }

    public setMessage(message: string): void {
        this._message = message
    }

    public setName(name: string): void {
        this._name = name
    }
}
