import {IRepository} from '../../../common/interface/repository.interface'
import {ITemplateModel} from './model.interface'
import {Observable} from 'rxjs'

export interface ITemplateRepository extends IRepository<ITemplateModel> {
    getAll(): Observable<ITemplateModel>
    save(model: ITemplateModel): Observable<{ id: string }>
}
