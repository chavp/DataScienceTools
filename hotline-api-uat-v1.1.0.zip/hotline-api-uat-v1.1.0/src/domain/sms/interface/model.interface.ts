import {IEntity} from '../../../common/interface/entity.interface'

export interface ITemplateModel extends IEntity {
    getMessage(): string

    getName(): string

    setMessage(message: string): void

    setName(name: string): void
}
