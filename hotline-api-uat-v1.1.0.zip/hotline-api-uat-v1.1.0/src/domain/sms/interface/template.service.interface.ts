import {Observable} from 'rxjs'
import {TemplateValidator} from '../../../controller/rest/validator/template.validator'

export interface ITemplateService {
    getAll(): Observable<any>
    create(data: TemplateValidator): Observable<any>
}
