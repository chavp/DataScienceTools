export interface ITemplateValidator {
    getMessage(): string

    getName(): string
}
