import {ITemplateService} from './interface/template.service.interface'
import {ITemplateRepository} from './interface/repository.interface'
import {from, Observable, of} from 'rxjs'
import {TemplateValidator} from '../../controller/rest/validator/template.validator'
import {map, mergeMap, tap} from 'rxjs/operators'
import {ITemplateModel} from './interface/model.interface'
import {HttpException, HttpStatus} from '@nestjs/common'
import * as _ from 'lodash'
import {TemplateModel} from './template.model'
import {ITemplateValidator} from './interface/template.validator.interface'

export class TemplateService implements ITemplateService {
    constructor(
        private readonly _templateRepository: ITemplateRepository,
    ) {
    }

    public create(data: TemplateValidator): Observable<any> {
        const model = new TemplateModel(data.getMessage())
        model.setName(data.getName())
        return of(data).pipe(
            mergeMap(res => {
                return this._templateRepository.save(model)
            }),
        )
    }

    public getAll(): Observable<any> {
        return this._templateRepository.getAll().pipe(
            tap((allTemplate: ITemplateModel) => {
                if (_.isNil(allTemplate)) {
                    throw new HttpException(
                        'Template Not Found',
                        HttpStatus.NOT_FOUND,
                    )
                }
            }),
        )
    }

}
