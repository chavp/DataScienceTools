import { Entity } from '../../common/entity'
import { IManagementQAModel } from './interface/model.interface'
import * as _ from 'lodash'

export class ManagementQAModel extends Entity implements IManagementQAModel {
    private _question: string
    private _maxScore: number
    private _createdAt: Date
    private _score: number
    private _createdBy: string
    private _updatedAt: Date
    private _updatedBy: string

    constructor() {
        super()
    }

    public getMaxScore(): number {
        return this._maxScore
    }

    public getQuestion(): string {
        return this._question
    }

    public getCreatedAt(): Date {
        if ( _.isNil(this._createdAt)) {
            return null
        }
        return new Date(this._createdAt)
    }

    public getValue(): number {
        return this._score
    }

    public getCreatedBy(): string {
        return this._createdBy
    }

    public getUpdatedAt(): Date {
        if ( _.isNil(this._updatedAt)) {
            return null
        }
        return new Date(this._updatedAt)
    }

    public getUpdatedBy(): string {
        return this._updatedBy
    }

    public setMaxScore(maxScore: number): void {
        this._maxScore = maxScore
    }

    public setQuestion(question: string): void {
        this._question = question
    }

    public setCreatedAt(createdAt: Date): void {
        this._createdAt = createdAt
    }

    public setValue(value: number): void {
        this._score = value
    }

    public setCreatedBy(createdBy: string): void {
        this._createdBy = createdBy
    }

    public setUpdatedAt(updatedAt: Date): void {
        this._updatedAt = updatedAt
    }

    public setUpdatedBy(updatedBy: string): void {
        this._updatedBy = updatedBy
    }
}
