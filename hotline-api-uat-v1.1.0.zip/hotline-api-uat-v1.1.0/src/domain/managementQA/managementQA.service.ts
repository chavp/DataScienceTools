import { IManagementQAService } from './interface/service.interface'
import { IManagementQARepository } from './interface/repository.interface'
import {
    forkJoin,
    Observable,
    of,
} from 'rxjs'
import { IManagementQAModel } from './interface/model.interface'
import {
    defaultIfEmpty,
    map,
    mergeMap,
    take,
    tap,
    throwIfEmpty,
} from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import { ManagementQAModel } from './managementQA.model'
import * as _ from 'lodash'
import { IPublisher } from '../../pubsub/interface/publisher.interface'
import { QAEvent } from './pubsub/event/qa.event'
import {
    CreateManagementQAValidator,
    UpdateManagementQAValidator,
} from '../../controller/rest/validator/managementQA.validator'
import { QaRecorder } from '../../pubsub/event.enum'

export class ManagementQAService implements IManagementQAService {
    constructor(
        private readonly _managementQARepository: IManagementQARepository,
        private readonly _publisher: IPublisher<IManagementQAModel>,
    ) {

    }

    public getAll(): Observable<IManagementQAModel> {
        return this._managementQARepository.find().pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `managementQA not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
        )
    }

    public getById(id: string): Observable<IManagementQAModel> {
        return this._managementQARepository.find({_id: id}).pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `ManagementQA ID : ${id} not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
        )
    }

    public save(input: CreateManagementQAValidator): Observable<any> {
        const runningId = () => {
            const running = '0000'
            return running
        }
        return this._managementQARepository.find().pipe(
            map((t: IManagementQAModel) => t.getId()),
            take(1),
            defaultIfEmpty(runningId()),
            map((rid): ManagementQAModel => {
                const id = rid.substr(rid.length - 4)
                const running = +id + 1
                let padding = ''
                padding = this.padLeft(running, 4)
                const model = new ManagementQAModel()
                model.setId(padding)
                model.setQuestion(input.getQuestion())
                model.setMaxScore(input.getMaxScore())
                model.setCreatedAt(new Date())
                return model
            }),
            mergeMap(res => {
                return forkJoin([
                    of(res),
                    this._managementQARepository.save(res),
                ])
            }),
            // tap((result: any[]) => {
            //     const manageQAModel: IManagementQAModel = result[0]
            //     this._publisher.publish(new QAEvent('save-qa-management', manageQAModel))
            // }),
            map((result: any[]) => {
                return result[1]
            }),
        )
    }

    public update(id: string, input: UpdateManagementQAValidator): Observable<IManagementQAModel> {
        return this._managementQARepository.find({_id: id}).pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `QA id: ${id} not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
            map((managementQA: IManagementQAModel) => {
                if (!_.isNil(input.getQuestion())) {
                    managementQA.setQuestion(input.getQuestion())
                }
                if (!_.isNil(input.getMaxScore())) {
                    managementQA.setMaxScore(input.getMaxScore())
                }
                managementQA.setUpdatedAt(new Date())
                return managementQA
            }),
            mergeMap((managementQA: IManagementQAModel) => {
                return this._managementQARepository.update(managementQA).pipe(
                    map((result) => {
                        if (result === true) {
                            return managementQA
                        }
                    }),
                )
            }),
            tap((model: IManagementQAModel) => {
                this._publisher.publish(new QAEvent(model))
            }),
            map((model: IManagementQAModel) => {
                return model
            }),
        )
    }

    private padLeft(nr, n): string {
        return Array(n - String(nr).length + 1).join('0') + nr
    }

}
