import { AbstractDomainEvent } from '../../../../pubsub/abstract.domain-event'
import { IManagementQAModel } from '../../interface/model.interface'
import { IManagementQAEventSchema } from '../../../recorderQA/pubsub/interface/schema.interface'
import { QaRecorder } from '../../../../pubsub/event.enum'

export class QAEvent extends AbstractDomainEvent<IManagementQAModel, IManagementQAEventSchema> {
    constructor( data: IManagementQAModel) {
        super(QaRecorder.RECORDER_QA_MANAGEMENT, data)
    }

    public serialize(model: IManagementQAModel): IManagementQAEventSchema {
        return {
            id: model.getId(),
            question: model.getQuestion(),
            maxScore: model.getMaxScore(),
        }
    }
}
