import { IManagementQAModel } from './model.interface'
import { Observable } from 'rxjs'
import {
    CreateManagementQAValidator,
    UpdateManagementQAValidator,
} from '../../../controller/rest/validator/managementQA.validator'

export interface IManagementQAService {
    getById(id: string): Observable<IManagementQAModel>

    getAll(): Observable<IManagementQAModel>

    save(input: CreateManagementQAValidator): Observable<IManagementQAModel>

    update(id: string, input: UpdateManagementQAValidator): Observable<IManagementQAModel>
}
