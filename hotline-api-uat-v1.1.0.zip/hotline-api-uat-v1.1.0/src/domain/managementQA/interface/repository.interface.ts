import { IRepository } from '../../../common/interface/repository.interface'
import { IManagementQAModel } from './model.interface'
import { Observable } from 'rxjs'

export interface IManagementQARepository extends IRepository<IManagementQAModel> {
    save(model: IManagementQAModel): Observable<{ id: string }>

    find(filter?: any): Observable<IManagementQAModel>

    update(model: IManagementQAModel): Observable<boolean>
}
