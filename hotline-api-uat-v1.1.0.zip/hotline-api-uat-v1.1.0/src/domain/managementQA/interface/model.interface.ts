import { IEntity } from '../../../common/interface/entity.interface'

export interface IManagementQAModel extends IEntity {
    getQuestion(): string
    getMaxScore(): number
    getValue(): number
    getCreatedAt(): Date
    getCreatedBy(): string
    getUpdatedAt(): Date
    getUpdatedBy(): string

    setQuestion(question: string): void
    setMaxScore(maxScore: number): void
    setValue(value: number): void
    setCreatedAt(createdAt: Date): void
    setCreatedBy(createdBy: string): void
    setUpdatedAt(updatedAt: Date): void
    setUpdatedBy(updatedBy: string): void
}
