export interface ICreateManagementQAValidator {
    getQuestion(): string
    getMaxScore(): number
    setCreatedBy(createdBy: string): void
}

export interface IUpdateManagementQAValidator {
    getQuestion(): string
    getMaxScore(): number
    setUpdatedBy(updatedBy: string): void
}
