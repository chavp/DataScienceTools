import { AbstractDomainEvent } from '../../../../pubsub/abstract.domain-event'
import { IIncidentEventSchema } from '../../../surveyor-case/pubsub/interface/schema.interface'
import { IIncidentModel } from '../../interface'
import * as _ from 'lodash'
import {
    IncidentEvent,
} from '../../../../pubsub/event.enum'

export class IncidentAssignSurveyorEvent extends AbstractDomainEvent<IIncidentModel, IIncidentEventSchema> {

    constructor(data: IIncidentModel) {
        super(IncidentEvent.INCIDENT_SURVEYOR_ASSIGNED, data)
    }

    public serialize(model: IIncidentModel): IIncidentEventSchema {
        let place
        if (!_.isNil(model.getSurveyor())) {
            place = model.getSurveyor().place
        } else {
            place = null
        }

        return {
            incidentNo: model.getId(),
            callerName: model.getCallerName(),
            contactNo: model.getContactNo(),
            place,
            lat: model.getSurveyor().lat,
            long: model.getSurveyor().long,
            surveyorNo: model.getSurveyor().id,
            province: model.getSurveyor().province,
            district: model.getSurveyor().district,
            note: model.getSurveyor().note,
            createdBy: model.getCreatedBy(),
        }
    }
}
