import { ITowingService } from './interface/towing.service.interface'
import {
    Observable,
    of,
} from 'rxjs'
import { ITowingRepository } from './interface/towing.repository.interface'
import { tap } from 'rxjs/operators'
import { ITowingModel } from './interface/towing.model.interface'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import * as _ from 'lodash'
import { empty } from 'rxjs/internal/Observer'

export class TowingService implements ITowingService {
    constructor(
        private readonly _towingRepository: ITowingRepository,
    ) {
    }

    public getTowingAll(): Observable<ITowingModel> {
        return this._towingRepository.list()
    }

}
