import {
    forkJoin,
    Observable,
    of,
} from 'rxjs'
import { IIncidentRepository } from './interface'
import {
    mergeMap,
    map,
    reduce,
} from 'rxjs/operators'
import { IDashboardService } from './interface/dashboard.interface'
import {
    IIncidentDeepFilter,
    IIncidentSort,
} from '../../repository/incident/incident.filter'

export class DashboardService implements IDashboardService {
    constructor(
        private readonly _incidentRepository: IIncidentRepository,
    ) {

    }

    public countByStatus(): any {
       return forkJoin([
           this.countAll(),
           this.countToday(),
           this.countYesterday(),
       ]).pipe(
           map((result: any[]) => {
               return {
                   all: result[0],
                   today: result[1],
                   yesterday: result[2],
               }
           }),
       )
    }

    private countAll(): Observable<any> {
        const dataStatus = {
            statusOpen: 0,
            statusProcessing: 0,
            statusClose: 0,
            statusAppointment: 0,
            statusTotal: 0,
        }

        return this._incidentRepository.find().pipe(
            reduce((data, item: any) => {
                if (item._status.id === 'open') {
                    ++data.statusTotal
                    ++data.statusOpen
                    return data
                }
                if (item._status.id === 'processing') {
                    ++data.statusTotal
                    ++data.statusProcessing
                    return data
                }
                if (item._status.id === 'close') {
                    ++data.statusTotal
                    ++data.statusClose
                    return data
                }
                if (item._status.id === 'appointment-due') {
                    ++data.statusTotal
                    ++data.statusAppointment
                    return data
                }
                return data
            }, dataStatus),
        )
    }

    private countYesterday(): Observable<any> {
        const dataStatus = {
            statusOpen: 0,
            statusProcessing: 0,
            statusClose: 0,
            statusAppointment: 0,
            statusTotal: 0,
        }

        const today = new Date()
        const date = today.getDate() - 1
        const month = today.getMonth() + 1
        const year = today.getFullYear()
        const start = year + '-' + month + '-' + date + ' 00:00'
        const end = year + '-' + month + '-' + date + ' 23:59'

        const yesterdayFilter = {
            $and: [
                {
                    createdAt: {
                        $gte: new Date(start),
                    },
                },
                {
                    createdAt: {
                        $lte: new Date(end),
                    },
                },
            ],
        }

        return this._incidentRepository.find(yesterdayFilter).pipe(
            reduce((data, item: any) => {
                if (item._status.id === 'open') {
                    ++data.statusTotal
                    ++data.statusOpen
                    return data
                }
                if (item._status.id === 'processing') {
                    ++data.statusTotal
                    ++data.statusProcessing
                    return data
                }
                if (item._status.id === 'close') {
                    ++data.statusTotal
                    ++data.statusClose
                    return data
                }
                if (item._status.id === 'appointment-due') {
                    ++data.statusTotal
                    ++data.statusAppointment
                    return data
                }
                return data
            }, dataStatus),
        )
    }

    private countToday(): Observable<any> {
        const dataStatus = {
            statusOpen: 0,
            statusProcessing: 0,
            statusClose: 0,
            statusAppointment: 0,
            statusTotal: 0,
        }

        const today = new Date()
        const date = today.getDate()
        const month = today.getMonth() + 1
        const year = today.getFullYear()
        const start = year + '-' + month + '-' + date + ' 00:00'
        const end = year + '-' + month + '-' + date + ' 23:59'

        const todayFilter = {
            $and: [
                {
                    createdAt: {
                        $gte: new Date(start),
                    },
                },
                {
                    createdAt: {
                        $lte: new Date(end),
                    },
                },
            ],
        }

        return this._incidentRepository.find(todayFilter).pipe(
            reduce((data, item: any) => {
                if (item._status.id === 'open') {
                    ++data.statusTotal
                    ++data.statusOpen
                    return data
                }
                if (item._status.id === 'processing') {
                    ++data.statusTotal
                    ++data.statusProcessing
                    return data
                }
                if (item._status.id === 'close') {
                    ++data.statusTotal
                    ++data.statusClose
                    return data
                }
                if (item._status.id === 'appointment-due') {
                    ++data.statusTotal
                    ++data.statusAppointment
                    return data
                }
                return data
            }, dataStatus),
        )
    }

    public filterIncident(filter): Observable<any> {
        const incidentFilter = filter.filter
        const incidentSorting = filter.sorting
        return this._incidentRepository.filter(incidentFilter,  incidentSorting)
    }

    public filterIncidentExcel(filter): Observable<any> {
        return this._incidentRepository.findAll(filter)
    }

}
