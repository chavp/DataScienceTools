import { Entity } from '../../common/entity'
import { IIncidentStatusModel } from './interface/status.model.interface'

export class IncidentStatusModel extends Entity implements IIncidentStatusModel {
    private _status: string
    private _used: boolean

    constructor(
        name: string,
    ) {
        super()
        this.setName(name)
    }

    public getName(): string {
        return this._status
    }

    public setName(status: string): void {
        this._status = status
    }

    public getUsed(): boolean {
        return this._used
    }

    public setUsed(used: boolean): void {
        this._used = used
    }

}
