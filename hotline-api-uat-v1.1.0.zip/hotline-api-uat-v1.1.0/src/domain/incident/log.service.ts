import { IIncidentLogService } from './interface/log.service.interface'
import {
    map,
    mergeMap,
} from 'rxjs/operators'
import { Observable } from 'rxjs'
import {
    IIncidentLogModel,
    IIncidentLogRecordModel,
    IIncidentLogRepository,
} from './interface'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import * as _ from 'lodash'

export class IncidentLogService implements IIncidentLogService {
    constructor(
        private readonly _incidentLogRepository: IIncidentLogRepository,
    ) {

    }

    public getById(id: string): Observable<IIncidentLogModel> {
        return this._incidentLogRepository.getById(id).pipe(
            map(result => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `Incident Log not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }

                return result
            }),
        )
    }

    public getRecordById(id: string): Observable<IIncidentLogRecordModel> {
        return this._incidentLogRepository.getById(id).pipe(
            map(result => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `Incident Log not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }
                return result
            }),
            mergeMap(result => {
                return result.getLogs() as IIncidentLogRecordModel[]
            }),
        )
    }
}
