import { Entity } from '../../common/entity'
import { ITowingModel } from './interface/towing.model.interface'

export class TowingModel extends Entity implements ITowingModel {
    private _name: string
    private _used: boolean

    constructor(name: string) {
        super()
        this._name = name
    }
    public getName(): string {
        return this._name
    }

    public setName(name: string): void {
        this._name = name
    }

    public getUsed(): boolean {
        return this._used
    }

    public setUsed(used: boolean): void {
        this._used = used
    }
}
