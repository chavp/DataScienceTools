export enum StatusEnum {
    OPEN = 'open',
    PROCESSING = 'processing',
    CLOSE = 'close',
    APPOINTMENT_DUE = 'appointment-due',
}
