import * as UUID from 'uuid'
import * as _ from 'lodash'
import { Entity } from '../../common/entity'
import {
    IIncidentLogModel,
    IIncidentLogRecordModel,
    IInputStatus,
} from './interface'
import { IAs400PolicySchema } from '../../adapter/as400/interface/schema.interface'
import { WorkFlowEnum } from '../../repository/incident/log.schema'

export class IncidentLogRecordModel extends Entity implements IIncidentLogRecordModel {
    private _createdDate: Date
    private readonly _createdBy: string
    private _note: string
    private _status: IInputStatus
    private _workFlow: WorkFlowEnum

    constructor(creator: string, note: string) {
        super()
        this._createdDate = new Date()
        this.setId(UUID.v4())
        this._createdBy = creator
        this._note = note
    }

    public getCreatedBy(): string {
        return this._createdBy
    }

    public getCreatedTime(): Date {
        return this._createdDate
    }

    public setCreatedTime(time: number): void {
        if (!_.isNil(time)) {
            this._createdDate = new Date(time)
        } else {
            this._createdDate = new Date()
        }
    }

    public getNote(): string {
        return this._note
    }

    public setNote(note: string): void {
        this._note = note
    }

    public getStatus(): IInputStatus {
        return this._status
    }

    public setStatus(status: IInputStatus): void {
        this._status = status
    }

    public getWorkFlow(): WorkFlowEnum {
        return this._workFlow
    }

    public setWorkFlow(workFlow: WorkFlowEnum): void {
        this._workFlow = workFlow
    }
}

export class IncidentLogModel extends Entity implements IIncidentLogModel {
    private _logs: IIncidentLogRecordModel[]
    private _policy: IAs400PolicySchema
    private readonly _lastUpdate: Date
    private _createdDate: Date

    constructor() {
        super()

        this._logs = []
    }

    public appendLog(log: IIncidentLogRecordModel): number {
        this._logs.push(log)
        this._logs = _.sortBy(this._logs, (o: IIncidentLogRecordModel) => o.getCreatedTime().getTime())
        return this._logs.length
    }

    public getCreatedTime(): Date {
        return _.cloneDeep(this._createdDate)
    }

    public setCreatedTime(date: Date): void {
        this._createdDate = date
    }

    public getLastUpdate(): Date {
        return _.cloneDeep(this._lastUpdate)
    }

    public getLogs(): IIncidentLogRecordModel[] {
        return _.slice(this._logs)
    }

    public getPolicy(): IAs400PolicySchema {
        return _.cloneDeep(this._policy)
    }

    public setPolicy(policy: IAs400PolicySchema): void {
        this._policy = policy
    }
}
