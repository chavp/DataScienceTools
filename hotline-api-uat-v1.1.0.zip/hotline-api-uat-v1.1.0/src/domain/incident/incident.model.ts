import * as _ from 'lodash'
import { Entity } from '../../common/entity'
import { IAs400PolicySchema } from '../../adapter/as400/interface/schema.interface'
import {
    IIncidentModel,
    IInputCompany,
    IInputInsured,
    IInputLossInfo,
    IInputStatus,
    IInputSurveyor,
    IInputThirdInsured,
    IInputTowing,
    IInputType,
} from './interface'

export class IncidentModel extends Entity implements IIncidentModel {
    private _contactNo: string
    private _callerName: string
    private _incidentType: IInputType
    private _status: IInputStatus
    private _appointmentDate: Date
    private _claimNo: string
    private _companyInfo: IInputCompany
    private _lossInformation: IInputLossInfo
    private _driverName: string
    private _towCompany: IInputTowing
    private _note: string
    private _insured: IInputInsured
    private _thirdInsured: IInputThirdInsured
    private _policy: IAs400PolicySchema
    private _surveyor: IInputSurveyor
    private _updatedAt: Date
    private _updatedBy: string
    private _createdAt: Date
    private _createdBy: string

    constructor(
        contactNo: string,
        callerName: string,
    ) {
        super()
        this.setContactNo(contactNo)
        this.setCallerName(callerName)
    }

    public getAppointmentDate(): Date {
        if ( _.isNil(this._appointmentDate)) {
            return null
        }
        return new Date(this._appointmentDate)
    }

    public getCallerName(): string {
        return this._callerName
    }

    public getClaimNo(): string {
        return this._claimNo
    }

    public getCompanyInfo(): IInputCompany {
        return this._companyInfo
    }

    public getContactNo(): string {
        return this._contactNo
    }

    public getCreatedBy(): string {
        return this._createdBy
    }

    public getCreatedAt(): Date {
        return new Date(this._createdAt)
    }

    public getDriverName(): string {
        return this._driverName
    }

    public getIncidentType(): IInputType {
        return this._incidentType
    }

    public getInsured(): IInputInsured {
        return this._insured
    }

    public getLossInformation(): IInputLossInfo {
        return this._lossInformation
    }

    public getNote(): string {
        return this._note
    }

    public getStatus(): IInputStatus {
        return this._status
    }

    public getThirdInsured(): IInputThirdInsured {
        return this._thirdInsured
    }

    public getTowCompany(): IInputTowing {
        return this._towCompany
    }

    public getPolicy(): IAs400PolicySchema {
        return this._policy
    }

    public getSurveyor(): IInputSurveyor {
        return this._surveyor
    }

    public getUpdatedBy(): string {
        return this._updatedBy
    }

    public getUpdatedAt(): Date {
        return new Date(this._updatedAt)
    }

    public setAppointmentDate(appointmentDate: Date): void {
        this._appointmentDate = appointmentDate
    }

    public setCallerName(callerName: string): void {
        this._callerName = callerName
    }

    public setClaimNo(claimNo: string): void {
        this._claimNo = claimNo
    }

    public setCompanyInfo(companyInfo: IInputCompany): void {
        this._companyInfo = companyInfo
    }

    public setContactNo(contactNo: string): void {
        this._contactNo = contactNo
    }

    public setCreatedBy(createdBy: string): void {
        this._createdBy = createdBy
    }

    public setCreatedAt(createdAt: Date): void {
        this._createdAt = createdAt
    }

    public setDriverName(driverName: string): void {
        this._driverName = driverName
    }

    public setIncidentType(incidentType: IInputType): void {
        this._incidentType = incidentType
    }

    public setInsured(insured: IInputInsured): void {
        this._insured = insured
    }

    public setLossInformation(lossInformation: IInputLossInfo): void {
        this._lossInformation = lossInformation
    }

    public setNote(note: string): void {
        this._note = note
    }

    public setStatus(status: IInputStatus): void {
        this._status = status
    }

    public setThirdInsured(thirdInsured: IInputThirdInsured): void {
        this._thirdInsured = thirdInsured
    }

    public setTowCompany(towCompany: IInputTowing): void {
        this._towCompany = towCompany
    }

    public setPolicy(policy: IAs400PolicySchema): void {
        this._policy = policy
    }

    public setSurveyor(surveyor: IInputSurveyor): void {
        this._surveyor = surveyor
    }

    public setUpdatedBy(updatedBy: string): void {
        this._updatedBy = updatedBy
    }

    public setUpdatedAt(updatedAt: Date): void {
        this._updatedAt = updatedAt
    }

}
