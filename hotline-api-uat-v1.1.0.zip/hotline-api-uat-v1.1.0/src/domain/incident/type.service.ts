import { Observable } from 'rxjs'
import { IIncidentTypeService } from './interface/type.service.interface'
import { IIncidentTypeRepository } from './interface/type.repository.interface'
import {
    map,
    throwIfEmpty,
} from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import * as _ from 'lodash'

export class IncidentTypeService implements IIncidentTypeService {
    constructor(
        private readonly _incidentTypeRepository: IIncidentTypeRepository,
    ) {

    }

    public find(): Observable<any> {
        return this._incidentTypeRepository.find().pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `type not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
        )
    }

    public getById(id: string): Observable<any> {
        return this._incidentTypeRepository.getById(id).pipe(
            map(result => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `type not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }

                return result
            }),
        )
    }

}
