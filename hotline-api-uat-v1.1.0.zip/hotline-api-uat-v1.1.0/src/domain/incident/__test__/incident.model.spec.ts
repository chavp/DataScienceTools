import { IncidentModel } from '../incident.model'
import { plainToClass } from 'class-transformer'

describe('Incident Model', () => {

    let model: IncidentModel = null

    beforeEach(() => {
        model = plainToClass(IncidentModel, {
            _id: 'test123',
            _createdBy: 'user1',
            _updateBy: '',
        })

    })

    it('should stamp agent name', () => {
        model.setUpdatedBy('test')
        expect(model.getUpdatedBy()).toEqual('test')
    })
})
