import {
    IIncidentBuilder,
} from './interface/builder.interface'
import { IncidentModel } from './incident.model'
import {
    IIncidentModel,
    IIncidentStatusValidator,
    IIncidentValidator,
    IInputCompany,
    IInputInsured,
    IInputLossInfo,
    IInputStatus,
    IInputThirdInsured,
    IInputTowing,
    IInputType,
} from './interface'
import * as _ from 'lodash'
import { IAs400PolicySchema } from '../../adapter/as400/interface/schema.interface'

export class SaveIncidentBuilder implements IIncidentBuilder {
    private model: IncidentModel

    public build(): IncidentModel {
        return this.model
    }

    public init(
        contactNo: string,
        callerName: string,
    ) {
        this.model = new IncidentModel(
            contactNo,
            callerName,
        )
        return this
    }

    public setId(id: string) {
        this.model.setId(id)
        return this
    }

    public setAppointmentDate(appointmentDate: Date) {
        this.model.setAppointmentDate(appointmentDate)
        return this
    }

    public setCallerName(callerName: string) {
        this.model.setCallerName(callerName)
        return this
    }

    public setClaimNo(claimNo: string) {
        this.model.setClaimNo(claimNo)
        return this
    }

    public setCompanyInfo(companyInfo: IInputCompany) {
        this.model.setCompanyInfo(companyInfo)
        return this
    }

    public setContactNo(contactNo: string) {
        this.model.setContactNo(contactNo)
        return this
    }

    public setDriverName(driverName: string) {
        this.model.setDriverName(driverName)
        return this
    }

    public setIncidentType(incidentType: IInputType) {
        this.model.setIncidentType(incidentType)
        return this
    }

    public setInsured(insured: IInputInsured) {
        this.model.setInsured(insured)
        return this
    }

    public setLossInformation(lossInformation: IInputLossInfo) {
        this.model.setLossInformation(lossInformation)
        return this
    }

    public setNote(note: string) {
        this.model.setNote(note)
        return this
    }

    public setPolicy(policy: IAs400PolicySchema) {
        this.model.setPolicy(policy)
        return this
    }

    public setStatus(status: IInputStatus) {
        this.model.setStatus(status)
        return this
    }

    public setThirdInsured(thirdInsured: IInputThirdInsured) {
        this.model.setThirdInsured(thirdInsured)
        return this
    }

    public setTowCompany(towCompany: IInputTowing) {
        this.model.setTowCompany(towCompany)
        return this
    }

    public setUpdatedAt(updateAt: Date) {
        this.model.setUpdatedAt(updateAt)
        return this
    }

    public setUpdatedBy(updatedBy: string) {
        this.model.setUpdatedBy(updatedBy)
        return this
    }

    public setCreatedAt(createdAt: Date) {
        this.model.setCreatedAt(createdAt)
        return this
    }

    public setCreatedBy(createdBy: string) {
        this.model.setCreatedBy(createdBy)
        return this
    }
}

export class UpdateIncidentBuilder {
    public static compareIncidentModel(model: IIncidentValidator, target?: IIncidentModel): IIncidentModel {
        let incident: any

        if (_.isNil(target)) {
            incident = new SaveIncidentBuilder()
        } else {
            incident = target
        }

        if (!_.isNil(model.getIncidentType())) {
            incident.setIncidentType(incident.getIncidentType())
        }
        if (!_.isNil(model.getCompanyInfo())) {
            incident.setCompanyInfo(model.getCompanyInfo())
        }
        if (!_.isNil(model.getLossInformation())) {
            incident.setLossInformation(model.getLossInformation())
        }
        if (!_.isNil(model.getAppointmentDate())) {
            incident.setAppointmentDate(model.getAppointmentDate())
        }
        if (!_.isNil(model.getClaimNo())) {
            incident.setClaimNo(model.getClaimNo())
        }
        if (!_.isNil(model.getDriverName())) {
            incident.setDriverName(model.getDriverName())
        }
        if (!_.isNil(model.getTowCompany())) {
            incident.setTowCompany(incident.getTowCompany())
        }
        if (!_.isNil(model.getNote())) {
            incident.setNote(model.getNote())
        }
        if (!_.isNil(model.getInsured())) {
            incident.setInsured(model.getInsured())
        }
        if (!_.isNil(model.getThirdInsured())) {
            incident.setThirdInsured(model.getThirdInsured())
        }

        incident.setUpdatedAt(new Date())

        return incident
    }

    public static compareIncidentStatus(model: IIncidentStatusValidator, target?: IIncidentModel): IIncidentModel {
        if (!_.isNil(model.getStatus())) {
            target.setStatus(target.getStatus())
        }

        return target
    }
}
