import { Entity } from '../../common/entity'
import { IIncidentTypeModel } from './interface/type.model.interface'
import * as _ from 'lodash'

export class IncidentTypeModel extends Entity implements IIncidentTypeModel {
    private _name: string
    private readonly _subType: Map<string, IIncidentTypeModel>

    constructor(
        name: string,
    ) {
        super()
        this.setName(name)
        this.setId(_.kebabCase(name))
        this._subType = new Map<string, IIncidentTypeModel>()
    }

    public getName(): string {
        return this._name
    }

    public getSubType(): IIncidentTypeModel[] {
        const types = []
        this._subType.forEach((value) => {
            types.push(value)
        })

        return types
    }

    public setName(name: string): void {
        this._name = name
    }

    public addSubType(subType: IIncidentTypeModel): void {
        this.assertTrue(_.isNil(this._subType.get(subType.getId())),
            'cannot set same type',
        )
        this._subType.set(subType.getId(), subType)
    }
}
