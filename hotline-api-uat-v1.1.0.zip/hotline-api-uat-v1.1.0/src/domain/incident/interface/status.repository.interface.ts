import { IRepository } from '../../../common/interface/repository.interface'
import { Observable } from 'rxjs'
import { IIncidentStatusModel } from './status.model.interface'

export interface IIncidentStatusRepository extends IRepository<IIncidentStatusModel> {
    getById(id: string): Observable<IIncidentStatusModel>

    find(filter?: any): Observable<IIncidentStatusModel>
}
