import { IEntity } from '../../../common/interface/entity.interface'

export interface IIncidentStatusModel extends IEntity {
    getName(): string,

    setName(status: string): void,

    getUsed(): boolean,

    setUsed(used: boolean): void
}
