import { IEntity } from '../../../common/interface/entity.interface'
import { IPolicySchema } from '../../../repository/incident/incident.policy'
import {
    IInputCompany,
    IInputInsured,
    IInputLossInfo,
    IInputTowing,
    IInputStatus,
    IInputThirdInsured,
    IInputSurveyor,
    IInputType,
} from './validator.interface'
import { IAs400PolicySchema } from '../../../adapter/as400/interface/schema.interface'
import { WorkFlowEnum } from '../../../repository/incident/log.schema'

export interface IIncidentModel extends IEntity {
    getContactNo(): string,

    getCallerName(): string,

    getIncidentType(): IInputType,

    getStatus(): IInputStatus,

    getAppointmentDate(): Date,

    getClaimNo(): string,

    getCompanyInfo(): IInputCompany,

    getLossInformation(): IInputLossInfo,

    getDriverName(): string,

    getTowCompany(): IInputTowing,

    getNote(): string,

    getInsured(): IInputInsured,

    getThirdInsured(): IInputThirdInsured,

    getPolicy(): IAs400PolicySchema,

    getSurveyor(): IInputSurveyor,

    getUpdatedAt(): Date,

    getUpdatedBy(): string,

    getCreatedAt(): Date,

    getCreatedBy(): string,

    setContactNo(contactNo: string): void,

    setCallerName(callerName: string): void,

    setIncidentType(incidentType: IInputType): void,

    setStatus(status: IInputStatus): void,

    setAppointmentDate(appointmentDate: Date): void,

    setClaimNo(claimNo: string): void,

    setCompanyInfo(companyInfo: IInputCompany): void,

    setLossInformation(lossInformation: IInputLossInfo): void,

    setDriverName(driverName: string): void,

    setTowCompany(towCompany: IInputTowing): void,

    setNote(note: string): void,

    setInsured(insured: IInputInsured): void,

    setThirdInsured(thirdInsured: IInputThirdInsured): void,

    setPolicy(policy: IAs400PolicySchema): void,

    setSurveyor(surveyor: IInputSurveyor): void,

    setUpdatedAt(updatedAt: Date): void,

    setUpdatedBy(updatedBy: string): void,

    setCreatedAt(createdAt: Date): void,

    setCreatedBy(createdBy: string): void,
}

export interface IAs400Model extends IEntity {
    getPolicyNo(): string
    getBranch(): string
    getInsured(): string
    getAgentCode(): string
    getModel(): string
    getAgentName(): string
    getPeriodFrom(): string
    getPeriodTo(): string
    getRegistration(): string
    getPolicyStatus(): string
    getCoveragePeriod(): string[]
    getProductName(): string
    getCoverageType(): string
    getCover(): string
    getContractType(): string
    getRiskType(): string
    getCoSi(): string
    getTfSi(): string
    getLongName(): string
    getDriverName(): string
    getChassis(): string
    getExcess(): string
    getOd(): string[]
    getTp(): string
    getReference(): string
    getGenPage1(): string
    getGenPage2(): string
    getEndNote(): string

    setPolicyNo(policyNo: string): void
    setBranch(branch: string): void
    setInsured(insured: string): void
    setAgentCode(agentCode: string): void
    setModel(model: string): void
    setAgentName(agentName: string): void
    setPeriodFrom(periodFrom: string): void
    setPeriodTo(periodTo: string): void
    setRegistration(registration: string): void
    setPolicyStatus(policyStatus: string): void
    setCoveragePeriod(coveragePeriod: string[]): void
    setProductName(productName: string): void
    setCoverageType(coverageType: string): void
    setCover(cover: string): void
    setContactType(contactType: string): void
    setRiskType(riskType: string): void
    setCoSi(coSi: string): void
    setTfSi(tfSi: string): void
    setLongName(longName: string): void
    setDriverName(driverName: string): void
    setChassis(chassis: string): void
    setExcess(excess: string): void
    setOd(od: string[]): void
    setTp(tp: string): void
    setReference(reference: string): void
    setGenPage1(genPage1: string): void
    setGenPage2(genPage2: string): void
    setEndNote(endNote: string): void
}

export interface IIncidentLogRecordModel extends IEntity {
    getCreatedTime(): Date
    setCreatedTime(time: number): void
    getCreatedBy(): string
    getNote(): string
    setNote(note: string): void
    getStatus(): IInputStatus
    setStatus(status: IInputStatus): void
    getWorkFlow(): WorkFlowEnum
    setWorkFlow(workFlow: WorkFlowEnum): void
}
export interface IIncidentLogModel extends IEntity {
    getPolicy(): IAs400PolicySchema
    setPolicy(policy: IAs400PolicySchema): void
    getCreatedTime(): Date
    setCreatedTime(date: Date): void
    getLastUpdate(): Date
    getLogs(): IIncidentLogRecordModel[]
    appendLog(log: IIncidentLogRecordModel): number
}
