import { IEntity } from '../../../common/interface/entity.interface'

export interface IIncidentTypeModel extends IEntity {
    getName(): string,

    getSubType(): IIncidentTypeModel[],

    setName(name: string): void,

    addSubType(subType: IIncidentTypeModel): void,
}
