import { IRepository } from '../../../common/interface/repository.interface'
import { Observable } from 'rxjs'
import {
    IIncidentLogModel,
    IIncidentModel,
} from './model.interface'
import {
    IIncidentDeepFilter,
    IIncidentSort,
} from '../../../repository/incident/incident.filter'

export interface IIncidentRepositoryFilter {
    type?: string,
    agent?: string,
    status?: string,
    subType?: string,
    incidentDateRange?: IDateRangeFilter,
    appointmentDateRange?: IDateRangeFilter,
}

export interface IDateRangeFilter {
    from?: Date,
    to?: Date,
}

export interface IIncidentRepository extends IRepository<IIncidentModel> {
    find(filter?: any): Observable<IIncidentModel>

    save(model: IIncidentModel): Observable<{ id: string }>

    update(model: IIncidentModel): Observable<{ id: string }>

    findAll(filter?: IIncidentRepositoryFilter): Observable<IIncidentModel>

    findByReport(filter?: IIncidentRepositoryFilter): Observable<IIncidentModel>

    filter(filter: IIncidentDeepFilter, sorting?: IIncidentSort): Observable<IIncidentModel>

    reportFindAll(): Observable<IIncidentModel>

    getById(id: string): Observable<IIncidentModel>
}

export interface IIncidentLogRepository extends IRepository<IIncidentLogModel> {
    save(model: IIncidentLogModel): Observable<{ id: string }>

    update(model: IIncidentLogModel): Observable<{ id: string }>

    getById(id: string): Observable<IIncidentLogModel>

    getReportById(id: string): Observable<any>
}
