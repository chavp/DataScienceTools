import { WorkFlowEnum } from '../../../repository/incident/log.schema'

export interface IIncidentValidator {
    getContactNo(): string
    getCallerName(): string
    getIncidentType(): IInputType
    getStatus(): IInputStatus
    getAppointmentDate(): Date
    getClaimNo(): string
    getCompanyInfo(): IInputCompany
    getLossInformation(): IInputLossInfo
    getDriverName(): string
    getTowCompany(): IInputTowing
    getNote(): string
    getInsured(): IInputInsured
    getThirdInsured(): IInputThirdInsured
    getPolicyNumber(): IInputPolicy
    getUpdatedBy(): string
    getCreatedBy(): string
    setCreatedBy(createdBy: string): void
    getCallTime(): number
    setUpdatedBy(name: string): void
}

export interface IIncidentStatusValidator {
    getStatus(): IInputStatus
    getUpdatedBy(): string
    setUpdatedBy(updatedBy: string): void
}

export interface IIncidentLogValidator {
    getNote(): string
    getStatus(): IInputStatus
    getCreatedBy(): string
    setCreatedBy(createdBy: string): void
    getWorkFlow(): WorkFlowEnum
}

export interface IIncidentSurveyorValidator {
    getSurveyor(): IInputSurveyor
    getUpdatedBy(): string
    setUpdatedBy(updatedBy: string): void
}

export interface IInputStatus {
    id: string,
    name: string,
    used?: boolean,
}

export interface IInputType {
    id: string,
    name: string,
    subType: IInputType
}

export interface IInputCompany {
    policyNo: string,
    claimNo: string,
}

export interface IInputTowing {
    id: string,
    name: string,
    used: boolean,
}

export interface IInputInsured {
    injured: number,
    death: number,
}

export interface IInputThirdInsured {
    injured: number,
    death: number,
}

export interface IInputLossInfo {
    detail: string,
    location: string,
    dateTime: number,
}

export interface IInputPolicy {
    policyNo: string,
    riskId: string,
}

export interface IInputSurveyor {
    id: string,
    name: string,
    phone: string,
    place: string,
    lat: number,
    long: number,
    note: string,
    province: string,
    district: string,
}
