import { Observable } from 'rxjs'
import { ITowingModel } from './towing.model.interface'

export interface ITowingService {
    getTowingAll(): Observable<ITowingModel>
}
