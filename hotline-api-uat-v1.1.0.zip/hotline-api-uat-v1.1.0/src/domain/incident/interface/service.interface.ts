import { Observable } from 'rxjs'
import { IIncidentFilterSchema } from '../../../repository/incident/incident.filter'
import { IIncidentModel } from './model.interface'
import {
    SaveIncidentValidator,
    UpdateIncidentLogValidator,
    UpdateIncidentStatusValidator,
    UpdateIncidentSurveyorValidator,
    UpdateIncidentValidator,
} from '../../../controller/rest/validator/incident.validator'

export interface IIncidentService {
    find(filter: IIncidentFilterSchema): Observable<IIncidentModel>

    getById(id: string): Observable<IIncidentModel>

    getAll(): Observable<IIncidentModel>

    save(model: SaveIncidentValidator): Observable<{id: string}>

    updateIncident(id: string, input: UpdateIncidentValidator): Observable<{id: string}>

    updateStatus(id: string, input: UpdateIncidentStatusValidator): Observable<any>

    updateLog(id: string, input: UpdateIncidentLogValidator): Observable<any>

    exportSearchExcel(sheetName: string, model: any): Observable<any>

    assignToSurveyor(incidentId: string, inputSurveyor: UpdateIncidentSurveyorValidator): Observable<any>
}
