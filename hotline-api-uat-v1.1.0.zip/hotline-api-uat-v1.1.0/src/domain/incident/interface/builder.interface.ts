import { IncidentModel } from '../incident.model'
import {
    IInputCompany,
    IInputInsured,
    IInputLossInfo,
    IInputStatus,
    IInputThirdInsured,
    IInputTowing,
    IInputType,
} from './validator.interface'
import {
    IAs400PolicySchema,
} from '../../../adapter/as400/interface/schema.interface'

export interface IIncidentBuilder {
    build(): IncidentModel
    init(contactNo: string, callerName: string): void

    setId(id: string)
    setContactNo(contactNo: string)
    setCallerName(callerName: string)
    setIncidentType(incidentType: IInputType)
    setStatus(status: IInputStatus)
    setAppointmentDate(appointmentDate: Date)
    setClaimNo(claimNo: string)
    setCompanyInfo(companyInfo: IInputCompany)
    setLossInformation(lossInformation: IInputLossInfo)
    setDriverName(driverName: string)
    setTowCompany(towCompany: IInputTowing)
    setNote(note: string)
    setInsured(insured: IInputInsured)
    setThirdInsured(thirdInsured: IInputThirdInsured)
    setPolicy(policy: IAs400PolicySchema)
    setUpdatedAt(updateAt: Date)
    setUpdatedBy(updatedBy: string)
    setCreatedAt(createdAt: Date)
    setCreatedBy(createdBy: string)
}
