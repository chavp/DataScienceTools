import { Observable } from 'rxjs'
import { IRepository } from '../../../common/interface/repository.interface'
import { IIncidentModel } from './model.interface'

export interface IIncidentTypeRepository extends IRepository<IIncidentModel> {
    find(): Observable<any>
    getById(id: string): Observable<any>
}
