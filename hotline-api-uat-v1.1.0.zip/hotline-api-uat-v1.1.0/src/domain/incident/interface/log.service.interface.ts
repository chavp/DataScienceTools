import { Observable } from 'rxjs'
import {
    IIncidentLogModel,
    IIncidentLogRecordModel,
} from './model.interface'

export interface IIncidentLogService {
    getById(id: string): Observable<IIncidentLogModel>
    getRecordById(id: string): Observable<IIncidentLogRecordModel>
}
