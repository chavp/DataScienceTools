import { IRepository } from '../../../common/interface/repository.interface'
import { Observable } from 'rxjs'
import { ITowingModel } from './towing.model.interface'
import { ObjectId } from 'bson'

export interface ITowingRepository extends IRepository<ITowingModel> {
    getById(id: string): Observable<ITowingModel>
}
