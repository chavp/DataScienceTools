import { IEntity } from '../../../common/interface/entity.interface'

export interface ITowingModel extends IEntity {
    getId(): string
    setId(id: string): void
    getName(): string
    setName(name: string): void
    getUsed(): boolean
    setUsed(used: boolean): void
}
