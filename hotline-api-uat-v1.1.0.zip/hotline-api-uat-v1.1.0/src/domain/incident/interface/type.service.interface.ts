import { Observable } from 'rxjs'

export interface IIncidentTypeService {
    find(): Observable<any>
    getById(id: string): Observable<any>
}
