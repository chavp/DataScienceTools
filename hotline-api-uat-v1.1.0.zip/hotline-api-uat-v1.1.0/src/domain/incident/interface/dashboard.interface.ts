import { Observable } from 'rxjs'

export interface IDashboardService {
    countByStatus(): Observable<any>

    filterIncident(filter): Observable<any>

    filterIncidentExcel(filter): Observable<any>
}
