import { ILineProfileModel } from './model.interface'
import { IMessageModel } from '../../message/interface'

export interface IMapResult {
    model: ILineProfileModel
    totalUnread: number
    lastMessage: string
    timeStamp: Date
    isRegister: boolean
}

export interface ILineProfileAllMessage {
    profile: ILineProfileModel
    message: IMessageModel[]
}
