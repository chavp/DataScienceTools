import { ILineProfileModel } from './model.interface'
import { Observable } from 'rxjs'
import { IRepository } from '../../../common/interface/repository.interface'

export interface ILineProfileRepository extends IRepository<ILineProfileModel> {
    save(model: ILineProfileModel): Observable<any>

    getByLineId(lineId: string): Observable<ILineProfileModel>

    update(model: ILineProfileModel): Observable<boolean>

    find(filter?: any): Observable<any>

    findMessages(userId: string, userType: string): Observable<any>
}
