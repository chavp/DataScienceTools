import { IEntity } from 'common/interface/entity.interface'
import { IMessage } from '../../../repository/line/line.schema'

export interface ILineProfileModel extends IEntity {
    getDisplayName(): string

    getPictureUrl(): string

    getIsFollow(): boolean

    getCreateDate(): Date

    getIsRegister(): boolean

    getPhone(): string

    getIncidentNo(): string

    setDisplayName(displayName: string): void

    setPictureUrl(pictureUrl: string): void

    setIsFollow(isFollow: boolean): void

    setCreateDate(): void

    setIsRegister(isRegister: boolean): void

    setPhone(phone: string): void

    setIncidentNo(incidentNo: string): void
}
