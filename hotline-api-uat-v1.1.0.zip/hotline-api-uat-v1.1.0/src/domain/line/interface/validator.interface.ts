
export interface IRegisterLineValidator {
    getPhone(): string
}
