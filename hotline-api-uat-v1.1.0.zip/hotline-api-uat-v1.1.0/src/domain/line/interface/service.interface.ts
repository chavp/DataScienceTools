import { Observable } from 'rxjs'
import {
    FileEventMessage,
    FollowEvent,
    ImageEventMessage,
    JoinEvent,
    LeaveEvent,
    LocationEventMessage,
    MessageEvent,
    StickerEventMessage,
    TextEventMessage,
    UnfollowEvent,
} from '@line/bot-sdk/lib/types'
import {
    IRegisterLineValidator,
} from './validator.interface'
import {
    ILineProfileAllMessage,
    IMapResult,
} from './result.interface'

export interface ILineService {

    publishTextMessage(packet: MessageEvent, payload: TextEventMessage): Observable<any>

    publishImageEventMessage(packet: MessageEvent, payload: ImageEventMessage): Observable<any>

    publishFileEventMessage(packet: MessageEvent, payload: FileEventMessage): Observable<any>

    publishStickerEventMessage(packet: MessageEvent, payload: StickerEventMessage): Observable<any>

    publishLocationEventMessage(packet: MessageEvent, payload: LocationEventMessage): Observable<any>

    publishFollowEvent(packet: FollowEvent): Observable<any>

    publishUnfollowEvent(packet: UnfollowEvent): Observable<any>

    publishJoinEvent(packet: JoinEvent): Observable<any>

    publishLeaveEvent(packet: LeaveEvent): Observable<any>

    registerLineProfile(lineId: string, phone: IRegisterLineValidator): Observable<boolean>

    unRegisterLineProfile(lineId: string): Observable<boolean>

    getAllUnregister(): Observable<IMapResult>

    getAllRegistered(): Observable<IMapResult>

    sendToIncident(lineId: string): Observable<{incidentNo: string}>

    unSentToIncident(lineId: string): Observable<boolean>

    getConversationByLineId(lineId: string): Observable<ILineProfileAllMessage>

    getConversationByIncidentNo(incidentNo: string): Observable<ILineProfileAllMessage>

    setReadAllConversation(lineId: string): Observable<boolean>

    commandQuery(packet: MessageEvent, command: string[]): Observable<any>
}
