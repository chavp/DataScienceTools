import {
    IFlexMessage,
    ILocationMessage,
    IMessage,
    ITextMessage,
} from '../../../repository/line/line.schema'
import { EventSource } from '@line/bot-sdk'

export interface IMessageDto {
    id: string
    isRegister?: boolean
    type: string
    conversation: {
        source?: EventSource
        destination: string
        groupId: string
        pictureUrl: string
        displayName: string
        createDate: number
    },
    content: IFlexMessage | ILocationMessage | string
}

export interface IFollowEventSchema {
    uid: string
    name: string
    imgProfile: string
    timestamp: number
    group: string
}

export interface IUnfollowEventSchema {
    uid: string
    name: string
    imgProfile: string
    timestamp: number
}

