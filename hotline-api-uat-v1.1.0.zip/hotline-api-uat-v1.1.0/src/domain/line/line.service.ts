import {
    BadRequestException,
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import { ILineService } from './interface/service.interface'
import { IFullDuplexWebSocket } from '../../adapter/notification/interfaces/socket.interface'
import {
    ILineProfileModel,
    ILineProfileRepository,
} from './interface'
import {
    forkJoin,
    iif,
    Observable,
    of,
} from 'rxjs'
import {
    FileEventMessage,
    Group,
    ImageEventMessage,
    LeaveEvent,
    LocationEventMessage,
    MessageEvent,
    StickerEventMessage,
    TextEventMessage,
    WebhookEvent,
} from '@line/bot-sdk/lib/types'
import {
    catchError,
    concatMap,
    filter,
    map,
    mergeMap,
    reduce,
    take,
    tap,
    throwIfEmpty,
    toArray,
} from 'rxjs/operators'
import {
    ILineAdapter,
    ILineProfile,
} from '../../adapter/line/interface/line.interface'
import { LineProfileModel } from './line.model'
import { ISurveyorLineModel } from '../surveyor-line/interface/model.interface'
import { ISurveyorLineRepository } from '../surveyor-line/interface/repository.interface'
import { SurveyorLineModel } from '../surveyor-line/surveyor-line.model'
import { JoinEvent } from '@line/bot-sdk'
import { IPublisher } from '../../pubsub/interface/publisher.interface'
import { LineBotJoinEvent } from './pubsub/event/line-bot-join-event'
import { IRegisterLineValidator } from './interface/validator.interface'
import {
    IIncidentModel,
    IIncidentRepository,
} from '../incident/interface'
import { StatusEnum } from '../incident/status.enum'
import * as _ from 'lodash'
import { IReceiveLocationEventSchema } from './pubsub/interface/receiveLocationEvent.schema'
import { IReceiveTextEventSchema } from './pubsub/interface/receiveTextEvent.schema'
import { IReceiveStickerEventSchema } from './pubsub/interface/receiveStickerEvent.schema'
import { ReceiveMessageStickerEvent } from './pubsub/event/line-message-sticker.event'
import { LineMessageTextEvent } from './pubsub/event/line-message-text-event'
import { IReceiveImageEventSchema } from './pubsub/interface/receiveImageEvent.schema'
import { LineMessageReceiveImageEvent } from './pubsub/event/line-message-image-event'
import { LineMessageLocationEvent } from './pubsub/event/line-message-location-event'
import {
    IMessageModel,
    IMessageRepository,
} from '../message/interface'
import { ContentTypeEnum } from '../../repository/message/message.schema'
import {
    ILineProfileAllMessage,
    IMapResult,
} from './interface/result.interface'
import { IMessagePayloadSchema } from '../message/interface/schema.interface'
import { LineBotUserFollowEvent } from './pubsub/event/line-bot-user-follow-event'
import { LineBotUserUnfollowEvent } from './pubsub/event/line-bot-user-unfollow-event'
import { ISurveyorCaseRepository } from '../surveyor-case/interface/repository.interface'
import { ISurveyorCaseModel } from '../surveyor-case/interface/model.interface'

export class LineService implements ILineService {
    constructor(
        private readonly _lineProfileRepository: ILineProfileRepository,
        private readonly _socketAdapter: IFullDuplexWebSocket,
        private readonly _lineAdapter: ILineAdapter,
        private readonly _surveyorLneRepository: ISurveyorLineRepository,
        private readonly _publisher: IPublisher<any>, // todo refactor this from any to model
        private readonly _incidentRepository: IIncidentRepository,
        private readonly _messageRepository: IMessageRepository,
        private readonly _caseRepository: ISurveyorCaseRepository,
    ) {

    }

    public commandQuery(packet: MessageEvent, command: string[]): Observable<any> {

        const inspect$ = (): Observable<any> => of(command).pipe(
            concatMap(() => {
                const replyToken = packet.replyToken
                const eventSource = packet.source as Group
                const groupId = eventSource.groupId

                return of(replyToken)
                    .pipe(
                        concatMap(() => this._surveyorLneRepository.getById(groupId)),
                        catchError(() => of({})),
                        concatMap(model => {
                            let messages = [
                                `id: ${groupId}`,
                            ]
                            if (!_.isEmpty(model)) {
                                const cast = model as ISurveyorLineModel
                                messages = _.concat(messages, [
                                    `code: ${cast.getSurveyorId()}`,
                                    `name: ${cast.getCompanyName()}`,
                                    `bof: ${cast.getGroupName()}`,
                                ])
                            }
                            return this._lineAdapter.replyMessage(replyToken, [ messages.join('\n') ])
                        }),
                    )

            }),
        )
        return of(packet).pipe(
            tap(() => {
                if (packet.source.type !== 'group') {
                    throw new BadRequestException(`Invalid request`)
                }
            }),
            concatMap(() => {
                switch (command[0]) {
                    case 'inspect':
                        return inspect$()
                    default:
                        return of('/command help')
                }
            }),
        )

    }

    public publishJoinEvent(packet: JoinEvent): Observable<any> {
        const event: Group = packet.source as Group
        return this._surveyorLneRepository.getById(event.groupId).pipe(
            map(model => {
                model.setStatus('join')
                model.setUpdatedDate(new Date())
                return model
            }),
            mergeMap(model => {
                return this._surveyorLneRepository.update(model).pipe(
                    map(() => model),
                )
            }),
            catchError(() => {
                const model: ISurveyorLineModel = new SurveyorLineModel()
                model.setId(event.groupId)
                return this._surveyorLneRepository.save(model).pipe(
                    map(() => model),
                )
            }),
            tap((model: ISurveyorLineModel) => {
                this._publisher.publish(new LineBotJoinEvent(model))
            }),
            mergeMap((model: ISurveyorLineModel) => {
                return this._lineAdapter.pushMessage(model.getId(), `Group Id: ${model.getId()}`)
            }),
        )
    }

    public publishTextMessage(packet: MessageEvent, payload: TextEventMessage): Observable<any> {
        const uid = packet.source.userId
        const groupId = packet.source.type === 'group' ? packet.source.groupId : null
        return this._getLineProfileAndCreateRecord(uid, packet.type, groupId).pipe(
            map((model: ILineProfileModel) => {
                return {
                    id: packet.message.id,
                    text: payload.text,
                    sender: uid,
                    receiver: 'agent',
                    group: packet.source.type === 'group' ? packet.source.groupId : null,
                    timeStamp: packet.timestamp,
                    incidentNo: model.getIncidentNo(),
                    senderName: model.getDisplayName(),
                    picPath: model.getPictureUrl(),
                    lineId: model.getId(),
                    isRegister: model.getIsRegister(),
                } as IReceiveTextEventSchema
            }),
            tap((data: IReceiveTextEventSchema) => {
                this._publisher.publish(new LineMessageTextEvent(data))
            }),
        )
    }

    public publishUnfollowEvent(packet: WebhookEvent): Observable<any> {
        const uid = packet.source.userId
        return this._lineProfileRepository.getByLineId(uid).pipe(
            map((profile) => {
                profile.setIsFollow(packet.type === 'follow')
                return profile
            }),
            mergeMap((model) => {
                return this._lineProfileRepository.update(model).pipe(
                    map(() => model),
                )
            }),
            tap(model => {
                this._publisher.publish(new LineBotUserUnfollowEvent(model))
            }),
        )
    }

    public publishFollowEvent(packet: WebhookEvent): Observable<any> {
        const uid = packet.source.userId
        const groupId = packet.source.type === 'group' ? packet.source.groupId : null
        return this._getLineProfileAndCreateRecord(uid, packet.type, groupId).pipe(
            tap(lineProfile => {
                this._publisher.publish(new LineBotUserFollowEvent(lineProfile))
            }),
        )
    }

    private _getLineProfileAndCreateRecord(lineId: string, type: string, groupId?: string): Observable<ILineProfileModel> {
        return this._lineProfileRepository.getByLineId(lineId)
            .pipe(
                map((profile) => {
                    profile.setIsFollow(type !== 'unfollow')
                    return profile
                }),
                mergeMap((model) => {
                    return this._lineProfileRepository.update(model).pipe(
                        map(() => model),
                    )
                }),
                catchError(err => {
                    return this._getLineProfile(lineId, groupId).pipe(
                        map(profile => {
                            const model: ILineProfileModel = new LineProfileModel(profile.displayName)
                            model.setPictureUrl(`/static/line/profile/${lineId}.jpeg`)
                            model.setId(profile.userId)
                            model.setCreateDate()
                            return model
                        }),
                        mergeMap((model: ILineProfileModel) => {
                            model.setIsFollow(type === 'follow')
                            return this._lineProfileRepository.save(model).pipe(
                                map(() => model),
                            )
                        }),
                    )
                }),
            ).pipe(
                concatMap(lineProfile => {
                    return this._lineAdapter.deleteRichMenuOfUser(lineProfile.getId()).pipe(
                        map(() => lineProfile),
                        catchError(() => of(lineProfile)),
                    )
                }),
            )
    }

    private _getLineProfile(lineId: string, groupId: string): Observable<ILineProfile> {
        return iif(() => _.isNil(groupId),
            this._lineAdapter.getProfile(lineId),
            this._lineAdapter.getProfileFromGroup(lineId, groupId),
        )
    }

    public publishLeaveEvent(packet: LeaveEvent): Observable<any> {
        const eventSource: Group = packet.source as Group
        return this._surveyorLneRepository.getById(eventSource.groupId).pipe(
            mergeMap(model => {
                model.setStatus('leave')
                return this._surveyorLneRepository.update(model)
            }),
        )
    }

    public registerLineProfile(lineId: string, phone: IRegisterLineValidator): Observable<boolean> {
        return this._lineProfileRepository.getByLineId(lineId).pipe(
            mergeMap((result: ILineProfileModel) => {
                result.setPhone(phone.getPhone())
                result.setIsRegister(true)

                return this._lineProfileRepository.update(result)
            }),
        )
    }

    public unRegisterLineProfile(lineId: string): Observable<boolean> {
        return this._lineProfileRepository.getByLineId(lineId).pipe(
            mergeMap((result: ILineProfileModel) => {
                result.setIsRegister(false)
                return this._lineProfileRepository.update(result)
            }),
        )
    }

    public getAllUnregister(): Observable<IMapResult> {
        const lineFilter = {
            $and: [
                { isRegister: false },
                { isFollow: true },
                { incidentNo: null },
            ],
        }

        return this._lineProfileRepository.find(lineFilter).pipe(
            mergeMap((result: ILineProfileModel) => {
                const msgFilter = {
                    $or: [
                        { sender: result.getId() },
                        { receiver: result.getId() },
                    ],
                }

                const lastResult: IMapResult = {
                    model: null,
                    totalUnread: 0,
                    lastMessage: null,
                    timeStamp: null,
                    isRegister: null,
                }

                return this._messageRepository.find(msgFilter).pipe(
                    filter((message: IMessageModel) => {
                        return message && message.getRead() !== true && message.getGroup() === null
                    }),
                    reduce((acc: number, message: IMessageModel) => {
                        acc++
                        return acc
                    }, 0),
                    map((unread: number) => {
                        lastResult.totalUnread = unread
                    }),
                    mergeMap(() => {
                        return this._messageRepository.find(msgFilter).pipe(
                            take(1),
                            map((data: IMessageModel) => {
                                if (data.getType() === ContentTypeEnum.TEXT) {
                                    const content = data.getContent() as IMessagePayloadSchema
                                    lastResult.lastMessage = content.text
                                } else if (data.getType() === ContentTypeEnum.STICKER) {
                                    lastResult.lastMessage = `sent a sticker.`
                                } else if (data.getType() === ContentTypeEnum.IMAGE) {
                                    lastResult.lastMessage = `sent a photo.`
                                } else if (data.getType() === ContentTypeEnum.LOCATION) {
                                    lastResult.lastMessage = `sent a location.`
                                }
                                lastResult.timeStamp = data.getTimeStamp()
                            }),
                        )
                    }),
                    catchError(() => {
                        return of(lastResult)
                    }),
                    tap(() => {
                        lastResult.model = result
                        lastResult.isRegister = result.getIsRegister()
                        return lastResult
                    }),
                    map(() => lastResult),
                )
            }),
        )
    }

    public getAllRegistered(): Observable<IMapResult> {
        const lineFilter = {
            $and: [
                { isRegister: true },
                { isFollow: true },
                { incidentNo: null },
            ],
        }
        return this._lineProfileRepository.find(lineFilter).pipe(
            mergeMap((result: ILineProfileModel) => {
                const msgFilter = {
                    $or: [
                        { sender: result.getId() },
                        { receiver: result.getId() },
                    ],
                }

                const lastResult: IMapResult = {
                    model: null,
                    totalUnread: 0,
                    lastMessage: null,
                    timeStamp: null,
                    isRegister: null,
                }

                return this._messageRepository.find(msgFilter).pipe(
                    filter((message: IMessageModel) => {
                        return message && message.getRead() !== true && message.getGroup() === null
                    }),
                    reduce((acc: number, message: IMessageModel) => {
                        acc++
                        return acc
                    }, 0),
                    map((unread: number) => {
                        lastResult.totalUnread = unread
                    }),
                    mergeMap(() => {
                        return this._messageRepository.listDirectLatestBySenderOrReceiver(result.getId(), 1).pipe(
                            filter((message: IMessageModel) => {
                                return message.getGroup() === null
                            }),
                            map((data: IMessageModel) => {
                                if (data.getType() === ContentTypeEnum.TEXT) {
                                    const content = data.getContent() as IMessagePayloadSchema
                                    lastResult.lastMessage = content.text
                                } else if (data.getType() === ContentTypeEnum.STICKER) {
                                    lastResult.lastMessage = `sent a sticker.`
                                } else if (data.getType() === ContentTypeEnum.IMAGE) {
                                    lastResult.lastMessage = `sent a photo.`
                                } else if (data.getType() === ContentTypeEnum.LOCATION) {
                                    lastResult.lastMessage = `sent a location.`
                                } else if (data.getType() === ContentTypeEnum.FLEX) {
                                    lastResult.lastMessage = `sent a flex.`
                                }
                                lastResult.timeStamp = data.getTimeStamp()
                            }),
                        )
                    }),
                    catchError(() => {
                        return of(lastResult)
                    }),
                    tap(() => {
                        lastResult.model = result
                        lastResult.isRegister = result.getIsRegister()
                        return lastResult
                    }),
                    map(() => lastResult),
                )
            }),
        )
    }

    public sendToIncident(lineId: string): Observable<{ incidentNo: string }> {
        return this._lineProfileRepository.getByLineId(lineId).pipe(
            throwIfEmpty(() => {
                throw new HttpException(`Line ID not found`, HttpStatus.NOT_FOUND)
            }),
            mergeMap((result: ILineProfileModel) => {
                if (!_.isNil(result.getIncidentNo())) {
                    throw new HttpException(`Line ID is already sent to incident`, HttpStatus.BAD_REQUEST)
                }

                const incidentFilter = {
                    $and: [
                        { contactNo: result.getPhone() },
                        {
                            'status.id': {
                                $ne: StatusEnum.CLOSE,
                            },
                        },
                    ],
                }

                return this._incidentRepository.find(incidentFilter).pipe(
                    take(1),
                    throwIfEmpty(() => {
                        throw new HttpException(`Incident not found`, HttpStatus.NOT_FOUND)
                    }),
                    mergeMap((incident: IIncidentModel) => {
                        return this._messageRepository.find({ incidentNo: incident.getId() }).pipe(
                            map((message: IMessageModel) => {
                                throw new HttpException(
                                    `The incident was assigned for another profile`,
                                    HttpStatus.BAD_REQUEST,
                                )
                            }),
                            catchError(() => {
                                return of(incident)
                            }),
                        )
                    }),
                    mergeMap((incident: IIncidentModel) => {
                        result.setIncidentNo(incident.getId())

                        return forkJoin([
                            this._lineProfileRepository.update(result).pipe(
                                map(() => incident),
                            ),
                            this._setIncidentToMessage(incident.getId(), lineId),
                        ])
                    }),
                    map((data: any[]) => {
                        return {
                            incidentNo: data[0].getId(),
                        }
                    }),
                )
            }),
        )
    }

    private _setIncidentToMessage(incidentNo: string, lineNo: string): Observable<boolean> {
        const msgFilter = {
            $and: [
                { group: null },
                {
                    $or: [
                        { sender: lineNo },
                        { receiver: lineNo },
                    ],
                },
            ],
        }
        return this._messageRepository.find(msgFilter).pipe(
            mergeMap((result: IMessageModel) => {
                result.setIncidentNo(incidentNo)
                return this._messageRepository.update(result)
            }),
        )
    }

    public unSentToIncident(lineId: string): Observable<boolean> {
        return this._lineProfileRepository.getByLineId(lineId).pipe(
            throwIfEmpty(() => {
                throw new HttpException(`Line ID not found`, HttpStatus.NOT_FOUND)
            }),
            mergeMap((result: ILineProfileModel) => {
                if (_.isNil(result.getIncidentNo())) {
                    throw new HttpException(
                        `Line Profile was not sent to incident`,
                        HttpStatus.BAD_REQUEST,
                    )
                }
                return forkJoin([
                    of(result),
                    this._messageRepository.find({incidentNo: result.getIncidentNo()}).pipe(
                        concatMap((message: IMessageModel) => {
                            message.setIncidentNo(null)
                            return this._messageRepository.update(message)
                        }),
                    ),
                ])
            }),
            mergeMap((result: any[]) => {
                const profile = result[0] as ILineProfileModel

                profile.setIncidentNo(null)
                return this._lineProfileRepository.update(profile)
            }),
        )
    }

    public getConversationByLineId(lineId: string): Observable<ILineProfileAllMessage> {
        const result: ILineProfileAllMessage = {
            profile: null,
            message: [],
        }
        return this._lineProfileRepository.getByLineId(lineId).pipe(
            throwIfEmpty(() => {
                throw new HttpException(`Line ID not found`, HttpStatus.NOT_FOUND)
            }),
            mergeMap((lineProfile: ILineProfileModel) => {
                result.profile = lineProfile
                return this._messageRepository.listDirectLatestBySenderOrReceiver(lineId, 100).pipe(
                    map((message: IMessageModel) => {
                        result.message.push(message)
                    }),
                    toArray(),
                )
            }),
            map(() => result),
        )
    }

    public getConversationByIncidentNo(incidentNo: string): Observable<ILineProfileAllMessage> {
        const result: ILineProfileAllMessage = {
            profile: null,
            message: [],
        }
        return this._lineProfileRepository.find({ incidentNo }).pipe(
            throwIfEmpty(() => {
                throw new HttpException(`Line Profile not found`, HttpStatus.NOT_FOUND)
            }),
            mergeMap((lineProfile: ILineProfileModel) => {
                result.profile = lineProfile
                return this._messageRepository.listDirectLatestByIncidentNo(incidentNo, 100).pipe(
                    map((message: IMessageModel) => {
                        result.message.push(message)
                    }),
                    toArray(),
                )
            }),
            map(() => result),
        )
    }

    public setReadAllConversation(lineId: string): Observable<boolean> {
        return this._lineProfileRepository.getByLineId(lineId).pipe(
            mergeMap((result: ILineProfileModel) => {
                const msgFilter = {
                    $and: [
                        { group: null },
                        {
                            $or: [
                                { sender: lineId },
                                { receiver: lineId },
                            ],
                        },
                    ],
                }
                return this._messageRepository.find(msgFilter)
            }),
            mergeMap((message: IMessageModel) => {
                if (message.getRead() !== true) {
                    message.setRead(true)
                }
                return this._messageRepository.update(message)
            }),
        )
    }

    public publishFileEventMessage(packet: MessageEvent, payload: FileEventMessage): Observable<any> {
        return of({}) // ignore event
    }

    public publishImageEventMessage(packet: MessageEvent, payload: ImageEventMessage): Observable<any> {
        const groupId = packet.source.type === 'group' ? packet.source.groupId : null
        return this._getLineProfileAndCreateRecord(packet.source.userId, packet.type, groupId).pipe(
            mergeMap((model) => {
                return this._lineAdapter.getMessageContent(packet.message.id, packet.message.type).pipe(
                    map(content => ({ model, content })),
                )
            }),
            tap(({ model, content }) => {
                const schema: IReceiveImageEventSchema = {
                    group: packet.source.type === 'group' ? packet.source.groupId : null,
                    name: content.fileName,
                    path: content.path,
                    sender: packet.source.userId,
                    receiver: 'agent',
                    timeStamp: packet.timestamp,
                    id: packet.message.id,
                    incidentNo: model.getIncidentNo(),
                    senderName: model.getDisplayName(),
                    picPath: model.getPictureUrl(),
                    lineId: model.getId(),
                    isRegister: model.getIsRegister(),
                }
                this._publisher.publish(new LineMessageReceiveImageEvent(schema))
            }),
        )

    }

    public publishLocationEventMessage(packet: MessageEvent, payload: LocationEventMessage): Observable<any> {
        const groupId = packet.source.type === 'group' ? packet.source.groupId : null
        return this._getLineProfileAndCreateRecord(packet.source.userId, packet.type, groupId).pipe(
            map((model) => {
                const eventPayload: IReceiveLocationEventSchema = {
                    id: packet.message.id,
                    address: payload.address,
                    group: packet.source.type === 'group' ? packet.source.groupId : null,

                    latitude: payload.latitude,
                    longitude: payload.longitude,

                    incidentNo: model.getIncidentNo(),
                    senderName: model.getDisplayName(),

                    sender: packet.source.userId,
                    title: payload.title,
                    timeStamp: packet.timestamp,

                    picPath: model.getPictureUrl(),
                    lineId: model.getId(),
                    receiver: 'agent',
                    isRegister: model.getIsRegister(),
                }
                return eventPayload
            }),
            tap(eventPayload => {
                this._publisher.publish(new LineMessageLocationEvent(eventPayload))
            }),
        )
    }

    public publishStickerEventMessage(packet: MessageEvent, payload: StickerEventMessage): Observable<any> {
        const uid = packet.source.userId
        const groupId = packet.source.type === 'group' ? packet.source.groupId : null
        return this._getLineProfileAndCreateRecord(uid, packet.type, groupId).pipe(
            map((model: ILineProfileModel) => {
                return {
                    id: packet.message.id,
                    stickerId: payload.stickerId,
                    packageId: payload.packageId,
                    receiver: 'agent',
                    sender: uid,
                    incidentNo: model.getIncidentNo(),
                    senderName: model.getDisplayName(),
                    group: packet.source.type === 'group' ? packet.source.groupId : null,
                    timeStamp: packet.timestamp,
                    picPath: model.getPictureUrl(),
                    lineId: model.getId(),
                    isRegister: model.getIsRegister(),
                } as IReceiveStickerEventSchema
            }),
            tap((data: IReceiveStickerEventSchema) => {
                this._publisher.publish(new ReceiveMessageStickerEvent(data))
            }),
        )
    }
}
