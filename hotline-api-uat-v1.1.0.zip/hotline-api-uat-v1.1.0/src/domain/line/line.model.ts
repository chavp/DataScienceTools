import { Entity } from '../../common/entity'
import { ILineProfileModel } from './interface'

export class LineProfileModel extends Entity implements ILineProfileModel {

    private _displayName: string
    private _pictureUrl: string
    private _isFollow: boolean
    private _createDate: Date
    private _isRegister: boolean
    private _phone: string
    private _incidentNo: string

    constructor(displayName: string) {
        super()
        this._displayName = displayName
        this._isRegister = false
    }

    public getDisplayName(): string {
        return this._displayName
    }

    public getPictureUrl(): string {
        return this._pictureUrl
    }

    public getIsFollow(): boolean {
        return this._isFollow
    }

    public getCreateDate(): Date {
        return this._createDate
    }

    public getIsRegister(): boolean {
        return this._isRegister
    }

    public getPhone(): string {
        return this._phone
    }

    public getIncidentNo(): string {
        return this._incidentNo
    }

    public setDisplayName(displayName: string): void {
        this._displayName = displayName
    }

    public setPictureUrl(pictureUrl: string): void {
        this._pictureUrl = pictureUrl
    }

    public setIsFollow(isFollow: boolean): void {
        this._isFollow = isFollow
    }

    public setCreateDate(): void {
        this._createDate = new Date()
    }

    public setIsRegister(isRegister: boolean): void {
        this._isRegister = isRegister || false
    }

    public setPhone(phone: string): void {
        this._phone = phone
    }

    public setIncidentNo(incidentNo: string): void {
        this._incidentNo = incidentNo
    }
}
