export interface ILineProfileEventSchema {
    lineId: string
    name: string
    phone: string
    pictureUrl: string
}
