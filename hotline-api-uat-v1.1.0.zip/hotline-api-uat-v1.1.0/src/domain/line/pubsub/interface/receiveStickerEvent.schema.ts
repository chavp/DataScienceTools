export interface IReceiveStickerEventSchema {
    id: string,
    stickerId: string,
    packageId: string,
    timeStamp: number,
    group: string,
    sender: string,
    receiver: string,
    incidentNo: string,
    senderName: string,
    picPath: string,
    lineId: string,
    isRegister: boolean,
}
