export interface IReceiveTextEventSchema {
    id: string,
    text: string,
    sender: string,
    receiver: string,
    group: string,
    timeStamp: number,
    incidentNo: string,
    senderName: string,
    picPath: string,
    lineId: string,
    isRegister: boolean,
}
