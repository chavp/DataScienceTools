export interface IJoinSchema {
    groupId: string
    createdTime: number
}
