import { EventSource } from '@line/bot-sdk'

export interface IMessageSchema {
    id: string,
    type: string,
    conversation: IConversation,
    content: IFlexMessage | ILocationMessage | string,
}

export interface IFlexMessage {
    id: string,
    messageType: string,
    caller: ICaller,
    surveyor?: ISurveyor,
}

export interface ILocationMessage {
    id: string,
    address: string,
    messageType: string,
    lat: number,
    lng: number,
}

export interface IConversation {
    source: EventSource,
    destination: string,
    groupId: string,
    pictureUrl: string,
    displayName: string,
    createDate: number,
    sender: string,
}

export interface ISurveyor {
    id: string,
    name: string,
    phone: string,
    companyNo: string,
}

export interface ICaller {
    name: string,
    phone: string,
}
