export interface IReceiveImageEventSchema {
    id: string,
    name: string,
    path: string,
    sender: string,
    receiver: string,
    group: string,
    timeStamp: number,
    incidentNo: string,
    senderName: string,
    picPath: string,
    lineId: string,
    isRegister: boolean,
}
