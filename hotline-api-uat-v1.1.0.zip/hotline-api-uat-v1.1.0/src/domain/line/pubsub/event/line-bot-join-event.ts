import { AbstractDomainEvent } from '../../../../pubsub/abstract.domain-event'
import * as _ from 'lodash'
import { ISurveyorLineModel } from '../../../surveyor-line/interface/model.interface'
import { IJoinSchema } from '../interface/join.schema'
import { LineEvent } from '../../../../pubsub/event.enum'

export class LineBotJoinEvent extends AbstractDomainEvent<ISurveyorLineModel, IJoinSchema> {

    constructor(data: ISurveyorLineModel) {
        super(LineEvent.LINE_BOT_JOINED, data)
    }

    public serialize(model: ISurveyorLineModel): IJoinSchema {
        return {
            groupId: model.getId(),
            createdTime: model.getUpdatedDate().getTime(),
        }

    }
}
