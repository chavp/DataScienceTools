import { AbstractDomainEvent } from '../../../../pubsub/abstract.domain-event'
import { IReceiveImageEventSchema } from '../interface/receiveImageEvent.schema'
import { LineEvent } from '../../../../pubsub/event.enum'

export class LineMessageReceiveImageEvent extends AbstractDomainEvent<IReceiveImageEventSchema, IReceiveImageEventSchema> {
    constructor(data: IReceiveImageEventSchema) {
        super(LineEvent.LINE_RECEIVE_IMAGE, data)
    }

    public serialize(schema: IReceiveImageEventSchema): IReceiveImageEventSchema {
        return {
            id: schema.id,
            name: schema.name,
            path: schema.path,
            timeStamp: schema.timeStamp,
            group: schema.group,
            sender: schema.sender,
            receiver: schema.receiver,
            incidentNo: schema.incidentNo,
            senderName: schema.senderName,
            picPath: schema.picPath,
            lineId: schema.lineId,
            isRegister: schema.isRegister,
        }
    }
}
