import { AbstractDomainEvent } from '../../../../pubsub/abstract.domain-event'
import { LineEvent } from '../../../../pubsub/event.enum'
import { IReceiveTextEventSchema } from '../interface/receiveTextEvent.schema'

export class LineMessageTextEvent extends AbstractDomainEvent<IReceiveTextEventSchema, IReceiveTextEventSchema> {
    constructor(data: IReceiveTextEventSchema) {
        super(LineEvent.LINE_RECEIVE_TEXT, data)
    }

    public serialize(schema: IReceiveTextEventSchema): IReceiveTextEventSchema {
        return {
            id: schema.id,
            text: schema.text,
            timeStamp: schema.timeStamp,
            group: schema.group,
            sender: schema.sender,
            receiver: schema.receiver,
            incidentNo: schema.incidentNo,
            senderName: schema.senderName,
            picPath: schema.picPath,
            lineId: schema.lineId,
            isRegister: schema.isRegister,
        }
    }
}
