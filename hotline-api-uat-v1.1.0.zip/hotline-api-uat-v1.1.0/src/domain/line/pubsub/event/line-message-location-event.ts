import { AbstractDomainEvent } from '../../../../pubsub/abstract.domain-event'
import { IReceiveLocationEventSchema } from '../interface/receiveLocationEvent.schema'
import { LineEvent } from '../../../../pubsub/event.enum'

export class LineMessageLocationEvent extends AbstractDomainEvent<IReceiveLocationEventSchema, IReceiveLocationEventSchema> {
    constructor(data: IReceiveLocationEventSchema) {
        super(LineEvent.LINE_RECEIVE_LOCATION, data)
    }

    public serialize(model: IReceiveLocationEventSchema): IReceiveLocationEventSchema {
        return {
            ...model,
        }
    }

}
