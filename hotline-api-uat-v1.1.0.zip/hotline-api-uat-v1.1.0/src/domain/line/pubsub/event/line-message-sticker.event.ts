import { AbstractDomainEvent } from '../../../../pubsub/abstract.domain-event'
import { IReceiveStickerEventSchema } from '../interface/receiveStickerEvent.schema'
import { LineEvent } from '../../../../pubsub/event.enum'

export class ReceiveMessageStickerEvent extends AbstractDomainEvent<IReceiveStickerEventSchema, IReceiveStickerEventSchema> {

    constructor(data: IReceiveStickerEventSchema) {
        super(LineEvent.LINE_RECEIVE_STICKER, data)
    }

    public serialize(model: IReceiveStickerEventSchema): IReceiveStickerEventSchema {
        return {
            id: model.id,
            stickerId: model.stickerId,
            packageId: model.packageId,
            sender: model.sender,
            receiver: model.receiver,
            group: model.group,
            timeStamp: model.timeStamp,
            incidentNo: model.incidentNo,
            senderName: model.senderName,
            picPath: model.picPath,
            lineId: model.lineId,
            isRegister: model.isRegister,
        }
    }
}
