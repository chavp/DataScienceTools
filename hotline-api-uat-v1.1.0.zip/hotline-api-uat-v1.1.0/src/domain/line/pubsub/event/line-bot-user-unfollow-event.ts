import { AbstractDomainEvent } from '../../../../pubsub/abstract.domain-event'
import { LineEvent } from '../../../../pubsub/event.enum'
import {
    ILineProfileEventSchema,
} from '../interface/line-profile.schema'
import { ILineProfileModel } from '../../interface'

export class LineBotUserUnfollowEvent extends AbstractDomainEvent<ILineProfileModel, ILineProfileEventSchema> {

    constructor(data: ILineProfileModel) {
        super(LineEvent.LINE_BOT_UNFOLLOWED, data)
    }

    public serialize(model: ILineProfileModel): ILineProfileEventSchema {
        return {
            lineId: model.getId(),
            name: model.getDisplayName(),
            phone: model.getPhone() || '',
            pictureUrl: model.getPictureUrl(),
        }

    }
}
