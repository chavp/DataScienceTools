import {ICCReportService} from './interface/service.interface'
import {from, Observable, of} from 'rxjs'
import {IMssqlInterface} from '../../adapter/mssql/interface/mssql.interface'
import {map, reduce} from 'rxjs/operators'
import * as _ from 'lodash'
import * as xls from 'excel4node'
import {PSurveyDto, SurveyDto} from '../../controller/rest/dto/ccreport.dto'

export class CCReportService implements ICCReportService {
    constructor(
        private readonly _mssqlAdapter: IMssqlInterface,
    ) {
    }

    public getCallabck(filter: any): Observable<any> {
        return this._mssqlAdapter.getCallabck(filter)
    }

    public exportCallabck(sheetName: string, model: any): Observable<any> {
        return from(model).pipe(
            map(content => {
                const headersExport = ['Time', 'Callback', 'Callback Leave', 'Call Time', 'Waiting Time', 'Agent']
                const headers = ['requestTime', 'requestAni', 'requestNumber', 'completeTime', 'waitingTime', 'completeUser']

                const workbook = new xls.Workbook()
                const worksheet = workbook.addWorksheet(sheetName)

                for (let col = 1, index = 0; col <= _.size(headersExport); col++, index++) {
                    worksheet.cell(1, col).string(headersExport[index])
                }

                // @ts-ignore
                for (let row = 2, recordRow = 0; row <= (_.size(content) + 1); row++, recordRow++) {
                    for (let col = 1, recordCol = 0; col <= _.size(headers); col++, recordCol++) {
                        const x = recordRow
                        const y = headers[recordCol]
                        worksheet.cell(row, col).string(content[x][y].toString())
                    }
                }

                return workbook
            }),
        )
    }

    public getSurvey(filter: any): Observable<any> {
        return this._mssqlAdapter.getSurvey(filter)
    }

    public exportSurvey(sheetName: string, model: any): Observable<any> {
        return from(model).pipe(
            map(content => {
                const headersExport = ['Time', 'Calltype', 'Customer Number', 'User', 'Name', 'Languages', 'Q1', 'Q2']
                const headers = ['surveyDate', 'callType', 'customerNumber', 'agentExt', 'agentName', 'languages', 'Q1', 'Q2']

                const workbook = new xls.Workbook()
                const worksheet = workbook.addWorksheet(sheetName)

                for (let col = 1, index = 0; col <= _.size(headersExport); col++, index++) {
                    worksheet.cell(1, col).string(headersExport[index])
                }

                // @ts-ignore
                for (let row = 2, recordRow = 0; row <= (_.size(content) + 1); row++, recordRow++) {
                    for (let col = 1, recordCol = 0; col <= _.size(headers); col++, recordCol++) {
                        const x = recordRow
                        const y = headers[recordCol]
                        worksheet.cell(row, col).string(content[x][y].toString())
                    }
                }

                return workbook
            }),
        )
    }

    public getPSurvey(filter: any): Observable<any> {
        return this._mssqlAdapter.getPSurvey(filter).pipe(
        map(models => {
            const model = models[0]
            if (_.isNil(model.score)) { model.score = 0 }
            if (_.isNil(model.total)) { model.total = 0 }

            if (model.total > 0) {
                model.icf = ((model.score  / model.total) * 100).toFixed(2)
            } else {
                model.icf = '0.00'
            }

            return model
            }),
        )
    }
}
