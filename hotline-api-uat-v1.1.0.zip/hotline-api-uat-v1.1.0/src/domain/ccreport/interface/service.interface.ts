import {Observable} from 'rxjs'

export interface ICCReportService {
    getCallabck(filter: any): Observable<any>

    exportCallabck(sheetName: string, model: any): Observable<any>

    getSurvey(filter: any): Observable<any>

    exportSurvey(sheetName: string, model: any): Observable<any>

    getPSurvey(filter: any): Observable<any>
}
