import {
    ICreateSurveyorCaseBuilder,
    IUpdateSurveyorCaseBuilder,
} from './interface/builder.interface'
import {
    SurveyorAssignmentModel,
    SurveyorCaseModel,
} from './case.model'
import {
    ISurveyorAssignmentValidator,
    IUpdateSurveyorCaseValidator,
} from './interface/validator.interface'
import {
    ISurveyorAssignmentModel,
    ISurveyorCaseModel,
} from './interface/model.interface'
import * as _ from 'lodash'

export class CreateSurveyorCaseBuilder implements ICreateSurveyorCaseBuilder {
    private model: SurveyorCaseModel

    public build(): SurveyorCaseModel {
        return this.model
    }

    public init() {
        this.model = new SurveyorCaseModel()
        return this
    }

    public setId(id: string) {
        this.model.setId(id)
        return this
    }

    public setSurveyCompanyNo(id: string) {
        this.model.setSurveyorCompanyNo(id)
        return this
    }

    public setSurveyorAssignment(assignment: ISurveyorAssignmentModel) {
        this.model.setSurveyorAssignment(assignment)
        return this
    }

    public setSurveyorNote(note: string) {
        this.model.setSurveyorNote(note)
        return this
    }
}

export class UpdateSurveyorCaseBuilder {
    public static compareSurveyorCaseModel(input: IUpdateSurveyorCaseValidator, target: ISurveyorCaseModel): ISurveyorCaseModel {
        const surveyorCase: ISurveyorCaseModel =  _.clone(target)

        if (!_.isNil(input.getSurveyorAssignment())) {
            const assignmentInput = input.getSurveyorAssignment()

            const assignmentModel = new SurveyorAssignmentModel()

            assignmentModel.setName(assignmentInput.getName())
            assignmentModel.setPhone(assignmentInput.getPhone())
            assignmentModel.setRemark(assignmentInput.getRemark())

            surveyorCase.setSurveyorAssignment(assignmentModel)
        }
        if (!_.isNil(input.getSurveyorNote())) {
            surveyorCase.setSurveyorNote(input.getSurveyorNote())
        }
        surveyorCase.setUpdatedAt(new Date())

        return surveyorCase
    }
}
