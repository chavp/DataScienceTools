import { IEntity } from '../../../common/interface/entity.interface'

export interface ISurveyorCaseModel extends IEntity {
    getIncidentNo(): string

    getSurveyorNo(): string

    getCustomerName(): string

    getCustomerPhone(): string

    getPlace(): string

    getSurveyorCompanyNo(): string

    getSurveyorNote(): string

    getSurveyorAssignment(): ISurveyorAssignmentModel[]

    getCreatedAt(): Date

    getUpdatedAt(): Date

    getFile(): string

    getProvince(): string

    getDistrict(): string

    setIncidentNo(incidentNo: string): void

    setSurveyorNo(surveyorNo: string): void

    setCustomerName(name: string): void

    setCustomerPhone(phone: string): void

    setPlace(place: string): void

    setSurveyorCompanyNo(surveyorCompanyNo: string): void

    setSurveyorNote(surveyorNote: string): void

    setSurveyorAssignment(surveyorAssignment: ISurveyorAssignmentModel): void

    setCreatedAt(createdAt: Date): void

    setUpdatedAt(updatedAt: Date): void

    setFile(fileName: string): void

    setProvince(province: string): void

    setDistrict(district: string): void

    isClosed(): boolean
}

export interface ISurveyorAssignmentModel {
    getName(): string

    getPhone(): string

    getRemark(): string

    setName(name: string): void

    setPhone(phone: string): void

    setRemark(remark: string): void

    getCreatedDate(): Date
}

export interface IIncidentSchema {
    incidentNo: string
    contactNo: string
    callerName: string
    driverName: string
    incidentType: {
        type: string
        subType: string
        claimType: string
    }
    status: string
    note: string
    policy: {
        no: string
        periodFrom: number
        periodTo: number
        branch: string
        productName: string
        insured: string
        registration: string
        makeModel: string
        chassis: string
        coverageType: string
        cover: string
        namedDriver: string
        od1: string
        od2: string
        tp: string
        genPage2: string
    }
}

export interface IAssignSurveyorCaseSchema {
    lineId: string,
    surveyorId: string,
    caseNo: string,
    callerName: string,
    callerPhone: string,
}
