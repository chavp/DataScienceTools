import { ISurveyorCaseModel } from './model.interface'
import { IRepository } from '../../../common/interface/repository.interface'
import { Observable } from 'rxjs'

export interface ISurveyorCaseRepository extends IRepository<ISurveyorCaseModel> {
    find(filter?: any): Observable<ISurveyorCaseModel>

    save(model: ISurveyorCaseModel): Observable<any>

    update(model: ISurveyorCaseModel): Observable<{id: string}>

    getById(id: string): Observable<ISurveyorCaseModel>

    getByIncidentNumber(incidentNumber: string): Observable<ISurveyorCaseModel>

    delete( model: ISurveyorCaseModel): Observable<boolean>
}
