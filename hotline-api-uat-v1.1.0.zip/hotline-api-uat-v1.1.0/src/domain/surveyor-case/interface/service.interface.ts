import { UpdateSurveyorCaseValidator } from '../../../controller/rest/validator/case.validator'
import { Observable } from 'rxjs'
import {
    IIncidentSchema,
    ISurveyorCaseModel,
} from './model.interface'
import { IFinalizeCaseValidator } from './validator.interface'
import { ICaseFilterSchema } from './filter.interface'

export interface ISurveyorCaseService {
    getAll(): Observable<ISurveyorCaseModel>

    filterData(caseFilter: ICaseFilterSchema): Observable<ISurveyorCaseModel>

    getById(id: string): Observable<ISurveyorCaseModel>

    getBySurveyorIdAndCaseId(surveyorId: string, caseId: string): Observable<{surveyorCase: ISurveyorCaseModel, incidentSchema: IIncidentSchema}>

    update(id: string, input: UpdateSurveyorCaseValidator): Observable<{ id: string }>

    updateImage(caseId: string, input: IFinalizeCaseValidator, file: Express.Multer.File): Observable<any>

    getImageFileContent(caseId: string): Observable<Buffer>

    deleteSurveyorCase(caseId: string): Observable<any>

    surveyorNotArrived(caseId: string, lineId: string, sendTo: string): Observable<any>

    surveyorArrived(caseId: string, lineId: string, sendTo: string): Observable<any>
}
