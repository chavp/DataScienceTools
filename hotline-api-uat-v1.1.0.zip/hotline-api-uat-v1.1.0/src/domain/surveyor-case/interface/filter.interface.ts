export interface ICaseFilterSchema {
    incidentNo?: string
}
