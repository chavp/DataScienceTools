export interface IUpdateSurveyorCaseValidator {
    getCaseNo(): string

    getSurveyorCompanyNo(): string

    getSurveyorNote(): string

    getSurveyorAssignment(): ISurveyorAssignmentValidator
}

export interface ISurveyorAssignmentValidator {
    getName(): string

    getPhone(): string

    getRemark(): string
}

export interface IFinalizeCaseValidator {
    getNote(): string
}
