import {
    ISurveyorArriveGroupSchema,
    ISurveyorArriveUserSchema,
} from '../../message/pubsub/schema/message-text.schema'
import { map } from 'rxjs/operators'
import { IConfig } from '../../../common/interface/config.interface'
import { IAuthService } from '../../../common/interface/auth.interface'
import { Observable } from 'rxjs'
import { ICaseNotArriveEventSchema } from '../pubsub/interface/case-not-arrive-interface'

export class ISurveyorCaseArriveBuilder {

    constructor(
        private readonly _config: IConfig,
        private readonly _auth: IAuthService,
    ) {
    }

    public groupLineFlex(caseModel: ICaseNotArriveEventSchema, confirmWord: string): Observable<any> {
        const path = `${this._config.surveyorUrl.surveyorWeb}`
        const surveyorId = caseModel.surveyorId
        const caseNo = caseModel.caseNo
        const payloadJson = {
            lineId: caseModel.lineId,
            sendTo: 'group',
        }
        return this._auth.generateJWT(payloadJson).pipe(
            map((token: string) => {
                return {
                    wordingCompany: `หมายเลขบริษัทสำรวจภัย: ${caseModel.companyNo}`,
                    wordingEmployeeName: `ชื่อเจ้าหน้าที่สำรวจภัย: ${caseModel.employeeName}`,
                    pathSurveyorArrived: `type=surveyor-arrived&case=${caseNo}&token=${token}`,
                    pathSurveyorNotArrived: `type=surveyor-not-arrived&case=${caseNo}&token=${token}`,
                }
            }),
            map(content => {
                return {
                    type: 'flex',
                    altText: 'Confirm ' + caseNo,
                    contents: {
                        type: 'bubble',
                        direction: 'ltr',
                        body: {
                            type: 'box',
                            layout: 'vertical',
                            contents: [
                                {
                                    type: 'text',
                                    text: confirmWord,
                                    size: 'md',
                                    align: 'start',
                                    gravity: 'top',
                                    weight: 'bold',
                                    wrap: true,
                                },
                                {
                                    type: 'text',
                                    text: content.wordingCompany,
                                    size: 'sm',
                                    wrap: true,
                                },
                                {
                                    type: 'text',
                                    text: content.wordingEmployeeName,
                                    size: 'sm',
                                    wrap: true,
                                },
                                {
                                    type: 'separator',
                                    margin: 'xl',
                                },
                                {
                                    type: 'box',
                                    layout: 'vertical',
                                    contents: [
                                        {
                                            type: 'button',
                                            action: {
                                                type: 'postback',
                                                label: 'ถึงที่หมายเรียบร้อย',
                                                data: content.pathSurveyorArrived,
                                            },
                                        },
                                        {
                                            type: 'button',
                                            action: {
                                                type: 'postback',
                                                label: 'ยังไม่ถึงที่หมาย',
                                                data: content.pathSurveyorNotArrived,
                                            },
                                        },
                                    ],
                                },
                            ],
                        },
                    },
                }
            }),
        )
    }

    public userLineFlex(caseModel: ICaseNotArriveEventSchema, confirmWord: string): Observable<any> {
        const path = `${this._config.surveyorUrl.surveyorWeb}`
        const surveyorId = caseModel.surveyorId
        const caseNo = caseModel.caseNo
        const payloadJson = {
            lineId: caseModel.lineId,
            sendTo: 'user',
        }
        return this._auth.generateJWT(payloadJson).pipe(
            map((token: string) => {
                return {
                    wordingEmployeeInfo: `${caseModel.employeeName} Tel: ${caseModel.employeePhone}`,
                    surveyorArrivedURL: `type=surveyor-arrived&case=${caseNo}&token=${token}`,
                    surveyorNotArrivedURL: `type=surveyor-not-arrived&case=${caseNo}&token=${token}`,
                }
            }),
            map(content => {
                return {
                    type: 'flex',
                    altText: 'Confirm Arrival',
                    contents: {
                        type: 'bubble',
                        direction: 'ltr',
                        body: {
                            type: 'box',
                            layout: 'vertical',
                            contents: [
                                {
                                    type: 'text',
                                    text: confirmWord,
                                    size: 'md',
                                    align: 'start',
                                    gravity: 'top',
                                    weight: 'bold',
                                    wrap: true,
                                },
                                {
                                    type: 'text',
                                    text: 'confirm to arrive at the destination',
                                    margin: 'md',
                                    size: 'sm',
                                    wrap: true,
                                },
                                {
                                    type: 'text',
                                    text: content.wordingEmployeeInfo,
                                    margin: 'md',
                                    size: 'sm',
                                    wrap: true,
                                },
                                {
                                    type: 'separator',
                                    margin: 'xl',
                                },
                                {
                                    type: 'box',
                                    layout: 'vertical',
                                    contents: [
                                        {
                                            type: 'button',
                                            action: {
                                                type: 'postback',
                                                label: 'ถึงที่หมายเรียบร้อยแล้ว / arrived',
                                                data: content.surveyorArrivedURL,
                                            },
                                        },
                                        {
                                            type: 'button',
                                            action: {
                                                type: 'postback',
                                                label: `ยังไม่ถึงที่หมาย / not arrived`,
                                                data: content.surveyorNotArrivedURL,
                                            },
                                        },
                                    ],
                                },
                            ],
                        },
                    },
                }
            }),
        )
    }
}
