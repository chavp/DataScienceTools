import { SurveyorCaseModel } from '../case.model'
import { ISurveyorAssignmentValidator } from './validator.interface'
import { ISurveyorAssignmentModel } from './model.interface'

export interface ICreateSurveyorCaseBuilder {
    build(): SurveyorCaseModel
    init(): void

    setId(id: string)
    setSurveyCompanyNo(id: string)
    setSurveyorNote(note: string)
    setSurveyorAssignment(assignment: ISurveyorAssignmentModel)
}

export interface IUpdateSurveyorCaseBuilder {
    setSurveyCompanyNo(id: string)
    setSurveyorNote(note: string)
    setSurveyorAssignment(assignment: ISurveyorAssignmentValidator)
    setCreatedAt(date: Date)
    setUpdatedAt(date: Date)
}
