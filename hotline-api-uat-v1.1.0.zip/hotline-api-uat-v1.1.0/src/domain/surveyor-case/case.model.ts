import { Entity } from '../../common/entity'
import {
    ISurveyorAssignmentModel,
    ISurveyorCaseModel,
} from './interface/model.interface'
import * as _ from 'lodash'

export class SurveyorCaseModel extends Entity implements ISurveyorCaseModel {

    private _incidentNo: string
    private _surveyorNo: string
    private _customerName: string
    private _customerPhone: string
    private _place: string
    private _surveyorCompanyNo: string
    private _surveyorNote: string
    private readonly _surveyorAssignment: ISurveyorAssignmentModel[]
    private _createdAt: Date
    private _updatedAt: Date
    private _file: string
    private _province: string
    private _district: string

    constructor() {
        super()
        this._surveyorAssignment = []
        this._file = ''
    }

    public getCreatedAt(): Date {
        return this._createdAt
    }

    public getIncidentNo(): string {
        return this._incidentNo
    }

    public getSurveyorNo(): string {
        return this._surveyorNo
    }

    public getCustomerName(): string {
        return this._customerName
    }

    public getCustomerPhone(): string {
        return this._customerPhone
    }

    public getPlace(): string {
        return this._place
    }

    public getSurveyorAssignment(): ISurveyorAssignmentModel[] {
        return _.slice(this._surveyorAssignment)
    }

    public getSurveyorCompanyNo(): string {
        return this._surveyorCompanyNo
    }

    public getSurveyorNote(): string {
        return this._surveyorNote
    }

    public getUpdatedAt(): Date {
        return this._updatedAt
    }

    public setCreatedAt(createdAt: Date): void {
        this._createdAt = createdAt
    }

    public setIncidentNo(incidentNo: string): void {
        this._incidentNo = incidentNo
    }

    public setSurveyorNo(surveyorNo: string): void {
        this._surveyorNo = surveyorNo
    }

    public setCustomerName(name: string): void {
        this._customerName = name
    }

    public setCustomerPhone(phone: string): void {
        this._customerPhone = phone
    }

    public setPlace(place: string): void {
        this._place = place
    }

    public setSurveyorAssignment(surveyorAssignment: ISurveyorAssignmentModel): void {
        this._surveyorAssignment.push(surveyorAssignment)
    }

    public setSurveyorCompanyNo(surveyorCompanyNo: string): void {
        this._surveyorCompanyNo = surveyorCompanyNo
    }

    public setSurveyorNote(surveyorNote: string): void {
        this._surveyorNote = surveyorNote
    }

    public setUpdatedAt(updatedAt: Date): void {
        this._updatedAt = updatedAt
    }

    public getFile(): string {
        return this._file
    }

    public setFile(fileName: string): void {
        this._file = fileName
    }

    public getProvince(): string {
        return this._province
    }

    public setProvince(province: string): void {
        this._province = province
    }

    public getDistrict(): string {
        return this._district
    }

    public setDistrict(district: string): void {
        this._district = district
    }

    public isClosed(): boolean {
        return !_.isEmpty(this._file)
    }
}

export class SurveyorAssignmentModel extends Entity implements ISurveyorAssignmentModel {
    private _name: string
    private _phone: string
    private _remark: string
    private _createdDate: Date

    constructor() {
        super()
        this._createdDate = new Date()
    }

    public getName(): string {
        return this._name
    }

    public getPhone(): string {
        return this._phone
    }

    public getRemark(): string {
        return this._remark
    }

    public setName(name: string): void {
        this._name = name
    }

    public setPhone(phone: string): void {
        this._phone = phone
    }

    public setRemark(remark: string): void {
        this._remark = remark
    }

    public getCreatedDate(): Date {
        return new Date(this._createdDate)
    }
}
