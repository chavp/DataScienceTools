import { ISurveyorCaseService } from './interface/service.interface'
import { UpdateSurveyorCaseValidator } from '../../controller/rest/validator/case.validator'
import { ISurveyorCaseRepository } from './interface/repository.interface'
import {
    forkJoin,
    Observable,
    of,
    throwError,
} from 'rxjs'
import {
    IIncidentSchema,
    ISurveyorCaseModel,
} from './interface/model.interface'
import {
    catchError,
    concatMap,
    defaultIfEmpty,
    filter,
    map,
    mergeMap,
    take,
    tap,
    throwIfEmpty,
    toArray,
} from 'rxjs/operators'
import * as _ from 'lodash'
import {
    BadRequestException,
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import { UpdateSurveyorCaseBuilder } from './case.builder'
import {
    ILineProfileModel,
    ILineProfileRepository,
} from '../line/interface'
import {
    IFullDuplexWebSocket,
    ReminderEvent,
} from '../../adapter/notification/interfaces/socket.interface'
import {
    ILineAdapter,
    IResultSchema,
} from '../../adapter/line/interface/line.interface'
import { IImageStorage } from '../../common/interface/image-storage.interface'
import { IFinalizeCaseValidator } from './interface/validator.interface'
import { RuntimeException } from '@nestjs/core/errors/exceptions/runtime.exception'
import {
    IIncidentModel,
    IIncidentRepository,
} from '../incident/interface'
import { ICaseFilterSchema } from './interface/filter.interface'
import { UpdateSurveyorAssignmentEvent } from './pubsub/event/updateSurveyorCase.event'
import { IPublisher } from '../../pubsub/interface/publisher.interface'
import { StatusEnum } from '../incident/status.enum'
import { ISurveyorLineRepository } from '../surveyor-line/interface/repository.interface'
import { ISurveyorLineModel } from '../surveyor-line/interface/model.interface'
import { ContentTypeEnum } from '../../repository/message/message.schema'
import {
    IMessageModel,
    IMessageRepository,
} from '../message/interface'
import {
    IDirectMessageSchema,
    IGroupMessageSchema,
} from '../message/pubsub/schema/message-text.schema'
import {
    IFlexPayloadSchema,
    IMessagePayloadSchema,
} from '../message/interface/schema.interface'
import { IGuaranteeZoneModel } from '../surveyor/interface/model.interface'
import { IGuaranteeZoneRepository } from '../surveyor/interface/repository.interface'
import { CaseNotArriveEvent } from './pubsub/event/case-not-arrive.event'
import {
    ICaseNotArriveEventSchema,
    TypeFlexEnum,
} from './pubsub/interface/case-not-arrive-interface'
import { MessageModel } from '../message/message.model'
import { ISchedulerTasksRepository } from '../scheduler/interface/repository.interface'
import { ISchedulerConfigModel } from '../scheduler/interface/model.interface'
import { IScheduleManager } from '../scheduler/interface/service.interface'

export class SurveyorCaseService implements ISurveyorCaseService {

    constructor(
        private readonly _surveyorCaseRepository: ISurveyorCaseRepository,
        private readonly _lineProfileRepository: ILineProfileRepository,
        private readonly _publisher: IPublisher<any>,
        private readonly _socketAdapter: IFullDuplexWebSocket,
        private readonly _lineAdapter: ILineAdapter,
        private readonly _imageStorage: IImageStorage,
        private readonly _incidentRepository: IIncidentRepository,
        private readonly _surveyorLineRepository: ISurveyorLineRepository,
        private readonly _messageRepository: IMessageRepository,
        private readonly _guaranteeZoneRepository: IGuaranteeZoneRepository,
        private readonly _scheduleRepository: ISchedulerTasksRepository,
        private readonly _taskManager: IScheduleManager,
    ) {

    }

    public getAll(): Observable<ISurveyorCaseModel> {
        return this._surveyorCaseRepository.find().pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `case not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
        )
    }

    public filterData(caseFilter: ICaseFilterSchema): Observable<ISurveyorCaseModel> {
        return this._surveyorCaseRepository.find({
            incidentNo: _.isNil(caseFilter.incidentNo) ? undefined : caseFilter.incidentNo,
        })
    }

    public getById(id: string): Observable<ISurveyorCaseModel> {
        return this._surveyorCaseRepository.find({ _id: id }).pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `case not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
            map((result: ISurveyorCaseModel) => {
                const expiredDate = result.getCreatedAt().getTime() + (48 * 60 * 60 * 1000)
                const now = new Date().getTime()

                if (now > expiredDate) {
                    throw new HttpException(
                        `case expired`,
                        HttpStatus.BAD_REQUEST,
                    )
                }

                return result
            }),
        )
    }

    public update(id: string, input: UpdateSurveyorCaseValidator): Observable<{ id: string }> {
        return this.checkCase(id).pipe(
            mergeMap((result: ISurveyorCaseModel) => {
                return this._incidentRepository.getById(result.getIncidentNo()).pipe(
                    map((incident: IIncidentModel) => {
                        if (!_.isNil(incident.getStatus()) && incident.getStatus().id === StatusEnum.CLOSE) {
                            throw new HttpException(`Incident ID ${incident.getId()} was closed`, HttpStatus.BAD_REQUEST)
                        }
                        return result
                    }),
                )
            }),
            map((result: ISurveyorCaseModel) => {
                return UpdateSurveyorCaseBuilder.compareSurveyorCaseModel(input, result)
            }),
            mergeMap((result) => {
                return this._surveyorCaseRepository.update(result).pipe(
                    tap(r => {
                        console.log('update case : ' + r)
                    }),
                    map(() => {
                        return result
                    }),
                )
            }),
            map(model => {
                // if (!_.isEmpty(model.getSurveyorAssignment())) {
                //     this._publisher.publish(new UpdateSurveyorAssignmentEvent(model))
                // }
                this._publisher.publish(new UpdateSurveyorAssignmentEvent(model))
                return {
                    id: model.getId(),
                }
            }),
        )
    }

    private checkCase(id: string): Observable<ISurveyorCaseModel> {
        return this._surveyorCaseRepository.find({ _id: id }).pipe(
            map((result) => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `Incident not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }

                return result
            }),
        )
    }

    public updateImage(caseId: string, input: IFinalizeCaseValidator, file: Express.Multer.File): Observable<any> {
        return this.checkCase(caseId).pipe(
            mergeMap(result => {
                const targetFileName = `${caseId}_${file.originalname}`
                return this._imageStorage.saveImage(targetFileName, file.buffer).pipe(
                    catchError((err: RuntimeException) => {
                        return throwError(new BadRequestException(err.message))
                    }),
                    map(imgDescriptor => {
                        result.setFile(file.originalname)
                        result.setSurveyorNote(input.getNote())
                        return result
                    }),
                )
            }),
            mergeMap(model => {
                return this._surveyorCaseRepository.update(model)
            }),
        )

    }

    public getImageFileContent(caseId: string): Observable<Buffer> {
        return this._surveyorCaseRepository.getById(caseId).pipe(
            mergeMap(model => {
                const file = model.getFile()
                const targetFileName = `${caseId}_${file}`
                return this._imageStorage.getImageContent(targetFileName)
            }),
        )
    }

    public getBySurveyorIdAndCaseId(
        surveyorId: string,
        caseId: string,
    ): Observable<{ surveyorCase: ISurveyorCaseModel, incidentSchema: IIncidentSchema }> {
        return this._surveyorCaseRepository.getById(caseId).pipe(
            filter(caseModel => caseModel.getSurveyorCompanyNo() === surveyorId),
            throwIfEmpty(() => {
                throwError(new BadRequestException(`Cannot find case ${caseId}`))
            }),
            tap(caseModel => {
                const expiredDate = caseModel.getCreatedAt().getTime() + (48 * 60 * 60 * 1000)
                const now = Date.now()

                if (now > expiredDate) {
                    throw new HttpException(
                        `case expired`,
                        HttpStatus.BAD_REQUEST,
                    )
                }
            }),
            mergeMap(caseModel => {
                return this._incidentRepository.getById(caseModel.getIncidentNo()).pipe(
                    map(incidentModel => {
                        const incidentType = incidentModel.getIncidentType()
                        const policySchema = incidentModel.getPolicy()

                        const periodFrom = _.get(policySchema, 'period_from')
                        const periodTo = _.get(policySchema, 'period_to')
                        const odSplit = _.get(policySchema, 'deductible', '').split('\n')

                        const incidentSchema: IIncidentSchema = {
                            callerName: incidentModel.getCallerName(),
                            contactNo: incidentModel.getContactNo(),
                            incidentNo: incidentModel.getId(),
                            driverName: incidentModel.getDriverName(),
                            incidentType: {
                                claimType: _.get(incidentType, 'name', ''),
                                subType: _.get(incidentType, 'subType.name', ''),
                                type: _.get(incidentType, 'subType.subType.name', ''),
                            },
                            note: incidentModel.getNote(),
                            policy: {
                                branch: _.get(policySchema, 'branch'),
                                chassis: _.get(policySchema, 'chassis'),
                                cover: _.get(policySchema, 'cover'),
                                coverageType: _.get(policySchema, 'coverage_type'),
                                genPage2: _.get(policySchema, 'genpage2'),
                                insured: _.get(policySchema, 'insured'),
                                makeModel: _.get(policySchema, 'make_model'),
                                namedDriver: _.get(policySchema, 'named_driver'),
                                no: _.get(policySchema, 'policy_no'),
                                od1: odSplit[0],
                                od2: odSplit[1],
                                periodFrom: !_.isNil(periodFrom) ? new Date(policySchema.period_from).getTime() : null,
                                periodTo: !_.isNil(periodTo) ? new Date(policySchema.period_to).getTime() : null,
                                productName: _.get(policySchema, 'product_name'),
                                registration: _.get(policySchema, 'registration'),
                                tp: odSplit[2],
                            },
                            status: incidentModel.getStatus().name,

                        }
                        return {
                            surveyorCase: caseModel,
                            incidentSchema,
                        }
                    }),
                )
            }),
        )
    }

    public deleteSurveyorCase(caseId: string): Observable<boolean> {
        return this._surveyorCaseRepository.getById(caseId).pipe(
            take(1),
            tap(caseModel => {
                if (caseModel.isClosed()) {
                    throw new BadRequestException(`Cannot cancel closed case`)
                }
            }),
            concatMap((model: ISurveyorCaseModel) => {
                return this._surveyorLineRepository.getBySurveyorId(model.getSurveyorCompanyNo()).pipe(
                    map((surveyorLineModel) => {
                        return ({
                            caseModel: model,
                            surveyorLine: surveyorLineModel,
                        })
                    }),
                )
            }),
            concatMap(({ caseModel, surveyorLine }) => {
                return this._surveyorCaseRepository.delete(caseModel).pipe(
                    tap((data: boolean) => {
                        console.log('delete: ' + data)
                    }),
                    map(() => ({ caseModel, surveyorLine })),
                )
            }),
            concatMap(({ caseModel, surveyorLine }) => {
                const content = {
                    id: caseModel.getId(),
                    text: 'Case ID ' + caseModel.getId() + ' cancelled',
                }
                const timeStamp = new Date()

                const groupMessageModel = new MessageModel()
                groupMessageModel.setContent(content)
                groupMessageModel.setGroup(surveyorLine.getId())
                groupMessageModel.setSender(null)
                groupMessageModel.setSenderName(surveyorLine.getGroupName())
                groupMessageModel.setTimeStamp(timeStamp)
                groupMessageModel.setType(ContentTypeEnum.TEXT)

                return this._messageRepository.save(groupMessageModel).pipe(
                    map((messageId) => {
                        groupMessageModel.setId(messageId.id)
                        return ({ caseModel, surveyorLine, messageModel: groupMessageModel })
                    }),
                )
            }),
            concatMap(({ caseModel, surveyorLine, messageModel }) => {
                return forkJoin([
                    this._sendMessageToGroup({ surveyorLine, messageModel }),
                    this._sendMessageToCustomer({ caseModel, surveyorLine }),
                ])
            }),
            map(() => true),
        )
    }

    public surveyorNotArrived(caseId: string, lineId: string, sendTo: string): Observable<any> {
        const firstTimeStamp = new Date()
        return this._surveyorCaseRepository.getById(caseId).pipe(
            throwIfEmpty(() => {
                throw new HttpException(`Case not found`, HttpStatus.NOT_FOUND)
            }),
            mergeMap((surveyorCase: ISurveyorCaseModel) => {
                return this._surveyorLineRepository.find({surveyorId: surveyorCase.getSurveyorNo()}).pipe(
                    map((surveyorLine: ISurveyorLineModel) => {
                        return ({surveyorLine, surveyorCase})
                    }),
                )
            }),
            mergeMap(({surveyorLine, surveyorCase}) => {
                return this._incidentRepository.getById(surveyorCase.getIncidentNo()).pipe(
                    mergeMap((incident: IIncidentModel) => {
                        if (_.isNil(incident.getSurveyor())) {
                            throw new HttpException(`Incident ${incident.getId()} was not assigned to surveyor`, HttpStatus.BAD_REQUEST)
                        }
                        return this._guaranteeZoneRepository.listByProvinceTH(incident.getSurveyor().province)
                    }),
                    map((guaranteeZone: IGuaranteeZoneModel) => guaranteeZone),
                    filter((guaranteeZone: IGuaranteeZoneModel) => {
                        return guaranteeZone && surveyorCase.getDistrict() === guaranteeZone.getDistrictTH()
                    }),
                    defaultIfEmpty(null),
                    map((guaranteeZone: IGuaranteeZoneModel) => {
                        const employee = _.last(surveyorCase.getSurveyorAssignment())
                        let flexType = TypeFlexEnum.GROUP
                        if (sendTo === 'user') {
                            flexType = TypeFlexEnum.USER
                        }

                        const evtSchema: ICaseNotArriveEventSchema = {
                            caseNo: caseId,
                            companyNo: surveyorCase.getSurveyorCompanyNo(),
                            employeeName: employee.getName(),
                            employeePhone: employee.getPhone(),
                            lineId,
                            surveyorId: surveyorCase.getSurveyorNo(),
                            timeSchedule: null,
                            type: flexType,
                        }
                        if (_.isNil(guaranteeZone)) {
                            evtSchema.timeSchedule = null
                        } else {
                            evtSchema.timeSchedule = firstTimeStamp.getTime() + (20 * 60 * 1000)
                        }
                        return evtSchema
                    }),
                    mergeMap((evtSchema: ICaseNotArriveEventSchema) => {
                        const receiver = lineId
                        const msg = `Case ${caseId} เจ้าหน้าที่ยังไม่ถึงที่หมาย`
                        return this._lineAdapter.pushMessage(receiver, msg).pipe(
                            mergeMap((pushResult: IResultSchema) => {
                                // console.log(`>>> `, pushResult)
                                const msgId = _.get(pushResult, 'x-line-request-id', null)
                                if (sendTo === 'user') {
                                    return this._lineProfileRepository.getByLineId(lineId).pipe(
                                        map((profile: ILineProfileModel) => {
                                            const content: IMessagePayloadSchema = {
                                                id: _.toString(pushResult.id),
                                                text: `Case ${caseId} เจ้าหน้าที่ยังไม่ถึงที่หมาย`,
                                            }

                                            const directSocketSchema: IDirectMessageSchema = {
                                                id: lineId,
                                                displayName: profile.getDisplayName(),
                                                picPath: profile.getPictureUrl(),
                                                incidentNo: surveyorCase.getIncidentNo(),
                                                isRegister: profile.getIsRegister(),
                                                message: [{
                                                    id: msgId,
                                                    sender: 'user',
                                                    senderName: profile.getDisplayName(),
                                                    receiver: 'agent',
                                                    type: ContentTypeEnum.TEXT,
                                                    content,
                                                    timeStamp: firstTimeStamp.getTime(),
                                                }],
                                            }

                                            return directSocketSchema
                                        }),
                                    )
                                }

                                const groupSocketSchema: IGroupMessageSchema = {
                                    content: {
                                        image: null,
                                        location: {
                                            address: null,
                                            latitude: null,
                                            longitude: null,
                                            title: null,
                                        },
                                        stickerId: null,
                                        text: `Case ${caseId} เจ้าหน้าที่ยังไม่ถึงที่หมาย`,
                                        type: ContentTypeEnum.TEXT,
                                        header: null,
                                    },
                                    from: {
                                        id: null,
                                        name: null,
                                        sender: 'agent',
                                    },
                                    messageId: msgId,
                                    timeStamp: firstTimeStamp.getTime(),
                                    groupId: surveyorLine.getId(),
                                }

                                return of(groupSocketSchema)
                            }),
                            mergeMap((socketSchema: any) => {
                                // console.log(`sendTo => `, sendTo)
                                // console.log(`socketSchema => `, socketSchema)
                                let msgId = null
                                let evtName = ReminderEvent.LINE_NEW_MESSAGE_GROUP
                                let timeStamp = null
                                let group = null
                                let sender = null
                                let senderName = null
                                let received = 'agent'
                                let incidentNo = null
                                if (sendTo === 'user') {
                                    sender = lineId
                                    senderName = socketSchema.displayName
                                    msgId = socketSchema.message[0].content.id
                                    evtName = ReminderEvent.LINE_NEW_MESSAGE_USER
                                    timeStamp = new Date(socketSchema.message[0].timeStamp)
                                    received = 'user'
                                    incidentNo = surveyorCase.getIncidentNo()
                                } else {
                                    msgId = socketSchema.messageId
                                    timeStamp = new Date(socketSchema.timeStamp)
                                    group = socketSchema.groupId
                                }

                                const content = {
                                    id: msgId,
                                    text: `Case ${caseId} เจ้าหน้าที่ยังไม่ถึงที่หมาย`,
                                }

                                const messageModel = new MessageModel()
                                messageModel.setContent(content)
                                messageModel.setGroup(group)
                                messageModel.setSender(sender)
                                messageModel.setTimeStamp(timeStamp)
                                messageModel.setSenderName(senderName)
                                messageModel.setType(ContentTypeEnum.TEXT)
                                messageModel.setReceiver(received)
                                messageModel.setIncidentNo(incidentNo)

                                return forkJoin([
                                    of(evtSchema),
                                    this._socketAdapter.sendMessage(evtName, socketSchema),
                                    this._messageRepository.save(messageModel),
                                ])
                            }),
                        )
                    }),
                    map((data: any[]) => {
                        const evtSchema = data[0] as ICaseNotArriveEventSchema
                        // console.log(`event schema : `, evtSchema)
                        return this._publisher.publish(new CaseNotArriveEvent(evtSchema))
                    }),
                )
            }),
        )
    }

    public surveyorArrived(caseId: string, lineId: string, sendTo: string): Observable<any> {
        const msg = `Case ${caseId} เจ้าหน้าที่ถึงที่หมายเรียบร้อยแล้ว`
        const timeStamp = new Date()

        return this._surveyorCaseRepository.getById(caseId).pipe(
            throwIfEmpty(() => {
                throw new HttpException(`Case not found`, HttpStatus.NOT_FOUND)
            }),
            mergeMap((caseModel: ISurveyorCaseModel) => {
                return this._scheduleRepository.find({caseNo: caseId}).pipe(
                    map((task: ISchedulerConfigModel) => task),
                    defaultIfEmpty(null),
                    mergeMap((task: ISchedulerConfigModel) => {
                        if (_.isNil(task)) {
                            return of(caseModel)
                            // console.log(`Case was not generated`)
                        }
                        // console.log(`delete task : ${task.getId()} [CASE ${task.getCaseNo()}]`)
                        return forkJoin([
                            this._scheduleRepository.delete(task),
                            this._taskManager.deleteTask(task),
                        ])
                    }),
                    toArray(),
                    map(() => caseModel),
                )
            }),
            mergeMap((caseModel: ISurveyorCaseModel) => {
                return this._surveyorLineRepository.find({surveyorId: caseModel.getSurveyorNo()}).pipe(
                    map((surveyorLine: ISurveyorLineModel) => {
                        return ({surveyorLine, caseModel})
                    }),
                )
            }),
            mergeMap(({surveyorLine, caseModel}) => {
                return this._lineAdapter.pushMessage(lineId, msg).pipe(
                    mergeMap((pushMessage: IResultSchema) => {
                        // console.log(`>>>> `, pushMessage)
                        const msgId = _.get(pushMessage, 'x-line-request-id', null)
                        const content: IMessagePayloadSchema = {
                            id: msgId,
                            text: msg,
                        }

                        if (sendTo === 'user') {
                            return this._lineProfileRepository.getByLineId(lineId).pipe(
                                mergeMap((profile: ILineProfileModel) => {
                                    const directSocketSchema: IDirectMessageSchema = {
                                        id: lineId,
                                        displayName: profile.getDisplayName(),
                                        picPath: profile.getPictureUrl(),
                                        incidentNo: caseModel.getIncidentNo(),
                                        isRegister: profile.getIsRegister(),
                                        message: [{
                                            id: msgId,
                                            sender: 'user',
                                            senderName: profile.getDisplayName(),
                                            receiver: 'agent',
                                            type: ContentTypeEnum.TEXT,
                                            content,
                                            timeStamp: timeStamp.getTime(),
                                        }],
                                    }

                                    return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_USER, directSocketSchema).pipe(
                                        map(() => directSocketSchema),
                                    )
                                }),
                                map((directSocketSchema: IDirectMessageSchema) => {
                                    const message = new MessageModel()
                                    message.setSender(directSocketSchema.id)
                                    message.setReceiver('agent')
                                    message.setGroup(null)
                                    message.setContent(content)
                                    message.setTimeStamp(timeStamp)
                                    message.setSenderName(directSocketSchema.displayName)
                                    message.setType(ContentTypeEnum.TEXT)
                                    message.setIncidentNo(directSocketSchema.incidentNo)

                                    console.log(`>>>>>>>>>>>>>>>> message to customer : `, msg)
                                    return message
                                }),
                            )
                        } else {
                            const groupSocketSchema: IGroupMessageSchema = {
                                content: {
                                    image: null,
                                    location: {
                                        address: null,
                                        latitude: null,
                                        longitude: null,
                                        title: null,
                                    },
                                    stickerId: null,
                                    text: `Case ${caseId} เจ้าหน้าที่ถึงที่หมายเรียบร้อยแล้ว`,
                                    type: ContentTypeEnum.TEXT,
                                    header: null,
                                },
                                from: {
                                    id: null,
                                    name: null,
                                    sender: 'agent',
                                },
                                messageId: msgId,
                                timeStamp: timeStamp.getTime(),
                                groupId: surveyorLine.getId(),
                            }

                            return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_GROUP, groupSocketSchema).pipe(
                                map(() => {
                                    const message = new MessageModel()
                                    message.setSender(null)
                                    message.setReceiver('user')
                                    message.setGroup(surveyorLine.getId())
                                    message.setContent(content)
                                    message.setTimeStamp(timeStamp)
                                    message.setSenderName(null)
                                    message.setType(ContentTypeEnum.TEXT)

                                    return message
                                }),
                            )
                        }
                    }),
                    mergeMap((message: IMessageModel) => {
                        return this._messageRepository.save(message)
                    }),
                )
            }),
        )
    }

    private _sendMessageToGroup(
        {
            surveyorLine, messageModel,
        }: ({
            surveyorLine: ISurveyorLineModel,
            messageModel: IMessageModel
        }),
    ): Observable<any> {

        const content = messageModel.getContent() as IMessagePayloadSchema
        const groupSocketSchema: IGroupMessageSchema = {
            timeStamp: messageModel.getTimeStamp().getTime(),
            content: {
                image: null,
                location: {
                    address: null,
                    latitude: null,
                    longitude: null,
                    title: null,
                },
                stickerId: null,
                text: content.text,
                type: ContentTypeEnum.TEXT,
                header: null,
            },
            from: {
                id: null,
                name: null,
                sender: !_.isNil(null) ? 'user' : 'agent',
            },
            groupId: surveyorLine.getId(),
            messageId: messageModel.getId(),
        }

        return forkJoin([
            this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_GROUP, groupSocketSchema),
            this._lineAdapter.pushMessage(surveyorLine.getId(), content.text),
        ])
    }

    private _sendMessageToCustomer(
        {
            caseModel, surveyorLine,
        }: ({
            caseModel: ISurveyorCaseModel,
            surveyorLine: ISurveyorLineModel
        }),
    ): Observable<any> {

        const textMessage = 'ขออภัยในความล่าช้า เนื่องจากเจ้าหน้าที่สำรวจภัยเกิดปัญหาระหว่างเดินทาง' +
            ' เจ้าหน้าที่สำรวจภัยจะไปถึงคุณในเร็วที่สุดค่ะ'

        const lineProfileQuery = {
            incidentNo: caseModel.getIncidentNo(),
        }
        return this._lineProfileRepository.find(lineProfileQuery).pipe(
            concatMap(lineProfile => {
                return this._lineAdapter.pushMessage(lineProfile.getId(), textMessage).pipe(
                    map((pushResult => {
                        return ({ lineProfile, pushResult })
                    })),
                )
            }),
            mergeMap(({ lineProfile, pushResult }) => {
                const msgContent = {
                    id: pushResult.id,
                    text: textMessage,
                }
                const directMessageModel = new MessageModel()
                directMessageModel.setContent(msgContent)
                directMessageModel.setGroup(null)
                directMessageModel.setSender(null)
                directMessageModel.setSenderName(null)
                directMessageModel.setTimeStamp(new Date())
                directMessageModel.setType(ContentTypeEnum.TEXT)
                directMessageModel.setReceiver('user')
                directMessageModel.setIncidentNo(lineProfile.getIncidentNo())

                return this._messageRepository.save(directMessageModel).pipe(
                    map(() => {
                        return ({ lineProfile, pushResult })
                    }),
                )
            }),
            map(({ lineProfile, pushResult }) => {
                const content: IMessagePayloadSchema = {
                    id: _.toString(pushResult.id),
                    text: textMessage,
                }

                const ts = new Date()
                const messageModel = new MessageModel()
                messageModel.setContent(content)
                messageModel.setGroup(null)
                messageModel.setSender(null)
                messageModel.setTimeStamp(ts)
                messageModel.setIncidentNo(lineProfile.getIncidentNo())
                messageModel.setSenderName(surveyorLine.getGroupName())
                messageModel.setType(ContentTypeEnum.TEXT)
                messageModel.setReceiver(lineProfile.getId())

                const directSocketSchema: IDirectMessageSchema = {
                    id: lineProfile.getId(),
                    displayName: lineProfile.getDisplayName(),
                    picPath: lineProfile.getPictureUrl(),
                    incidentNo: messageModel.getIncidentNo(),
                    isRegister: lineProfile.getIsRegister(),
                    message: [ {
                        id: messageModel.getId(),
                        sender: 'agent',
                        senderName: surveyorLine.getGroupName(),
                        receiver: lineProfile.getId(),
                        type: ContentTypeEnum.TEXT,
                        content,
                        timeStamp: ts.getTime(),
                    } ],
                }
                return forkJoin([
                    this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_USER, directSocketSchema),
                    this._lineAdapter.pushMessage(lineProfile.getId, content.text),
                ])

            }),
        )

    }
}
