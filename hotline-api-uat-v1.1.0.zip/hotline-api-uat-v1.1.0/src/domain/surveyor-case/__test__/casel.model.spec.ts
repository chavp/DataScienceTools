import {
    SurveyorAssignmentModel,
    SurveyorCaseModel,
} from '../case.model'
import { plainToClass } from 'class-transformer'
import { ISurveyorAssignmentModel } from '../interface/model.interface'
import { empty } from 'rxjs/internal/Observer'

describe('SurveyorCaseModel', () => {
    let model: SurveyorCaseModel = null

    beforeEach(() => {
        model = plainToClass(SurveyorCaseModel, {
            id: 'sr388810',
            picture: 'ser/fdsa/fff/gds',
            surveyorCompanyNo: 'test test',
            surveyorNote: 'this test',
            surveyorAssignment: [],
            createdAt: '',
            updatedAt: '',
        })
    })

    let modelAssignment: SurveyorAssignmentModel = null
    // let modelAssignmentTest: SurveyorAssignmentModel = null

    beforeEach(() => {
        modelAssignment = plainToClass(SurveyorAssignmentModel, {
            name: 'prateep',
            phone: '0889898848',
            remark: 'fdsafdafdsafdfdfff',
        })
    })

    // modelAssignment = {
    //     _name: 'fdsaf',
    //     _phone: '097733737',
    //     _remark: 'remark',
    // }

    const cs = {
        name: 'dfdsafd',
        phone: '039888108',
        remark: 'fdsafdsa',
    }

    it('stamp data surveyor case', () => {
        model.setId('sr38881')
        expect(model.getId()).toEqual('sr38881')
        model.setPicture('svh/gdgd/gdgdgds.jpg')
        expect(model.getPicture()).toEqual('svh/gdgd/gdgdgds.jpg')
        model.setSurveyorCompanyNo('5552222555')
        expect(model.getSurveyorCompanyNo()).toEqual('5552222555')
        model.setSurveyorNote('ioioioioio')
        expect(model.getSurveyorNote()).toEqual('ioioioioio')

        modelAssignment.setName('prateep')
        expect(modelAssignment.getName()).toEqual('prateep')
        modelAssignment.setPhone('0874782934')
        expect(modelAssignment.getPhone()).toEqual('0874782934')
        modelAssignment.setRemark('yyyyyyyyyyyyyyyyyo')
        expect(modelAssignment.getRemark()).toEqual('yyyyyyyyyyyyyyyyyo')
        model.setSurveyorAssignment(modelAssignment)
        expect(model.getSurveyorAssignment()).toEqual([modelAssignment])
        model.setCreatedAt(new Date('2019/03/31'))
        expect(model.getCreatedAt()).toEqual(new Date('2019/03/31'))
        model.setUpdatedAt(new Date('2019/06/30'))
        expect(model.getUpdatedAt()).toEqual(new Date('2019/06/30'))
    })

    // it('stamp data surveyor assign')
})
