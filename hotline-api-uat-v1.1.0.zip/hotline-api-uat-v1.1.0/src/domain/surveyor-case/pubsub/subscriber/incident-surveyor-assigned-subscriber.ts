import { AbstractSubscriber } from '../../../../pubsub/abstract.subscriber'
import { IIncidentEventSchema } from '../interface/schema.interface'
import { IConfig } from '../../../../common/interface/config.interface'
import { SurveyorCaseModel } from '../../case.model'
import { ISurveyorModel } from '../../../surveyor/interface/model.interface'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import {
    catchError,
    concatMap,
    defaultIfEmpty,
    map,
    tap,
    mergeMap,
    take,
    throwIfEmpty,
} from 'rxjs/operators'
import {
    forkJoin,
    Observable,
    of,
} from 'rxjs'
import { ISurveyorRepository } from '../../../surveyor/interface/repository.interface'
import {
    IIncidentModel,
    IIncidentRepository,
} from '../../../incident/interface'
import * as _ from 'lodash'
import * as moment from 'moment'
import { ISurveyorCaseRepository } from '../../interface/repository.interface'
import {
    IAssignSurveyorCaseSchema,
    ISurveyorCaseModel,
} from '../../interface/model.interface'
import { IncidentEvent } from '../../../../pubsub/event.enum'
import { ILineAdapter } from '../../../../adapter/line/interface/line.interface'
import {
    IWebSocketAdapter,
    ReminderEvent,
} from '../../../../adapter/notification/interfaces/socket.interface'
import { IAuthService } from '../../../../common/interface/auth.interface'
import { ISurveyorLineRepository } from '../../../surveyor-line/interface/repository.interface'
import { IGroupMessageSchema } from '../../../message/pubsub/schema/message-text.schema'
import { ContentTypeEnum } from '../../../../repository/message/message.schema'
import { MessageModel } from '../../../message/message.model'
import { IMessageRepository } from '../../../message/interface'
import {
    IFlexPayloadSchema,
    ILocationPayloadSchema,
} from '../../../message/interface/schema.interface'
import { ILoggerService } from '../../../../common/interface/logger.interface'

export class IncidentSurveyorAssignedSubscriber extends AbstractSubscriber {
    constructor(
        private readonly _config: IConfig,
        private readonly _surveyorRepository: ISurveyorRepository,
        private readonly _surveyorCaseRepository: ISurveyorCaseRepository,
        private readonly _incidentRepository: IIncidentRepository,
        private readonly _lineAdapter: ILineAdapter,
        private readonly _socketAdapter: IWebSocketAdapter,
        private readonly _auth: IAuthService,
        private readonly _surveyorLineRepository: ISurveyorLineRepository,
        private readonly _messageRepository: IMessageRepository,
        private readonly _loggerService: ILoggerService,
    ) {
        super(IncidentEvent.INCIDENT_SURVEYOR_ASSIGNED)
        this._loggerService.setContext('Surveyor Case Service')
    }

    public onEventPublished(topic: string, data: Buffer): Observable<any> {
        const url = this._config.surveyorUrl.surveyorWeb
        const jsonData: IIncidentEventSchema = JSON.parse(data.toString('utf8'))
        const timeStamp = new Date()

        return forkJoin([
            this.checkIncident(jsonData.incidentNo),
            this.checkSurveyor(jsonData.surveyorNo, jsonData.incidentNo).pipe(
                mergeMap((surveyor: ISurveyorModel) => {
                    return this.generateId(surveyor).pipe(
                        map((genId: string) => {
                            return ({ genId, surveyor })
                        }),
                    )
                }),
            ),
            this._surveyorLineRepository.getBySurveyorId(jsonData.surveyorNo),
        ]).pipe(
            concatMap((result) => {
                return this.deleteCaseIfExisted(result[0]).pipe(
                    map(() => result),
                )
            }),
            concatMap((result) => {
                const incident: IIncidentModel = result[0]

                const surveyorCaseData = result[1]
                const generateId = surveyorCaseData.genId
                const surveyorModel = surveyorCaseData.surveyor

                const surveyorLine = result[2]

                const caseModel = new SurveyorCaseModel()
                caseModel.setId(generateId)
                caseModel.setCreatedAt(timeStamp)
                caseModel.setIncidentNo(incident.getId())
                caseModel.setSurveyorNo(jsonData.surveyorNo)
                caseModel.setSurveyorCompanyNo(jsonData.surveyorNo)
                caseModel.setCustomerName(incident.getCallerName())
                caseModel.setCustomerPhone(incident.getContactNo())
                caseModel.setProvince(jsonData.province)
                caseModel.setDistrict(jsonData.district)
                if (!_.isNil(incident.getSurveyor())) {
                    caseModel.setPlace(incident.getSurveyor().place)
                }

                return this._surveyorCaseRepository.save(caseModel).pipe(
                    map(() => ({ caseModel, surveyorModel, surveyorLine })),
                    tap(() => {
                        this._loggerService.info(`surveyor case id: ${generateId} was created by ${jsonData.createdBy}`)
                    }),
                )
            }),
            concatMap(({ caseModel, surveyorModel, surveyorLine }) => {
                const schema: IAssignSurveyorCaseSchema = {
                    lineId: surveyorLine.getId(),
                    surveyorId: surveyorModel.getId(),
                    caseNo: caseModel.getId(),
                    callerName: caseModel.getCustomerName(),
                    callerPhone: caseModel.getCustomerPhone(),
                }

                return this.assignCaseSurveyorLineFlex(schema).pipe(
                    concatMap(container => {
                        return this._lineAdapter.pushFlexMessage(surveyorLine.getId(), container)
                    }),
                    mergeMap((pushResult) => {
                        const flexId = _.get(pushResult, 'x-line-request-id', null)
                        const groupCaseSocketSchema: IGroupMessageSchema = {
                            content: {
                                image: null,
                                location: {
                                    address: null,
                                    latitude: null,
                                    longitude: null,
                                    title: null,
                                },
                                stickerId: null,
                                text: `${caseModel.getCustomerName()} tel : ${caseModel.getCustomerPhone()}`,
                                type: ContentTypeEnum.FLEX,
                                header: caseModel.getId(),
                            },
                            from: {
                                id: null,
                                name: null,
                                sender: 'agent',
                            },
                            messageId: flexId,
                            timeStamp: timeStamp.getTime(),
                            groupId: surveyorLine.getId(),
                        }

                        const content: IFlexPayloadSchema = {
                            id: flexId,
                            header: caseModel.getId(),
                            text: `${caseModel.getCustomerName()} tel : ${caseModel.getCustomerPhone()}`,
                        }

                        const messageModel = new MessageModel()
                        messageModel.setContent(content)
                        messageModel.setGroup(surveyorLine.getId())
                        messageModel.setSender(null)
                        messageModel.setTimeStamp(timeStamp)
                        messageModel.setSenderName(null)
                        messageModel.setType(ContentTypeEnum.FLEX)
                        messageModel.setReceiver('user')

                        const newTitle = !_.isEmpty(jsonData.note) ? jsonData.note : jsonData.place

                        const location = {
                            type: 'location',
                            title: newTitle,
                            address: jsonData.place,
                            latitude: jsonData.lat,
                            longitude: jsonData.long,
                        }

                        return forkJoin([
                            this._lineAdapter.pushFlexMessage(surveyorLine.getId(), location).pipe(
                                mergeMap((pushLocation) => {
                                    const locationFlexId = _.get(pushLocation, 'x-line-request-id', null)
                                    const groupLocationSocketSchema: IGroupMessageSchema = {
                                        content: {
                                            image: null,
                                            location: {
                                                address: jsonData.place,
                                                latitude: jsonData.lat,
                                                longitude: jsonData.long,
                                                title: jsonData.note,
                                            },
                                            stickerId: null,
                                            text: null,
                                            type: ContentTypeEnum.LOCATION,
                                            header: caseModel.getId(),
                                        },
                                        from: {
                                            id: null,
                                            name: null,
                                            sender: 'agent',
                                        },
                                        messageId: locationFlexId,
                                        timeStamp: timeStamp.getTime(),
                                        groupId: surveyorLine.getId(),
                                    }

                                    return this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_GROUP, groupLocationSocketSchema).pipe(
                                        map(() => locationFlexId),
                                        // tap((s) => console.log(`socket >> `, s)),
                                    )
                                }),
                                mergeMap((locationFlexId) => {
                                    const mapContent: ILocationPayloadSchema = {
                                        id: locationFlexId,
                                        title: jsonData.note,
                                        address: jsonData.place,
                                        latitude: jsonData.lat,
                                        longitude: jsonData.long,
                                    }

                                    const mapMessage = new MessageModel()
                                    mapMessage.setContent(mapContent)
                                    mapMessage.setGroup(surveyorLine.getId())
                                    mapMessage.setSender(null)
                                    mapMessage.setTimeStamp(timeStamp)
                                    mapMessage.setSenderName(null)
                                    mapMessage.setType(ContentTypeEnum.LOCATION)
                                    mapMessage.setReceiver('user')

                                    return this._messageRepository.save(mapMessage)
                                }),
                            ),
                            this._socketAdapter.sendMessage(ReminderEvent.LINE_NEW_MESSAGE_GROUP, groupCaseSocketSchema),
                            this._messageRepository.save(messageModel),
                        ])
                    }),
                )
            }),
        )
    }

    private checkSurveyor(surveyorId: string, incidentId: string): Observable<ISurveyorModel> {
        return this._surveyorRepository.getById(surveyorId).pipe(
            map(result => {
                if (_.isNil(result)) {
                    throw new HttpException(
                        `Surveyor not found`,
                        HttpStatus.NOT_FOUND,
                    )
                }

                return result
            }),
            map((surveyor: ISurveyorModel) => {
                const jobs = surveyor.getAssignedJob()
                const findIncident = _.find(jobs, (job) => job === incidentId)
                if (_.isNil(findIncident)) {
                    throw new HttpException(
                        `Incident was not assigned to this surveyor`,
                        HttpStatus.BAD_REQUEST,
                    )
                }

                return surveyor
            }),
        )
    }

    private generateId(surveyor: ISurveyorModel): Observable<string> {
        const startDate = moment().format('YYYY-MM')
        const start = startDate + '-1' + ' 00:00:00'

        const filterSchema = {
            $and: [
                {
                    createdAt: {
                        $gte: new Date(start),
                    },
                },
                {
                    createdAt: {
                        $lte: new Date(),
                    },
                },
                {
                    surveyorNo: surveyor.getId(),
                },
            ],
        }

        const idGenerationFunction = () => {
            const prefix = moment().format('YYYYMM')
            const running = '000'
            const company = surveyor.getCompanyInitial()

            return company + prefix + running
        }

        return this._surveyorCaseRepository.find(filterSchema).pipe(
            take(1),
            map((model: ISurveyorCaseModel) => model.getId()),
            defaultIfEmpty(idGenerationFunction()),
            mergeMap((id) => {
                const running = id.slice(-3)
                const newRunning = _.toNumber(running) + 1
                const newCaseNo = id.substring(0, id.length - 3)

                return of(newCaseNo + ('000' + newRunning).slice(-3))
            }),
        )
    }

    private checkIncident(incidentId: string): Observable<IIncidentModel> {
        return this._incidentRepository.find({ _id: incidentId }).pipe(
            throwIfEmpty(() => {
                throw new HttpException(
                    `incident not found`,
                    HttpStatus.NOT_FOUND,
                )
            }),
            map((incident: IIncidentModel) => {
                if (_.isNil(incident.getSurveyor())) {
                    throw new HttpException(
                        `Incident was not assigned`,
                        HttpStatus.BAD_REQUEST,
                    )
                }

                return incident
            }),
        )
    }

    private deleteCaseIfExisted(incidentModel: IIncidentModel): Observable<any> {
        return this._surveyorCaseRepository.getByIncidentNumber(incidentModel.getId()).pipe(
            mergeMap(existingCase => {
                return this._surveyorCaseRepository.delete(existingCase)
            }),
            catchError(() => of({})), // ignore any error
        )
    }

    private assignCaseSurveyorLineFlex(caseModel: IAssignSurveyorCaseSchema): Observable<any> {
        const path = `${this._config.surveyorUrl.surveyorWeb}`
        const surveyorId = caseModel.surveyorId
        const caseNo = caseModel.caseNo
        const name = caseModel.callerName
        const phone = caseModel.callerPhone
        const payloadJson = {
            lineId: caseModel.lineId,
        }
        return this._auth.generateJWT(payloadJson).pipe(
            map((token: string) => {
                return {
                    caseNo,
                    infoAssign: `${name} tel : ${phone}`,
                    receiveURL: `${path}/surveyor/${surveyorId}/case/${caseNo}/accept?token=${token}`,
                    cancelURL: `${path}/surveyor/${surveyorId}/case/${caseNo}/cancel?token=${token}`,
                    detailURL: `${path}/surveyor/${surveyorId}/case/${caseNo}/view?token=${token}`,
                }
            }),
            map((content: any) => {
                return {
                    type: 'flex',
                    altText: `Case: ${content.caseNo}`,
                    contents: {
                        type: 'bubble',
                        direction: 'ltr',
                        body: {
                            type: 'box',
                            layout: 'vertical',
                            spacing: 'md',
                            contents: [
                                {
                                    type: 'text',
                                    text: content.caseNo,
                                    size: 'xl',
                                    align: 'start',
                                    weight: 'bold',
                                    wrap: true,
                                },
                                {
                                    type: 'text',
                                    text: content.infoAssign,
                                    align: 'start',
                                    gravity: 'top',
                                },
                                {
                                    type: 'separator',
                                    margin: 'xl',
                                },
                                {
                                    type: 'box',
                                    layout: 'vertical',
                                    contents: [
                                        {
                                            type: 'button',
                                            action: {
                                                type: 'uri',
                                                label: 'รับงาน / Receive',
                                                uri: content.receiveURL,
                                            },
                                            gravity: 'center',
                                        },
                                        {
                                            type: 'button',
                                            action: {
                                                type: 'uri',
                                                label: 'ยกเลิก / Cancel',
                                                uri: content.cancelURL,
                                            },
                                        },
                                        {
                                            type: 'button',
                                            action: {
                                                type: 'uri',
                                                label: 'รายละเอียด / Detail',
                                                uri: content.detailURL,
                                            },
                                        },
                                    ],
                                },
                            ],
                        },
                    },
                }
            }),
        )
    }
}
