export interface ICaseNotArriveEventSchema {
    timeSchedule: number,
    lineId: string,
    surveyorId: string,
    caseNo: string,
    companyNo: string,
    employeeName: string,
    employeePhone: string,
    type: TypeFlexEnum
}

export enum TypeFlexEnum {
    USER = 'user',
    GROUP = 'group',
}
