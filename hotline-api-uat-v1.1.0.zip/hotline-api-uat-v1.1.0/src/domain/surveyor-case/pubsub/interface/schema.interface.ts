import { ISurveyorAssignmentSchema } from '../../../../repository/surveyor-case/case.schema'

export interface IIncidentEventSchema {
    incidentNo: string
    callerName: string
    contactNo: string
    place: string
    lat: number
    long: number
    surveyorNo: string
    province: string
    district: string
    note: string
    createdBy: string
}

export interface IUpdateSurveyorCaseEventSchema {
    id: string
    incidentNo: string
    surveyorNo: string
    customerName: string
    customerPhone: string
    place: string
    province: string
    district: string
    surveyorAssignment: ISurveyorAssignmentSchema[]
    timestamp: number
}

export interface ISurveyorAssignmentEventSchema {
    name: string
    phone: string
    remark: string
    createdDate: Date
}

export interface IReConfirmEventSchema {
    guarantee: boolean
    groupId: string
}
