import { AbstractDomainEvent } from '../../../../pubsub/abstract.domain-event'
import { SurveyorEvent } from '../../../../pubsub/event.enum'
import { IReConfirmEventSchema } from '../interface/schema.interface'

export class ReConfirmSurveyorArrivedEvent extends AbstractDomainEvent<IReConfirmEventSchema, IReConfirmEventSchema> {
    constructor(data: IReConfirmEventSchema) {
        super(SurveyorEvent.RECONFIRM_SURVEYOR_ARRIVED, data)
    }

    public serialize(model: IReConfirmEventSchema): IReConfirmEventSchema {
        return {
            guarantee: model.guarantee,
            groupId: model.groupId,
        }
    }
}
