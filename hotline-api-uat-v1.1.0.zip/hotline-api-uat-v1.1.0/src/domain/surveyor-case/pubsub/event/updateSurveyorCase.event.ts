import { IUpdateSurveyorCaseEventSchema } from '../interface/schema.interface'
import {
    ISurveyorAssignmentModel,
    ISurveyorCaseModel,
} from '../../interface/model.interface'
import { AbstractDomainEvent } from '../../../../pubsub/abstract.domain-event'
import { ISurveyorAssignmentSchema } from '../../../../repository/surveyor-case/case.schema'
import { SurveyorEvent } from '../../../../pubsub/event.enum'

export class UpdateSurveyorAssignmentEvent extends AbstractDomainEvent<ISurveyorCaseModel, IUpdateSurveyorCaseEventSchema> {
    constructor(data: ISurveyorCaseModel) {
        super(SurveyorEvent.UPDATE_SURVEYOR_ASSIGNMENT, data)
    }

    public serialize(model: ISurveyorCaseModel): IUpdateSurveyorCaseEventSchema {
        const assignments: ISurveyorAssignmentModel[] =  model.getSurveyorAssignment()
        const surveyorAssignment: ISurveyorAssignmentSchema[] = assignments.map( (item) => {
            return {
                name: item.getName(),
                phone: item.getPhone(),
                remark: item.getRemark(),
                createdDate: new Date(),
            }
        })
        console.log('publish assignment => ' + surveyorAssignment)
        return {
            id: model.getId(),
            incidentNo: model.getIncidentNo(),
            surveyorNo: model.getSurveyorCompanyNo(),
            customerName: model.getCustomerName(),
            customerPhone: model.getCustomerPhone(),
            place: model.getPlace(),
            province: model.getProvince(),
            district: model.getDistrict(),
            surveyorAssignment,
            timestamp: Date.now(),
        }
    }
}
