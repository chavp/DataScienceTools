import { AbstractDomainEvent } from '../../../../pubsub/abstract.domain-event'
import { ICaseNotArriveEventSchema } from '../interface/case-not-arrive-interface'
import { SurveyorEvent } from '../../../../pubsub/event.enum'

export class CaseNotArriveEvent extends AbstractDomainEvent<ICaseNotArriveEventSchema, ICaseNotArriveEventSchema> {
    constructor(data: ICaseNotArriveEventSchema) {
        super(SurveyorEvent.CASE_NOT_ARRIVE, data)
    }

    public serialize(model: ICaseNotArriveEventSchema): ICaseNotArriveEventSchema {
        return {
            timeSchedule: model.timeSchedule,
            lineId: model.lineId,
            surveyorId: model.surveyorId,
            caseNo: model.caseNo,
            companyNo: model.companyNo,
            employeeName: model.employeeName,
            employeePhone: model.employeePhone,
            type: model.type,
        }
    }
}
