import { IEntity } from '../../../common/interface/entity.interface'
import { SchedulerTypeEnum } from './scheduler-type.enum'
import { TypeFlexEnum } from '../../surveyor-case/pubsub/interface/case-not-arrive-interface'

export interface ISchedulerConfigModel extends IEntity {
    getName(): string

    getType(): TypeFlexEnum

    getDays(): number[]

    getTime(): string

    getDate(): Date

    getCreatedDate(): Date

    getUpdatedDate(): Date

    setName(name: string): void

    getTimeSchedule(): number

    getLineId(): string

    getSurveyorId(): string

    getCaseNo(): string

    getCompanyNo(): string

    getEmployeeName(): string

    getEmployeePhone(): string

    setType(type: TypeFlexEnum): void

    setDays(days: number[]): void

    addDay(day: number): number

    setTime(timeOfDay: string): void

    setDate(date: Date): void

    setCreatedDate(date: Date): void

    setUpdatedDate(date: Date): void

    activate(): void

    deactivate(): void

    isActivated(): boolean

    setTimeSchedule(timeSchedule: number): void

    setLineId(lineId: string): void

    setSurveyorId(surveyorId: string): void

    setCaseNo(caseNo: string): void

    setCompanyNo(companyNo: string): void

    setEmployeeName(employeeName: string): void

    setEmployeePhone(employeePhone: string): void

}
