export enum SchedulerTypeEnum {
    FIXED = 'fixed',
    RECURRING = 'recurring',
}
