import { IRepository } from '../../../common/interface/repository.interface'
import { ISchedulerConfigModel } from './model.interface'
import { Observable } from 'rxjs'

export interface ISchedulerTasksRepository extends IRepository<ISchedulerConfigModel> {

    save(model: ISchedulerConfigModel): Observable<{ id: string }>

    getById(id: string): Observable<ISchedulerConfigModel>

    update(model: ISchedulerConfigModel): Observable<ISchedulerConfigModel>

    delete(model: ISchedulerConfigModel): Observable<ISchedulerConfigModel>

    find(filter: any): Observable<ISchedulerConfigModel>

}
