import { SchedulerTypeEnum } from './scheduler-type.enum'

export interface IScheduleRecurringValidator {
    getName(): string

    getType(): SchedulerTypeEnum

    getDays(): number[]

    getTime(): string

}

export interface IScheduleFixedValidator {
    getName(): string

    getType(): SchedulerTypeEnum

    getDate(): number

}

export interface ISchedulerUpdateValidator {
    getName(): string

    getDate(): number

    getDays(): number[]

    getTime(): string

}
