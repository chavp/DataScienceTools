import {
    IScheduleFixedValidator,
    IScheduleRecurringValidator,
    ISchedulerUpdateValidator,
} from './validator.interface'
import { Observable } from 'rxjs'
import { ISchedulerConfigModel } from './model.interface'
import { ScheduledTask } from 'node-cron'

export interface ISchedulerService {
    createNewScheduler(input: IScheduleFixedValidator | IScheduleRecurringValidator): Observable<{ id: string }>

    updateScheduler(id: string, input: ISchedulerUpdateValidator): Observable<ISchedulerConfigModel>

    deleteSchedule(id: string): Observable<ISchedulerConfigModel>

    activateSchedulerTask(id: string): Observable<ISchedulerConfigModel>

    deactivateSchedulerTask(id: string): Observable<ISchedulerConfigModel>

    listAllTasks(): Observable<ISchedulerConfigModel>

    getTaskDetail(id: string): Observable<ISchedulerConfigModel>
}

export interface IScheduleManager {
    addTask(model: ISchedulerConfigModel): Observable<ScheduledTask>

    activateTask(model: ISchedulerConfigModel): Observable<ScheduledTask>

    deactivateTask(model: ISchedulerConfigModel): Observable<ScheduledTask>

    deleteTask(model: ISchedulerConfigModel): Observable<any>
}
