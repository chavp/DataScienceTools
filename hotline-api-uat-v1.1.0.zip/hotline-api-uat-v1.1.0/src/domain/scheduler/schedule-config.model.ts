import { Entity } from '../../common/entity'
import { ISchedulerConfigModel } from './interface/model.interface'
import { SchedulerTypeEnum } from './interface/scheduler-type.enum'
import * as _ from 'lodash'
import { TypeFlexEnum } from '../surveyor-case/pubsub/interface/case-not-arrive-interface'

export class ScheduleConfigModel extends Entity implements ISchedulerConfigModel {
    private _days: number[]
    private _date: Date
    private _createdDate: Date
    private _updatedDate: Date
    private _name: string
    private _type: TypeFlexEnum
    private _time: string
    private _activated: boolean
    private _timeSchedule: number
    private _lineId: string
    private _surveyorId: string
    private _caseNo: string
    private _companyNo: string
    private _employeeName: string
    private _employeePhone: string

    constructor() {
        super()
        this._createdDate = new Date()
        this._updatedDate = new Date()
        this._days = []
        this._date = null
        this._name = ''
        this._type = null
        this._time = ''
        this._activated = true
    }

    public addDay(day: number): number {
        this.assertTrue(_.findIndex(this._days, day) === -1,
            `Day ${day} existed`,
        )

        this.assertTrue(
            _.includes([0, 1, 2, 3, 4, 5, 6], day),
            `Day must be range of 0 - 6`,
        )
        return 0
    }

    public getCreatedDate(): Date {
        return new Date(this._createdDate)
    }

    public getDate(): Date {
        return new Date(this._date)
    }

    public getDays(): number[] {
        return _.slice(this._days)
    }

    public getName(): string {
        return this._name
    }

    public getTime(): string {
        return this._time
    }

    public getType(): TypeFlexEnum {
        return this._type
    }

    public getUpdatedDate(): Date {
        return new Date(this._updatedDate)
    }

    public setCreatedDate(date: Date): void {
        this._createdDate = new Date(date)
    }

    public setDate(date: Date): void {
        this._date = new Date(date)
    }

    public setDays(days: number[]): void {
        this.assertTrue(
            _.uniq(days).length === days.length,
            `Days not unique`,
        )
        days.forEach(dayNumber => {
            this.assertTrue(
                _.includes([0, 1, 2, 3, 4, 5, 6], dayNumber),
                `Day must be range of 0 - 6`,
            )
        })

        this._days = _.slice(days)
    }

    public setName(name: string): void {
        this._name = name
    }

    public setTime(timeOfDay: string): void {
        this.assertTrue(
            _.isEmpty(timeOfDay) || /^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/.test(timeOfDay),
            `Invalid time format HH:mm, found ${timeOfDay}`,
        )
        this._time = timeOfDay
    }

    public setType(type: TypeFlexEnum): void {
        this._type = type
    }

    public setUpdatedDate(date: Date): void {
        this._updatedDate = new Date(date)
    }

    public activate(): void {
        this._activated = true
    }

    public deactivate(): void {
        this._activated = false
    }

    public isActivated(): boolean {
        return !!this._activated
    }

    public getCaseNo(): string {
        return this._caseNo
    }

    public getCompanyNo(): string {
        return this._companyNo
    }

    public getEmployeeName(): string {
        return this._employeeName
    }

    public getEmployeePhone(): string {
        return this._employeePhone
    }

    public getLineId(): string {
        return this._lineId
    }

    public getSurveyorId(): string {
        return this._surveyorId
    }

    public getTimeSchedule(): number {
        return this._timeSchedule
    }

    public setCaseNo(caseNo: string): void {
        this._caseNo = caseNo
    }

    public setCompanyNo(companyNo: string): void {
        this._companyNo = companyNo
    }

    public setEmployeeName(employeeName: string): void {
        this._employeeName = employeeName
    }

    public setEmployeePhone(employeePhone: string): void {
        this._employeePhone = employeePhone
    }

    public setLineId(lineId: string): void {
        this._lineId = lineId
    }

    public setSurveyorId(surveyorId: string): void {
        this._surveyorId = surveyorId
    }

    public setTimeSchedule(timeSchedule: number): void {
        this._timeSchedule = timeSchedule
    }

}
