import { ISchedulerTasksRepository } from './interface/repository.interface'
import {
    schedule,
    ScheduledTask,
} from 'node-cron'
import {
    Observable,
    of,
} from 'rxjs'
import {
    concatMap,
    map,
    mergeMap,
} from 'rxjs/operators'
import * as Moment from 'moment'
import { IScheduleManager } from './interface/service.interface'
import { ISchedulerConfigModel } from './interface/model.interface'
import * as _ from 'lodash'
import { ISurveyorCaseArriveBuilder } from '../surveyor-case/interface/builder.confirmArrive.interface'
import { ILineAdapter } from '../../adapter/line/interface/line.interface'
import {
    ICaseNotArriveEventSchema,
    TypeFlexEnum,
} from '../surveyor-case/pubsub/interface/case-not-arrive-interface'

export class ScheduleManager implements IScheduleManager {

    private readonly _taskMap: Map<string, ScheduledTask>

    constructor(
        private readonly _scheduleRepository: ISchedulerTasksRepository,
        private readonly _lineAdapter: ILineAdapter,
        private readonly _flex: ISurveyorCaseArriveBuilder,
    ) {
        this._taskMap = new Map<string, ScheduledTask>()

        this._init().subscribe()
    }

    private _init(): Observable<any> {
        console.log('init tasks')
        return this._scheduleRepository.list(1, 0).pipe(
            mergeMap(model => {
                console.log(model)
                return this._buildTask(model)
            }),
        )

    }

    private _buildTask(model: ISchedulerConfigModel): Observable<ScheduledTask> {
        return of(model).pipe(
            map(() => {
                let task = null
                const momentDate = Moment(model.getDate())
                const minute = momentDate.format('mm')
                const hour = momentDate.format('HH')
                const day = momentDate.format('D')
                const month = momentDate.format('M')
                const schema: ICaseNotArriveEventSchema = {
                    lineId: model.getLineId(),
                    surveyorId: model.getSurveyorId(),
                    caseNo: model.getCaseNo(),
                    companyNo: model.getCompanyNo(),
                    employeeName: model.getEmployeeName(),
                    employeePhone: model.getEmployeePhone(),
                    timeSchedule: model.getTimeSchedule(),
                    type: model.getType(),
                }

                if (model.getType() === TypeFlexEnum.GROUP) {
                    task = schedule(
                        `${minute} ${hour} ${day} ${month} *`,
                        () => {
                            console.log(`fire task ${model.getName()}`)
                            this._flex.groupLineFlex(schema, 'ยืนยันการถึงที่หมายภายใน 30 นาที').pipe(
                                concatMap(res => {
                                    return this._lineAdapter.pushFlexMessage(model.getLineId(), res)
                                }),
                            ).subscribe()
                        }, {
                            scheduled: model.isActivated(),
                        })

                    this._taskMap.set(model.getId(), task)
                } else if (model.getType() === TypeFlexEnum.USER) {
                    task = schedule(
                        `${minute} ${hour} ${day} ${month} *`,
                        () => {
                            console.log(`fire task ${model.getName()}`)
                            this._flex.userLineFlex(schema, 'ยืนยันการถึงที่หมายภายใน 30 นาที').pipe(
                                concatMap(res => {
                                    return this._lineAdapter.pushFlexMessage(model.getLineId(), res)
                                }),
                            ).subscribe()
                        }, {
                            scheduled: model.isActivated(),
                        })

                    this._taskMap.set(model.getId(), task)
                }

                return task
            }),
        )
    }

    public activateTask(model: ISchedulerConfigModel): Observable<ScheduledTask> {
        return of(model).pipe(
            mergeMap(() => {
                const task = this._taskMap.get(model.getId())
                if (_.isNil(task)) {
                    return this._buildTask(model)
                }

                return of(task)
            }),
            map(task => {
                task.start()
                return task
            }),
        )
    }

    public addTask(model: ISchedulerConfigModel): Observable<ScheduledTask> {
        console.log(`add new task ${model}`)
        return this._buildTask(model)
    }

    public deactivateTask(model: ISchedulerConfigModel): Observable<ScheduledTask> {
        return of(model).pipe(
            mergeMap(() => {
                const task = this._taskMap.get(model.getId())
                if (_.isNil(task)) {
                    return this._buildTask(model)
                }

                return of(task)
            }),
            map((task: ScheduledTask) => {
                task.stop()
                return task
            }),
        )
    }

    public deleteTask(model: ISchedulerConfigModel): Observable<any> {
        return this.deactivateTask(model).pipe(
            map((task: ScheduledTask) => {
                task.destroy()
                this._taskMap.delete(model.getId())
                return model
            }),
        )
    }

}
