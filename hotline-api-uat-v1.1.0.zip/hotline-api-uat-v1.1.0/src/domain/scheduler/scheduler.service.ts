import {
    IScheduleManager,
    ISchedulerService,
} from './interface/service.interface'
import { ISchedulerTasksRepository } from './interface/repository.interface'
import {
    IScheduleFixedValidator,
    IScheduleRecurringValidator,
    ISchedulerUpdateValidator,
} from './interface/validator.interface'
import { ISchedulerConfigModel } from './interface/model.interface'
import {
    Observable,
    of,
    throwError,
} from 'rxjs'
import {
    map,
    mergeMap,
} from 'rxjs/operators'
import { SchedulerTaskBuilder } from './scheduler-task.builder'
import { SchedulerTypeEnum } from './interface/scheduler-type.enum'
import * as _ from 'lodash'
import { InternalServerErrorException } from '@nestjs/common'
import { TypeFlexEnum } from '../surveyor-case/pubsub/interface/case-not-arrive-interface'

export class SchedulersService implements ISchedulerService {
    constructor(
        private readonly _schedulerRepository: ISchedulerTasksRepository,
        private readonly _taskManager: IScheduleManager,
    ) {
    }

    public activateSchedulerTask(id: string): Observable<ISchedulerConfigModel> {
        return this._schedulerRepository.getById(id).pipe(
            map(model => {
                model.activate()
                return model
            }),
            mergeMap(model => {
                return this._schedulerRepository.update(model)
            }),
            mergeMap((model) => {
                return this._taskManager.activateTask(model).pipe(
                    map(() => model),
                )
            }),
        )
    }

    public createNewScheduler(input: IScheduleFixedValidator | IScheduleRecurringValidator): Observable<{ id: string }> {

        return throwError(() => new InternalServerErrorException(`Not implemented`))

    }

    public deleteSchedule(id: string): Observable<ISchedulerConfigModel> {
        return this._schedulerRepository.getById(id).pipe(
            mergeMap(model => {
                return this._schedulerRepository.delete(model)
            }),
            mergeMap((model) => {
                return this._taskManager.deleteTask(model).pipe(
                    map(() => model),
                )
            }),
        )
    }

    public deactivateSchedulerTask(id: string): Observable<ISchedulerConfigModel> {
        return this._schedulerRepository.getById(id).pipe(
            map(model => {
                model.deactivate()
                return model
            }),
            mergeMap(model => {
                return this._schedulerRepository.update(model)
            }),
            mergeMap((model) => {
                return this._taskManager.deactivateTask(model).pipe(
                    map(() => model),
                )
            }),
        )
    }

    public listAllTasks(): Observable<ISchedulerConfigModel> {
        return this._schedulerRepository.list(1, 0)
    }

    public updateScheduler(id: string, input: ISchedulerUpdateValidator): Observable<ISchedulerConfigModel> {
        return throwError(() => new InternalServerErrorException(`Not implemented`))
    }

    public getTaskDetail(id: string): Observable<ISchedulerConfigModel> {
        return this._schedulerRepository.getById(id)
    }
}
