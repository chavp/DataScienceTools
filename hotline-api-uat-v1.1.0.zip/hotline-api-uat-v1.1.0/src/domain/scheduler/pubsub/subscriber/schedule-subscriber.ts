import { AbstractSubscriber } from '../../../../pubsub/abstract.subscriber'
import {
    DomainEvent,
    SurveyorEvent,
} from '../../../../pubsub/event.enum'
import {
    Observable,
    of,
} from 'rxjs'
import { IScheduleManager } from '../../interface/service.interface'
import { ICaseNotArriveEventSchema } from '../../../surveyor-case/pubsub/interface/case-not-arrive-interface'
import {
    map,
    mergeMap,
} from 'rxjs/operators'
import { SchedulerTaskBuilder } from '../../scheduler-task.builder'
import { ISchedulerTasksRepository } from '../../interface/repository.interface'

export class ScheduleSubscriber extends AbstractSubscriber {
    constructor(
        private readonly _taskManager: IScheduleManager,
        private readonly _schedulerRepository: ISchedulerTasksRepository,
    ) {
        super(SurveyorEvent.CASE_NOT_ARRIVE)
    }

    public onEventPublished(topic: DomainEvent | string, buffer: Buffer): Observable<any> {
        const jsonData: ICaseNotArriveEventSchema = JSON.parse(buffer.toString('utf8'))
        return of(jsonData).pipe(
            map((data) => {
                const builder: SchedulerTaskBuilder = new SchedulerTaskBuilder(data.type)
                builder.name('line')
                    .activated('activated')
                    .lineId(data.lineId)
                    .surveyorId(data.surveyorId)
                    .employeePhone(data.employeePhone)
                    .employeeName(data.employeeName)
                    .companyNo(data.companyNo)
                    .caseNo(data.caseNo)
                    .triggerOnce(new Date(data.timeSchedule))
                return builder.build()
            }),
            mergeMap(model => {
                return this._schedulerRepository.save(model)
            }),
            mergeMap((result) => {
                return this._schedulerRepository.getById(result.id).pipe(
                    mergeMap((model) => {
                        return this._taskManager.addTask(model).pipe(
                            map(() => model),
                        )
                    }),
                    map(() => result),
                )
            }),
        )
    }

}
