import { ScheduleConfigModel } from './schedule-config.model'
import { ISchedulerConfigModel } from './interface/model.interface'
import { TypeFlexEnum } from '../surveyor-case/pubsub/interface/case-not-arrive-interface'

export class SchedulerTaskBuilder {
    private readonly _model: ISchedulerConfigModel

    constructor(type: TypeFlexEnum) {
        this._model = new ScheduleConfigModel()
        this._model.setType(type)
    }

    id(id: string) {
        this._model.setId(id)
        return this
    }

    name(name: string) {
        this._model.setName(name)
        return this
    }

    updatedDate(date: Date) {
        this._model.setUpdatedDate(date)
        return this
    }

    createdDate(date: Date) {
        this._model.setCreatedDate(date)
        return this
    }

    triggerOnce(date: Date) {
        this._model.setDate(date)
        return this
    }

    triggerTime(time: string) {
        this._model.setTime(time)
        return this
    }

    days(days: number[]) {
        this._model.setDays(days)
        return this
    }

    activated(status: 'activated' | 'inactivated') {
        if (status === 'activated') {
            this._model.activate()
        } else {
            this._model.deactivate()
        }
        return this
    }

    timeSchedule(timeSchedule: number) {
        this._model.setTimeSchedule(timeSchedule)
        return this
    }

    lineId(lineId: string) {
        this._model.setLineId(lineId)
        return this
    }

    surveyorId(surveyorId: string) {
        this._model.setSurveyorId(surveyorId)
        return this
    }

    caseNo(caseNo: string) {
        this._model.setCaseNo(caseNo)
        return this
    }

    companyNo(companyNo: string) {
        this._model.setCompanyNo(companyNo)
        return this
    }

    employeeName(employeeName: string) {
        this._model.setEmployeeName(employeeName)
        return this
    }

    employeePhone(employeePhone: string) {
        this._model.setEmployeePhone(employeePhone)
        return this
    }

    build(): ISchedulerConfigModel {
        return this._model
    }
}
