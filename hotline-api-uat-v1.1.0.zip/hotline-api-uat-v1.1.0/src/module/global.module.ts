import {
    Global,
    Module,
} from '@nestjs/common'
import { environmentConfig } from '../provider/env-config'
import { databaseProviders } from '../provider/database'
import { repositoryProviders } from '../provider/repository'
import { repositoryMappingProviders } from '../provider/mapping'

@Global()
@Module({
    providers: [
        ...environmentConfig,
        ...databaseProviders,
        ...repositoryProviders,
        ...repositoryMappingProviders,
    ],
    exports: [
        ...environmentConfig,
        ...databaseProviders,
        ...repositoryProviders,
        ...repositoryMappingProviders,
    ],
})
export class GlobalModule {
}
