import {
    Module,
} from '@nestjs/common'
import {
    eventBusProvider,
} from '../provider/eventbus'

@Module({
    providers: [
        eventBusProvider,
    ],
    exports: [
        eventBusProvider,
    ],
})
export class PubSubModule {}
