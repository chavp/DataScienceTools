import {
    Inject,
    MiddlewareConsumer,
    Module,
    NestModule,
    OnModuleInit,
    RequestMethod,
} from '@nestjs/common'

import { ProviderName } from '../provider'
import { CommonController } from '../controller/rest/common.controller'
import {
    audioDecoder,
    audioTranscoder,
    authServiceProvider,
    ccreportServiceProvider,
    commonServiceProvider,
    confirmArriveBuilder,
    dashboardServiceProvider,
    incidentServiceProviders,
    lineProfileServiceProvider,
    managementQAServiceProvider,
    messageServiceProvider,
    permissionServiceProvider,
    profileServiceProvider,
    recorderQAServiceProvider,
    reminderServiceProviders,
    remindingScheduleProvider,
    reportServiceProvider,
    schedulerServiceProviders,
    schedulerTackServiceProviders,
    surveyorCaseServiceProvider,
    surveyorExcelServiceProvider,
    surveyorLineServiceProvider,
    surveyorServiceProviders,
    templateServiceProvider,
    loggerServiceProvider,
} from '../provider/service'
import { adapterProvider } from '../provider/adapter'
import { IncidentController } from '../controller/rest/incident.controller'
import { CCReportController } from '../controller/rest/ccreport.controller'
import { DashboardController } from '../controller/rest/dashboard.controller'
import { ReportController } from '../controller/rest/report.controller'
import { SurveyorController } from '../controller/rest/surveyor.controller'
import { SmsController } from '../controller/rest/sms.controller'
import { ReminderController } from '../controller/rest/reminder.controller'
import { UserController } from '../controller/rest/user.controller'
import { PubSubModule } from './pubsub'
import { SurveyorCaseController } from '../controller/rest/surveyor-case.controller'
import { ProfileController } from '../controller/rest/profile.controller'
import { PermissionController } from '../controller/rest/permission.controller'
import { migrationTasks } from '../migration'
import { IMigrationTask } from '../migration/interface/migration.interface'
import { SurveyorMigration } from '../migration/surveyor'
import { ManagementQAController } from '../controller/rest/managementQA.controller'
import { GlobalModule } from './global.module'
import { RecorderQAController } from '../controller/rest/recorderQA.controller'
import { LineController } from '../controller/rest/line.controller'
import { StaticController } from '../controller/rest/static.controller'
import { SurveyorLineController } from '../controller/rest/surveyor-line.controller'
import { imageStorageProviders } from '../provider/image-storage'
import { domainEventSubscribers } from '../provider/eventbus'
import { MessagingController } from '../controller/rest/messaging.controller'
import { MiddlewareGuard } from '../common/middleware/guards.middleware'

const {
    RECORDER_QA_SERVICE,
} = ProviderName

@Module({
    imports: [
        GlobalModule,
        PubSubModule,
    ],
    controllers: [
        CommonController,
        IncidentController,
        CCReportController,
        DashboardController,
        ReportController,
        SurveyorController,
        SmsController,
        ReminderController,
        UserController,
        SurveyorCaseController,
        ProfileController,
        PermissionController,
        ManagementQAController,
        RecorderQAController,
        LineController,
        StaticController,
        SurveyorLineController,
        MessagingController,
    ],
    providers: [
        // ...databaseProviders,
        // ...repositoryMappingProviders,
        // ...repositoryProviders,
        ...adapterProvider,
        authServiceProvider,
        commonServiceProvider,
        ...incidentServiceProviders,
        ccreportServiceProvider,
        dashboardServiceProvider,
        ...reportServiceProvider,
        ...surveyorServiceProviders,
        reminderServiceProviders,
        remindingScheduleProvider,
        surveyorCaseServiceProvider,
        profileServiceProvider,
        permissionServiceProvider,
        managementQAServiceProvider,
        surveyorExcelServiceProvider,
        ...migrationTasks,
        templateServiceProvider,
        recorderQAServiceProvider,
        audioDecoder,
        audioTranscoder,
        lineProfileServiceProvider,
        surveyorLineServiceProvider,
        ...imageStorageProviders,
        ...domainEventSubscribers,
        messageServiceProvider,
        schedulerServiceProviders,
        schedulerTackServiceProviders,
        confirmArriveBuilder,
        loggerServiceProvider,
    ],

})

export class MainModule implements OnModuleInit, NestModule {

    constructor(
        @Inject(SurveyorMigration) // class name
        private readonly _surveyorMigration: IMigrationTask,
    ) {
    }

    public onModuleInit(): any {
        // Run migration tasks
        console.log('Migration tasks started')
        this._surveyorMigration.run()
    }

    public configure(consumer: MiddlewareConsumer) {
        consumer
            .apply(MiddlewareGuard)
            .exclude(
                '/(.*)',
                // Add Routing Here...
            ).forRoutes(
            UserController,
            CommonController,
            IncidentController,
            CCReportController,
            DashboardController,
            ReportController,
            SurveyorController,
            SmsController,
            ReminderController,
            UserController,
            SurveyorCaseController,
            ProfileController,
            PermissionController,
            ManagementQAController,
            RecorderQAController,
            LineController,
            StaticController,
            SurveyorLineController,
            MessagingController,
            // Add Routing Here...
        )
    }
}
