// import { Module } from '@nestjs/common'
// import { profileServiceProvider } from '../provider/service'
// import { profileMappingProviders } from '../provider/mapping'
// import { profileRepositoryProviders } from '../provider/repository'
//
// @Module({
//     providers: [
//         profileServiceProvider,
//         profileMappingProviders,
//         profileRepositoryProviders,
//     ],
//     exports: [
//         profileServiceProvider,
//         profileMappingProviders,
//         profileRepositoryProviders,
//     ],
// })
//
// export class ProfileModule {}
