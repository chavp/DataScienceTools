import {ProviderName} from '../../provider'
import {
    Controller,
    Get,
    Headers,
    Inject,
    Query,
    Req,
    Res,
    UseGuards,
} from '@nestjs/common'

import {map, mergeMap, reduce, toArray, tap} from 'rxjs/operators'
import {CallbackDto, SurveyDto, PSurveyDto} from './dto/ccreport.dto'
import {ICCReportService} from '../../domain/ccreport/interface/service.interface'
import { ProfileGuard } from '../../common/guard/profile.guard'
import * as jwt from 'jsonwebtoken'
import { ILoggerService } from '../../common/interface/logger.interface'

const {
    CCREPORT_SERVICE,
    LOGGER_SERVICE,
} = ProviderName

@Controller('/ccreport')
export class CCReportController {

    constructor(
        @Inject(CCREPORT_SERVICE)
        private readonly _ccreportService: ICCReportService,
        @Inject(LOGGER_SERVICE)
        private readonly _loggerService: ILoggerService,
    ) {
        this._loggerService.setContext('Report Service')
    }

    @UseGuards(ProfileGuard)
    @Get('/callback')
    public getCallabck(
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Query('startdate') startdate: string,
        @Query('enddate') enddate: string,
        @Query('phone') phone: string,
        @Query('type') type: string, ) {

        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        const filter = { startdate, enddate, phone , type }
        const dataCallback = {
            total: 0,
            data: [],
        }

        return this._ccreportService.getCallabck(filter).pipe(
            map(models => {
                models.forEach((model) => {
                    dataCallback.data.push(CallbackDto.getCallbackDto(model))
                    ++dataCallback.total
                })
                return dataCallback
            }),
            tap(() => {
                this._loggerService.info(`search cc report by ${user} [${req.ip}]`)
            }),
        )
    }

    @UseGuards(ProfileGuard)
    @Get('/callback/excel')
    public getExportCallback(
        @Req() req,
        @Res() res,
        @Headers('x-profile') profileToken: string,
        @Query('startdate') startdate: string,
        @Query('enddate') enddate: string,
        @Query('phone') phone: string,
        @Query('type') type: string, ) {

        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        const filter = { startdate, enddate, phone, type }
        const dataCallback = []

        return this._ccreportService.getCallabck(filter).pipe(
            map(models => {
                models.forEach((model) => {
                    dataCallback.push(CallbackDto.getCallbackDto(model))
                })
                return dataCallback
            }),
            toArray(),
            mergeMap(dataExportCallback => {
                return this._ccreportService.exportCallabck('callback', dataExportCallback).pipe(
                    map(callbackExcel => callbackExcel.write('export.xls', res)),
                )
            }),
            tap(() => {
                this._loggerService.info(`export cc report by ${user} [${req.ip}]`)
            }),
        )
    }

    @UseGuards(ProfileGuard)
    @Get('/survey')
    public getSurvey(
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Query('startdate') startdate: string,
        @Query('enddate') enddate: string,
        @Query('type') type: string,
        @Query('user') user: string, ) {

        const profile: any = jwt.decode(profileToken)
        const agent = `${profile.given_name} ${profile.family_name}`

        const filter = { startdate, enddate, type , user  }
        const dataSurvey = {
            total: 0,
            data: [],
        }

        return this._ccreportService.getSurvey(filter).pipe(
            map(models => {
                models.forEach((model) => {
                    dataSurvey.data.push(SurveyDto.getSurveyDto(model))
                    ++dataSurvey.total
                })
                return dataSurvey
            }),
            tap(() => {
                this._loggerService.info(`search survey report by ${agent}`)
            }),
        )
    }

    @UseGuards(ProfileGuard)
    @Get('/survey/excel')
    public getExportSurvey(
        @Req() req,
        @Res() res,
        @Headers('x-profile') profileToken: string,
        @Query('startdate') startdate: string,
        @Query('enddate') enddate: string,
        @Query('type') type: string,
        @Query('user') user: string, ) {

        const profile: any = jwt.decode(profileToken)
        const agent = `${profile.given_name} ${profile.family_name}`

        const filter = { startdate, enddate, type , user  }
        const dataSurvey = []

        return this._ccreportService.getSurvey(filter).pipe(
            map(models => {
                models.forEach((model) => {
                    dataSurvey.push(SurveyDto.getSurveyDto(model))
                })
                return dataSurvey
            }),
            toArray(),
            mergeMap(dataExportSurvey => {
                return this._ccreportService.exportSurvey('survey', dataExportSurvey).pipe(
                    map(surveyExcel => surveyExcel.write('export.xls', res)),
                )
            }),
            tap(() => {
                this._loggerService.info(`export survey report by ${agent}`)
            }),
        )
    }

    @UseGuards(ProfileGuard)
    @Get('/psurvey')
    public getPSurvey(
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Query('date') date: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        const filter = { date }
        return this._ccreportService.getPSurvey(filter).pipe(
            map(models => {
                return PSurveyDto.getPSurveyDto(models)
            }),
            tap(model => {
                console.log('icf------>', model)
            }),
            tap(() => {
                this._loggerService.info(`search survey report by ${user} [${req.ip}]`)
            }),
        )
    }
}
