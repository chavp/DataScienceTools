import { ProviderName } from '../../provider'
import { IProfileService } from '../../domain/profile/interface/service.interface'
import {
    Body,
    Controller,
    Get,
    Headers,
    Inject,
    Param,
    Patch,
    Post,
    Put,
    Req,
    SetMetadata,
    UseGuards,
} from '@nestjs/common'
import {
    catchError,
    map,
    mergeMap,
    reduce,
    tap,
} from 'rxjs/operators'
import {
    IProfileDto,
    ProfileDto,
} from './dto/profile.dto'
import {
    CreateProfileValidator,
    UpdateProfileValidator,
} from './validator/profile.validator'
import * as jwt from 'jsonwebtoken'
import { IProfileModel } from '../../domain/profile/interface/model.interface'
import {
    AdminGuard,
    ProfileGuard,
    ProfileSessionGuard,
} from '../../common/guard/profile.guard'
import { IAuthService } from '../../common/interface/auth.interface'
import { Request } from 'express'
import { UserRolesEnum } from '../../repository/profile/profile.schema'
import {
    RoleGuard,
    Roles,
} from '../../common/guard/role-guard'
import { ILoggerService } from '../../common/interface/logger.interface'
import { v4 } from 'uuid'
import { of } from 'rxjs'
import { ClassStringify } from '../../utils/class-stringify'

const {
    PROFILE_SERVICE,
    AUTH_SERVICE,
    LOGGER_SERVICE,
} = ProviderName

@Controller('/profile')
export class ProfileController {
    constructor(
        @Inject(PROFILE_SERVICE)
        private readonly _profileService: IProfileService,
        @Inject(AUTH_SERVICE)
        private readonly _authService: IAuthService,
        @Inject(LOGGER_SERVICE)
        private readonly _loggerService: ILoggerService,
    ) {
        this._loggerService.setContext('Profile Service')
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/me')
    public getMyProfile(
        @Headers('x-profile') profileToken: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const myID = profile.user_id

        return this._profileService.getById(myID).pipe(
            map((result: any) => {
                return ProfileDto.toProfilePermissionDto(result)
            }),
            mergeMap((result: any) => {
                return this._authService.generateToken(result)
            }),
        )
    }

    @UseGuards(ProfileGuard)
    @Get('/me/session')
    public checkOwnSession(
        @Headers('x-profile') profileToken: string,
        @Req() req: any,
    ) {
        const session = req.session
        const profile: any = jwt.decode(profileToken)
        const myID = profile.user_id
        return this._profileService.getById(myID).pipe(
            map((results) => {
                const model  = results.role
                return model.getSessionId() === session.id
            }),
            catchError(err => {
                return of(false)
            }),
            map(success => {
                return ({ success })
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    // @UseGuards(RoleGuard)
    // @Roles(UserRolesEnum.ADMIN)
    @Get('/:id')
    public getProfile(
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Param('id') id: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        return this._profileService.getById(id).pipe(
            map((result: any) => {
                return ProfileDto.toProfilePermissionDto(result)
            }),
            tap(() => {
                this._loggerService.info(`get profile id: ${id} by ${user} [${req.ip}]`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    // @UseGuards(RoleGuard)
    // @Roles(UserRolesEnum.ADMIN)
    @Get('/')
    public getAllProfiles(
        @Req() req,
        @Headers('x-profile') profileToken: string,
    ) {
        const dtoTemplate = {
            total: 0,
            data: [],
        }

        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        return this._profileService.getAll().pipe(
            reduce((acc, model) => {
                acc.total++
                acc.data.push(ProfileDto.toProfileDto(model))
                return acc
            }, dtoTemplate),
            tap(() => {
                this._loggerService.info(`get all profile by ${user} [${req.ip}]`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    // @UseGuards(RoleGuard)
    // @Roles(UserRolesEnum.ADMIN)
    @Post('/')
    public CreateProfile(
        @Req() req,
        @Headers('x-profile') profileToken: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const body = {
            id: profile.user_id,
            name: profile.given_name + ' ' + profile.family_name,
        }
        const user = `${profile.given_name} ${profile.family_name}`

        return this._profileService.save(body).pipe(
            map((result: IProfileModel) => {
                return ProfileDto.toProfileDto(result)
            }),
            tap((result: IProfileDto) => {
                this._loggerService.info(`profile id: ${result.id} was created by ${user} [${req.ip}]`)
            }),
            mergeMap((result: IProfileDto) => {
                return this._authService.generateToken(result)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    // @UseGuards(RoleGuard)
    // @Roles(UserRolesEnum.ADMIN)
    @Put('/:id')
    public UpdateProfile(
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Param('id') id: string,
        @Body() body: UpdateProfileValidator,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`
        body.setUpdatedBy(user)

        return this._profileService.update(id, body).pipe(
            map((result: IProfileModel) => {
                return ProfileDto.toProfileDto(result)
            }),
            tap((result: IProfileDto) => {
                this._loggerService.info(`profile id: ${result.id} was updated by ${user} [${req.ip}]`)
                this._loggerService.info(` - profile id: ${result.id}\n${ClassStringify.fromClass(body)}`)
            }),
        )
    }

    @UseGuards(ProfileGuard)
    @Patch('/session')
    public patchCookieSession(
        @Req() req: any,
        @Headers('x-profile') profileToken: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        req.session.user = profile.user_id
        return this._profileService.updateSession(profile.user_id, req.session.id).pipe(
            map( success => ({success})),
        )
    }
}
