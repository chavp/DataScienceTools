import {
    Controller,
    Get,
    Query,
    Req,
    Res,
    Param,
} from '@nestjs/common'

@Controller('/static')
export class StaticController {

    @Get('/line/profile/*')
    public getLineProfileImage(
        @Req() req,
        @Res() res,
    ) {
        res.sendFile(req.params[0], {root: 'static/line/profile'})
    }

    @Get('/line/images/*')
    public getLineMessageImage(
        @Req() req,
        @Res() res,
    ) {
        res.sendFile(req.params[0], {root: 'static/line/images'})
    }

    @Get('/line/image/*')
    public getLineImage(
        // @Param('image') image: string,
        @Req() req,
        @Res() res,
    ) {
        res.sendFile(req.params[0], {root: 'vendor/images'})
    }

}
