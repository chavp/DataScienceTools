import {
    IFinalizeCaseValidator,
    ISurveyorAssignmentValidator,
    IUpdateSurveyorCaseValidator,
} from '../../../domain/surveyor-case/interface/validator.interface'
import {
    IsDefined,
    IsOptional,
    IsString,
    ValidateNested,
} from 'class-validator'
import { Type } from 'class-transformer'

class SurveyorAssignment implements ISurveyorAssignmentValidator {
    @IsOptional()
    @IsString()
    name: string

    @IsOptional()
    @IsString()
    phone: string

    @IsOptional()
    @IsString()
    remark: string

    public getName(): string {
        return this.name
    }

    public getPhone(): string {
        return this.phone
    }

    public getRemark(): string {
        return this.remark
    }
}

export class UpdateSurveyorCaseValidator implements IUpdateSurveyorCaseValidator {
    @IsOptional()
    @IsString()
    private readonly caseNo: string

    @IsOptional()
    @IsString()
    private readonly company: string

    @IsOptional()
    @IsString()
    private readonly note: string

    @IsDefined()
    @Type(() => SurveyorAssignment)
    private readonly assignment: SurveyorAssignment

    public getCaseNo(): string {
        return this.caseNo
    }

    public getSurveyorAssignment(): SurveyorAssignment {
        return this.assignment
    }

    public getSurveyorCompanyNo(): string {
        return this.company
    }

    public getSurveyorNote(): string {
        return this.note
    }

}

export class FinalizeCaseValidator implements IFinalizeCaseValidator {

    @IsOptional()
    @IsString()
    private note: string

    public getNote(): string {
        return this.note
    }

}
