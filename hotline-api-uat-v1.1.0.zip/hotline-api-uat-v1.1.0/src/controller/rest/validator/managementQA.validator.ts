import {
    ICreateManagementQAValidator,
    IUpdateManagementQAValidator,
} from '../../../domain/managementQA/interface/validator.interface'
import {
    IsDefined,
    IsNumber,
    IsOptional,
    IsString,
} from 'class-validator'

export class CreateManagementQAValidator implements ICreateManagementQAValidator {
    @IsDefined()
    @IsString()
    private readonly question: string

    @IsDefined()
    @IsNumber()
    private readonly maxScore: number

    private createdBy: string

    public getQuestion(): string {
        return this.question
    }

    public getMaxScore(): number {
        return this.maxScore
    }

    public setCreatedBy(createdBy: string): void {
        this.createdBy = createdBy
    }

}

export class UpdateManagementQAValidator implements IUpdateManagementQAValidator {
    @IsOptional()
    @IsString()
    private readonly question: string

    @IsOptional()
    @IsNumber()
    private readonly maxScore: number

    private updatedBy: string

    public getMaxScore(): number {
        return this.maxScore
    }

    public getQuestion(): string {
        return this.question
    }

    public setUpdatedBy(updatedBy: string): void {
        this.updatedBy = updatedBy
    }
}
