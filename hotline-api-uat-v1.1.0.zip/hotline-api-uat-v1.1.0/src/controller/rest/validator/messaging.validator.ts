import { ISendMessageValidator } from '../../../domain/message/interface/validator.interface'
import {
    IsDefined,
    IsString,
    MinLength,
} from 'class-validator'

export class SendGroupMessageValidator implements ISendMessageValidator {

    @IsDefined()
    @IsString()
    private surveyorId: string

    @IsDefined()
    @IsString()
    @MinLength(1)
    private message: string

    private _senderName: string

    public getMessage(): string {
        return this.message
    }

    public getReceiver(): string {
        return this.surveyorId
    }

    public setSenderName(name: string): void {
        this._senderName = name
    }

    public getSenderName(): string {
        return this._senderName
    }

}

export class SendUserMessageValidator implements ISendMessageValidator {

    @IsDefined()
    @IsString()
    private userId: string

    @IsDefined()
    @IsString()
    @MinLength(1)
    private message: string

    private _senderName: string

    public getMessage(): string {
        return this.message
    }

    public getReceiver(): string {
        return this.userId
    }

    public setSenderName(name: string): void {
        this._senderName = name
    }

    public getSenderName(): string {
        return this._senderName
    }

}
