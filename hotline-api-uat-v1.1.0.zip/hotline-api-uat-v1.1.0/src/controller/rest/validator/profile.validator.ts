import {
    ICreateProfileValidator,
    IUpdateProfileValidator,
} from '../../../domain/profile/interface/validator.interface'
import {
    IsArray,
    IsDefined,
    IsEnum,
    IsNotEmpty,
    IsOptional,
    IsString,
    Validate,
} from 'class-validator'
import { UserRolesEnum } from '../../../repository/profile/profile.schema'

export class CreateProfileValidator implements ICreateProfileValidator {
    // @IsDefined()
    @IsString()
    private readonly id: string

    // @IsDefined()
    @IsString()
    private readonly name: string

    public getId(): string {
        return this.id
    }

    public getName(): string {
        return this.name
    }
}

export class UpdateProfileValidator implements IUpdateProfileValidator {
    @IsOptional()
    @IsString()
    @IsNotEmpty()
    private readonly name: string

    @IsOptional()
    @IsNotEmpty()
    @IsArray()
    // @IsEnum(UserRolesEnum)
    private readonly roles: UserRolesEnum[]

    @IsOptional()
    @IsString()
    @IsNotEmpty()
    private updatedBy: string

    public getName(): string {
        return this.name
    }

    public getRoles(): UserRolesEnum[] {
        return this.roles
    }

    public getUpdatedBy(): string {
        return this.updatedBy
    }

    public setUpdatedBy(name: string): void {
        this.updatedBy = name
    }
}
