import {
    IQA,
    IUpdateRecorderQAValidator,
} from '../../../domain/recorderQA/interface/recorderQA.validator.interface'
import {
    IsDefined,
    IsNumber,
    IsOptional,
    IsString,
    ValidateNested,
} from 'class-validator'
import { Type } from 'class-transformer'

class QADetail implements IQA {
    @IsOptional()
    @IsString()
    id: string

    @IsOptional()
    @IsString()
    question: string

    @IsOptional()
    @IsNumber()
    score: number
}

export class UpdateRecorderQAValidator implements IUpdateRecorderQAValidator {
    @IsDefined()
    private readonly id: string

    @IsOptional()
    @IsString()
    private readonly comment: string

    @IsOptional()
    @ValidateNested()
    @Type(() => QADetail)
    private readonly QA: QADetail[]

    public getComment(): string {
        return this.comment
    }

    public getId(): string {
        return this.id
    }

    public getQA(): IQA[] {
        return this.QA
    }

}
