import { Type } from 'class-transformer'
import {
    IIncidentLogValidator,
    IIncidentStatusValidator,
    IIncidentSurveyorValidator,
    IIncidentValidator,
    IInputCompany,
    IInputInsured,
    IInputLossInfo,
    IInputPolicy,
    IInputStatus,
    IInputSurveyor,
    IInputThirdInsured,
    IInputTowing,
    IInputType,
} from '../../../domain/incident/interface/validator.interface'
import {
    IsDefined,
    IsEmpty,
    IsEnum,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    IsString,
    ValidateNested,
} from 'class-validator'
import * as _ from 'lodash'
import { WorkFlowEnum } from '../../../repository/incident/log.schema'

class IncidentType implements IInputType {
    @IsDefined()
    @IsString()
    @IsNotEmpty()
    id: string

    name: string

    @IsOptional()
    subType: IncidentType
}

class CompanyInfo implements IInputCompany {
    @IsOptional()
    @IsString()
    policyNo: string

    @IsOptional()
    @IsString()
    claimNo: string
}

class IncidentStatus implements IInputStatus {
    @IsOptional()
    @IsString()
    id: string

    name: string

    used: boolean
}

class TowingCompany implements IInputTowing {
    @IsOptional()
    @IsString()
    id: string

    name: string

    used: boolean
}

class LossInformation implements IInputLossInfo {
    @IsOptional()
    @IsString()
    detail: string

    @IsOptional()
    @IsString()
    location: string

    @IsOptional()
    dateTime: number
}

class Insured implements IInputInsured {
    @IsOptional()
    @IsNumber()
    injured: number

    @IsOptional()
    @IsNumber()
    death: number
}

class ThirdInsured implements IInputThirdInsured {
    @IsOptional()
    @IsNumber()
    injured: number

    @IsOptional()
    @IsNumber()
    death: number
}

class Surveyor implements IInputSurveyor {
    @IsDefined()
    @IsString()
    id: string

    name: string

    phone: string

    @IsNumber()
    lat: number

    @IsNumber()
    long: number

    @IsString()
    note: string

    @IsString()
    place: string

    @IsDefined()
    @IsString()
    province: string

    @IsDefined()
    @IsString()
    district: string
}

class Policy implements IInputPolicy {
    @IsOptional()
    @IsString()
    policyNo: string

    @IsOptional()
    @IsString()
    riskId: string
}

export class SaveIncidentValidator implements IIncidentValidator {
    @IsDefined()
    @IsString()
    @IsNotEmpty()
    private readonly contactNo: string

    @IsDefined()
    @IsString()
    @IsNotEmpty()
    private readonly callerName: string

    @IsOptional()
    @ValidateNested()
    @Type(() => IncidentStatus)
    private readonly status: IncidentStatus

    @IsOptional()
    @IsNumber()
    @IsNotEmpty()
    private readonly appointmentDate: number

    @IsOptional()
    @IsString()
    private readonly claimNo: string

    @IsOptional()
    @IsString()
    private readonly driverName: string

    @IsOptional()
    @IsString()
    private readonly note: string

    @IsEmpty()
    private updatedBy: string

    @IsOptional()
    @IsString()
    private createdBy: string

    @IsOptional()
    @IsNumber()
    private readonly callTime: number

    @IsOptional()
    @ValidateNested()
    @Type(() => Policy)
    private readonly policyNumber: Policy

    @IsDefined()
    @ValidateNested()
    @Type(() => IncidentType)
    private readonly incidentType: IncidentType

    @IsOptional()
    @ValidateNested()
    @Type(() => CompanyInfo)
    private readonly companyInfo: CompanyInfo

    @IsOptional()
    @ValidateNested()
    @Type(() => TowingCompany)
    private readonly towCompany: TowingCompany

    @IsOptional()
    @ValidateNested()
    @Type(() => LossInformation)
    private readonly lossInformation: LossInformation

    @IsOptional()
    @ValidateNested()
    @Type(() => Insured)
    private readonly insured: Insured

    @IsOptional()
    @ValidateNested()
    @Type(() => ThirdInsured)
    private readonly thirdInsured: ThirdInsured

    public getAppointmentDate(): Date {
        if ( _.isNil(this.appointmentDate)) {
            return null
        }
        return new Date(this.appointmentDate)
    }

    public getCallerName(): string {
        return this.callerName
    }

    public getClaimNo(): string {
        return this.claimNo
    }

    public getCompanyInfo(): IInputCompany {
        return this.companyInfo
    }

    public getContactNo(): string {
        return this.contactNo
    }

    public getCreatedBy(): string {
        return this.createdBy
    }

    public getDriverName(): string {
        return this.driverName
    }

    public getIncidentType(): IInputType {
        return this.incidentType
    }

    public getInsured(): IInputInsured {
        return this.insured
    }

    public getLossInformation(): IInputLossInfo {
        return this.lossInformation
    }

    public getNote(): string {
        return this.note
    }

    public getPolicyNumber(): IInputPolicy {
        return this.policyNumber
    }

    public getStatus(): IInputStatus {
        return this.status
    }

    public getThirdInsured(): IInputThirdInsured {
        return this.thirdInsured
    }

    public getTowCompany(): IInputTowing {
        return this.towCompany
    }

    public getUpdatedBy(): string {
        return this.updatedBy
    }

    public getCallTime(): number {
        return this.callTime
    }

    public setCreatedBy(createdBy: string): void {
        this.createdBy = createdBy
    }

    public setUpdatedBy(name: string): void {
        this.updatedBy = name
    }
}

export class UpdateIncidentValidator implements IIncidentValidator {
    @IsDefined()
    @IsString()
    public readonly _id: string

    @IsEmpty()
    private readonly contactNo: string

    @IsEmpty()
    private readonly callerName: string

    private readonly status: IInputStatus

    @IsOptional()
    @IsNumber()
    private readonly appointmentDate: number

    @IsOptional()
    @IsString()
    private readonly claimNo: string

    @IsOptional()
    @IsString()
    private readonly driverName: string

    @IsOptional()
    @IsString()
    private readonly note: string

    @IsEmpty()
    private readonly updatedAt: number

    @IsOptional()
    @IsString()
    private updatedBy: string

    @IsEmpty()
    private readonly createdAt: number

    @IsEmpty()
    private createdBy: string

    private readonly callTime: number

    @IsOptional()
    @ValidateNested()
    @Type(() => Policy)
    private readonly policyNumber: Policy

    @IsOptional()
    @ValidateNested()
    @Type(() => IncidentType)
    private readonly incidentType: IncidentType

    @IsOptional()
    @ValidateNested()
    @Type(() => CompanyInfo)
    private readonly companyInfo: CompanyInfo

    @IsOptional()
    @ValidateNested()
    @Type(() => TowingCompany)
    private readonly towCompany: TowingCompany

    @IsOptional()
    @ValidateNested()
    @Type(() => LossInformation)
    private readonly lossInformation: LossInformation

    @IsOptional()
    @ValidateNested()
    @Type(() => Insured)
    private readonly insured: Insured

    @IsOptional()
    @ValidateNested()
    @Type(() => ThirdInsured)
    private readonly thirdInsured: ThirdInsured

    public getId(): string {
        return this._id
    }

    public getAppointmentDate(): Date {
        if ( _.isNil(this.appointmentDate)) {
            return null
        }
        return new Date(this.appointmentDate)
    }

    public getCallerName(): string {
        return this.callerName
    }

    public getClaimNo(): string {
        return this.claimNo
    }

    public getCompanyInfo(): IInputCompany {
        return this.companyInfo
    }

    public getContactNo(): string {
        return this.contactNo
    }

    public getCreatedBy(): string {
        return this.createdBy
    }

    public getDriverName(): string {
        return this.driverName
    }

    public getIncidentType(): IInputType {
        return this.incidentType
    }

    public getInsured(): IInputInsured {
        return this.insured
    }

    public getLossInformation(): IInputLossInfo {
        return this.lossInformation
    }

    public getNote(): string {
        return this.note
    }

    public getPolicyNumber(): IInputPolicy {
        return this.policyNumber
    }

    public getStatus(): IInputStatus {
        return this.status
    }

    public getThirdInsured(): IInputThirdInsured {
        return this.thirdInsured
    }

    public getTowCompany(): IInputTowing {
        return this.towCompany
    }

    public getUpdatedBy(): string {
        return this.updatedBy
    }

    public getCallTime(): number {
        return this.callTime
    }

    public setCreatedBy(createdBy: string): void {
        this.createdBy = createdBy
    }

    public setUpdatedBy(name: string): void {
        this.updatedBy = name
    }
}

export class UpdateIncidentStatusValidator implements IIncidentStatusValidator {
    @IsDefined()
    @ValidateNested()
    @Type(() => IncidentStatus)
    private readonly status: IncidentStatus

    @IsOptional()
    @IsString()
    private updatedBy: string

    public getStatus(): IInputStatus {
        return this.status
    }

    public getUpdatedBy(): string {
        return this.updatedBy
    }

    public setUpdatedBy(updatedBy: string): void {
        this.updatedBy = updatedBy
    }
}

export class UpdateIncidentLogValidator implements IIncidentLogValidator {
    @IsDefined()
    @IsString()
    private readonly note: string

    @IsOptional()
    @IsEnum(WorkFlowEnum)
    private readonly workFlow: WorkFlowEnum

    @IsOptional()
    @ValidateNested()
    @Type(() => IncidentStatus)
    private readonly status: IncidentStatus

    @IsDefined()
    @IsString()
    private createdBy: string

    public getNote(): string {
        return this.note
    }

    public getStatus(): IInputStatus {
        return this.status
    }

    public getCreatedBy(): string {
        return this.createdBy
    }

    public setCreatedBy(createdBy: string): void {
        this.createdBy = createdBy
    }

    public getWorkFlow(): WorkFlowEnum {
        return this.workFlow
    }
}

export class UpdateIncidentSurveyorValidator implements IIncidentSurveyorValidator {
    @IsDefined()
    @ValidateNested()
    @Type(() => Surveyor)
    private readonly surveyor: Surveyor

    @IsOptional()
    @IsString()
    private updatedBy: string

    public getSurveyor(): IInputSurveyor {
        return this.surveyor
    }

    public getUpdatedBy(): string {
        return this.updatedBy
    }

    public setUpdatedBy(updatedBy: string): void {
        this.updatedBy = updatedBy
    }

}
