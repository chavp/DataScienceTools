import {
    Equals,
    IsDefined,
    IsIn,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    IsString,
    Length,
    Matches,
} from 'class-validator'
import * as _ from 'lodash'
import {
    IScheduleFixedValidator,
    IScheduleRecurringValidator,
    ISchedulerUpdateValidator,
} from '../../../domain/scheduler/interface/validator.interface'
import { SchedulerTypeEnum } from '../../../domain/scheduler/interface/scheduler-type.enum'

const timeRegExp = /^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/
const dayOfWeekArray = [0, 1, 2, 3, 4, 5, 6]

export class ScheduleFixedTimeValidator implements IScheduleFixedValidator {

    @IsDefined()
    @IsString()
    @Length(4)
    private readonly name: string

    @IsDefined()
    @Equals(SchedulerTypeEnum.FIXED)
    private readonly type: SchedulerTypeEnum

    @IsNumber()
    @IsDefined()
    private readonly date: number

    public getDate(): number {
        return _.toNumber(this.date)
    }

    public getName(): string {
        return this.name
    }

    public getType(): SchedulerTypeEnum {
        return this.type
    }

}

export class ScheduleRecurringValidator implements IScheduleRecurringValidator {

    @IsDefined()
    @IsString()
    @Length(4)
    private readonly name: string

    @IsDefined()
    @Equals(SchedulerTypeEnum.RECURRING)
    private readonly type: SchedulerTypeEnum

    @IsDefined()
    @IsNotEmpty()
    @IsIn(dayOfWeekArray, {
        each: true,
    })
    private readonly days: number[]

    @IsDefined()
    @Matches(timeRegExp)
    private readonly time: string

    public getDays(): number[] {
        return this.days
    }

    public getName(): string {
        return this.name
    }

    public getTime(): string {
        return this.time
    }

    public getType(): SchedulerTypeEnum {
        return this.type
    }

}

export class SchedulerUpdateValidator implements ISchedulerUpdateValidator {

    @IsOptional()
    @IsString()
    @Length(4)
    private readonly name: string

    @IsOptional()
    @IsNotEmpty()
    @IsIn(dayOfWeekArray, {
        each: true,
    })
    private readonly days: number[]

    @IsOptional()
    @Matches(timeRegExp)
    private readonly time: string

    @IsOptional()
    @IsNumber()
    private readonly date: number

    public getDate(): number {
        return this.date
    }

    public getDays(): number[] {
        return this.days
    }

    public getName(): string {
        return this.name
    }

    public getTime(): string {
        return this.time
    }

}
