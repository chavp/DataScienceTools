import {
    IsDefined,
    IsOptional,
    IsString,
    Length,
} from 'class-validator'
import { IExportSurveyorLineDto } from '../dto/surveyor-line.dto'

export class UploadSurveyorLineValidator implements IExportSurveyorLineDto {
    @IsDefined()
    public id: string

    @IsOptional()
    @IsString()
    public groupName: string

    @IsDefined()
    @IsString()
    @Length(8)
    public surveyorCode: string
}
