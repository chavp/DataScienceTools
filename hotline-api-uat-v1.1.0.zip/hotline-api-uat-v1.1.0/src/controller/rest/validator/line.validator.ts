import {
    IsDefined,
    IsString,
} from 'class-validator'
import {
    IRegisterLineValidator,
} from '../../../domain/line/interface/validator.interface'

export class RegisterLineValidator implements IRegisterLineValidator {
    @IsDefined()
    @IsString()
    phone: string

    public getPhone(): string {
        return this.phone
    }
}
