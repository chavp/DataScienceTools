import {ITemplateValidator} from '../../../domain/sms/interface/template.validator.interface'
import {IsDefined, IsString} from 'class-validator'
import * as _ from 'lodash'
import {ObjectId} from 'bson'

export class TemplateValidator implements ITemplateValidator {
    @IsDefined()
    @IsString()
    private readonly message: string

    @IsDefined()
    @IsString()
    private readonly name: string

    getMessage(): string {
        return _.toString(this.message)
    }

    getName(): string {
        return this.name
    }
}
