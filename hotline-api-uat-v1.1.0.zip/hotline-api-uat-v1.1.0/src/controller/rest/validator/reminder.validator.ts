import {
    IReadReminderValidator,
    ISaveReminderValidator,
} from '../../../domain/reminder/interface/validator.interface'
import {
    IsDefined,
    IsIn,
    IsNumber,
    IsOptional,
    IsString,
} from 'class-validator'

export class SaveReminderValidator implements ISaveReminderValidator {
    @IsDefined()
    @IsString()
    private incidentNo: string

    @IsOptional()
    @IsString()
    private registration: string

    @IsOptional()
    @IsString()
    private note: string

    @IsDefined()
    @IsNumber()
    private remindTime: number

    @IsDefined()
    @IsString()
    private agent: string

    public getAgent(): string {
        return this.agent
    }

    public setAgent(agent: string): void {
        this.agent = agent
    }

    public getIncidentNo(): string {
        return this.incidentNo
    }

    public setIncidentNo(incidentNo: string): void {
        this.incidentNo = incidentNo
    }

    public getNote(): string {
        return this.note
    }

    public setNote(note: string): void {
        this.note = note
    }

    public getRegistration(): string {
        return this.registration
    }

    public setRegistration(registration: string): void {
        this.registration = registration
    }

    public getRemindTime(): number {
        return this.remindTime
    }

    public setRemindTime(remindTime: number): void {
        this.remindTime = remindTime
    }
}

export class ReadReminderValidator implements IReadReminderValidator {
    @IsDefined()
    @IsIn(['read', 'unread'])
    private readonly status: 'read' | 'unread'

    private agent: string

    public getStatus(): 'read' | 'unread' {
        return this.status
    }

    public getAgent(): string {
        return this.agent
    }

    public setAgent(agent: string): void {
        this.agent = agent
    }

}
