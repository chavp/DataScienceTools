import { IPermissionValidator } from '../../../domain/permission/interface/validator.interface'
import { PermissionEnum } from '../../../domain/common/interface/permission-enum'
import {
    IsArray,
    IsDefined,
} from 'class-validator'

export class PermissionValidate implements IPermissionValidator {
    @IsDefined()
    @IsArray()
    private readonly permission: PermissionEnum[]

    public getPermission(): PermissionEnum[] {
        return this.permission
    }
}
