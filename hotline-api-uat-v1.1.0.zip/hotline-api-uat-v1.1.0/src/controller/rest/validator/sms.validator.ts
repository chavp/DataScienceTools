import * as _ from 'lodash'
import {ISmsValidator} from '../../../domain/common/interface/common.interface'
import {
    IsDefined,
    IsOptional,
    IsString,
    Length,
    Min,
    MinLength,
} from 'class-validator'

export class SMSBodyValidator implements ISmsValidator {
    @IsDefined()
    @IsString()
    @MinLength(4)
    private readonly message: string

    @IsDefined()
    @IsString()
    @MinLength(10)
    private readonly receiver: string

    @IsDefined()
    @IsString()
    @Length(11)
    private readonly incidentNo: string

    @IsOptional()
    @IsString()
    private sender: string

    getMessage(): string {
        return _.toString(this.message)
    }

    getReceiver(): string {
        return _.toString(this.receiver)
    }

    getIncidentNo(): string {
        return _.toString(this.incidentNo)
    }

    setSender(sender: string): void {
        this.sender = sender
    }
}
