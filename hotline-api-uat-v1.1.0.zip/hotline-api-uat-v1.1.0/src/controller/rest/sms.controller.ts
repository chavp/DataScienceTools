import {
    Body,
    Controller,
    Get,
    Headers,
    Inject,
    Post,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common'
import { IAs400Adapter } from '../../adapter/as400/interface'
import { ISmsAdapter } from '../../adapter/sms/interface/adaper.interface'
import { ProviderName } from '../../provider'
import { SMSBodyValidator } from './validator/sms.validator'
import { ICommonService } from '../../domain/common/interface/service.interface'
import {
    reduce,
    tap,
} from 'rxjs/operators'
import { SmsDto } from './dto/sms.dto'
import * as jwt from 'jsonwebtoken'
import { ProfileGuard } from '../../common/guard/profile.guard'
import { ITemplateService } from '../../domain/sms/interface/template.service.interface'
import { TemplateDto } from './dto/template.dto'
import { TemplateValidator } from './validator/template.validator'
import { ILoggerService } from '../../common/interface/logger.interface'
import { ProfileSessionGuard } from '../../common/guard/profile.guard'

const {
    COMMON_SERVICE,
    TOWING_SERVICE,
    INCIDENT_TYPE_SERVICE,
    AS400_ADAPTER,
    SMS_ADAPTER,
    TEMPLATE_SERVICE,
    LOGGER_SERVICE,
} = ProviderName

@Controller('/sms')
export class SmsController {
    constructor(
        @Inject(COMMON_SERVICE)
        private readonly _commonService: ICommonService,
        @Inject(AS400_ADAPTER)
        private readonly _adapterAs400: IAs400Adapter,
        @Inject(SMS_ADAPTER)
        private readonly _smsAdapter: ISmsAdapter,
        @Inject(TEMPLATE_SERVICE)
        private readonly _templateService: ITemplateService,
        @Inject(LOGGER_SERVICE)
        private readonly _loggerService: ILoggerService,
    ) {
        this._loggerService.setContext('SMS Service')
    }

    @UseGuards(ProfileSessionGuard)
    @Post('/')
    public sendMessage(
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Body() body: SMSBodyValidator,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`
        body.setSender(user)

        return this._commonService.sendSms(body).pipe(
            tap(() => {
                this._loggerService.info(`send sms (incident: ${body.getIncidentNo()}) to ${body.getReceiver()} by ${user} [${req.ip}]`)
            }),
        )
    }

    @UseGuards(ProfileGuard)
    @Get('/')
    public getSms(
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Query('incidentNo') incidentNo: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        const dtoSmsTemplate = {
            total: 0,
            data: [],
        }

        return this._commonService.getSms(incidentNo).pipe(
            reduce((acc, model) => {
                ++acc.total
                acc.data.push(SmsDto.toSmsDto(model))
                return acc
            }, dtoSmsTemplate),
            tap(() => {
                this._loggerService.info(`get sms of incident ${incidentNo} by ${user} [${req.ip}]`)
            }),
        )
    }

    @UseGuards(ProfileGuard)
    @Get('/template')
    public getAll(
        @Headers('x-profile') profileToken: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        const template = {
            total: 0,
            data: [],
        }
        return this._templateService.getAll().pipe(
            reduce((acc, model) => {
                ++acc.total
                acc.data.push(TemplateDto.toTemplateDTO(model))
                return acc
            }, template),
        )
    }

    @UseGuards(ProfileGuard)
    @Post('/template')
    public createNewTemplate(
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Body() body: TemplateValidator,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        return this._templateService.create(body).pipe(
            tap(() => {
                this._loggerService.info(`create new template by ${user} [${req.ip}]`)
            }),
        )
    }
}
