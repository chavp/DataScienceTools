import {
    Controller,
    Get,
    Inject,
    Query,
    Req,
} from '@nestjs/common'
import { ProviderName } from '../../provider'
import { IActiveDirectoryAdapter } from '../../adapter/active-directory/interface/adapter.interface'
import { map } from 'rxjs/operators'
import { ILoggerService } from '../../common/interface/logger.interface'

@Controller('/user')
export class UserController {
    constructor(
        @Inject(ProviderName.AD_ADAPTER)
        private readonly _adAdapter: IActiveDirectoryAdapter,
        @Inject(ProviderName.LOGGER_SERVICE)
        private readonly _loggerService: ILoggerService,
    ) {
        this._loggerService.setContext('User Service')
    }

    @Get('/login')
    public login(
        @Req() req,
    ) {
        this._loggerService.info(`Login request from ${req.ip}`)
        return this._adAdapter.generateLink().pipe(
            map(url => ({ url })),
        )
    }

    @Get('/logout')
    public logout(
        @Req() req,
    ) {
        this._loggerService.info(`Logout request from ${req.ip}`)
        if (req.session) {
            const id = req.session.id
            req.session.destroy( () => {
                console.log(`session [${id}] destroyed`)
            })
        }

        return { success: true }

    }
}
