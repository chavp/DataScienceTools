import {
    Body,
    Controller,
    Get,
    Headers,
    Inject,
    Param,
    Post,
    Put,
    Query,
    UseGuards,
} from '@nestjs/common'
import { ProviderName } from '../../provider'
import { IReminderService } from '../../domain/reminder/interface/service.interface'
import {
    reduce,
    map,
    tap,
} from 'rxjs/operators'
import { ReminderDto } from './dto/reminder.dto'
import {
    IReadReminderValidator,
    ISaveReminderValidator,
} from '../../domain/reminder/interface/validator.interface'
import {
    ReadReminderValidator,
    SaveReminderValidator,
} from './validator/reminder.validator'
import { ProfileSessionGuard } from '../../common/guard/profile.guard'
import * as jwt from 'jsonwebtoken'
import * as _ from 'lodash'
import { ILoggerService } from '../../common/interface/logger.interface'

const {
    REMINDER_SERVICE,
    LOGGER_SERVICE,
} = ProviderName

@Controller('/reminder')
export class ReminderController {
    constructor(
        @Inject(REMINDER_SERVICE)
        public readonly _reminderService: IReminderService,
        @Inject(LOGGER_SERVICE)
        private readonly _loggerService: ILoggerService,
    ) {
        this._loggerService.setContext('Reminder Service')
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/')
    public getReminders(
        @Headers('x-profile') profileToken: string,
        @Query('date') date: string,
    ) {
        const queryDate = new Date(date)
        const dtoTemplate = {
            total: 0,
            data: [],
        }

        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        return this._reminderService.find(queryDate).pipe(
            reduce((acc, model) => {
                // acc.total++
                acc.data.push(ReminderDto.toReminderDto(model))
                return acc
            }, dtoTemplate),
            map(result => {
                return result.data
            }),
            map((result) => {
                _.forEach(result, (e) => {
                    if (e.status === 'unread') {
                        dtoTemplate.total++
                    }
                })
                return dtoTemplate
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Post('/')
    public createReminder(
        @Headers('x-profile') profileToken: string,
        @Body() body: SaveReminderValidator,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`
        body.setAgent(user)

        return this._reminderService.save(body).pipe(
            tap((result: {id: string}) => {
                this._loggerService.info(`reminder id: ${result.id} was created by ${user}`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Put('/:id')
    public updateReminder(
        @Headers('x-profile') profileToken: string,
        @Param('id') id: string,
        @Body() body: ReadReminderValidator,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`
        body.setAgent(user)

        return this._reminderService.update(id, body).pipe(
            tap(() => {
                this._loggerService.info(`reminder id: ${id} was updated by ${user}`)
            }),
        )
    }
}
