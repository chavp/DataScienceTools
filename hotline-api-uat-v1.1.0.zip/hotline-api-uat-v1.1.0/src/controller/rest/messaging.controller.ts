import {
    Body,
    Controller,
    Headers,
    Inject,
    Param,
    Post,
    Put,
    UseGuards,
} from '@nestjs/common'
import { ProviderName } from '../../provider'
import { IMessageService } from '../../domain/message/interface/service.interface'
import {
    SendGroupMessageValidator,
    SendUserMessageValidator,
} from './validator/messaging.validator'
import { map } from 'rxjs/operators'
import { ProfileSessionGuard } from '../../common/guard/profile.guard'
import * as jwt from 'jsonwebtoken'

@Controller('/message')
export class MessagingController {
    constructor(
        @Inject(ProviderName.MESSAGE_SERVICE)
        private readonly _messageService: IMessageService,
    ) {
    }

    @UseGuards(ProfileSessionGuard)
    @Post('/group')
    public sendMessageToSurveyorGroup(
        @Headers('x-profile') profileToken: string,
        @Body() input: SendGroupMessageValidator,
    ) {
        const profile: any = jwt.decode(profileToken)
        const givenName = profile.given_name
        const familyName = profile.family_name
        input.setSenderName(givenName + ' ' + familyName)
        return this._messageService.sendGroupMessage(input).pipe(
            map(result => ({ id: result.id })),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Post('/user')
    public sendMessageToUser(
        @Headers('x-profile') profileToken: string,
        @Body() input: SendUserMessageValidator,
    ) {
        const profile: any = jwt.decode(profileToken)
        const givenName = profile.given_name
        const familyName = profile.family_name
        input.setSenderName(givenName + ' ' + familyName)
        return this._messageService.sendDirectMessage(input).pipe(
            map(result => ({ id: result.id })),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Put('/:id/read')
    public setMessageReadByIncidentNo(
        @Param('id') incidentNo: string,
    ) {
        return this._messageService.readMessageByIncidentNo(incidentNo)
    }
}
