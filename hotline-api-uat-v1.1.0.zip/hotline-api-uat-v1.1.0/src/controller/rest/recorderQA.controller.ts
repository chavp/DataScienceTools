import {
    Body,
    Controller,
    Get,
    Header,
    HttpException,
    HttpStatus,
    Inject,
    Param,
    Post,
    Put,
    Query,
    Req,
    Res,
    UseGuards,
} from '@nestjs/common'
import { ProviderName } from '../../provider'
import { IRecorderQAService } from '../../domain/recorderQA/interface/recorderQA.service.interface'
import {
    map,
    mergeMap,
    reduce,
    tap,
    toArray,
} from 'rxjs/operators'
import {
    IRecorderQADto,
    RecorderQADto,
} from './dto/recorderQA.dto'
import { IRecorderQAModel } from '../../domain/recorderQA/interface/recorderQA.model.interface'
import { UpdateRecorderQAValidator } from './validator/recorderQA.validator'
import { ProfileSessionGuard } from '../../common/guard/profile.guard'
import { IRecorderFilter } from '../../domain/recorderQA/interface/recorder.filter'
import * as _ from 'lodash'
import * as fs from 'fs'
import { IRecorderAdapter } from '../../adapter/recorder/interface/recoder.interface'
import * as crypto from 'crypto'
import { opensslKeyDeriv } from 'sshpk'
import { of } from 'rxjs'
import {
    Request,
    Response,
} from 'express'

const {
    RECORDER_QA_SERVICE,
} = ProviderName

@Controller('recorderQA')
export class RecorderQAController {
    constructor(
        @Inject(RECORDER_QA_SERVICE)
        private readonly _recorderQAService: IRecorderQAService,
    ) {

    }

    @UseGuards(ProfileSessionGuard)
    @Get('/export')
    public exportToExcel(
        @Res() res,
        @Query('startTime') startTime: string,
        @Query('endTime') endTime: string,
        @Query('source') source: string,
        @Query('destination') destination: string,
        @Query('callType') callType: string,
        @Query('duration') duration: string,
        @Query('score') score: string,
    ) {
        const searchFilter: IRecorderFilter = {}

        if ((!_.isEmpty(startTime)) && (_.isEmpty(endTime))) {
            throw new HttpException(
                `endTime must be NOT NULL`,
                HttpStatus.BAD_REQUEST,
            )
        }

        if ((_.isEmpty(startTime)) && (!_.isEmpty(endTime))) {
            throw new HttpException(
                `startTime must be NOT NULL`,
                HttpStatus.BAD_REQUEST,
            )
        }

        if ((!_.isEmpty(startTime)) && (!_.isEmpty(endTime))) {
            const start = new Date(startTime)
            const end = new Date(endTime)
            searchFilter.startTime = start.getTime()
            searchFilter.endTime = end.getTime()
        }

        if (!_.isEmpty(source)) {
            searchFilter.source = source
        }

        if (!_.isEmpty(destination)) {
            searchFilter.destination = destination
        }

        if (!_.isEmpty(callType)) {
            searchFilter.callType = callType
        }

        if (!_.isEmpty(duration)) {
            searchFilter.duration = _.toNumber(duration)
        }

        if (!_.isEmpty(score)) {
            searchFilter.score = _.toNumber(duration)
        }

        return this._recorderQAService.find(searchFilter).pipe(
            map((result: IRecorderQAModel) => {
                return RecorderQADto.toRecorderQADto(result)
            }),
            toArray(),
            mergeMap((recorder: IRecorderQADto[]) => {
                return this._recorderQAService.export(`recorder`, recorder).pipe(
                    map((excelData) => excelData.write(`recorder.xlsx`, res)),
                )
            }),
        )
    }

    // @UseGuards(ProfileSessionGuard)
    // @Get('/')
    // public getAllRecorderQA() {
    //     const dtoTemplate = {
    //         total: 0,
    //         data: [],
    //     }
    //
    //     return this._recorderQAService.getAll().pipe(
    //         reduce((acc, model) => {
    //                 acc.total++
    //                 acc.data.push(RecorderQADto.toRecorderQADto(model))
    //                 return acc
    //             },
    //             dtoTemplate,
    //         ),
    //     )
    // }

    @UseGuards(ProfileSessionGuard)
    @Get('/:id')
    public getRecorderQAById(
        @Param('id') id: string,
    ) {
        return this._recorderQAService.getById(id).pipe(
            map((result: IRecorderQAModel) => {
                return RecorderQADto.toRecorderQADto(result)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Put('/:id')
    public UpdateRecorderQA(
        @Param('id') id: string,
        @Body() body: UpdateRecorderQAValidator,
    ) {
        return this._recorderQAService.update(id, body).pipe(
            map((result: IRecorderQAModel) => {
                return RecorderQADto.toRecorderQADto(result)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/')
    public SearchRecorder(
        @Query('id') id?: string,
        @Query('startTime') startTime?: string,
        @Query('endTime') endTime?: string,
        @Query('source') source?: string,
        @Query('destination') destination?: string,
        @Query('callType') callType?: string,
        @Query('duration') duration?: string,
        @Query('score') score?: string,
        @Query('limit') limit?: string,
        @Query('page') page?: string,
    ) {
        const dtoTemplate = {
            total: 0,
            data: [],
        }

        const searchFilter: IRecorderFilter = {}

        if ((!_.isEmpty(startTime)) && (_.isEmpty(endTime))) {
            throw new HttpException(
                `endTime must be NOT NULL`,
                HttpStatus.BAD_REQUEST,
            )
        }

        if ((_.isEmpty(startTime)) && (!_.isEmpty(endTime))) {
            throw new HttpException(
                `startTime must be NOT NULL`,
                HttpStatus.BAD_REQUEST,
            )
        }

        if ((!_.isEmpty(startTime)) && (!_.isEmpty(endTime))) {
            // const start = new Date(startTime)
            // const end = new Date(endTime)
            searchFilter.startTime = _.toNumber(startTime)
            searchFilter.endTime = _.toNumber(endTime)
        }

        if (!_.isEmpty(id)) {
            searchFilter.id = id
        }

        if (!_.isEmpty(source)) {
            searchFilter.source = source
        }

        if (!_.isEmpty(destination)) {
            searchFilter.destination = destination
        }

        if (!_.isEmpty(callType)) {
            searchFilter.callType = callType
        }

        if (!_.isEmpty(duration)) {
            searchFilter.duration = _.toNumber(duration)
        }

        if (!_.isEmpty(score)) {
            searchFilter.score = _.toNumber(score)
        }

        if (!_.isEmpty(limit)) {
            searchFilter.limit = _.toNumber(limit)
        }

        if (!_.isEmpty(page)) {
            searchFilter.page = _.toNumber(page)
        }

        return this._recorderQAService.find(searchFilter).pipe(
            reduce((acc: any, model: IRecorderQAModel) => {
                acc.total++
                acc.data.push(RecorderQADto.toRecorderQADto(model))
                return acc
            }, dtoTemplate),
        )
    }

    // @UseGuards(ProfileSessionGuard)
    @Get('/steam/:id')
    public SteamWAV(
        @Param('id') id: string,
        @Req() req: Request,
        @Res() res: Response,
    ) {
        const name = id.split('.')
        return this._recorderQAService.getDecodedAudioFile(name[0]).pipe(
            map((path: string) => {
                const stat = fs.statSync(path)
                const fileSize = stat.size
                const range = req.headers.range
                if (!!range) {
                    const parts = range.replace(/bytes=/, '').split('-')
                    const start = parseInt(parts[0], 10)
                    const end = parts[1]
                        ? parseInt(parts[1], 10)
                        : fileSize - 1
                    const chunksize = (end - start) + 1
                    const file = fs.createReadStream(path, {
                        start,
                        end,
                    })
                    const head = {
                        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
                        'Accept-Ranges': 'bytes',
                        'Content-Length': chunksize,
                        'Content-Type': 'audio/wav',
                    }
                    res.status(HttpStatus.PARTIAL_CONTENT)
                    res.set(head)
                    file.pipe(res)
                } else {
                    const head = {
                        'Content-Length': fileSize,
                        'Content-Type': 'audio/wav',
                    }
                    res.status(HttpStatus.OK)
                    res.set(head)
                    fs.createReadStream(path).pipe(res)
                }
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/steam/download/:id')
    public DownloadSteam(
        @Req() req,
        @Res() res,
        @Param('id') id: string,
    ) {
        return this._recorderQAService.getDecodedAudioFile(id).pipe(
            map((newPath: string) => {
                res.download(newPath)
            }),
        )
    }

}
