import {
    Body,
    Controller,
    Get,
    Headers,
    Inject,
    Param,
    Patch,
    Post,
    Put,
    Query,
    Req,
    Res,
    UseGuards,
} from '@nestjs/common'
import { ProviderName } from '../../provider'
import {
    map,
    mergeMap,
    reduce,
    tap,
    toArray,
} from 'rxjs/operators'
import {
    IIncidentSearchDto,
    IncidentDto,
    IncidentExcelDto,
    IncidentSearchDto,
} from './dto/incident.dto'
import {
    IIncidentRepository,
    IIncidentRepositoryFilter,
    IIncidentService,
} from '../../domain/incident/interface'
import { IIncidentTypeService } from '../../domain/incident/interface/type.service.interface'
import {
    SaveIncidentValidator,
    UpdateIncidentLogValidator,
    UpdateIncidentStatusValidator,
    UpdateIncidentSurveyorValidator,
    UpdateIncidentValidator,
} from './validator/incident.validator'
import * as _ from 'lodash'
import { IDashboardService } from '../../domain/incident/interface/dashboard.interface'
import { IncidentLogDto } from './dto/log.dto'
import { IIncidentLogService } from '../../domain/incident/interface/log.service.interface'
import {
    IIncidentDeepFilter,
    IIncidentSort,
} from '../../repository/incident/incident.filter'
import {
    forkJoin,
    of,
} from 'rxjs'
import {
    CertGuard,
    ProfileSessionGuard,
} from '../../common/guard/profile.guard'
import * as jwt from 'jsonwebtoken'
import { ILoggerService } from '../../common/interface/logger.interface'
import { ClassStringify } from '../../utils/class-stringify'

const {
    INCIDENT_SERVICE,
    INCIDENT_TYPE_SERVICE,
    DASHBOARD_SERVICE,
    INCIDENT_LOG_SERVICE,
    INCIDENT_REPOSITORY,
    LOGGER_SERVICE,
} = ProviderName

@Controller('/incident')
export class IncidentController {
    constructor(
        @Inject(INCIDENT_SERVICE)
        private readonly _incidentService: IIncidentService,
        @Inject(INCIDENT_TYPE_SERVICE)
        private readonly _incidentTypeService: IIncidentTypeService,
        @Inject(DASHBOARD_SERVICE)
        private readonly _dashboardService: IDashboardService,
        @Inject(INCIDENT_LOG_SERVICE)
        private readonly _incidentLogsService: IIncidentLogService,
        @Inject(INCIDENT_REPOSITORY)
        private readonly _incidentRepository: IIncidentRepository,
        @Inject(LOGGER_SERVICE)
        private readonly _loggerService: ILoggerService,
    ) {
        this._loggerService.setContext('Incident Service')
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/:id')
    public getIncidentById(
        @Headers('x-profile') profileToken: string,
        @Param('id') id: string,
        @Req() req,
    ) {
        const dtoTemplate = {
            total: 0,
            data: [],
        }

        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        return this._incidentService.getById(id).pipe(
            reduce((acc, model) => {
                ++acc.total
                acc.data.push(IncidentDto.toIncidentDto(model))
                return acc
            }, dtoTemplate),
            tap(() => {
                this._loggerService.info(`get incident id: ${id} by ${user} [${req.ip}]`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @UseGuards(CertGuard)
    @Post('/')
    public saveIncident(
        @Headers('x-profile') profileToken: string,
        @Body() body: SaveIncidentValidator,
        @Req() req,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`
        body.setCreatedBy(user)

        return this._incidentService.save(body).pipe(
            tap((result: {id: string}) => {
                this._loggerService.info(`incident id: ${result.id} was created by ${user} [${req.ip}]`)
                this._loggerService.info(` - incident id: ${result.id}\n${ClassStringify.fromClass(body)}`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @UseGuards(CertGuard)
    @Patch('/:id')
    public updateIncident(
        @Headers('x-profile') profileToken: string,
        @Param('id') id: string,
        @Body() body: UpdateIncidentValidator,
        @Req() req,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`
        body.setUpdatedBy(user)

        return this._incidentService.updateIncident(id, body).pipe(
            tap((result: {id: string}) => {
                this._loggerService.info(`incident id: ${result.id} was updated by ${user} [${req.ip}]`)
                this._loggerService.info(` - incident id: ${result.id}\n${ClassStringify.fromClass(body)}`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @UseGuards(CertGuard)
    @Put('/:id/status')
    public updateIncidentStatus(
        @Headers('x-profile') profileToken: string,
        @Param('id') id: string,
        @Body() body: UpdateIncidentStatusValidator,
        @Req() req,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`
        body.setUpdatedBy(user)

        return this._incidentService.updateStatus(id, body).pipe(
            tap((result: {id: string}) => {
                this._loggerService.info(`incident id: ${result.id} status was updated by ${user} [${req.ip}]`)
                this._loggerService.info(` - incident id: ${result.id}\n${ClassStringify.fromClass(body)}`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/:id/logs')
    public getIncidentLogs(
        @Headers('x-profile') profileToken: string,
        @Param('id') id: string,
        @Req() req,
    ) {
        const dtoTemplate = {
            total: 0,
            data: [],
        }

        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        return this._incidentLogsService.getRecordById(id).pipe(
            reduce((acc, model) => {
                ++acc.total
                acc.data.push(IncidentLogDto.toIncidentLogRecordDto(model))
                return acc
            }, dtoTemplate),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @UseGuards(CertGuard)
    @Put('/:id/logs')
    public createLogs(
        @Headers('x-profile') profileToken: string,
        @Param('id') id: string,
        @Body() body: UpdateIncidentLogValidator,
        @Req() req,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`
        body.setCreatedBy(user)

        return this._incidentService.updateLog(id, body).pipe(
            tap((result: {id: string}) => {
                this._loggerService.info(`incident id: ${result.id} timeline was updated by ${user} [${req.ip}]`)
                this._loggerService.info(` - incident id: ${result.id}\n${ClassStringify.fromClass(body)}`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @UseGuards(CertGuard)
    @Put('/:id/surveyor')
    public assignToSurveyor(
        @Headers('x-profile') profileToken: string,
        @Param('id') incidentId: string,
        @Body() body: UpdateIncidentSurveyorValidator,
        @Req() req,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`
        body.setUpdatedBy(user)

        return this._incidentService.assignToSurveyor(incidentId, body).pipe(
            tap(() => {
                this._loggerService.info(`incident id: ${incidentId} was assigned to surveyor by ${user} [${req.ip}]`)
                this._loggerService.info(` - incident id: ${incidentId}\n${ClassStringify.fromClass(body)}`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/count/status')
    public getCountStatus() {
        return this._dashboardService.countByStatus()
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/')
    public SearchIncident(
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Query('phone') phone: string,
        @Query('openFrom') openFrom?: string,
        @Query('openTo') openTo?: string,
        @Query('appointmentFrom') appointmentFrom?: string,
        @Query('appointmentTo') appointmentTo?: string,
        @Query('status') status?: string,
        @Query('incidentType') type?: string,
        @Query('agent') agent?: string,
        @Query('subType') subType?: string,
        @Query('limit') limit?: string,
        @Query('page') page?: string,
        @Query('sortKeyword') sortKeyword?: string,
        @Query('sortDirection') sortDirection?: 1 | -1,
        @Query('query') query?: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        if (!_.isNil(phone)) {
            const phoneNumber = {
                contactNo: phone,
            }

            const dtoTemplate = {
                total: 0,
                data: [],
            }

            return this._incidentService.find(phoneNumber).pipe(
                reduce((acc, model) => {
                    ++acc.total
                    acc.data.push(IncidentDto.toIncidentDto(model))
                    return acc
                }, dtoTemplate),
                tap(() => {
                    this._loggerService.info(`search incident by ${user} [${req.ip}]`)
                    this._loggerService.info(` - search incident query ${JSON.stringify(req.query)}`)
                }),
            )
        }

        const incidentData = {
            total: 0,
            data: [],
        }

        const filtering: IIncidentDeepFilter = {
            appointment: null,
            open: null,
        }
        const sorting: IIncidentSort = {
            direction: null,
            limit: null,
            page: null,
            sortKey: null,
        }

        if (_.isEmpty(status) && _.isEmpty(type) && _.isEmpty(agent) && _.isEmpty(subType) &&
            _.isEmpty(openFrom) && _.isEmpty(openTo) && _.isEmpty(appointmentFrom) && _.isEmpty(appointmentTo) &&
            _.isEmpty(limit) && _.isEmpty(page) && _.isEmpty(sortKeyword) && _.isEmpty(sortDirection)) {
            return this._incidentService.getAll().pipe(
                reduce((acc, model) => {
                    ++acc.total
                    const test = IncidentSearchDto.toIncidentSearchDto(model)
                    acc.data.push(IncidentSearchDto.toIncidentSearchDto(model))
                    return acc
                }, incidentData),
                tap(() => {
                    this._loggerService.info(`search incident by ${user} [${req.ip}]`)
                    this._loggerService.info(` - search incident query ${JSON.stringify(req.query)}`)
                }),
            )
        }
        if (!_.isEmpty(openFrom) && !_.isEmpty(openTo)) {
            const from = new Date(_.toNumber(openFrom))
            const to = new Date(_.toNumber(openTo))

            filtering.open = {
                from: from.getTime(),
                to: to.getTime(),
            }
        }
        if (!_.isEmpty(appointmentFrom) && !_.isEmpty(appointmentTo)) {
            const from = new Date(_.toNumber(appointmentFrom))
            const to = new Date(_.toNumber(appointmentTo))

            filtering.appointment = {
                from: from.getTime(),
                to: to.getTime(),
            }

        }
        if (!_.isEmpty(status)) {
            filtering.status = status
        }
        if (!_.isEmpty(type)) {
            filtering.type = type
        }
        if (!_.isEmpty(agent)) {
            filtering.agent = agent
        }
        if (!_.isEmpty(subType)) {
            filtering.subType = subType
        }
        if (!_.isEmpty(query)) {
            filtering.query = query
        }
        if (!_.isEmpty(limit)) {
            sorting.limit = _.toNumber(limit)
        }
        if (!_.isEmpty(page)) {
            sorting.page = _.toNumber(page)
        }
        if (!_.isEmpty(sortKeyword)) {
            sorting.sortKey = sortKeyword
        }
        if (!_.isEmpty(sortDirection)) {
            sorting.direction = sortDirection
        }

        const incidentFilter = {
            filter: filtering,
            sorting,
        }

        return this._incidentService.getAll().pipe(
            toArray(),
            mergeMap((arrayOfData) => {
                const total = arrayOfData.length
                return forkJoin<number, IIncidentSearchDto[]>([
                    of(total),
                    this._dashboardService.filterIncident(incidentFilter).pipe(
                        map(model => IncidentSearchDto.toIncidentSearchDto(model)),
                        toArray(),
                    ),
                ])
            }),
            map((results) => {
                return {
                    total: results[0],
                    data: results[1],
                }
            }),
            tap(() => {
                this._loggerService.info(`search incident by ${user} [${req.ip}]`)
                this._loggerService.info(` - search incident query ${JSON.stringify(req.query)}`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/filter/search/excel')
    public exportIncidentExcel(
        @Res() res,
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Query('openFrom') openFrom?: string,
        @Query('openTo') openTo?: string,
        @Query('appointmentFrom') appointmentFrom?: string,
        @Query('appointmentTo') appointmentTo?: string,
        @Query('status') status?: string,
        @Query('incidentType') type?: string,
        @Query('agent') agent?: string,
        @Query('subType') subType?: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        if (_.isNil(openFrom) || (_.isNil(openTo))) {
            openFrom = null, openTo = null
        }
        if (_.isNil(appointmentFrom) || _.isNil(appointmentTo)) {
            appointmentFrom = null, appointmentTo = null
        }
        if (_.isNil(status)) {
            status = null
        }
        if (_.isNil(type)) {
            type = null
        }
        if (_.isNil(agent)) {
            agent = null
        }
        if (_.isNil(subType)) {
            subType = null
        }
        if (_.isEmpty(status) && _.isEmpty(type) && _.isEmpty(agent) && _.isEmpty(subType) &&
            _.isEmpty(openFrom) && _.isEmpty(openTo) && _.isEmpty(appointmentFrom) && _.isEmpty(appointmentTo)) {
            return this._incidentService.getAll().pipe(
                map(model => {
                    return IncidentExcelDto.toIncidentExcelDto(model)
                }),
                toArray(),
                mergeMap(data => {
                    return this._incidentService.exportSearchExcel('incident', data).pipe(
                        map(incidentExcel => incidentExcel.write(`incident.xlsx`, res)),
                    )
                }),
                tap(() => {
                    this._loggerService.info(`export incident by ${user} [${req.ip}]`)
                    this._loggerService.info(` - search incident query ${JSON.stringify(req.query)}`)
                }),
            )
        }

        const excelFilter: IIncidentRepositoryFilter = {}

        if (!_.isEmpty(openFrom) && !_.isEmpty(openTo)) {
            excelFilter.incidentDateRange = {
                from: new Date(_.toNumber(openFrom)),
                to: new Date(_.toNumber(openTo)),
            }
        }
        if (!_.isEmpty(appointmentFrom) && !_.isEmpty(appointmentTo)) {
            excelFilter.appointmentDateRange = {
                from: new Date(_.toNumber(appointmentFrom)),
                to: new Date(_.toNumber(appointmentTo)),
            }

        }
        if (!_.isEmpty(status)) {
            excelFilter.status = status
        }
        if (!_.isEmpty(type)) {
            excelFilter.type = type
        }
        if (!_.isEmpty(agent)) {
            excelFilter.agent = agent
        }
        if (!_.isEmpty(subType)) {
            excelFilter.subType = subType
        }

        return this._dashboardService.filterIncidentExcel(excelFilter).pipe(
            map(model => {
                return IncidentExcelDto.toIncidentExcelDto(model)
            }),
            toArray(),
            mergeMap(data => {
                return this._incidentService.exportSearchExcel('incident', data).pipe(
                    map(incidentExcel => incidentExcel.write(`incident.xlsx`, res)),
                )
            }),
            tap(() => {
                this._loggerService.info(`export incident by ${user} [${req.ip}]`)
                this._loggerService.info(` - search incident query ${JSON.stringify(req.query)}`)
            }),
        )
    }

}
