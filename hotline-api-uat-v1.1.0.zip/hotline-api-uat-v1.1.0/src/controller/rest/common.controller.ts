import {
    Controller,
    Get,
    Headers,
    HttpException,
    HttpStatus,
    Inject,
    Param,
    Query,
    Req,
    Res,
    UseGuards,
} from '@nestjs/common'
import { ProviderName } from '../../provider'
import { ICommonService } from '../../domain/common/interface/service.interface'
import {
    map,
    mergeMap,
    reduce,
    tap,
    toArray,
} from 'rxjs/operators'
import { TowingDto } from './dto/towing.dto'
import { ITowingService } from '../../domain/incident/interface/towing.service.interface'
import { Observable } from 'rxjs'
import { IncidentTypeDto } from './dto/type.dto'
import { IIncidentTypeService } from '../../domain/incident/interface/type.service.interface'
import * as _ from 'lodash'
import { IAs400Adapter } from '../../adapter/as400/interface'
import { ISmsAdapter } from '../../adapter/sms/interface/adaper.interface'
import { ProfileSessionGuard } from '../../common/guard/profile.guard'
import { IAudioDownloadAdapter } from '../../adapter/audio-download/interface/adapter.interface'
import { IAudioDecoder } from '../../common/interface/audio-decoder.interface'
import * as FileSystem from 'fs'
import * as fs from 'fs'
import { ILoggerService } from '../../common/interface/logger.interface'

const {
    COMMON_SERVICE,
    TOWING_SERVICE,
    INCIDENT_TYPE_SERVICE,
    AS400_ADAPTER,
    SMS_ADAPTER,
    RECORDER_AUDIO_ADAPTER,
    AUDIO_DECODER_SERVICE,
} = ProviderName

@Controller('/')
export class CommonController {
    constructor(
        @Inject(COMMON_SERVICE)
        private readonly _commonService: ICommonService,
        @Inject(TOWING_SERVICE)
        private readonly _towingService: ITowingService,
        @Inject(INCIDENT_TYPE_SERVICE)
        private readonly _incidentTypeService: IIncidentTypeService,
        @Inject(AS400_ADAPTER)
        private readonly _adapterAs400: IAs400Adapter,
        @Inject(SMS_ADAPTER)
        private readonly _smsAdapter: ISmsAdapter,
        @Inject(RECORDER_AUDIO_ADAPTER)
        private readonly _audioDownload: IAudioDownloadAdapter,
        @Inject(AUDIO_DECODER_SERVICE)
        private readonly _audioDecoder: IAudioDecoder,
    ) {
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/')
    public healthCheck(
        @Headers('x-profile') profileToken: string,
    ) {
        return this._commonService.healthCheck()
    }

    @Get('/towing')
    public getTowing() {
        return this._towingService.getTowingAll().pipe(
            map(model => TowingDto.toTowingDto(model)),
            toArray(),
            map(dto => {
                return {
                    total: dto.length,
                    data: dto,
                }
            }),
        )
    }

    @Get('/type')
    public getType(): Observable<any> {
        const result = {
            data: [],
            total: 0,
        }
        return this._incidentTypeService.find().pipe(
            reduce((accumulator, model) => {
                accumulator.total++
                const data = IncidentTypeDto.toIncidentTypeDto((model))
                accumulator.data.push(data)
                return accumulator
            }, result),
        )
    }

    @Get('/as400')
    public getSearchByPolicy(
        @Query('policyNo') policyNo: string,
        @Query('name') name: string,
        @Query('registration') registration: string,
        @Query('chassis') chassis: string,
    ) {
        let observable = null
        console.log(`----- as400 -----`)
        if (!_.isNil(policyNo)) {
            console.log(`>>>> policyNo`)
            observable = this._adapterAs400.getAs400ByPolicyNo(policyNo)
        } else if (!_.isNil(name)) {
            observable = this._adapterAs400.getAs400ByInsured(name)
        } else if (!_.isNil(registration)) {
            observable = this._adapterAs400.getAs400ByRegistration(registration)
        } else if (!_.isNil(chassis)) {
            observable = this._adapterAs400.getAs400ByChassis(chassis)
        } else {
            throw new HttpException(
                `Get As400 error`,
                HttpStatus.BAD_REQUEST,
            )
        }
        const outputDto = {
            total: 0,
            data: [],
        }
        return observable.pipe(
            reduce((accumulator, item) => {
                ++accumulator.total
                accumulator.data.push(item)
                return accumulator
            }, outputDto),
        )
    }

    @Get('/as400/:policy/risks')
    public getPolicyRisksMeta(
        @Param('policy') policyId: string,
    ) {
        const outputDto = {
            total: 0,
            data: [],
        }
        return this._adapterAs400.getRisksMetaByPolicyId(policyId).pipe(
            reduce((accumulator, item) => {
                ++accumulator.total
                accumulator.data.push(item)
                return accumulator
            }, outputDto),
        )
    }

    @Get('/as400/:policy/risks/:riskId')
    public getPolicyDetail(
        @Param('policy') policyId: string,
        @Param('riskId') riskId: string,
    ) {
        return this._adapterAs400.getPolicyDetail(policyId, riskId)
    }

    @Get('/audio')
    public getAudio(
        @Query('path') path: string,
        @Req() req,
        @Res() res,
    ) {
        return this._audioDownload.getFile(path).pipe(
            mergeMap((buffer: Buffer) => {
                return this._audioDecoder.decodeBuffer(buffer)
            }),
            map(({decodedFile}: { decodedFile: string }) => {
                const stat = fs.statSync(decodedFile)
                const fileSize = stat.size
                console.log(decodedFile, stat)
                const range = _.get(req, 'headers.range', false)

                if (!!range) {
                    let readStream
                    let head
                    let start = 0
                    let end = fileSize
                    const parts = range.replace(/bytes=/, '').split('-')
                    start = parseInt(parts[0], 10)
                    end = parts[1]
                        ? parseInt(parts[1], 10)
                        : fileSize - 1
                    const chunksize = (end - start) + 1

                    readStream = FileSystem.createReadStream(decodedFile, {
                        start,
                        end,
                    })

                    head = {
                        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
                        'Accept-Ranges': 'bytes',
                        'Content-Length': chunksize,
                        'Content-Type': 'audio/wav',
                    }
                    const responseHeader = HttpStatus.PARTIAL_CONTENT
                    res.writeHead(responseHeader, head)
                    readStream.pipe(res)

                } else {
                    let readStream
                    let head
                    head = {
                        'Content-Length': fileSize,
                        'Content-Type': 'audio/wav',
                    }

                    readStream = FileSystem.createReadStream(decodedFile)
                    const responseHeader = HttpStatus.OK
                    res.writeHead(responseHeader, head)
                    readStream.pipe(res)
                }

            }),
        )
    }
}
