import {
    Body,
    Controller,
    Get,
    Headers,
    Inject,
    Param,
    Post,
    Put,
    Req,
    UseGuards,
} from '@nestjs/common'
import {
    map,
    reduce,
} from 'rxjs/operators'
import {
    ManagementQADto,
} from './dto/managementQA.dto'
import { ProviderName } from '../../provider'
import { IManagementQAService } from '../../domain/managementQA/interface/service.interface'
import { IManagementQAModel } from '../../domain/managementQA/interface/model.interface'
import {
    CreateManagementQAValidator,
    UpdateManagementQAValidator,
} from './validator/managementQA.validator'
import { ProfileSessionGuard } from '../../common/guard/profile.guard'
import * as jwt from 'jsonwebtoken'
import { ILoggerService } from '../../common/interface/logger.interface'

const {
    LOGGER_SERVICE,
    MANAGEMENT_QA_SERVICE,
} = ProviderName

@Controller('/managementQA')
export class ManagementQAController {
    constructor(
        @Inject(MANAGEMENT_QA_SERVICE)
        private readonly _managementQAService: IManagementQAService,
        @Inject(LOGGER_SERVICE)
        private readonly _loggerService: ILoggerService,
    ) {
        this._loggerService.setContext('ManagementQA Service')
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/')
    public getAllManagementQA() {
        const dtoTemplate = {
            total: 0,
            data: [],
        }

        return this._managementQAService.getAll().pipe(
            reduce((acc, model) => {
                    acc.total++
                    acc.data.push(ManagementQADto.toManagementDto(model))
                    return acc
                },
                dtoTemplate,
            ),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/:id')
    public getManagementQA(
        @Param('id') id: string,
    ) {
        return this._managementQAService.getById(id).pipe(
            map((result: IManagementQAModel) => {
                return ManagementQADto.toManagementDto(result)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Post('/')
    public CreateManagementQA(
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Body() body: CreateManagementQAValidator,
    ) {
        const profile: any = jwt.decode(profileToken)
        const givenName = profile.given_name
        const familyName = profile.family_name
        const user = givenName + ' ' + familyName
        body.setCreatedBy(user)
        this._loggerService.info(`CreateManagementQA by ${user} [${req.ip}]`)
        return this._managementQAService.save(body)
    }

    @UseGuards(ProfileSessionGuard)
    @Put('/:id')
    public UpdateManagementQA(
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Param('id') id: string,
        @Body() body: UpdateManagementQAValidator,
    ) {
        const profile: any = jwt.decode(profileToken)
        const givenName = profile.given_name
        const familyName = profile.family_name
        const user = givenName + ' ' + familyName
        body.setUpdatedBy(user)
        this._loggerService.info(`CreateManagementQA by ${user} [${req.ip}]`)

        return this._managementQAService.update(id, body).pipe(
            map((result: IManagementQAModel) => {
                return ManagementQADto.toManagementDto(result)
            }),
        )
    }
}
