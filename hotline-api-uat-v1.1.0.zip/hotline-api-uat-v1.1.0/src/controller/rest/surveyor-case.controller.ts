import { ProviderName } from '../../provider'
import { ISurveyorCaseService } from '../../domain/surveyor-case/interface/service.interface'
import {
    map,
    mergeMap,
    reduce,
    tap,
    toArray,
} from 'rxjs/operators'
import { SurveyorCaseDto } from './dto/surveyor-case.dto'
import {
    BadRequestException,
    Body,
    Controller,
    Delete,
    Get,
    Headers,
    Inject,
    Param,
    Post,
    Put,
    Query,
    Res,
    UploadedFile,
    UseGuards,
    UseInterceptors,
} from '@nestjs/common'
import {
    FinalizeCaseValidator,
    UpdateSurveyorCaseValidator,
} from './validator/case.validator'
import { FileInterceptor } from '@nestjs/platform-express'
import * as _ from 'lodash'
import { plainToClass } from 'class-transformer'
import { validate } from 'class-validator'
import {
    from,
    iif,
} from 'rxjs'
import { SurveyorGuard } from '../../common/guard/surveyor.guard'
import { ProfileSessionGuard } from '../../common/guard/profile.guard'
import { ProfileGuard } from '../../common/guard/profile.guard'
import { ILoggerService } from '../../common/interface/logger.interface'
import * as jwt from 'jsonwebtoken'
import { ClassStringify } from '../../utils/class-stringify'

const {
    SURVEYOR_CASE_SERVICE,
    LOGGER_SERVICE,
} = ProviderName

@Controller('/case')
export class SurveyorCaseController {
    constructor(
        @Inject(SURVEYOR_CASE_SERVICE)
        private readonly _surveyorCaseService: ISurveyorCaseService,
        @Inject(LOGGER_SERVICE)
        private readonly _loggerService: ILoggerService,
    ) {
        this._loggerService.setContext('Surveyor Case Service')
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/')
    public listCases(
        @Headers('x-profile') profileToken: string,
        @Query('incidentNo') incidentNo: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        const dtoTemplate = {
            total: 0,
            data: [],
        }

        const conditionalObservable = () => !_.isEmpty(incidentNo)

        return iif(conditionalObservable,
            this._surveyorCaseService.filterData({ incidentNo }),
            this._surveyorCaseService.getAll(),
        ).pipe(
            reduce((acc, model) => {
                ++acc.total
                acc.data.push(SurveyorCaseDto.toSurveyorCaseDto(model))
                return acc
            }, dtoTemplate),
            tap(() => {
                this._loggerService.info(`search surveyor case by ${user}`)
            }),
        )
    }

    @UseGuards(SurveyorGuard)
    @Delete('/:id')
    public deleteCase(
        @Param('id') id: string,
    ) {
        return this._surveyorCaseService.deleteSurveyorCase(id).pipe(
            tap(() => {
                this._loggerService.info(`surveyor cancel case ${id}`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/:id')
    public getSurveyorCaseById(
        @Param('id') id: string,
    ) {
        return this._surveyorCaseService.getById(id).pipe(
            map((model) => {
                return SurveyorCaseDto.toSurveyorCaseDto(model)
            }),
        )
    }

    // @UseGuards(SurveyorGuard)
    @Get('/:caseId/file')
    public getFileContent(
        @Param('caseId') caseId: string,
        @Res() res,
    ) {
        return this._surveyorCaseService.getImageFileContent(caseId).pipe(
            tap(buffer => {
                res.end(buffer)
            }),
        )
    }

    @UseGuards(SurveyorGuard)
    @Get('/:surveyorId/:caseId')
    public getSurveyorCase(
        @Param('surveyorId') surveyorId: string,
        @Param('caseId') caseId: string,
    ) {
        return this._surveyorCaseService.getBySurveyorIdAndCaseId(surveyorId, caseId).pipe(
            map(({ surveyorCase, incidentSchema }) => {
                const dto = SurveyorCaseDto.toSurveyorCaseDto(surveyorCase)
                return {
                    ...dto,
                    incident: {
                        ...incidentSchema,
                    },
                }
            }),
        )

    }

    @UseGuards(SurveyorGuard)
    @Put('/:id')
    public updateSurveyorCase(
        @Param('id') id: string,
        @Body() body: UpdateSurveyorCaseValidator,
    ) {
        return this._surveyorCaseService.update(id, body).pipe(
            tap(result => {
                this._loggerService.info(`case ${id} updated`)
                this._loggerService.info(`case ${id}\n${ClassStringify.fromClass(body)}`)
            }),
        )
    }

    @UseGuards(SurveyorGuard)
    @Put('/:id/finalize')
    @UseInterceptors(FileInterceptor('file'))
    public finalizeCase(
        @Param('id') id: string,
        @Body() body: any,
        @UploadedFile() file: Express.Multer.File,
    ) {
        if (_.isNil(file)) {
            throw new BadRequestException(`Please upload image file`)
        }
        const bodyInput = plainToClass(FinalizeCaseValidator, body)
        return from(validate(bodyInput)).pipe(
            tap(errors => {
                if (errors.length > 0) {
                    throw new BadRequestException(`Invalid form data`)
                }
            }),
            mergeMap(() => {
                file.originalname = new Date().getTime() + '_' + file.originalname
                return this._surveyorCaseService.updateImage(id, bodyInput, file)
            }),
            tap(result => {
                this._loggerService.info(`case ${id} finalized`)
                this._loggerService.info(`case ${id}\n${ClassStringify.fromClass(body)}`)
            }),
        )

    }

}
