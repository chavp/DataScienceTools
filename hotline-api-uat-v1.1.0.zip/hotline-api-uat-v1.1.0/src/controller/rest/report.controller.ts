import {
    Controller,
    Get,
    Headers,
    Inject,
    Query,
    Res,
    UseGuards,
} from '@nestjs/common'
import { ProviderName } from '../../provider'
import * as _ from 'lodash'
import { IIncidentService } from '../../domain/incident/interface'
import {
    map,
    mergeMap,
    reduce,
    tap,
    toArray,
} from 'rxjs/operators'
import { IDashboardService } from '../../domain/incident/interface/dashboard.interface'
import { IReportService } from '../../domain/report/interface/report.intefarce'
import { ProfileGuard } from '../../common/guard/profile.guard'
import {
    forkJoin,
    from,
    of,
} from 'rxjs'
import { ProfileSessionGuard } from '../../common/guard/profile.guard'
import {
    IIncidentSearchDto,
    IncidentDto,
    IncidentSearchDto,
} from './dto/incident.dto'
import {
    IIncidentDeepFilter,
    IIncidentSort,
} from '../../repository/incident/incident.filter'
import { ILoggerService } from '../../common/interface/logger.interface'
import * as jwt from 'jsonwebtoken'

const {
    REPORT_SERVICE,
    INCIDENT_SERVICE,
    DASHBOARD_SERVICE,
    LOGGER_SERVICE,
} = ProviderName

@Controller('/report')
export class ReportController {
    constructor(
        @Inject(REPORT_SERVICE)
        private readonly _reportService: IReportService,
        @Inject(INCIDENT_SERVICE)
        private readonly _incidentService: IIncidentService,
        @Inject(DASHBOARD_SERVICE)
        private readonly _dashboardService: IDashboardService,
        @Inject(LOGGER_SERVICE)
        private readonly _loggerService: ILoggerService,
    ) {
        this._loggerService.setContext('Report Service')
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/incident')
    public searchIncident(
        @Headers('x-profile') profileToken: string,
        @Query('phone') phone: string,
        @Query('openFrom') openFrom?: string,
        @Query('openTo') openTo?: string,
        @Query('appointmentFrom') appointmentFrom?: string,
        @Query('appointmentTo') appointmentTo?: string,
        @Query('status') status?: string,
        @Query('incidentType') type?: string,
        @Query('agent') agent?: string,
        @Query('subType') subType?: string,
        @Query('limit') limit?: string,
        @Query('page') page?: string,
        @Query('sortKeyword') sortKeyword?: string,
        @Query('sortDirection') sortDirection?: 1 | -1,
        @Query('query') query?: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        if (!_.isNil(phone)) {
            const phoneNumber = {
                contactNo: phone,
            }

            const dtoTemplate = {
                total: 0,
                data: [],
            }

            return this._incidentService.find(phoneNumber).pipe(
                reduce((acc, model) => {
                    ++acc.total
                    acc.data.push(IncidentDto.toIncidentDto(model))
                    return acc
                }, dtoTemplate),
                tap(() => {
                    return this._loggerService.info(`search incident report by ${user}`)
                }),
            )
        }

        const incidentData = {
            total: 0,
            data: [],
        }

        const filtering: IIncidentDeepFilter = {
            appointment: null,
            open: null,
        }
        const sorting: IIncidentSort = {
            direction: null,
            limit: null,
            page: null,
            sortKey: null,
        }

        if (_.isEmpty(status) && _.isEmpty(type) && _.isEmpty(agent) && _.isEmpty(subType) &&
            _.isEmpty(openFrom) && _.isEmpty(openTo) && _.isEmpty(appointmentFrom) && _.isEmpty(appointmentTo) &&
            _.isEmpty(limit) && _.isEmpty(page) && _.isEmpty(sortKeyword) && _.isEmpty(sortDirection)) {
            return this._reportService.getAll().pipe(
                reduce((acc, model) => {
                    ++acc.total
                    acc.data.push(model)
                    return acc
                }, incidentData),
                tap(() => {
                    return this._loggerService.info(`search incident report by ${user}`)
                }),
            )
        }
        if (!_.isEmpty(openFrom) && !_.isEmpty(openTo)) {
            const fromO = new Date(_.toNumber(openFrom))
            const to = new Date(_.toNumber(openTo))

            filtering.open = {
                from: fromO.getTime(),
                to: to.getTime(),
            }
        }
        if (!_.isEmpty(appointmentFrom) && !_.isEmpty(appointmentTo)) {
            const fromA = new Date(_.toNumber(appointmentFrom))
            const to = new Date(_.toNumber(appointmentTo))

            filtering.appointment = {
                from: fromA.getTime(),
                to: to.getTime(),
            }

        }
        if (!_.isEmpty(status)) {
            filtering.status = status
        }
        if (!_.isEmpty(type)) {
            filtering.type = type
        }
        if (!_.isEmpty(agent)) {
            filtering.agent = agent
        }
        if (!_.isEmpty(subType)) {
            filtering.subType = subType
        }
        if (!_.isEmpty(query)) {
            filtering.query = query
        }
        if (!_.isEmpty(limit)) {
            sorting.limit = _.toNumber(limit)
        }
        if (!_.isEmpty(page)) {
            sorting.page = _.toNumber(page)
        }
        if (!_.isEmpty(sortKeyword)) {
            sorting.sortKey = sortKeyword
        }
        if (!_.isEmpty(sortDirection)) {
            sorting.direction = sortDirection
        }

        const incidentFilter = {
            filter: filtering,
            sorting,
        }

        return this._reportService.searchIncident(incidentFilter).pipe(
            reduce((acc, model) => {
                ++acc.total
                acc.data.push(model)
                return acc
            }, incidentData),
            tap(() => {
                return this._loggerService.info(`search incident report by ${user}`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/incident/excel')
    public exportIncidentExcel(
        @Res() res,
        @Headers('x-profile') profileToken: string,
        @Query('phone') phone: string,
        @Query('openFrom') openFrom?: string,
        @Query('openTo') openTo?: string,
        @Query('appointmentFrom') appointmentFrom?: string,
        @Query('appointmentTo') appointmentTo?: string,
        @Query('status') status?: string,
        @Query('incidentType') type?: string,
        @Query('agent') agent?: string,
        @Query('subType') subType?: string,
        @Query('limit') limit?: string,
        @Query('page') page?: string,
        @Query('sortKeyword') sortKeyword?: string,
        @Query('sortDirection') sortDirection?: 1 | -1,
        @Query('query') query?: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        if (!_.isNil(phone)) {
            const phoneNumber = {
                contactNo: phone,
            }

            const dtoTemplate = {
                total: 0,
                data: [],
            }
            return this._incidentService.find(phoneNumber).pipe(
                reduce((acc, model) => {
                    ++acc.total
                    acc.data.push(IncidentDto.toIncidentDto(model))
                    return acc
                }, dtoTemplate),
                tap(() => {
                    return this._loggerService.info(`export incident report by ${user}`)
                }),
            )
        }
        const incidentData = {
            total: 0,
            data: [],
        }

        const filtering: IIncidentDeepFilter = {
            appointment: null,
            open: null,
        }
        const sorting: IIncidentSort = {
            direction: null,
            limit: null,
            page: null,
            sortKey: null,
        }

        if (_.isEmpty(status) && _.isEmpty(type) && _.isEmpty(agent) && _.isEmpty(subType) &&
            _.isEmpty(openFrom) && _.isEmpty(openTo) && _.isEmpty(appointmentFrom) && _.isEmpty(appointmentTo) &&
            _.isEmpty(limit) && _.isEmpty(page) && _.isEmpty(sortKeyword) && _.isEmpty(sortDirection)) {
            return this._reportService.getAll().pipe(
                toArray(),
                mergeMap(data => {
                    return this._reportService.exportSearchExcel('reportIncident', data).pipe(
                        map(incidentExcel => incidentExcel.write(`reportIncident.xlsx`, res)),
                    )
                }),
                tap(() => {
                    return this._loggerService.info(`export incident report by ${user}`)
                }),
            )
        }
        if (!_.isEmpty(openFrom) && !_.isEmpty(openTo)) {
            const fromO = new Date(_.toNumber(openFrom))
            const to = new Date(_.toNumber(openTo))

            filtering.open = {
                from: fromO.getTime(),
                to: to.getTime(),
            }
        }
        if (!_.isEmpty(appointmentFrom) && !_.isEmpty(appointmentTo)) {
            const fromA = new Date(_.toNumber(appointmentFrom))
            const to = new Date(_.toNumber(appointmentTo))

            filtering.appointment = {
                from: fromA.getTime(),
                to: to.getTime(),
            }

        }
        if (!_.isEmpty(status)) {
            filtering.status = status
        }
        if (!_.isEmpty(type)) {
            filtering.type = type
        }
        if (!_.isEmpty(agent)) {
            filtering.agent = agent
        }
        if (!_.isEmpty(subType)) {
            filtering.subType = subType
        }
        if (!_.isEmpty(query)) {
            filtering.query = query
        }
        if (!_.isEmpty(limit)) {
            sorting.limit = _.toNumber(limit)
        }
        if (!_.isEmpty(page)) {
            sorting.page = _.toNumber(page)
        }
        if (!_.isEmpty(sortKeyword)) {
            sorting.sortKey = sortKeyword
        }
        if (!_.isEmpty(sortDirection)) {
            sorting.direction = sortDirection
        }

        const incidentFilter = {
            filter: filtering,
            sorting,
        }

        return this._reportService.searchIncident(incidentFilter).pipe(
            toArray(),
            mergeMap(data => {
                return this._reportService.exportSearchExcel('reportIncident', data).pipe(
                    map(incidentExcel => incidentExcel.write(`reportIncident.xlsx`, res)),
                )
            }),
            tap(() => {
                return this._loggerService.info(`export incident report by ${user}`)
            }),
        )
    }
}
