import {
    Body,
    Controller,
    Get,
    HttpCode,
    Inject,
    Param,
    Post,
    Put,
    Req,
    UseGuards,
} from '@nestjs/common'
import {
    EventMessage,
    Postback,
    PostbackEvent,
    WebhookEvent,
    WebhookRequestBody,
} from '@line/bot-sdk'
import { ProviderName } from '../../provider'
import { LineHookGuard } from '../../common/guard/line-hook.guard'
import { ILineService } from '../../domain/line/interface/service.interface'
import {
    from,
    Observable,
    of,
} from 'rxjs'
import {
    concatMap,
    map,
    reduce,
    toArray,
} from 'rxjs/operators'
import {
    RegisterLineValidator,
} from './validator/line.validator'
import { LineProfileDto } from './dto/line-profile.dto'
import { MessageEvent } from '@line/bot-sdk/lib/types'
import {
    ILineProfileAllMessage,
    IMapResult,
} from '../../domain/line/interface/result.interface'
import { ISurveyorCaseService } from '../../domain/surveyor-case/interface/service.interface'
import * as QueryString from 'qs'
import * as jwt from 'jsonwebtoken'
import * as _ from 'lodash'
import { ILoggerService } from '../../common/interface/logger.interface'

const {
    LINE_SERVICE,
    SURVEYOR_CASE_SERVICE,
    LOGGER_SERVICE,
} = ProviderName

@Controller('line')
export class LineController {
    constructor(
        @Inject(LINE_SERVICE)
        private readonly _lineService: ILineService,
        @Inject(SURVEYOR_CASE_SERVICE)
        private readonly _surveyorCase: ISurveyorCaseService,
        @Inject(LOGGER_SERVICE)
        private readonly _loggerService: ILoggerService,
    ) {
        this._loggerService.setContext('Line Service')
    }

    @Post('/:prefix/hook')
    @HttpCode(200)
    @UseGuards(LineHookGuard)
    public MessageHook(
        @Req() request: Express.Request,
        @Body() body: WebhookRequestBody,
        @Param() params: any,
    ) {
        // console.log(`LINE HOOK !!`)
        const messageEventRouting = (msgEvt: MessageEvent): Observable<any> => {
            const msg = msgEvt.message as EventMessage
            switch (msg.type) {
                case 'text':
                    if (_.startsWith(msg.text, '/command')) {
                        const command: string[] = msg.text.split(' ')
                        return this._lineService.commandQuery(msgEvt, _.slice(command, 1))
                    }
                    return this._lineService.publishTextMessage(msgEvt, msg)
                case 'file':
                    return this._lineService.publishFileEventMessage(msgEvt, msg)
                case 'image':
                    return this._lineService.publishImageEventMessage(msgEvt, msg)
                case 'location':
                    return this._lineService.publishLocationEventMessage(msgEvt, msg)
                case 'sticker':
                    return this._lineService.publishStickerEventMessage(msgEvt, msg)
                default:
                    return of({})
            }
        }

        const postbackEventRouting = (msgEvt: PostbackEvent): Observable<any> => {
            const postbackData = msgEvt.postback as Postback
            const parseString = (postbackData.data).toString()
            const jsonData = QueryString.parse(parseString)
            const tokenData = jwt.decode(jsonData.token) as any
            // console.log(`json data -> `, jsonData)
            // console.log(`json token -> `, tokenData)
            // console.log(`jsonData.type --------> `, jsonData.type)
            switch (jsonData.type) {
                case 'surveyor-not-arrived':
                    return this._surveyorCase.surveyorNotArrived(jsonData.case, tokenData.lineId, tokenData.sendTo)
                case 'surveyor-arrived':
                    return this._surveyorCase.surveyorArrived(jsonData.case, tokenData.lineId, tokenData.sendTo)
                default:
                    return of({})
            }
        }

        return from(body.events).pipe(
            concatMap((evt: WebhookEvent) => {
                switch (evt.type) {
                    case 'join':
                        return this._lineService.publishJoinEvent(evt)
                    case 'follow':
                        return this._lineService.publishFollowEvent(evt)
                    case 'unfollow':
                        return this._lineService.publishUnfollowEvent(evt)
                    case 'message':
                        return messageEventRouting(evt as MessageEvent)
                    case 'leave':
                        return this._lineService.publishLeaveEvent(evt)
                    case 'postback':
                        return postbackEventRouting(evt as PostbackEvent)
                    default:
                        return of({})
                }
            }),
            toArray(),
        )
    }

    @Put('/:lineId')
    public RegisterLine(
        @Req() req,
        @Param('lineId') lineId: string,
        @Body() body: RegisterLineValidator,
    ) {
        this._loggerService.info(`RegisterLine ${lineId} from [${req.ip}]`)
        return this._lineService.registerLineProfile(lineId, body)
    }

    @Get('/unregister')
    public GetAllUnregister() {
        const dtoTemplate = {
            total: 0,
            data: [],
        }

        return this._lineService.getAllUnregister().pipe(
            reduce((acc, model: IMapResult) => {
                acc.total++
                acc.data.push(LineProfileDto.toRegisterLineProfileDto(model))
                return acc
            }, dtoTemplate),
        )
    }

    @Get('/registered')
    public GetAllRegister() {
        const dtoTemplate = {
            total: 0,
            data: [],
        }

        return this._lineService.getAllRegistered().pipe(
            reduce((acc, model: IMapResult) => {
                acc.total++
                acc.data.push(LineProfileDto.toRegisterLineProfileDto(model))
                return acc
            }, dtoTemplate),
        )
    }

    @Put('/unRegister/:lineId')
    public UnRegisterLineProfile(
        @Req() req,
        @Param('lineId') lineId: string,
    ) {
        this._loggerService.info(`UnRegisterLineProfile ${lineId} from [${req.ip}]`)
        return this._lineService.unRegisterLineProfile(lineId)
    }

    @Put('/sendToIncident/:lineId')
    public SendToIncident(
        @Param('lineId') lineId: string,
    ) {
        return this._lineService.sendToIncident(lineId)
    }

    @Put('/unSendToIncident/:lineId')
    public UnSendToIncident(
        @Req() req,
        @Param('lineId') lineId: string,
    ) {
        this._loggerService.info(`UnSendToIncident ${lineId} from [${req.ip}]`)
        return this._lineService.unSentToIncident(lineId)
    }

    @Get('/:lineId/message')
    public GetConversationByLineId(
        @Param('lineId') lineId: string,
    ) {
        return this._lineService.getConversationByLineId(lineId).pipe(
            map((model: ILineProfileAllMessage) => {
                return LineProfileDto.toLineProfileMessageDto(model)
            }),
        )
    }

    @Get('/incident/:id/message')
    public GetConversationByIncidentNo(
        @Param('id') id: string,
    ) {
        return this._lineService.getConversationByIncidentNo(id).pipe(
            map((model: ILineProfileAllMessage) => {
                return LineProfileDto.toLineProfileMessageDto(model)
            }),
        )
    }

    @Put('/:lineId/message/read')
    public ReadMessage(
        @Param('lineId') lineId: string,
    ) {
        return this._lineService.setReadAllConversation(lineId)
    }
}
