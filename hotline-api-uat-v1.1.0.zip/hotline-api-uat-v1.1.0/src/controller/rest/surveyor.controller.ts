import * as _ from 'lodash'
import {
    Controller,
    Get,
    Inject,
    Param,
    Patch,
    Query,
    Req,
    UploadedFile,
    UseGuards,
    UseInterceptors,
} from '@nestjs/common'
import { FileInterceptor } from '@nestjs/platform-express'
import { ISurveyorService } from '../../domain/surveyor/interface/service.interface'
import { ProviderName } from '../../provider'
import { Observable } from 'rxjs'
import { ISurveyorModel } from '../../domain/surveyor/interface/model.interface'
import { SurveyorDto } from './dto/surveyor.dto'
import {
    map,
    reduce,
} from 'rxjs/operators'
import { ProfileSessionGuard } from '../../common/guard/profile.guard'

@Controller('/surveyor')
export class SurveyorController {
    constructor(
        @Inject(ProviderName.SURVEYOR_SERVICE)
        private readonly _surveyorService: ISurveyorService,
    ) {
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/')
    public getSurveyorList(
        @Query('province') province: string,
        @Query('district') district: string,
    ) {
        let observable: Observable<ISurveyorModel> = null
        if (!_.isEmpty(province) && !_.isEmpty(district)) {
            observable = this._surveyorService.listByLocation(province, district)
        } else {
            observable = this._surveyorService.listAll()
        }

        const result = {
            total: 0,
            data: [],
        }
        return observable.pipe(
            map((model => SurveyorDto.toSurveyorDto(model))),
            reduce((accumulator, dto) => {
                ++result.total
                result.data.push(dto)
                return result
            }, result),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @UseInterceptors(FileInterceptor('file'))
    @Patch('/upload')
    public uploadSurveyorsByXls(@UploadedFile() file: any, @Req() request: any) {
        if (file.mimetype !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
            throw new Error(`invalid file type not support file type ${file.mimetype}`)
        }

        const xlsRawString: string = file.buffer.toString('utf-8')

        return this._surveyorService
            .uploadAndReplace(file.buffer)
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/:id/message')
    public getSurveyorMessages(
        @Param('id') id: string,
    ) {
        return this._surveyorService.getLatestMessage(id, 100).pipe(
            map(message => SurveyorDto.toSurveyorMessageDto(message)),
            reduce((acc, value) => {
                acc.unshift(value)
                return acc
            }, []),
            map(data => {
                return {
                    total: data.length,
                    data,
                }
            }),
        )
    }
}
