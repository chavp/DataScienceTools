import {ProviderName} from '../../provider'
import {
    Controller,
    Get,
    Headers,
    Inject,
    Param,
    UseGuards,
} from '@nestjs/common'
import {
    map,
    tap,
} from 'rxjs/operators'
import {ICiscoDashboardService} from '../../domain/dashboard/interface/service.interface'
import {of} from 'rxjs'
import { ILoggerService } from '../../common/interface/logger.interface'
import { ProfileGuard } from '../../common/guard/profile.guard'
import * as jwt from 'jsonwebtoken'

const {
    CISCO_DASHBOARD_SERVICE,
    LOGGER_SERVICE,
} = ProviderName

@Controller('/dashboard')
export class DashboardController {

    constructor(
        @Inject(CISCO_DASHBOARD_SERVICE)
        private readonly _dashboardService: ICiscoDashboardService,
        @Inject(LOGGER_SERVICE)
        private readonly _loggerService: ILoggerService,
    ) {
        this._loggerService.setContext('Dashboard Service')
    }

    @UseGuards(ProfileGuard)
    @Get('/agent')
    public getAgent(
        @Headers('x-profile') profileToken: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        return this._dashboardService.getAgent().pipe(
            map(models => {
                return models
            }),
        )
    }

    @UseGuards(ProfileGuard)
    @Get('/queue')
    public getQueue(
        @Headers('x-profile') profileToken: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        return this._dashboardService.getQueue().pipe(
            map(models => {
                return models
            }),
        )
    }

    @UseGuards(ProfileGuard)
    @Get('/outbound')
    public getOutbound(
        @Param('date') date: string,
        @Headers('x-profile') profileToken: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        const outbound = [0, 5, 30, 130, 1020, 1234]
        const index = Math.floor((Math.random() * 5))
        return of({
            outbound: outbound[index],
        })
    }
}
