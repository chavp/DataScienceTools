import { ISurveyorLineModel } from '../../../domain/surveyor-line/interface/model.interface'
import { IMessageModel } from '../../../domain/message/interface'
import { ContentTypeEnum } from '../../../repository/message/message.schema'
import { IMessagePayloadSchema } from '../../../domain/message/interface/schema.interface'

export interface ISurveyorLineDto {
    id: string
    companyName: string
    groupName: string
    surveyorId: string
    botStatus: string
    groupImage: string
}

export interface ISurveyorLineWithMessageDto extends ISurveyorLineDto {
    message: {
        from: string
        lastMessage: string
        timeStamp: number
    }
}

export interface IExportSurveyorLineDto {
    id: string
    groupName: string
    surveyorCode: string
    area?: {
        province: string
        district: string[]
    },
}

export class SurveyorLineDto {
    public static createSurveyorListDTO(model: ISurveyorLineModel): ISurveyorLineDto {
        return {
            id: model.getId(),
            companyName: model.getCompanyName(),
            groupName: model.getGroupName(),
            surveyorId: model.getSurveyorId(),
            botStatus: model.getStatus(),
            groupImage: `https://i.pravatar.cc/100`,
        }
    }

    public static createListWithLastMessage(
        model: ISurveyorLineModel,
        lastMessage: IMessageModel,
    ): ISurveyorLineWithMessageDto {

        let messageContent

        if (lastMessage.getType() === ContentTypeEnum.TEXT) {
            const content = lastMessage.getContent() as IMessagePayloadSchema
            messageContent = content.text
        } else if (lastMessage.getType() === ContentTypeEnum.STICKER) {
            messageContent = `sent a sticker.`
        } else if (lastMessage.getType() === ContentTypeEnum.IMAGE) {
            messageContent = `sent a photo.`
        } else if (lastMessage.getType() === ContentTypeEnum.LOCATION) {
            messageContent = `sent a location.`
        } else if (lastMessage.getType() === ContentTypeEnum.FLEX) {
            messageContent = `sent a flex.`
        }

        return {
            id: model.getId(),
            companyName: model.getCompanyName(),
            groupName: model.getGroupName(),
            surveyorId: model.getSurveyorId(),
            botStatus: model.getStatus(),
            groupImage: `https://i.pravatar.cc/100`,
            message: {
                from: lastMessage.getSenderName() || 'agent',
                lastMessage: messageContent,
                timeStamp: lastMessage.getTimeStamp().getTime(),
            },
        }
    }

    public static createExportList(model: ISurveyorLineModel): IExportSurveyorLineDto {
        return {
            id: model.getId(),
            groupName: model.getGroupName() || '',
            surveyorCode: model.getSurveyorId() || '',
        }

    }
}
