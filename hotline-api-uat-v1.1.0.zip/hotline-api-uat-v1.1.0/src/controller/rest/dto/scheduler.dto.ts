import { ISchedulerConfigModel } from '../../../domain/scheduler/interface/model.interface'

export interface ISchedulerDto {
    id: string
    name: string
    type: string
    days: number[]
    time: string
    date: number
    activated: boolean

}

export class SchedulerDto {
    public static toSchedulerDto(model: ISchedulerConfigModel): ISchedulerDto {
        return {
            id: model.getId(),
            name: model.getName(),
            type: model.getType(),
            days: model.getDays(),
            time: model.getTime(),
            date: model.getDate().getTime(),
            activated: model.isActivated(),
        } as ISchedulerDto
    }
}
