import { IIncidentTypeModel } from '../../../domain/incident/interface/type.model.interface'

export interface IIncidentTypeDto {
    id: string,
    name: string,
    subType: IIncidentTypeDto[],
}

export class IncidentTypeDto {
    public static toIncidentTypeDto(model: IIncidentTypeModel): IIncidentTypeDto {
        return {
            id: model.getId(),
            name: model.getName(),
            subType: model.getSubType().map((subModel) => {
                return this.toIncidentTypeDto(subModel)
            }),
        } as IIncidentTypeDto
    }
}
