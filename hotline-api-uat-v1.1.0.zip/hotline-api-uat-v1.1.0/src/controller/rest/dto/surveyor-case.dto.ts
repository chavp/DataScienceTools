import { ISurveyorCaseModel } from '../../../domain/surveyor-case/interface/model.interface'
import * as _ from 'lodash'

export interface ISurveyorCaseDto {
    id: string
    incidentNo: string
    surveyorNo: string
    customerName: string
    customerPhone: string
    place: string
    file: string
    surveyorCompanyNo: string
    surveyorNote: string
    surveyorAssignment: ISurveyorAssignmentDto[]
    createdAt: number
    updatedAt: number
}

export interface ISurveyorAssignmentDto {
    name: string
    phone: string
    remark: string
}

export class SurveyorCaseDto {
    public static toSurveyorCaseDto(model: ISurveyorCaseModel): ISurveyorCaseDto {
        const assignments = []
        const surveyorAssignments = model.getSurveyorAssignment()
        surveyorAssignments.forEach((item) => {
            assignments.push({
                name: item.getName(),
                phone: item.getPhone(),
                remark: item.getRemark(),
            })
        })

        let createdAt
        if (!_.isNil(model.getCreatedAt())) {
            createdAt = model.getCreatedAt().getTime()
        } else {
            createdAt = null
        }

        let updatedAt
        if (!_.isNil(model.getUpdatedAt())) {
            updatedAt = model.getUpdatedAt().getTime()
        } else {
            updatedAt = null
        }

        return {
            id: model.getId(),
            incidentNo: model.getIncidentNo(),
            surveyorNo: model.getSurveyorNo(),
            customerName: model.getCustomerName(),
            customerPhone: model.getCustomerPhone(),
            place: model.getPlace(),
            file: model.getFile(),
            surveyorCompanyNo: model.getSurveyorCompanyNo(),
            surveyorNote: model.getSurveyorNote(),
            surveyorAssignment: assignments,
            createdAt,
            updatedAt,
        }
    }
}
