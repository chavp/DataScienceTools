import { ILineProfileModel } from '../../../domain/line/interface'
import * as _ from 'lodash'
import {
    ILineProfileAllMessage,
    IMapResult,
} from '../../../domain/line/interface/result.interface'
import { ContentTypeEnum } from '../../../repository/message/message.schema'

export interface IRegisterLineProfileDto {
    id: string
    displayName: string
    picPath: string
    lastMessage: string
    isRegister: boolean
    unread: number
    timeStamp: number
}

export interface IUnRegisterLineProfileDto {
    id: string
    displayName: string
    picPath: string
}

export interface ILineProfileMessageDto {
    id: string
    displayName: string
    picPath: string
    isRegister: boolean
    message: IMapMessageDto[]
}

export interface IMapMessageDto {
    id: string
    sender: string
    senderName: string
    receiver: string
    type: ContentTypeEnum
    content: any
    timeStamp: number
}

export class LineProfileDto {
    public static toRegisterLineProfileDto(data: IMapResult): IRegisterLineProfileDto {
        const timeStamp = !_.isNil(data.timeStamp) ? data.timeStamp.getTime() : null
        return {
            id: !_.isNil(data.model) ? data.model.getId() : null,
            displayName: !_.isNil(data.model) ? data.model.getDisplayName() : null,
            picPath: !_.isNil(data.model) ? data.model.getPictureUrl() : null,
            isRegister: data.isRegister,
            lastMessage: data.lastMessage,
            unread: data.totalUnread,
            timeStamp,
        }
    }

    public static toUnRegisterLineProfileDto(model: ILineProfileModel): IUnRegisterLineProfileDto {
        return {
            id: model.getId(),
            displayName: model.getDisplayName(),
            picPath: model.getPictureUrl(),
        }
    }

    public static toLineProfileMessageDto(model: ILineProfileAllMessage): ILineProfileMessageDto {
        const allMsg = [] as IMapMessageDto[]
        (model.message).forEach((e) => {
            const msg: IMapMessageDto = {
                id: e.getId(),
                content: e.getContent(),
                sender: !!e.getSender() ? 'user' : 'agent',
                senderName: e.getSenderName(),
                receiver: e.getReceiver(),
                timeStamp: !_.isNil(e.getTimeStamp()) ? e.getTimeStamp().getTime() : null,
                type: e.getType(),
            }
            allMsg.push(msg)
        })

        return {
            id: model.profile.getId(),
            displayName: model.profile.getDisplayName(),
            picPath: model.profile.getPictureUrl(),
            isRegister: model.profile.getIsRegister(),
            message: allMsg,
        }
    }
}
