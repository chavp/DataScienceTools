import { UserRolesEnum } from '../../../repository/profile/profile.schema'
import { IProfileModel } from '../../../domain/profile/interface/model.interface'
import * as _ from 'lodash'
import { IPermissionModel } from '../../../domain/permission/interface/model.interface'
import { PermissionEnum } from '../../../domain/common/interface/permission-enum'

export interface IProfileDto {
    id: string
    name: string
    roles: UserRolesEnum[]
    createdAt: number
    updatedAt: number
    updatedBy: string
}

export interface IProfilePermissionDto {
    id: string
    name: string
    roles: IPermission[]
    createdAt: number
    updatedAt: number
    updatedBy: string
}

export interface IPermission {
    role: string
    permission: PermissionEnum[]
}

export class ProfileDto {
    public static toProfileDto(model: IProfileModel): IProfileDto {
        let createdAt = null
        if (!_.isNil(model.getCreatedAt())) {
            createdAt = model.getCreatedAt().getTime()
        }

        let updatedAt = null
        if (!_.isNil(model.getUpdatedAt())) {
            updatedAt = model.getUpdatedAt().getTime()
        }

        const roles = []
        const profileRoles = model.getRoles()
        profileRoles.forEach((role) => {
            roles.push(role)
        })

        return {
            id: model.getId(),
            name: model.getName(),
            roles,
            createdAt,
            updatedAt,
            updatedBy: model.getUpdatedBy(),
        }
    }

    public static toProfilePermissionDto(data: any): IProfilePermissionDto {
        const model = data.role as IProfileModel
        const permission = data.permission as IPermissionModel[]

        let createdAt = null
        if (!_.isNil(model.getCreatedAt())) {
            createdAt = model.getCreatedAt().getTime()
        }

        let updatedAt = null
        if (!_.isNil(model.getUpdatedAt())) {
            updatedAt = model.getUpdatedAt().getTime()
        }

        const permissions = []
        if (!_.isNil(permission)) {
            permission.forEach((p) => {
                permissions.push({
                    id: p.getId(),
                    permission: p.getPermission(),
                })
            })
        }

        return {
            id: model.getId(),
            name: model.getName(),
            roles: permissions,
            createdAt,
            updatedAt,
            updatedBy: model.getUpdatedBy(),
        }
    }
}
