import * as _ from 'lodash'
import { IReminderModel } from '../../../domain/reminder/interface/model.interface'

export interface IReminderDto {
    id: string
    incidentNo: string
    registration: string
    note: string
    remindTime: number
    agent: string
    status: 'read' | 'unread'
    createdAt: number
}

export class ReminderDto {
    public static toReminderDto(model: IReminderModel): IReminderDto {
        let remindTime = null
        if (!_.isNil(model.getRemindTime())) {
            if (model.getType() === 'appointment') {
                remindTime = model.getRemindTime().getTime() + (60 * 60 * 1000)
            }
            remindTime = model.getRemindTime().getTime()
        }

        let createdAt
        if (!_.isNil(model.getCreatedAt())) {
            createdAt = model.getCreatedAt().getTime()
        } else {
            createdAt = null
        }

        return {
            id: model.getId(),
            incidentNo: model.getIncidentNo(),
            registration: model.getRegistration(),
            note: model.getNote(),
            remindTime,
            agent: model.getAgent(),
            status: model.getStatus(),
            createdAt,
        }
    }
}
