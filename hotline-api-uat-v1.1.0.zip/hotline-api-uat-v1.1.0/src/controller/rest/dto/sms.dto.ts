import { ISmsLogModel } from '../../../domain/common/interface/common.interface'

export interface ISmsDto {
    id: string,
    contactNo: string,
    createdAt: number,
    createdBy: string,
    incidentNo: string,
    message: string,
}

export class SmsDto {
    public static toSmsDto(model: ISmsLogModel): ISmsDto {
        return {
            id: model.getId(),
            contactNo: model.getContactNo(),
            createdAt: model.getCreatedTime().getTime(),
            createdBy: model.getSender(),
            incidentNo: model.getIncidentNo(),
            message: model.getMessage(),
        }
    }
}
