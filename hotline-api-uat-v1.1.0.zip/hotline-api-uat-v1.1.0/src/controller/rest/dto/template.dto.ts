import {ITemplateModel} from '../../../domain/sms/interface/model.interface'
import * as _ from 'lodash'

export interface ITemplateDto {
    id: string
    name: string
    message: string
}

export class TemplateDto {
    public static toTemplateDTO(model: ITemplateModel): ITemplateDto {
        if (_.isNil(model)) {
            return null
        }
        return {
            id: model.getId(),
            name: model.getName(),
            message: model.getMessage(),
        }
    }
}
