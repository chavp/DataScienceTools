import { IManagementQAModel } from '../../../domain/managementQA/interface/model.interface'
import * as _ from 'lodash'

export interface IManagementQADto {
    id: string
    question: string
    maxScore: number
    createdAt: number
    createdBy: string
    updatedAt: number
    updatedBy: string
}

export class ManagementQADto {
    public static toManagementDto(model: IManagementQAModel): IManagementQADto {
        let createdAt = null
        if (!_.isNil(model.getCreatedAt())) {
            createdAt = model.getCreatedAt().getTime()
        }

        let updatedAt = null
        if (!_.isNil(model.getUpdatedAt())) {
            updatedAt = model.getUpdatedAt().getTime()
        }

        return {
            id: model.getId(),
            question: model.getQuestion(),
            maxScore: model.getMaxScore(),
            createdAt,
            createdBy: model.getCreatedBy(),
            updatedAt,
            updatedBy: model.getUpdatedBy(),
        }
    }
}
