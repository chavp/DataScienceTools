import {
    ISurveyorAssignmentModel,
    ISurveyorCaseModel,
} from '../../../../domain/surveyor-case/interface/model.interface'
import {
    SurveyorAssignmentModel,
    SurveyorCaseModel,
} from '../../../../domain/surveyor-case/case.model'
import { SurveyorCaseDto } from '../surveyor-case.dto'
import { plainToClass } from 'class-transformer'

describe('surveyor case dto', () => {

    let model: ISurveyorCaseModel = null

    beforeEach(() => {
        // assignment.setName('Geena')
        // assignment.setPhone('0993619597')
        // assignment.setRemark('my remark')
    })

    it('should return ISurveyorCaseDto (dto schema)', () => {
        const day = new Date(1549999934534)
        const sModel = plainToClass(SurveyorCaseModel, {
            _id: 'CASE001',
            _picture: 'picture path',
            _surveyorNote: 'test note',
            _surveyorCompanyNo: 'test company',
        })
        sModel.setCreatedAt(day)
        sModel.setUpdatedAt(day)

        const testDto = SurveyorCaseDto.toSurveyorCaseDto(sModel)
        expect(testDto).toEqual({
            id: 'CASE001',
            picture: 'picture path',
            surveyorAssignment: [],
            surveyorNote: 'test note',
            surveyorCompanyNo: 'test company',
            createdAt: new Date(1549999934534).getTime(),
            updatedAt: new Date(1549999934534).getTime(),
        })
    })

    it('should return date as null', () => {
        model = plainToClass(SurveyorCaseModel, {
            _id: 'CASE001',
            _picture: 'picture path',
            _surveyorNote: 'test note',
            _surveyorCompanyNo: 'test company',
        })

        const testDto = SurveyorCaseDto.toSurveyorCaseDto(model)
        expect(testDto).toEqual({
            id: 'CASE001',
            picture: 'picture path',
            surveyorAssignment: [],
            surveyorNote: 'test note',
            surveyorCompanyNo: 'test company',
            createdAt: null,
            updatedAt: null,
        })
    })

    it('should return surveyorAssignment', () => {
        const assignment = plainToClass(SurveyorAssignmentModel, {
            _name: 'eee',
            _phone: '222',
            _remark: 'test',
        })

        model = plainToClass(SurveyorCaseModel, {
            _id: 'CASE001',
            _picture: 'picture path',
            _surveyorNote: 'test note',
            _surveyorCompanyNo: 'test company',

        })
        console.log(assignment)
        model.setSurveyorAssignment(assignment)

        const testDto = SurveyorCaseDto.toSurveyorCaseDto(model)
        expect(testDto).toEqual({
            id: '',
            picture: '',
            surveyorAssignment: {
                name: 'Geena',
                phone: '0993619597',
                remark: 'my remark',
            },
            surveyorNote: '',
            surveyorCompanyNo: '',
            createdAt: null,
            updatedAt: null,
        })
    })
})
