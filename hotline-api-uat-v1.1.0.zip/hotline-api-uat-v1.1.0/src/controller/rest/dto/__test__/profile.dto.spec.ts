import {
    IProfileDto,
    ProfileDto,
} from '../profile.dto'
import { plainToClass } from 'class-transformer'
import { ProfileModel } from '../../../../domain/profile/profile.model'

describe('profile dto', () => {
    it('should return profile dto schema', () => {
        const sModel = plainToClass(ProfileModel, {
            _id: 'TEST001',
            _name: 'test name',
            _roles: ['admin', 'reporter'],
            _createdAt: new Date(1549999934534),
            _updatedAt: new Date(1549999935534),
            _updatedBy: 'tester',
        })

        const testDto = ProfileDto.toProfileDto(sModel)
        expect(testDto).toEqual({
            id: 'TEST001',
            name: 'test name',
            roles: ['admin', 'reporter'],
            createdAt: new Date(1549999934534).getTime(),
            updatedAt: new Date(1549999935534).getTime(),
            updatedBy: 'tester',
        })
    })

    it('should return date as null', () => {
        const sModel = plainToClass(ProfileModel, {
            _id: 'TEST001',
            _name: 'test name',
            _roles: ['admin', 'reporter'],
            _updatedBy: 'tester',
        })

        const testDto = ProfileDto.toProfileDto(sModel)
        expect(testDto).toEqual({
            id: 'TEST001',
            name: 'test name',
            roles: ['admin', 'reporter'],
            createdAt: null,
            updatedAt: null,
            updatedBy: 'tester',
        })
    })
})
