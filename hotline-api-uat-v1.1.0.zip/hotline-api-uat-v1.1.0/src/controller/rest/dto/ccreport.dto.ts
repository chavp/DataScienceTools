export interface ICallbackDto {
    requestTime: string
    requestNumber: string
    requestAni: string
    completeTime: string
    waitingTime: string
    completeUser: string
}

export class CallbackDto {
    public static getCallbackDto(model: any): ICallbackDto {
        return {
            requestTime: ((model.RequestDate === null) ? '' : model.RequestDate),
            requestAni: ((model.AniNumber === null) ? '' : model.AniNumber),
            requestNumber: ((model.RequestNumber === null) ? '' : model.RequestNumber),
            completeTime: ((model.CompleteDate === null) ? '' : model.CompleteDate),
            waitingTime: ((model.WaitingTime === null) ? '' : model.WaitingTime),
            completeUser: ((model.EmpName === null) ? '' : model.EmpName),
        } as ICallbackDto
    }
}

export interface ISurveyDto {
    surveyDate: string
    callType: string
    customerNumber: string
    agentExt: string
    agentName: string
    languages: string
    Q1: string
    Q2: string
}

export class SurveyDto {
    public static getSurveyDto(model: any): ISurveyDto {
        return {
            surveyDate: ((model.SurveyDate === null) ? '' : model.SurveyDate),
            callType: ((model.SectionDetail === null) ? '' : model.SectionDetail),
            customerNumber: ((model.CustomerNumber === null) ? '' : model.CustomerNumber),
            agentExt: ((model.AgentExt === null) ? '' : model.AgentExt),
            agentName: ((model.EmpName === null) ? '' : model.EmpName),
            languages: ((model.LanguagesDetail === null) ? '' : model.LanguagesDetail),
            Q1: ((model.Q1Choice === null) ? '' : model.Q1Choice),
            Q2: ((model.Q2Choice === null) ? '' : model.Q2Choice),
        } as ISurveyDto
    }
}

export interface IPSurveyDto {
    icf: string
}

export class PSurveyDto {
    public static getPSurveyDto(model: any): IPSurveyDto {
        return {
            icf: ((model.icf === null) ? '0' : model.icf),
        } as IPSurveyDto
    }
}
