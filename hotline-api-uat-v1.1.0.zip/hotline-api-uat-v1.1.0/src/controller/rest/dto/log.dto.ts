import {
    IIncidentLogModel,
    IIncidentLogRecordModel,
} from '../../../domain/incident/interface'
import * as _ from 'lodash'

export interface IIncidentLogRecordDto {
    id: string,
    note: string,
    createdBy: string,
    createdDate: number,
}

export interface IIncidentLogDto {
    id: string,
    logs: IIncidentLogRecordDto[]
}

export class IncidentLogDto {
    public static toIncidentLogDto(model: IIncidentLogModel): IIncidentLogDto {
        const incidentLogs = []
        const logs = model.getLogs()
        logs.forEach((log) => {
            incidentLogs.push({
                id: log.getId(),
                note: log.getNote(),
                createdBy: log.getCreatedBy(),
                createdDate: log.getCreatedTime(),
            })
        })

        return {
            id: model.getId(),
            logs: incidentLogs,
        } as IIncidentLogDto
    }

    public static toIncidentLogRecordDto(model: IIncidentLogRecordModel): IIncidentLogRecordDto {
        const workflow = _.get(model, model.getWorkFlow(), '')

        return {
            id: model.getId(),
            note: model.getNote(),
            createdBy: model.getCreatedBy(),
            createdDate: model.getCreatedTime().getTime(),
            workFlow: model.getWorkFlow() || '',
        } as IIncidentLogRecordDto
    }
}
