import { PermissionEnum } from '../../../domain/common/interface/permission-enum'
import { IPermissionModel } from '../../../domain/permission/interface/model.interface'

export interface IPermissionDto {
    id: string,
    permission: PermissionEnum[]
}

export class PermissionDto {
    public static toPermissionDto(model: IPermissionModel): IPermissionDto {
        return {
            id: model.getId(),
            permission: model.getPermission(),
        }
    }
}
