import { IAs400Model } from '../../../domain/incident/interface'

export interface IAs400Dto {
    policyNo: string
    branch: string
    insured: string,
    agentCode: string,
    model: string,
    agentName: string,
    periodFrom: string,
    periodTo: string,
    registration: string,
    policyStatus: string,
    coveragePeriod: string[],
    productName: string,
    coverageType: string,
    cover: string,
    contractType: string,
    riskType: string,
    coSi: string,
    tfSi: string,
    longName: string,
    driverName: string,
    chassis: string,
    excess: string,
    od: string[],
    tp: string,
    reference: string,
    genPage1: string,
    genPage2: string,
    endNote: string,
}

export class As400Dto {
    public static toAs400Dto(model: IAs400Model): IAs400Dto {
        return {
            policyNo: model.getPolicyNo(),
            branch: model.getBranch(),
            insured: model.getInsured(),
            agentCode: model.getAgentCode(),
            model: model.getModel(),
            agentName: model.getAgentName(),
            periodFrom: model.getPeriodFrom(),
            periodTo: model.getPeriodTo(),
            registration: model.getRegistration(),
            policyStatus: model.getPolicyStatus(),
            coveragePeriod: model.getCoveragePeriod(),
            productName: model.getProductName(),
            coverageType: model.getCoverageType(),
            cover: model.getCover(),
            contractType: model.getContractType(),
            riskType: model.getRiskType(),
            coSi: model.getCoSi(),
            tfSi: model.getTfSi(),
            longName: model.getLongName(),
            driverName: model.getDriverName(),
            chassis: model.getChassis(),
            excess: model.getExcess(),
            od: model.getOd(),
            tp: model.getTp(),
            reference: model.getReference(),
            genPage1: model.getGenPage1(),
            genPage2: model.getGenPage2(),
            endNote: model.getEndNote(),
        } as IAs400Dto
    }
}
