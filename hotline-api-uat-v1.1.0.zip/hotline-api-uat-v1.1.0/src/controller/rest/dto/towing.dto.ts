import { ITowingModel } from '../../../domain/incident/interface/towing.model.interface'

export interface ITowingDto {
    id: string
    name: string
}

export class TowingDto {
    public static toTowingDto(model: ITowingModel): ITowingDto {
        return {
            id: model.getId(),
            name: model.getName(),
        }as ITowingDto
    }
}
