import {
    IIncidentModel,
    IInputCompany,
    IInputInsured,
    IInputLossInfo,
    IInputStatus,
    IInputSurveyor,
    IInputThirdInsured,
    IInputTowing,
    IInputType,
} from '../../../domain/incident/interface'
import * as _ from 'lodash'
import * as moment from 'moment'
import { IAs400PolicySchema } from '../../../adapter/as400/interface/schema.interface'

export interface IIncidentDto {
    id: string,
    contactNo: string,
    callerName: string,
    incidentType: IInputType,
    status: IInputStatus,
    appointmentDate: number,
    claimNo: string,
    companyInfo: IInputCompany,
    lossInformation: IInputLossInfo,
    driverName: string,
    towCompany: IInputTowing,
    note: string,
    insured: IInputInsured,
    thirdInsured: IInputThirdInsured,
    policy: IAs400PolicySchema,
    surveyor: IInputSurveyor,
    updatedAt: number,
    updatedBy: string,
    createdAt: number,
    createdBy: string,
}

export class IncidentDto {
    public static toIncidentDto(model: IIncidentModel): IIncidentDto {
        let appointmentDate
        if (!_.isNil(model.getAppointmentDate())) {
            appointmentDate = model.getAppointmentDate().getTime()
        } else {
            appointmentDate = null
        }

        let updatedAt
        if (!_.isNil(model.getUpdatedAt())) {
            updatedAt = model.getUpdatedAt().getTime()
        } else {
            updatedAt = null
        }

        let createdAt
        if (!_.isNil(model.getCreatedAt())) {
            createdAt = model.getCreatedAt().getTime()
        } else {
            createdAt = null
        }

        return {
            id: model.getId(),
            contactNo: model.getContactNo(),
            callerName: model.getCallerName(),
            incidentType: model.getIncidentType(),
            status: model.getStatus(),
            appointmentDate,
            claimNo: model.getClaimNo(),
            companyInfo: model.getCompanyInfo(),
            lossInformation: model.getLossInformation(),
            driverName: model.getDriverName(),
            towCompany: model.getTowCompany(),
            note: model.getNote(),
            insured: model.getInsured(),
            thirdInsured: model.getThirdInsured(),
            policy: model.getPolicy(),
            surveyor: model.getSurveyor(),
            updatedAt,
            updatedBy: model.getUpdatedBy(),
            createdAt,
            createdBy: model.getCreatedBy(),
        } as IIncidentDto
    }
}
export interface IIncidentSearchDto {
    id: string,
    contactNo: string,
    callerName: string,
    incidentType: IInputType,
    status: IInputStatus,
    appointmentDate: Date,
    claimNo: string,
    companyInfo: IInputCompany,
    lossInformation: IInputLossInfo,
    driverName: string,
    towCompany: IInputTowing,
    note: string,
    insured: IInputInsured,
    thirdInsured: IInputThirdInsured,
    policy: IAs400PolicySchema,
    surveyor: IInputSurveyor,
    updatedAt: Date,
    updatedBy: string,
    createdAt: Date,
    createdBy: string,
}

export class IncidentSearchDto {
    public static toIncidentSearchDto(model: IIncidentModel): IIncidentSearchDto {
        return {
            id: model.getId(),
            contactNo: model.getContactNo(),
            callerName: model.getCallerName(),
            incidentType: model.getIncidentType(),
            status: model.getStatus(),
            appointmentDate: model.getAppointmentDate(),
            claimNo: model.getClaimNo(),
            companyInfo: model.getCompanyInfo(),
            lossInformation: model.getLossInformation(),
            driverName: model.getDriverName(),
            towCompany: model.getTowCompany(),
            note: model.getNote(),
            insured: model.getInsured(),
            thirdInsured: model.getThirdInsured(),
            policy: model.getPolicy(),
            surveyor: model.getSurveyor(),
            updatedAt: model.getUpdatedAt(),
            updatedBy: model.getUpdatedBy(),
            createdAt: model.getCreatedAt(),
            createdBy: model.getCreatedBy(),
        } as IIncidentSearchDto
    }
}

export interface IIncidentExcelDto {
    id: string,
    contactNo: string,
    callerName: string,
    incidentType: IInputType,
    status: IInputStatus,
    appointmentDate: Date,
    claimNo: string,
    companyInfo: IInputCompany,
    lossInformation: IInputLossInfo,
    driverName: string,
    towCompany: IInputTowing,
    note: string,
    insured: IInputInsured,
    thirdInsured: IInputThirdInsured,
    policy: IAs400PolicySchema,
    surveyor: IInputSurveyor,
    updatedAt: Date,
    updatedBy: string,
    createdAt: Date,
    createdBy: string,
}

export class IncidentExcelDto {
    public static toIncidentExcelDto(model: IIncidentModel): IIncidentExcelDto {
        let closeDate
        if (_.get(model.getStatus(), 'id', '') === 'close') {
            closeDate = moment(model.getCreatedAt()).format('DD/MM/YYYY HH:mm')
        } else {
            closeDate = ''
        }
        const createdAtFormat =  moment(model.getCreatedAt()).format('DD/MM/YYYY HH:mm')
        let contactNoIs
        if (!_.isNil(model.getContactNo())) {
            contactNoIs = model.getContactNo()
        } else {
            contactNoIs = ''
        }
        let claimNoIs
        if (!_.isNil(model.getClaimNo())) {
            claimNoIs = model.getClaimNo()
        } else {
            claimNoIs = ''
        }
        let callerNameIs
        if (!_.isNil(model.getCallerName())) {
            callerNameIs = model.getCallerName()
        } else {
            callerNameIs = ''
        }
        const typeIs = _.get(model.getIncidentType(), 'id', '')

        const registrationIs = _.get(model.getPolicy(), 'registration', '')

        const incidentStatusIs = _.get(model.getStatus(), 'id', '')

        let appointmentDateFormat
        if (!_.isNil(model.getAppointmentDate())) {
            appointmentDateFormat = moment(model.getAppointmentDate()).format('DD/MM/YYYY HH.mm')
        } else {
            appointmentDateFormat = ''
        }
        const agentCodeIs = _.get(model.getPolicy(), 'agent_code', '')

        const openDate = moment(model.getCreatedAt()).format('DD/MM/YYYY HH:mm')
        return {
            id: model.getId(),
            contactNo: model.getContactNo(),
            callerName: model.getCallerName(),
            incidentType: model.getIncidentType(),
            status: model.getStatus(),
            appointmentDate: model.getAppointmentDate(),
            claimNo: model.getClaimNo(),
            companyInfo: model.getCompanyInfo(),
            lossInformation: model.getLossInformation(),
            driverName: model.getDriverName(),
            towCompany: model.getTowCompany(),
            note: model.getNote(),
            insured: model.getInsured(),
            thirdInsured: model.getThirdInsured(),
            policy: model.getPolicy(),
            surveyor: model.getSurveyor(),
            updatedAt: model.getUpdatedAt(),
            appointmentDateFormat,
            closeDate,
            createdAtFormat,
            openDate,
            contactNoIs,
            claimNoIs,
            callerNameIs,
            typeIs,
            registrationIs,
            incidentStatusIs,
            agentCodeIs,
            updatedBy: model.getUpdatedBy(),
            createdAt: model.getCreatedAt(),
            createdBy: model.getCreatedBy(),
        } as IIncidentExcelDto
    }
}
