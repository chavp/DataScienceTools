import { ISurveyorModel } from '../../../domain/surveyor/interface/model.interface'
import { IMessageModel } from '../../../domain/message/interface'
import * as _ from 'lodash'

export interface ISurveyorDto {
    id: string
    name: string
    closedJob: number
    assignedJob: number
    allJobs: number
}

export interface IMessageDto {
    messageId: string
    groupId: string
    timestamp: number
    from: {
        id: string
        name: string
        sender: 'agent' | 'user'
    },
    content: {
        type: string
        text: string
        location: {
            title: string
            address: string
            latitude: string
            longitude: string
        },
        stickerId: string
        image: string
        header: string
    }

}

export class SurveyorDto {
    public static toSurveyorDto(model: ISurveyorModel): ISurveyorDto {
        return {
            id: model.getId(),
            name: model.getName(),
            closedJob: model.getClosedJobs().length,
            assignedJob: model.getAssignedJob().length,
            allJobs: (model.getClosedJobs().length) + (model.getAssignedJob().length),
        }
    }

    public static toSurveyorMessageDto(model: IMessageModel): IMessageDto {
        const content = model.getContent()
        const ts = !_.isNil(model.getTimeStamp()) ? model.getTimeStamp().getTime() : null
        return {
            messageId: model.getId(),
            from: {
                id: model.getSender(),
                name: model.getSenderName(),
                sender: !!model.getSender() ? 'user' : 'agent',
            },
            groupId: model.getGroup(),
            content:
                {
                    type: model.getType(),
                    image: _.get(content, 'name', ''),
                    location: {
                        address: _.get(content, 'address', ''),
                        latitude: _.get(content, 'latitude', null),
                        longitude: _.get(content, 'longitude', null),
                        title: _.get(content, 'title', ''),
                    },
                    stickerId: _.get(content, 'stickerId', ''),
                    text: _.get(content, 'text', ''),
                    header: _.get(content, 'header', ''),
                },
            timestamp: ts,
        }

    }
}
