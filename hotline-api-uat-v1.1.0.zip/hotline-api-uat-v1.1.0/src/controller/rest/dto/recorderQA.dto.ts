import { IRecorderQAModel } from '../../../domain/recorderQA/interface/recorderQA.model.interface'
import * as _ from 'lodash'

export interface IRecorderQADto {
    id: string
    callDate: number
    source: string
    destination: string
    callType: string
    duration: number
    totalScore: number
    QA: IQADto[]
    comment: string
    createdAt: number
    updatedAt: number
}

export interface IQADto {
    id: string
    question: string
    maxScore: number
    score: number
}

export class RecorderQADto {
    public static toRecorderQADto(model: IRecorderQAModel): IRecorderQADto {
        const QA = []
        _.forEach(model.getQA(), (item) => {
            QA.push({
                id: item.getId(),
                question: item.getQuestion(),
                maxScore: item.getMaxScore(),
                score: item.getValue(),
            })
        })

        let totalSum = 0
        if (model.getQA().length > 0) {
            _.forEach(model.getQA(), (e) => {
                const score = e.getValue() || 0
                totalSum = totalSum + score
            })
        } else {
            totalSum = null
        }

        let createdAt = null
        if (!_.isNil(model.getCreatedAt())) {
            createdAt = model.getCreatedAt().getTime()
        }

        let updatedAt = null
        if (!_.isNil(model.getUpdatedAt())) {
            updatedAt = model.getUpdatedAt().getTime()
        }

        return {
            id: model.getId(),
            callDate: model.getCreatedAt().getTime(),
            source: model.getSource(),
            destination: model.getDestination(),
            callType: model.getCallType(),
            duration: model.getDuration(),
            QA,
            comment: model.getComment(),
            createdAt,
            updatedAt,
            totalScore: totalSum,
        } as IRecorderQADto
    }
}
