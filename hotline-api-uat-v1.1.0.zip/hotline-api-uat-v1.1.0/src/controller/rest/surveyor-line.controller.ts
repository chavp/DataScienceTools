import {
    BadRequestException,
    Body,
    Controller,
    Get,
    Inject,
    Param,
    Post,
    Put,
    Query,
    Res,
    UploadedFile,
    UseGuards,
    UseInterceptors,
} from '@nestjs/common'
import * as _ from 'lodash'
import { ProviderName } from '../../provider'
import { ProfileSessionGuard } from '../../common/guard/profile.guard'
import { IUpdateSurveyorLineValidator } from '../../domain/surveyor-line/interface/validator.interface'
import {
    map,
    mergeMap,
    reduce,
    tap,
    toArray,
} from 'rxjs/operators'
import {
    ISurveyorLineDto,
    ISurveyorLineWithMessageDto,
    SurveyorLineDto,
} from './dto/surveyor-line.dto'
import { FileInterceptor } from '@nestjs/platform-express'
import { UploadSurveyorLineValidator } from './validator/surveyor-line.validator'
import { validate } from 'class-validator'
import { plainToClass } from 'class-transformer'
import {
    from,
    iif,
    Observable,
    of,
} from 'rxjs'
import { IMessageService } from '../../domain/message/interface/service.interface'
import { ISurveyorLineService } from '../../domain/surveyor-line/interface/service.interface'
import { ISurveyorLineModel } from '../../domain/surveyor-line/interface/model.interface'
import { ILoggerService } from '../../common/interface/logger.interface'
import { ClassStringify } from '../../utils/class-stringify'

const {
    SURVEYOR_LINE_SERVICE,
    MESSAGE_SERVICE,
    LOGGER_SERVICE,
} = ProviderName

@Controller('/surveyor-line')
export class SurveyorLineController {
    constructor(
        @Inject(SURVEYOR_LINE_SERVICE)
        private readonly _surveyorLneService: ISurveyorLineService,
        @Inject(MESSAGE_SERVICE)
        private readonly _messageService: IMessageService,
        @Inject(LOGGER_SERVICE)
        private readonly _loggerService: ILoggerService,
    ) {
        this._loggerService.setContext('Surveyor Line Service')
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/')
    public getSurveyorLine(
        @Query('lastMessage') queryLastMessage: string,
    ) {

        // prepare message query
        const lastMessageQuery$ = (surveyorLineModel: ISurveyorLineModel): Observable<ISurveyorLineWithMessageDto> => {
            return this._messageService.getLatestMessageFromGroupId(surveyorLineModel.getId()).pipe(
                map(lastMessage => {
                    return ({ model: surveyorLineModel, lastMessage })
                }),
                map(({ model, lastMessage }) => SurveyorLineDto.createListWithLastMessage(model, lastMessage)),
            )
        }

        const plainQuery$ = (surveyorLineModel: ISurveyorLineModel): Observable<ISurveyorLineDto> => {
            return of(surveyorLineModel).pipe(
                map((model) => SurveyorLineDto.createSurveyorListDTO(model)),
            )

        }

        return this._surveyorLneService.getRegisteredGroup().pipe(
            mergeMap(model => {
                return iif(() => queryLastMessage === 'true',
                    lastMessageQuery$(model),
                    plainQuery$(model),
                )
            }),

            reduce(((acc, value) => {
                acc.push(value)
                return acc
            }), []),
            map(data => {
                return {
                    total: data.length,
                    data,
                }
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/export')
    public exportList(
        @Res() res,
    ) {
        return this._surveyorLneService.getAll().pipe(
            map(model => SurveyorLineDto.createExportList(model)),
            toArray(),
            tap(data => {
                res.header('Content-Type', 'text/plain')
                res.header('Content-Disposition', `attachment; filename="surveyor-line-map-${Date.now()}.json"`)
                res.end(JSON.stringify(data))
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Post('/import')
    @UseInterceptors(FileInterceptor('file'))
    public importList(
        @UploadedFile('file') file: Express.Multer.File,
    ) {
        const str: string = file.buffer.toString('utf8')
        const arrData: string[] = JSON.parse(str)
        const input = plainToClass(UploadSurveyorLineValidator, arrData)
        return from(validate(input)).pipe(
            tap(errors => {
                if (!_.isEmpty(errors)) {
                    throw new BadRequestException(`Upload file error`, JSON.stringify(errors))
                }
            }),
            mergeMap(() => {
                return this._surveyorLneService.surveyorFileMap(input).pipe(
                    map(model => SurveyorLineDto.createSurveyorListDTO(model)),
                )
            }),
            toArray(),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Put('/:id')
    public UpdateSurveyorLine(
        @Body() body: IUpdateSurveyorLineValidator,
        @Param('id') id: string,
    ) {
        return this._surveyorLneService.update(id, body).pipe(
            tap(() => {
                this._loggerService.warn(`surveyor line update ${id}`)
                this._loggerService.warn(` - surveyor line update\n${ClassStringify.fromClass(body)}`)
            }),
        )
    }
}
