import {
    Body,
    Controller,
    Get,
    Headers,
    Inject,
    Param,
    Put,
    Req,
    UseGuards,
} from '@nestjs/common'
import { ProviderName } from '../../provider'
import { IPermissionService } from '../../domain/permission/interface/service.interface'
import { ProfileSessionGuard } from '../../common/guard/profile.guard'
import {
    map,
    reduce,
    tap,
} from 'rxjs/operators'
import { PermissionDto } from './dto/permission.dto'
import { PermissionValidate } from './validator/permission.validator'
import { ILoggerService } from '../../common/interface/logger.interface'
import * as jwt from 'jsonwebtoken'

const {
    PERMISSION_SERVICE,
    LOGGER_SERVICE,
} = ProviderName

@Controller('/permission')
export class PermissionController {
    constructor(
        @Inject(PERMISSION_SERVICE)
        private readonly _permissionService: IPermissionService,
        @Inject(LOGGER_SERVICE)
        private readonly _loggerService: ILoggerService,
    ) {
        this._loggerService.setContext('Permission Service')
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/')
    public getPermission(
        @Req() req,
        @Headers('x-profile') profileToken: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        const dtoTemplate = {
            total: 0,
            data: [],
        }
        return this._permissionService.getAll().pipe(
            reduce((acc, model) => {
                acc.total++
                acc.data.push(PermissionDto.toPermissionDto(model))
                return acc
            }, dtoTemplate),
            tap(() => {
                this._loggerService.info(`get all profile permission by ${user} [${req.ip}]`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Get('/:id')
    public getPermissionDto(
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Param('id') id: string,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        return this._permissionService.getById(id).pipe(
            map((result) => {
                return PermissionDto.toPermissionDto(result)
            }),
            tap(() => {
                this._loggerService.info(`get profile permission id: ${id} by ${user} [${req.ip}]`)
            }),
        )
    }

    @UseGuards(ProfileSessionGuard)
    @Put('/:id')
    public updatePermission(
        @Req() req,
        @Headers('x-profile') profileToken: string,
        @Param('id') id: string,
        @Body() body: PermissionValidate,
    ) {
        const profile: any = jwt.decode(profileToken)
        const user = `${profile.given_name} ${profile.family_name}`

        return this._permissionService.update(id, body).pipe(
            tap(() => {
                this._loggerService.info(`profile permission id: ${id} was updated by ${user} [${req.ip}]`)
            }),
        )
    }
}
