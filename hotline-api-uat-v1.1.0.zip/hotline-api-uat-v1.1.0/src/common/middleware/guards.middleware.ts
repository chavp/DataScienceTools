import {
    BadRequestException,
    Injectable,
    NestMiddleware,
} from '@nestjs/common'
import * as _ from 'lodash'

@Injectable()
export class MiddlewareGuard implements NestMiddleware {
    public use(req: any, res: any, next: () => void) {
        // const reg = /(\.\.\/)|(\.\.\\)|(%00)|(%0a)|(\\r)|(\\n)|[<>&+]/g
        // _.forEach(req.headers, (value) => {
        //     const result = reg.exec(value)
        //     if (result) {
        //         throw new BadRequestException('Invalid request')
        //     }
        // })
        next()
    }
}
