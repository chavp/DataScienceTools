import { NestMiddleware } from '@nestjs/common'

export class SessionActivityMiddleware implements NestMiddleware {
    public use(req: any, res: any, next: () => void): any {
        if (req.session) {
            req.session.lastActivity = Date.now()
        }
        next()
    }

}
