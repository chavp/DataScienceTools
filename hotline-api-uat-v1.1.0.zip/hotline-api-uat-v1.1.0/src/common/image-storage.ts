import {
    IImageStorage,
    IImageStorageSchema,
} from './interface/image-storage.interface'
import {
    iif,
    Observable,
    of,
    throwError,
} from 'rxjs'
import * as FileSystem from 'fs'
import * as Path from 'path'
import { RuntimeException } from '@nestjs/core/errors/exceptions/runtime.exception'
import * as _ from 'lodash'
import {
    buffer,
    catchError,
    filter,
    map,
    mergeMap,
    tap,
} from 'rxjs/operators'
import * as Crypto from 'crypto'
import { NotFoundException } from '@nestjs/common'

export class ImageStorage implements IImageStorage {

    private readonly _storageDirectory: string

    constructor(
        private readonly _filePrefix: string,
        fileDirPath: string,
    ) {
        this._storageDirectory = Path.resolve(fileDirPath)
        FileSystem.mkdir(this._storageDirectory, { recursive: true }, (err) => {
            if (err) {
                throw new RuntimeException(`Cannot create file path directory for Image Storage: ${this._storageDirectory}`)
            }
        })
    }

    public getImage(imageName: string): Observable<IImageStorageSchema> {
        return of(this._getFileName(imageName)).pipe(
            mergeMap((fileName: string) => {
                return this._checkFileExisted(fileName).pipe(
                    mergeMap(isExisted => {
                        return iif(() => !isExisted,
                            throwError(new NotFoundException(`Cannot found image ${imageName}`)),
                            of(fileName),
                        )
                    }),
                )
            }),
            map((fileName: string) => {
                const subDirectory = ImageStorage.getSubDirectory(fileName)
                const filePath = `${this._storageDirectory}/${subDirectory}/${fileName}`
                return {
                    filePath,
                }
            }),
        )
    }

    public getImageContent(imageName: string): Observable<Buffer> {
        return this.getImage(imageName).pipe(
            mergeMap((imageSchema): Observable<Buffer> => {
                return new Observable<Buffer>(subscriber => {
                    const filePath = imageSchema.filePath
                    FileSystem.readFile(filePath, (err, data) => {
                        if (err) {
                            subscriber.error(err)
                            subscriber.complete()
                            return
                        }
                        subscriber.next(data)
                        subscriber.complete()
                        return
                    })
                })

            }),
        )
    }

    public saveImage(imageName: string, imageBuffer: Buffer): Observable<IImageStorageSchema> {
        return of(this._getFileName(imageName)).pipe(
            mergeMap((fileName: string) => {
                return this._checkFileExisted(fileName).pipe(
                    tap(isExisted => {
                        if (isExisted) {
                            throw new RuntimeException(`File existed: ${fileName}`)
                        }
                    }),
                    map(() => {
                        return fileName
                    }),
                )
            }),
            mergeMap((fileName: string): Observable<string> => {
                return new Observable(subscriber => {
                    const subDirectory = ImageStorage.getSubDirectory(fileName)
                    const fileFullPath = `${this._storageDirectory}/${subDirectory}/${fileName}`
                    const dirPath = `${this._storageDirectory}/${subDirectory}`

                    FileSystem.mkdir(dirPath, { recursive: true }, (mkdirError) => {
                        if (mkdirError) {
                            subscriber.error(mkdirError)
                            subscriber.complete()
                            return
                        }
                        FileSystem.writeFile(fileFullPath, imageBuffer, (err) => {
                            if (_.isNil(err)) {
                                subscriber.next(fileFullPath)
                                subscriber.complete()
                                return
                            }

                            subscriber.error(err)
                            subscriber.complete()
                            return
                        })
                    })

                })

            }),
            // mergeMap(partialFileName => {
            //     const fileRegExp = new RegExp(`^(surveyorCase_)(${partialFileName})$`)
            //     return this._readDir(partialFileName).pipe(
            //         filter((existingFileName: string) => {
            //             return fileRegExp.test(existingFileName)
            //         }),
            //         map(file => {
            //             console.log(file)
            //         }),
            //     )
            // }),
            map((filePath) => {
                return {
                    filePath,
                }
            }),
        )

    }

    private _readDir(fileName: string): Observable<string> {

        return new Observable<string>(subscriber => {

            const subDir = ImageStorage.getSubDirectory(fileName)
            FileSystem.readdir(
                `${this._storageDirectory}/${subDir}`,
                (err, files) => {
                    if (!_.isNil(err)) {
                        subscriber.complete()
                        return
                    }

                    files.forEach(file => {
                        subscriber.next(file)
                    })
                    subscriber.complete()
                    return

                },
            )
        })
    }

    private _getFileName(imageId: string): string {
        return `${this._filePrefix}${imageId}`
    }

    private static getFileHash(fileName: string): string {
        const hash = Crypto.createHash('sha256')
        hash.update(fileName)
        return hash.digest('hex')

    }

    private static getSubDirectory(fileName: string) {
        const hash: string = ImageStorage.getFileHash(fileName)
        return hash.substring(0, 2)
    }

    private _checkFileExisted(fileName: string): Observable<boolean> {
        return new Observable<boolean>(subscriber => {

            const subDirectory = ImageStorage.getSubDirectory(fileName)
            const fileFullPath = `${this._storageDirectory}/${subDirectory}/${fileName}`

            FileSystem.access(fileFullPath, FileSystem.constants.F_OK, err => {
                subscriber.next(_.isNil(err))
                subscriber.complete()
                return

            })

        })
    }

}
