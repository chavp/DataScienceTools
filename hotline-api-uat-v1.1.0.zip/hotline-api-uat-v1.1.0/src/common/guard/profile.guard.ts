import {
    CanActivate,
    ExecutionContext,
    Inject,
    Injectable,
} from '@nestjs/common'
import {
    forkJoin,
    Observable,
    of,
} from 'rxjs'
import * as jwt from 'jsonwebtoken'
import * as Moment from 'moment'
import * as FileSystem from 'fs'
import * as _ from 'lodash'
import { ProfileMongoRepository } from '../../repository/profile/profile.repository'
import { ProviderName } from '../../provider'
import {
    map,
    mergeMap,
} from 'rxjs/operators'

@Injectable()
export class ProfileSessionGuard implements CanActivate {
    private readonly _memoryStorage: Map<string, any>

    constructor(
        @Inject(ProviderName.PROFILE_REPOSITORY)
        private readonly _profileRepo: ProfileMongoRepository,
    ) {
        this._memoryStorage = new Map()
    }

    public getSessionFromProfileId(id: string): Observable<string> {
        const profile = this._memoryStorage.get(id)
        const now = Date.now()
        if (!profile || (profile.iat < now - 5000)) {
            return this._profileRepo.find({ _id: id }).pipe(
                map((model) => {
                    if (_.isNil(model)) {
                        return ''
                    }

                    this._memoryStorage.set(id, {
                        iat: Date.now(),
                        sessionId: model.getSessionId(),
                    })
                    return model.getSessionId()
                }),
            )
        }
        return of(profile.sessionId)
    }

    public canActivate(context: ExecutionContext): Observable<boolean> {
        const request = context.switchToHttp().getRequest()
        const headers = request.headers
        const profileJwt = headers['x-profile']
        const profile: any = jwt.decode(profileJwt)
        return forkJoin([
            of(!!profile),
            of(_.get(profile, 'user_id', '')).pipe(
                mergeMap((id) => {
                    return this.getSessionFromProfileId(id)
                }),
                map(result => {
                    return result === request.session.id
                }),
            ),
        ]).pipe(
            map(results => {
                return results[0] && results[1]
            }),
        )
    }
}

export class ProfileGuard implements CanActivate {
    public canActivate(context: ExecutionContext): boolean {
        const request = context.switchToHttp().getRequest()
        const headers = request.headers
        const profileJwt = headers['x-profile']
        const profile = jwt.decode(profileJwt)
        return !!profile
    }

}

export class AdminGuard implements CanActivate {

    public canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
        const request = context.switchToHttp().getRequest()
        const headers = request.headers
        const profileJwt = headers.authorization
        const auth: any = jwt.decode(profileJwt)
        const admin = (auth) && (auth.roles).find(role => role === 'admin')
        return !!admin
    }
}

export class CertGuard implements CanActivate {
    private _token: Moment.Moment
    private _exp: Moment.Moment

    constructor() {
        this._exp = Moment()
        const str = FileSystem.readFileSync('./vendor/cert/certificate', 'utf8')
        this._token = Moment.unix(_.toNumber((new Buffer(str, 'base64'))))
    }

    public canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
        if (this._exp.isBefore(Moment())) {
            this._exp = Moment().add('1', 'm')
            const str = FileSystem.readFileSync('./vendor/cert/certificate', 'utf8')
            this._token = Moment.unix(_.toNumber((new Buffer(str, 'base64'))))
        }
        return this._token.isAfter(Moment())
    }
}
