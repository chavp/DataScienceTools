import { CanActivate, ExecutionContext, Injectable, Inject } from '@nestjs/common'
import { Observable } from 'rxjs'
import { ProviderName } from '../../provider'
import { IConfig } from '../interface/config.interface'

@Injectable()
export class LineHookGuard implements CanActivate {
    constructor(
        @Inject(ProviderName.CONFIG)
        private readonly _config: IConfig,
    ) {
    }

    public canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
        const request = context.switchToHttp().getRequest()
        const prefix = request.params.prefix
        return prefix === this._config.lineApi.hookPrefix
    }
}
