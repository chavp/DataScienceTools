import {
    CanActivate,
    ExecutionContext,
    Inject,
    Injectable,
} from '@nestjs/common'
import { Observable } from 'rxjs'
import { IAuthService } from '../interface/auth.interface'
import { ProviderName } from '../../provider'
import * as _ from 'lodash'

@Injectable()
export class SurveyorGuard implements CanActivate {
    constructor(
        @Inject(ProviderName.AUTH_SERVICE)
        private readonly _authService: IAuthService,
    ) {
    }

    public canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
        const request = context.switchToHttp().getRequest()
        const headers = request.headers
        const data = headers['x-line-id']

        try {
            const jwt = this._authService.verifyTokenIgnoreExpiration(data.toString())
            return !!jwt
        } catch (e) {
            return false
        }
    }
}
