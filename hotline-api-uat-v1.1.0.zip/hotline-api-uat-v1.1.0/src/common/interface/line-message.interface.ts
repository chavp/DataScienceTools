import { MessageEvent } from '@line/bot-sdk'

export type LineMessageEvent = MessageEvent
export enum LineMessageType {
    TEXT = 'text',
}

export interface ILineTextMessage {
    id: string,
    type: LineMessageType,
    text: string
}

export interface IMessageSource {
    type: string
    userId: string
}

export type LineMessageEventType = ILineTextMessage

export interface ILineMessageSchema {
    type: LineMessageEvent
    replyToken: string
    timestamp: number
    source: IMessageSource
    message?: LineMessageEventType
}

export interface ILineEventHookSchema {
    events: ILineMessageSchema[]
}
