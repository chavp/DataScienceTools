export interface IConfig {
    application: {
        host: string,
        port: number
    }
    mongodb: IMongoDB
    auth: IAuth
    adapter: {
        as400: IAs400Adapter
        sms: ISmsAdapter
        ad: IAdAdapterConfig
    }
    MssqlDB: IMssqlDB
    MySqlDB: IMySqlDB
    OdbcDB: IOdbcDB
    surveyorUrl: {
        surveyorWeb: string
    }
    CiscoSkill: ICiscoSkill,
    recorderAudio: {
        path: string
    }
    lineApi: {
        hookPrefix: string
        channelId: string
        channelSecret: string
        accessToken: string
    },
    static: {
        lineProfile: string,
        lineMessageImages: string,
        lineMessageVideo: string,
        lineMessageAudio: string,
        uploads: string
    }
    imageStorage: {
        surveyorCase: IImageStorageConfig
    }
}

export interface IImageStorageConfig {
    path: string
    prefix: string
}

export interface IMongoDB {
    servers: string
    port: number
    dbName: string
    username?: string
    password?: string
    authSource?: string
    replicaSetName?: string
}

export interface IAuth {
    ignoreExpiration: boolean
    public: string
    private: string
}

export interface IAs400Adapter {
    auth: IAs400AdapterAuth
    endpoint: IAs400AdapterEndpoint
}

export interface ISmsAdapter {
    auth: ISmsAdapterAuth
    endpoint: ISmsAdapterEndpoint
}

export interface IAs400AdapterAuth {
    host: string
    path: string
    clientId: string
    clientSecret: string
    scope: string[]
}

export interface ISmsAdapterAuth {
    host: string
    path: string
    clientId: string
    clientSecret: string
    scope: string[]
}

export interface ISmsAdapterEndpoint {
    host: string
    path: string
}

export interface IAs400AdapterEndpoint {
    host: string
    path: string
}

export interface IMssqlDB {
    servers: string
    port: number
    dbName: string
    username: string
    password: string
}

export interface IOdbcDB {
    connectionString: string
}

export interface IAdAdapterConfig {
    issuer: string
    clientId: string
    clientSecret: string
    redirectUri: string
    responseType: string
    scope: string
    app: string
}

export interface IMySqlDB {
    host: string
    port: number
    user: string
    password: string
    database: string
}

export interface ICiscoSkill {
    th: { name: string, keyword: string },
    en: { name: string, keyword: string },
    team: string
}
