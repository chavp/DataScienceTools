export interface IRunnable {
    run(): void
}
