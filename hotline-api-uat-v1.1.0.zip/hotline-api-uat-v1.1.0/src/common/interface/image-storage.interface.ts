import { Observable } from 'rxjs'

export interface IImageStorageSchema {
    filePath: string
}

export interface IImageStorage {
    getImage(imageName: string): Observable<IImageStorageSchema>

    getImageContent(imageName: string): Observable<Buffer>

    saveImage(imageName: string, imageBuffer: Buffer): Observable<IImageStorageSchema>

}
