export enum FlexMessageType {
    SURVEYER_ACCEPTED_JOB = 'surveyor-accepted-job',
    AGENT_ASSIGNED_SURVEYER = 'agent-assigned-surveyor',
    LOCATION = 'location',
    IMAGE = 'image',
    VIDEO = 'video',
}

export enum MessageType {
    TEXT = 'text',
    FLEX_MESSAGE = 'flexMessage',
    LOCATION = 'location',
    IMAGE = 'image',
    VIDEO = 'video',
}

export enum SenderType {
    USER = 'user',
    AGENT = 'agent',
}

export enum RoomType {
    USER = 'user',
    GROUP = 'group',
    ROOM = 'room',
}
