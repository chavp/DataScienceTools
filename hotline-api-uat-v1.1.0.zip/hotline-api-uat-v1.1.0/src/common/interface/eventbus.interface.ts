export enum Events {
    DOMAIN_EVENT = 'domain-event',
}
