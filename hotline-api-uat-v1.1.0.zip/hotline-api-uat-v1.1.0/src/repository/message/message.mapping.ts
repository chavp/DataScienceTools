import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IMessageModel } from '../../domain/message/interface'
import { IMessageSchema } from './message.schema'
import * as _ from 'lodash'
import {ObjectId} from 'bson'
import { MessageModel } from '../../domain/message/message.model'
export class MessageRepositoryMapping implements IRepositoryMapping<IMessageModel, IMessageSchema> {
    public deserialize(schema: IMessageSchema): IMessageModel {
        if (_.isNil(schema)) {
            return null
        }
        const model = new MessageModel()
        Object.assign(model, {
            _id: schema._id,
            _sender: schema.sender,
            _receiver: schema.receiver,
            _group: schema.group,
            _content: schema.content,
            _timeStamp: schema.timeStamp,
            _type: schema.type,
            _read: schema.read,
            _incidentNo: schema.incidentNo,
            _senderName: schema.senderName,
        })
        return model
    }

    public serialize(model: IMessageModel): IMessageSchema {
        return {
            _id: _.isEmpty(model.getId()) ? new ObjectId() : new ObjectId(model.getId()),
            sender: model.getSender(),
            receiver: model.getReceiver(),
            group: model.getGroup(),
            content: model.getContent(),
            timeStamp: model.getTimeStamp(),
            read: model.getRead(),
            type: model.getType(),
            incidentNo: model.getIncidentNo(),
            senderName: model.getSenderName(),
        }
    }

}
