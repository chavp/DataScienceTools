import {ObjectId} from 'bson'
export interface IMessageSchema {
    _id: ObjectId
    sender: string
    receiver: string
    group: string
    type: ContentTypeEnum
    content: any
    timeStamp: Date
    read: boolean
    incidentNo: string,
    senderName: string,
}

export enum ContentTypeEnum {
    TEXT = 'text',
    IMAGE = 'image',
    STICKER = 'sticker',
    LOCATION = 'location',
    FLEX = 'flex',
}
