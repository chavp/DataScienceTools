import { MongoRepository } from '../../common/mongo-repository'
import {
    IMessageModel,
    IMessageRepository,
} from '../../domain/message/interface'
import {
    from,
    Observable,
} from 'rxjs'
import {
    Db,
    IndexSpecification,
} from 'mongodb'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IMessageSchema } from './message.schema'
import {
    map,
    throwIfEmpty,
} from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'

export class MessageRepository extends MongoRepository<IMessageModel> implements IMessageRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<IMessageModel, IMessageSchema>,
    ) {
        super(db.collection('message'), mapping)

        this._collection.listIndexes()

        const indexSpecs: IndexSpecification[] = [
            {
                key: { timeStamp: -1 },
            },
            {
                key: { group: 'hashed' },
            },
            {
                key: { sender: 'hashed'},
            },
            {
                key: { receiver: 'hashed'},
            },
        ]

        this._collection.createIndexes(indexSpecs)
            .then( result => {
                console.log(`Message repository indexes created`)
            })
    }

    public save(model: IMessageModel): Observable<{ id: string }> {
        const doc = this.toDocument(model)
        const promise = this._collection.insertOne(doc)
        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot save message`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return {
                    id: result.insertedId.toString(),
                }
            }),
        )
    }

    public update(model: IMessageModel): Observable<boolean> {
        const id = model.getId()
        const doc = this.toDocument(model)
        const promise = this._collection.updateOne({
                _id: id,
            },
            {
                $set: doc,
            })
        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot update profile`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return result.modifiedCount === 1
            }),
        )
    }

    public listLatestFromGroupId(id: string, limit: number = 20): Observable<IMessageModel> {
        const cursor = this._collection.find(
            {
                group: id,
            },
        ).sort({ timeStamp: -1 }).limit(limit)

        return this.toObservable(cursor)
    }

    public listDirectLatestBySenderOrReceiver(id: string, limit?: number): Observable<IMessageModel> {
        const cursor = this._collection.find(
            {
                $and: [
                    { group: null },
                    {
                        $or: [
                            { sender: id },
                            { receiver: id },
                        ],
                    },
                ],
            },
        ).sort({ timeStamp: -1 }).limit(limit)

        return this.toObservable(cursor)
    }

    public listDirectLatestByIncidentNo(id: string, limit?: number): Observable<IMessageModel> {
        const cursor = this._collection.find(
            {
                $and: [
                    { incidentNo: id },
                    { group: null },
                ],
            },
        ).sort({ timeStamp: -1 }).limit(limit)

        return this.toObservable(cursor)
    }

    public find(filter?: any): Observable<IMessageModel> {
        const cursor = this._collection.find(filter).sort({ timeStamp: -1 })
        return this.toObservable(cursor).pipe(
            throwIfEmpty(() => {
                throw new HttpException(`Message not found`, HttpStatus.NOT_FOUND)
            }),
        )
    }

    public listGroupMessage(groupId: string): Observable<IMessageModel> {
        const cursor = this._collection.find({
            group: groupId,
        }).sort({ timeStamp: -1 })
        return this.toObservable(cursor)
    }

    public getTotalUnreadMessageById(id: string): Observable<number> {
        return undefined
    }

    public getTotalUnreadMessageBySenderOrReceiver(sender: string): Observable<number> {
        return undefined
    }

}
