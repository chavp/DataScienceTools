import { IRepositoryMapping } from '../../common/interface/repository.interface'
import {
    IRecorderQAModel,
} from '../../domain/recorderQA/interface/recorderQA.model.interface'
import {
    RecorderQAModel,
} from '../../domain/recorderQA/recorderQA.model'
import * as _ from 'lodash'
import { IRecorderQASchema } from './recorderQA.schema'
import { ManagementQARepositoryMapping } from '../managementQA/mapping'
import { IManagementQASchema } from '../managementQA/schema'
import { IManagementQAModel } from '../../domain/managementQA/interface/model.interface'
import { ManagementQAModel } from '../../domain/managementQA/managementQA.model'

export class RecorderQAMapping implements IRepositoryMapping<IRecorderQAModel, IRecorderQASchema> {
    private readonly _qaMapping: ManagementQARepositoryMapping

    constructor() {
        this._qaMapping = new QAMapping()
    }

    public deserialize(schema: IRecorderQASchema): IRecorderQAModel {
        const model = new RecorderQAModel()
        _.assign(model, {
            _id: schema._id,
            _comment: schema.comment,
            _QA: _.map(
                schema.QA,
                (item: IManagementQASchema) => this._qaMapping.deserialize(item),
            ),
            _createdAt: schema.createdAt,
            _updatedAt: schema.updatedAt,
            _direction: schema.direction,
            _duration: schema.duration,
            _expiryTimestamp: schema.expiryTimestamp,
            _fileName: schema.fileName,
            _localEntryPoint: schema.localEntryPoint,
            _localParty: schema.localParty,
            _portName: schema.portName,
            _remoteParty: schema.remoteParty,
            _portId: schema.portId,
            _serviceId: schema.serviceId,
            _source: schema.source,
            _destination: schema.destination,
            _callType: schema.callType,
        })
        return model
    }

    public serialize(model: IRecorderQAModel): IRecorderQASchema {
        return {
            _id: model.getId(),
            comment: model.getComment(),
            QA: _.map(
                model.getQA(),
                (item: IManagementQAModel) => this._qaMapping.serialize(item),
            ),
            createdAt: model.getCreatedAt(),
            updatedAt: model.getUpdatedAt(),
            direction: model.getDirection(),
            duration: model.getDuration(),
            expiryTimestamp: model.getExpiryTimestamp(),
            fileName: model.getFileName(),
            localEntryPoint: model.getLocalEntryPoint(),
            localParty: model.getLocalParty(),
            portName: model.getPortName(),
            remoteParty: model.getRemoteParty(),
            portId: model.getPortId(),
            serviceId: model.getServiceId(),
            source: model.getSource(),
            destination: model.getDestination(),
            callType: model.getCallType(),
        }
    }
}

export class QAMapping implements IRepositoryMapping<IManagementQAModel, IManagementQASchema> {
    public deserialize(schema: any): IManagementQAModel {
        if (_.isNil(schema)) {
            return null
        }
        const model = new ManagementQAModel()
        Object.assign(model, {
            _id: schema.id,
            _question: schema.question,
            _maxScore: schema.maxScore,
            _score: schema.score,
        })
        return model
    }

    public serialize(model: IManagementQAModel): any {
        return {
            id: model.getId(),
            question: model.getQuestion(),
            maxScore: model.getMaxScore(),
            score: model.getValue(),
        }
    }
}
