import { MongoRepository } from '../../common/mongo-repository'
import { IRecorderQAModel } from '../../domain/recorderQA/interface/recorderQA.model.interface'
import { IRecorderQASchema } from './recorderQA.schema'
import { Db } from 'mongodb'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IRecorderQARepository } from '../../domain/recorderQA/interface/recorderQA.repository.interface'
import {
    from,
    Observable,
} from 'rxjs'
import {
    map,
    tap,
    throwIfEmpty,
} from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import * as _ from 'lodash'

export class RecorderQARepository extends MongoRepository<IRecorderQAModel> implements IRecorderQARepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<IRecorderQAModel, IRecorderQASchema>,
    ) {
        super(db.collection('recorderQA'), mapping)
    }

    public find(filter?: any): Observable<IRecorderQAModel> {
        const cursor = this._collection.find(filter).sort({createdAt: -1})
        return this.toObservable(cursor)
    }

    public save(model: IRecorderQAModel): Observable<{ id: string }> {
        const data = this.toDocument(model)
        const promise = this._collection.insertOne(data)
        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot save recorderQA`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return {
                    id: result.insertedId.toString(),
                }
            }),
        )
    }

    public update(model: IRecorderQAModel): Observable<boolean> {
        const id = model.getId()
        const data = this.toDocument(model)
        const promise = this._collection.updateOne({
                _id: id,
            },
            {
                $set: data,
            })
        return from(promise).pipe(
            map((result) => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot update recorderQA`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return result.modifiedCount === 1
            }),
        )
    }
}
