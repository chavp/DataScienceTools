import { IManagementQASchema } from '../managementQA/schema'

export interface IRecorderQASchema {
    _id: string
    comment: string
    QA: IManagementQASchema[]
    source: string
    destination: string
    callType: string
    createdAt: Date
    updatedAt: Date
    direction: string
    duration: number
    expiryTimestamp: Date
    fileName: string
    localEntryPoint: string
    localParty: string
    portName: string
    remoteParty: string
    portId: string
    serviceId: string
}
