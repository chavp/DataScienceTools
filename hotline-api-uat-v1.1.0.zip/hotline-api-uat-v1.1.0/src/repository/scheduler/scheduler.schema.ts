import { ObjectId } from 'mongodb'
import { SchedulerTypeEnum } from '../../domain/scheduler/interface/scheduler-type.enum'
import { TypeFlexEnum } from '../../domain/surveyor-case/pubsub/interface/case-not-arrive-interface'

export interface ISchedulerTaskSchema {
    _id: ObjectId
    type: TypeFlexEnum
    days: number[]
    triggerDate: number
    createdDate: number
    updatedDate: number
    taskName: string
    triggerTime: string
    activatedStatus: 'activated' | 'inactivated'
    timeSchedule: number,
    lineId: string,
    surveyorId: string,
    caseNo: string,
    companyNo: string,
    employeeName: string,
    employeePhone: string,

}
