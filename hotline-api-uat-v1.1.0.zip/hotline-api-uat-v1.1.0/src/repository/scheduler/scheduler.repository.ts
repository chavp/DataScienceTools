import { MongoRepository } from '../../common/mongo-repository'
import { ISchedulerTasksRepository } from '../../domain/scheduler/interface/repository.interface'
import { ISchedulerConfigModel } from '../../domain/scheduler/interface/model.interface'
import { ISchedulerTaskSchema } from './scheduler.schema'
import {
    from,
    Observable,
} from 'rxjs'
import { Db } from 'mongodb'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import {
    catchError,
    map,
    tap,
} from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import * as _ from 'lodash'
import { ObjectId } from 'mongodb'

export class SchedulerRepository extends MongoRepository<ISchedulerConfigModel> implements ISchedulerTasksRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<ISchedulerConfigModel, ISchedulerTaskSchema>,
    ) {
        super(
            db.collection('scheduler'),
            mapping,
        )
    }

    public delete(model: ISchedulerConfigModel): Observable<ISchedulerConfigModel> {
        const id = new ObjectId(model.getId())
        const promise = this._collection.deleteOne({
            _id: id,
        })
        return from(promise).pipe(
            map(deleteResult => {
                if (deleteResult.deletedCount !== 1) {
                    throw new HttpException(
                        `Task deletion Failed on id ${model.getId()}`,
                        HttpStatus.BAD_REQUEST,
                    )
                }
                return model
            }),
        )
    }

    public getById(id: string): Observable<ISchedulerConfigModel> {
        const promise = this._collection.findOne({
            _id: new ObjectId(id),
        })
        return from(promise).pipe(
            tap(schema => {
                if (_.isNil(schema)) {
                    throw new HttpException(
                        `Scheduler Task not found`,
                        HttpStatus.NOT_FOUND)
                }

            }),
            map((schema) => {
                return this.toModel(schema)
            }),
        )
    }

    public update(model: ISchedulerConfigModel): Observable<ISchedulerConfigModel> {
        const schema: ISchedulerTaskSchema = this.toDocument(model)
        const id = schema._id
        delete schema._id
        schema.updatedDate = new Date().getTime()
        const promise = this._collection.updateOne({
            _id: id,
        }, {
            $set: schema,
        })

        return from(promise).pipe(
            tap((result) => {
                if (result.result.ok !== 1) {
                    throw new HttpException(
                        `Cannot update schedule ${model.getId()}`,
                        HttpStatus.BAD_REQUEST,
                    )
                }
            }),
            map(() => model),
        )
    }

    public save(model: ISchedulerConfigModel): Observable<{ id: string }> {
        const schema = this.toDocument(model)
        delete schema._id
        const promise = this._collection.insertOne(schema)
        return from(promise).pipe(
            map(result => {
                return {
                    id: schema._id,
                }
            }),
            catchError(() => {
                throw new HttpException(
                    `Cannot insert new schedule ${schema._id}`,
                    HttpStatus.BAD_REQUEST,
                )
            }),
        )
    }

    public find(filter: any): Observable<ISchedulerConfigModel> {
        const cursor = this._collection.find(filter)
        return this.toObservable(cursor)
    }

}
