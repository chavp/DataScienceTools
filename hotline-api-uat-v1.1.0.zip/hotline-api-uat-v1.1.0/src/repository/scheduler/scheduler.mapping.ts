import { ISchedulerTaskSchema } from './scheduler.schema'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { ISchedulerConfigModel } from '../../domain/scheduler/interface/model.interface'
import { SchedulerTaskBuilder } from '../../domain/scheduler/scheduler-task.builder'
import { SchedulerTypeEnum } from '../../domain/scheduler/interface/scheduler-type.enum'
import * as _ from 'lodash'
import { ObjectId } from 'mongodb'

export class SchedulerRepositoryMapping implements IRepositoryMapping<ISchedulerConfigModel, ISchedulerTaskSchema> {

    public deserialize(schema: ISchedulerTaskSchema): ISchedulerConfigModel {
        const builder: SchedulerTaskBuilder = new SchedulerTaskBuilder(schema.type)
        builder
            .id(schema._id.toHexString())
            .name(schema.taskName)
            .createdDate(new Date(schema.createdDate))
            .updatedDate(new Date(schema.updatedDate))
            .activated(schema.activatedStatus)
            .timeSchedule(schema.timeSchedule)
            .caseNo(schema.caseNo)
            .companyNo(schema.companyNo)
            .lineId(schema.lineId)
            .employeeName(schema.employeeName)
            .employeePhone(schema.employeePhone)
            .surveyorId(schema.surveyorId)
            .triggerOnce(new Date(schema.triggerDate))

        return builder.build()
    }

    public serialize(model: ISchedulerConfigModel): ISchedulerTaskSchema {
        return {
            _id: !_.isNil(model.getId()) ? new ObjectId(model.getId()) : '',
            taskName: model.getName(),
            type: model.getType(),
            days: model.getDays(),
            triggerDate: !_.isNil(model.getDate()) ? model.getDate().getTime() : null,
            triggerTime: model.getTime(),
            createdDate: model.getCreatedDate().getTime(),
            updatedDate: model.getUpdatedDate().getTime(),
            activatedStatus: model.isActivated() ? 'activated' : 'inactivated',
            timeSchedule: model.getTimeSchedule(),
            lineId: model.getLineId(),
            surveyorId: model.getSurveyorId(),
            caseNo: model.getCaseNo(),
            companyNo: model.getCompanyNo(),
            employeeName: model.getEmployeeName(),
            employeePhone: model.getEmployeePhone(),

        } as ISchedulerTaskSchema
    }

}
