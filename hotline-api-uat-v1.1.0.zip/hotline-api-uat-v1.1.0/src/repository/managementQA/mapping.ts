import { IManagementQAModel } from '../../domain/managementQA/interface/model.interface'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IManagementQASchema } from './schema'
import { ManagementQAModel } from '../../domain/managementQA/managementQA.model'
import * as _ from 'lodash'

export class ManagementQARepositoryMapping implements IRepositoryMapping<IManagementQAModel, IManagementQASchema> {
    public deserialize(schema: IManagementQASchema): IManagementQAModel {
        if (_.isNil(schema)) {
            return null
        }
        const model = new ManagementQAModel()
        Object.assign(model, {
            _id: schema._id,
            _question: schema.question,
            _maxScore: schema.maxScore,
            _createdAt: schema.createdAt,
            _createdBy: schema.createdBy,
            _updatedAt: schema.updatedAt,
            _updatedBy: schema.updatedBy,
        })
        return model
    }

    public serialize(model: IManagementQAModel): IManagementQASchema {
        return {
            _id: model.getId(),
            question: model.getQuestion(),
            maxScore: model.getMaxScore(),
            createdAt: model.getCreatedAt(),
            createdBy: model.getCreatedBy(),
            updatedAt: model.getUpdatedAt(),
            updatedBy: model.getUpdatedBy(),
        }
    }
}
