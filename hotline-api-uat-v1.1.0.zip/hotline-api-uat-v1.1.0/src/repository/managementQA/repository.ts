import { MongoRepository } from '../../common/mongo-repository'
import { IManagementQAModel } from '../../domain/managementQA/interface/model.interface'
import { IManagementQARepository } from '../../domain/managementQA/interface/repository.interface'
import { Db } from 'mongodb'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IManagementQASchema } from './schema'
import {
    from,
    Observable,
} from 'rxjs'
import { map } from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'

export class ManagementQAMongoRepository extends MongoRepository<IManagementQAModel> implements IManagementQARepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<IManagementQAModel, IManagementQASchema>,
    ) {
        super(
            db.collection<IManagementQASchema>('managementQA'),
            mapping,
        )
    }

    public find(filter?: any): Observable<IManagementQAModel> {
        const cursor = this._collection.find(filter).sort({createdAt: -1})
        return this.toObservable(cursor)
    }

    public save(model: IManagementQAModel): Observable<{ id: string }> {
        const doc = this.toDocument(model)
        const promise = this._collection.insertOne(doc)
        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot save managementQA`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return {
                    id: result.insertedId.toString(),
                }
            }),
        )
    }

    public update(model: IManagementQAModel): Observable<boolean> {
        const schema = this.toDocument(model)
        const id = schema._id
        delete schema._id
        const promise = this._collection.updateOne({
            _id: id,
        },
            {
                $set: schema,
            })

        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot update managementQA`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return result.modifiedCount === 1
            }),
        )
    }
}
