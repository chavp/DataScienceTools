export interface IManagementQASchema {
    _id: string
    question: string
    maxScore: number
    createdAt: Date
    createdBy: string
    updatedAt: Date
    updatedBy: string
}
