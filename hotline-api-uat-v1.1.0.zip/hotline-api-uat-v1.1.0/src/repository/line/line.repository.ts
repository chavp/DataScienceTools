import { MongoRepository } from '../../common/mongo-repository'
import {
    Db,
    ObjectID,
} from 'mongodb'
import { ILineProfileSchema } from './line.schema'
import {
    from,
    Observable,
    of,
    throwError,
} from 'rxjs'
import {
    map,
    mergeMap,
    tap,
} from 'rxjs/operators'
import { ILineProfileModel } from '../../domain/line/interface/model.interface'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { ILineProfileRepository } from '../../domain/line/interface/repository.interface'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import _ = require('lodash')

export class LineProfileRepository extends MongoRepository<ILineProfileModel> implements ILineProfileRepository {

    constructor(
        db: Db,
        mapping: IRepositoryMapping<ILineProfileModel, ILineProfileSchema>,
    ) {
        super(db.collection('lineProfile'), mapping)
    }

    public save(model: ILineProfileModel): Observable<any> {
        const doc = this.toDocument(model)
        const promise = this._collection.insertOne(doc)
        return from(promise).pipe(
            mergeMap(result => {
                if (result.result.ok === 0) {
                    throwError(`Cannot save data ${model.getDisplayName()}`)
                }
                return of(result)
            }),
            map(result => ({
                id: result.insertedId.toString(),
            })),
        )
    }

    public find(filter?: any): Observable<ILineProfileModel> {
        const cursor = this._collection.find(filter)
        return this.toObservable(cursor)
    }

    public getByLineId(id: string): Observable<ILineProfileModel> {

        const promise = this._collection.findOne({
            _id: id,
        })
        return from(promise).pipe(
            tap(schema => {
                if (_.isNil(schema)) {
                    throw new HttpException(`Cannot find profile`,
                        HttpStatus.NOT_FOUND,
                    )
                }
            }),
            map(schema => {
                return this.toModel(schema)
            }),
        )
    }

    public update(model: ILineProfileModel): Observable<boolean> {

        const schema = this.toDocument(model)
        const id = schema._id
        delete schema._id
        const promise = this._collection.findOneAndUpdate({
                _id: id,
            },
            {
                $set: schema,
            },
        )
        return from(promise).pipe(
            map(result => {
                return result.ok === 1
            }),
        )
    }

    public findMessages(userId: string, userType: string): Observable<ILineProfileModel> {
        const promise = this._collection.aggregate([
            { $match: { userId } },
            { $unwind: '$messages' },
            { $match: { 'messages.conversation.source.type': userType } },
            {
                $project: {
                    _id: 0,
                    messages: '$messages',
                    phone: '$phone',
                },
            },
        ])
        console.log(promise)
        return this.toObservableFromAggregateCursor(promise)
    }

}
