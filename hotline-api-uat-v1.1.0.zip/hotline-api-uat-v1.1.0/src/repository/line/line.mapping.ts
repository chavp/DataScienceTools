import * as _ from 'lodash'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { ILineProfileModel } from '../../domain/line/interface'
import { LineProfileModel } from '../../domain/line/line.model'
import { ILineProfileSchema } from './line.schema'

export class LineProfileRepositoryMapping implements IRepositoryMapping<ILineProfileModel, ILineProfileSchema> {

    public deserialize(schema: ILineProfileSchema): ILineProfileModel {
        if (_.isNil(schema)) {
            return null
        }
        const model = new LineProfileModel(
            schema.displayName,
        )
        Object.assign(model, {
            _id: schema._id,
            _displayName: schema.displayName,
            _pictureUrl: schema.pictureUrl,
            _createDate: new Date(schema.createDate),
            _isFollow: schema.isFollow,
            _isRegister: schema.isRegister,
            _phone: schema.phone,
            _incidentNo: schema.incidentNo,
        })
        return model
    }

    public serialize(model: ILineProfileModel): ILineProfileSchema {
        return {
            _id: model.getId(),
            displayName: model.getDisplayName(),
            pictureUrl: model.getPictureUrl(),
            createDate: model.getCreateDate().getTime(),
            isFollow: model.getIsFollow(),
            isRegister: model.getIsRegister(),
            phone: model.getPhone(),
            incidentNo: model.getIncidentNo(),
        }
    }

}
