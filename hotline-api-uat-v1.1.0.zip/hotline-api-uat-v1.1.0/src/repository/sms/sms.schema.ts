import { ObjectId } from 'bson'

export interface ISmsSchema {
    _id: ObjectId
    incidentNo: string
    contactNo: string
    message: string
    createdAt: Date
    createdBy: string
}
