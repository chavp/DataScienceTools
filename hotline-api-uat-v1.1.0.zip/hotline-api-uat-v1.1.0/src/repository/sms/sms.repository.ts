import {MongoRepository} from '../../common/mongo-repository'
import {ISmsLogRepository} from '../../domain/common/interface/repository.interface'
import {ISmsLogModel} from '../../domain/common/interface/common.interface'
import {from, Observable} from 'rxjs'
import {IRepositoryMapping} from '../../common/interface/repository.interface'
import {ISmsSchema} from './sms.schema'
import {Db} from 'mongodb'
import {map} from 'rxjs/operators'

export class SmsRepository extends MongoRepository<ISmsLogModel> implements ISmsLogRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<ISmsLogModel, ISmsSchema>,
    ) {
        super(db.collection('sms-log'), mapping)
    }

    save(model: ISmsLogModel): Observable<{ id: string }> {
        const document = this.toDocument(model)
        const promise = this._collection.insertOne(document)
        return from(promise).pipe(
            map(result => {
                return {id: result.insertedId.toHexString()}
            }),
        )
    }

    public find(filter?: any): Observable<ISmsLogModel> {
        const cursor = this._collection.find(filter)
        return this.toObservable(cursor)
    }

}
