import {IRepositoryMapping} from '../../common/interface/repository.interface'
import {ISmsLogModel} from '../../domain/common/interface/common.interface'
import {ISmsSchema} from './sms.schema'
import {ObjectId} from 'mongodb'
import {plainToClass} from 'class-transformer'
import {SmsLogModel} from '../../domain/common/sms-log.model'

export class SmsMapping implements IRepositoryMapping<ISmsLogModel, ISmsSchema> {

    deserialize(schema: ISmsSchema): ISmsLogModel {
        return plainToClass(SmsLogModel, {
            _id: schema._id.toHexString(),
            _createdTime: schema.createdAt,
            _createdBy: schema.createdBy,
            _message: schema.message,
            _contactNo: schema.contactNo,
            _incidentNo: schema.incidentNo,
        })
    }

    serialize(model: ISmsLogModel): ISmsSchema {
        return {
            _id: new ObjectId(model.getId()),
            contactNo: model.getContactNo(),
            createdAt: model.getCreatedTime(),
            createdBy: model.getSender(),
            incidentNo: model.getIncidentNo(),
            message: model.getMessage(),
        }
    }

}
