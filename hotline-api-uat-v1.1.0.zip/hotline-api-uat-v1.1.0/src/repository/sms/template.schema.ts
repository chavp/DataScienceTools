import {ObjectId} from 'bson'

export interface ITemplateSchema {
    _id: ObjectId
    name: string
    message: string
}
