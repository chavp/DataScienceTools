import {IRepositoryMapping} from '../../common/interface/repository.interface'
import {ITemplateModel} from '../../domain/sms/interface/model.interface'
import {ITemplateSchema} from './template.schema'
import * as _ from 'lodash'
import {TemplateModel} from '../../domain/sms/template.model'
import {ObjectId} from 'bson'

export class TemplateRepositoryMapping implements IRepositoryMapping<ITemplateModel, ITemplateSchema> {
    public deserialize(schema: ITemplateSchema): ITemplateModel {
        if (_.isNil(schema)) {
            return null
        }
        const model = new TemplateModel(
            schema.message,
        )
        Object.assign(model, {
            _id: schema._id,
            _name: schema.name,
            _message: schema.message,
        })
        return model
    }

    public serialize(model: ITemplateModel): ITemplateSchema {
        return {
            _id: _.isNil(model.getId()) ? undefined : new ObjectId(model.getId()),
            name: model.getName(),
            message: model.getMessage(),
        }
    }
}
