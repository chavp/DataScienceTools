import {MongoRepository} from '../../common/mongo-repository'
import {ITemplateModel} from '../../domain/sms/interface/model.interface'
import {IRepositoryMapping} from '../../common/interface/repository.interface'
import {ITemplateSchema} from './template.schema'
import {Db} from 'mongodb'
import {ITemplateRepository} from '../../domain/sms/interface/repository.interface'
import {from, Observable} from 'rxjs'
import {map} from 'rxjs/operators'
import {RepositoryError, RepositoryErrorType} from '../../common/error'

export class TemplateMongoRepository extends MongoRepository<ITemplateModel> implements ITemplateRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<ITemplateModel, ITemplateSchema>,
    ) {
        super(db.collection('template'), mapping)
    }

    public getAll(): Observable<ITemplateModel> {
        const cursor = this._collection.find()
        return this.toObservable(cursor)
    }

    save(model: ITemplateModel): Observable<{ id: string }> {
        const doc = this.toDocument(model)
        const promise = this._collection.insertOne(doc)
        return from(promise).pipe(
            map(result => {
                return {
                    id: result.insertedId.toHexString(),
                }
                throw new RepositoryError(
                    RepositoryErrorType.InsertError,
                    'Cannot save new model',
                )
            }),
        )
    }
}
