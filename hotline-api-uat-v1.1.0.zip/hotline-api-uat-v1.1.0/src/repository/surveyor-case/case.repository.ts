import { ISurveyorCaseRepository } from '../../domain/surveyor-case/interface/repository.interface'
import { MongoRepository } from '../../common/mongo-repository'
import { ISurveyorCaseSchema } from './case.schema'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { Db } from 'mongodb'
import { ISurveyorCaseModel } from '../../domain/surveyor-case/interface/model.interface'
import {
    from,
    Observable,
} from 'rxjs'
import {
    HttpException,
    HttpStatus,
    NotFoundException,
} from '@nestjs/common'
import {
    map,
    tap,
} from 'rxjs/operators'
import * as _ from 'lodash'
import { ISurveyorModel } from '../../domain/surveyor/interface/model.interface'

export class SurveyorCaseMongoRepository extends MongoRepository<ISurveyorCaseModel> implements ISurveyorCaseRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<ISurveyorCaseModel, ISurveyorCaseSchema>,
    ) {
        super(db.collection('surveyor-case'), mapping)
    }

    public getById(id: string): Observable<ISurveyorCaseModel> {
        const promise = this._collection.findOne({
            _id: id,
        })
        return from(promise).pipe(
            tap((schema: ISurveyorModel) => {
                if (_.isNil(schema)) {
                    throw new NotFoundException(`Cannot find case ${id}`)
                }
            }),
            map(schema => this.toModel(schema)),
        )
    }

    public getByIncidentNumber(incidentNumber: string): Observable<ISurveyorCaseModel> {
        const promise = this._collection.findOne({
            incidentNo: incidentNumber,
        })
        return from(promise).pipe(
            tap((schema: ISurveyorModel) => {
                if (_.isNil(schema)) {
                    throw new NotFoundException(`Cannot find case by incident ${incidentNumber}`)
                }
            }),
            map(schema => this.toModel(schema)),
        )
    }

    public find(filter?: any): Observable<ISurveyorCaseModel> {
        const cursor = this._collection.find(filter).sort({createdAt: -1})
        return this.toObservable(cursor)
    }

    public save(model: ISurveyorCaseModel): Observable<any> {
        const data = this.toDocument(model)
        const promise = this._collection.insertOne(data)
        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot save surveyor`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }

                return {
                    id: (result.insertedId),
                }
            }),
        )
    }

    public update(model: ISurveyorCaseModel): Observable<{ id: string }> {
        const id = model.getId()
        const doc = this.toDocument(model)
        const promise = this._collection.updateOne({
                _id: id,
            },
            {
                $set: doc,
            })
        return from(promise).pipe(
            map((resp: any) => {
                if (_.get(resp, 'result.n') === 1) {
                    return {
                        id: model.getId(),
                    }
                    throw new HttpException('Update Error',
                        HttpStatus.INTERNAL_SERVER_ERROR)
                }
            }),
        )
    }

    public delete(model: ISurveyorCaseModel): Observable<boolean> {
        const id: string = model.getId()
        const promise = this._collection.deleteOne({
            _id: id,
        })
        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot delete surveyor case ${id}`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return result.deletedCount === 1
            }),
        )
    }
}
