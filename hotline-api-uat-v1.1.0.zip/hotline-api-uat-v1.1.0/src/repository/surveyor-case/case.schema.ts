export interface ISurveyorCaseSchema {
    _id: string
    incidentNo: string
    surveyorNo: string
    customerName: string
    customerPhone: string
    place: string
    province: string
    district: string
    surveyorCompanyNo: string
    surveyorNote: string
    surveyorAssignment: ISurveyorAssignmentSchema[]
    createdAt: Date
    updatedAt: Date
    file: string
}

export interface ISurveyorAssignmentSchema {
    name: string
    phone: string
    remark: string
    createdDate: Date
}
