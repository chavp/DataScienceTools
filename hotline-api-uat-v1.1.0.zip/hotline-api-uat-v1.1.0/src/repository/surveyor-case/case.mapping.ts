import {
    ISurveyorAssignmentModel,
    ISurveyorCaseModel,
} from '../../domain/surveyor-case/interface/model.interface'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import * as _ from 'lodash'
import {
    ISurveyorAssignmentSchema,
    ISurveyorCaseSchema,
} from './case.schema'
import {
    SurveyorAssignmentModel,
    SurveyorCaseModel,
} from '../../domain/surveyor-case/case.model'

export class SurveyorCaseMapping implements IRepositoryMapping<ISurveyorCaseModel, ISurveyorCaseSchema> {
    private readonly _surveyorAssignMapping: SurveyorAssignmentMapping

    constructor() {
        this._surveyorAssignMapping = new SurveyorAssignmentMapping()
    }

    public deserialize(schema: ISurveyorCaseSchema): ISurveyorCaseModel {
        if (_.isNil(schema)) {
            return null
        }
        const model = new SurveyorCaseModel()
        Object.assign(model, {
            _id: schema._id,
            _incidentNo: schema.incidentNo,
            _surveyorNo: schema.surveyorNo,
            _customerName: schema.customerName,
            _customerPhone: schema.customerPhone,
            _place: schema.place,
            _province: schema.province,
            _district: schema.district,
            _surveyorCompanyNo: schema.surveyorCompanyNo,
            _surveyorNote: schema.surveyorNote,
            _file: schema.file,
            _surveyorAssignment: _.map(
                schema.surveyorAssignment,
                (item: ISurveyorAssignmentSchema) => this._surveyorAssignMapping.deserialize(item),
            ),
            _createdAt: schema.createdAt,
            _updatedAt: schema.updatedAt,
        })
        return model
    }

    public serialize(model: ISurveyorCaseModel): ISurveyorCaseSchema {
        return {
            _id: model.getId(),
            incidentNo: model.getIncidentNo(),
            surveyorNo: model.getSurveyorNo(),
            customerName: model.getCustomerName(),
            customerPhone: model.getCustomerPhone(),
            place: model.getPlace(),
            province: model.getProvince(),
            district: model.getDistrict(),
            surveyorCompanyNo: model.getSurveyorCompanyNo(),
            surveyorNote: model.getSurveyorNote(),
            surveyorAssignment: _.map(
                model.getSurveyorAssignment(),
                (item: ISurveyorAssignmentModel) => this._surveyorAssignMapping.serialize(item),
            ),
            createdAt: model.getCreatedAt(),
            updatedAt: model.getUpdatedAt(),
            file: model.getFile(),
        }
    }
}

export class SurveyorAssignmentMapping implements IRepositoryMapping<ISurveyorAssignmentModel, ISurveyorAssignmentSchema> {
    public deserialize(schema: ISurveyorAssignmentSchema): ISurveyorAssignmentModel {
        const model = new SurveyorAssignmentModel()
        _.assign(model, {
            _name: schema.name,
            _phone: schema.phone,
            _remark: schema.remark,
            _createdDate: schema.createdDate,
        })
        return model
    }

    public serialize(model: ISurveyorAssignmentModel): ISurveyorAssignmentSchema {
        return {
            name: model.getName(),
            phone: model.getPhone(),
            remark: model.getRemark(),
            createdDate: model.getCreatedDate(),
        }
    }
}
