export enum UserRolesEnum {
    AGENT = 'agent',
    REPORTER = 'reporter',
    ADMIN = 'admin',
}

export interface IProfileSchema {
    _id: string
    name: string
    roles: UserRolesEnum[]
    sessionId: string
    createdAt: Date
    updatedAt: Date
    updatedBy: string
}
