import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IProfileSchema } from './profile.schema'
import { IProfileModel } from '../../domain/profile/interface/model.interface'
import { ProfileModel } from '../../domain/profile/profile.model'

export class ProfileRepositoryMapping implements IRepositoryMapping<IProfileModel, IProfileSchema> {
    public deserialize(schema: IProfileSchema): IProfileModel {
        const model = new ProfileModel()
        Object.assign(model, {
            _id: schema._id,
            _name: schema.name,
            _roles: schema.roles,
            _createdAt: schema.createdAt,
            _updatedAt: schema.updatedAt,
            _updatedBy: schema.updatedBy,
            _sessionId: schema.sessionId || '',
        })
        return model
    }

    public serialize(model: IProfileModel): IProfileSchema {
        return {
            _id: model.getId(),
            name: model.getName(),
            roles: model.getRoles(),
            createdAt: model.getCreatedAt(),
            updatedAt: model.getUpdatedAt(),
            updatedBy: model.getUpdatedBy(),
            sessionId: model.getSessionId(),
        }
    }
}
