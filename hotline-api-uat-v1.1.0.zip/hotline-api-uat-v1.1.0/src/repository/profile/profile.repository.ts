import { IProfileModel } from '../../domain/profile/interface/model.interface'
import { MongoRepository } from '../../common/mongo-repository'
import { IProfileRepository } from '../../domain/profile/interface/repository.interface'
import { Db } from 'mongodb'
import { IProfileSchema } from './profile.schema'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import {
    from,
    Observable,
} from 'rxjs'
import { map } from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'

export class ProfileMongoRepository extends MongoRepository<IProfileModel> implements IProfileRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<IProfileModel, IProfileSchema>,
    ) {
        super(
            db.collection<IProfileSchema>('profile'),
            mapping,
        )
    }

    public find(filter?: any): Observable<IProfileModel> {
        const cursor = this._collection.find(filter).sort({createdAt: -1})
        return this.toObservable(cursor)
    }

    public save(model: IProfileModel): Observable<{id: string}> {
        const doc = this.toDocument(model)
        const promise = this._collection.insertOne(doc)
        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot save profile`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }

                return {
                    id: result.insertedId.toString(),
                }
            }),
        )
    }

    public update(model: IProfileModel): Observable<boolean> {
        const schema = this.toDocument(model)
        const id = schema._id
        delete schema._id
        const promise = this._collection.updateOne({
            _id: id,
        }, {
            $set: schema,
        })

        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot update profile`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return result.modifiedCount === 1
            }),
        )
    }
}
