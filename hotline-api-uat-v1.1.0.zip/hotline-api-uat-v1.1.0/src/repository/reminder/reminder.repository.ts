import { MongoRepository } from '../../common/mongo-repository'
import { IReminderModel } from '../../domain/reminder/interface/model.interface'
import { IReminderRepository } from '../../domain/reminder/interface/repository.interface'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IReminderSchema } from './reminder.schema'
import { ObjectId } from 'bson'
import { Db } from 'mongodb'
import { map } from 'rxjs/operators'
import {
    from,
    Observable,
} from 'rxjs'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'

export class ReminderRepository extends MongoRepository<IReminderModel> implements IReminderRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<IReminderModel, IReminderSchema>,
    ) {
        super(db.collection('reminder'), mapping)
    }

    public getById(id: string): Observable<IReminderModel> {
        const reminderId = new ObjectId(id)
        const promise = this._collection.findOne({ _id: reminderId })
        return from(promise).pipe(
            map(result => {
                return this.toModel(result)
            }),
        )
    }

    public find(dateFilter: Date): Observable<IReminderModel> {
        const date = dateFilter.getDate()
        const month = dateFilter.getMonth() + 1
        const year = dateFilter.getFullYear()

        const start = year + '-' + month + '-' + date + ' 00:00'
        const end = year + '-' + month + '-' + date + ' 23:59'

        const filter = {
            $and: [
                {
                    remindTime: {
                        $gte: new Date(start),
                    },
                },
                {
                    remindTime: {
                        $lte: new Date(end),
                    },
                },
            ],
        }

        const cursor = this._collection.find(filter).sort({remindTime: -1})
        return this.toObservable(cursor)
    }

    public save(model: IReminderModel): Observable<{ id: string }> {
        const document = this.toDocument(model)
        const promise = this._collection.insertOne(document)
        return from(promise).pipe(
            map(result => {
                return {id: result.insertedId.toHexString()}
            }),
        )
    }

    public update(model: IReminderModel): Observable<boolean> {
        const id = model.getId()
        const reminderId = new ObjectId(id)
        const data = this.toDocument(model)
        const promise = this._collection.updateOne({
                _id: reminderId,
            },
            {
                $set: data,
            })
        return from(promise).pipe(
            map((result) => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot update reminder`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }

                return result
            }),
            map(result => {
                return result.modifiedCount === 1
            }),
        )
    }

    public getIncidentNo(id: string): Observable<IReminderModel> {
        const filter = {incidentNo: id}
        const promise = this._collection.findOne(filter)
        return from(promise).pipe(
            map(result => {
                return this.toModel(result)
            }),
        )
    }

    public getByIncidentNo(id: string): Observable<IReminderModel> {
        const filter = {incidentNo: id}
        const promise = this._collection.find(filter)
        return this.toObservable(promise)
    }

    public delete(id: string): Observable<boolean> {
        const newId = new ObjectId(id)
        const promise = this._collection.deleteOne({
            _id: newId,
        })
        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot delete reminder ${id}`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return result.deletedCount === 1
            }),
        )
    }
}
