import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IReminderModel } from '../../domain/reminder/interface/model.interface'
import { IReminderSchema } from './reminder.schema'
import { ObjectId } from 'bson'
import { ReminderModel } from '../../domain/reminder/reminder.model'
import * as _ from 'lodash'

export class ReminderMapping implements IRepositoryMapping<IReminderModel, IReminderSchema> {
    deserialize(schema: IReminderSchema): IReminderModel {
        if (_.isNil(schema)) {
            return null
        }

        const model = new ReminderModel()

        Object.assign(model, {
            _id: !_.isNil(schema._id) ? schema._id.toHexString() : null,
            _incidentNo: schema.incidentNo,
            _registration: schema.registration,
            _note: schema.note,
            _remindTime: schema.remindTime,
            _type: !_.isNil(schema.type) ? schema.type : 'manual',
            _status: schema.status,
            _agent: schema.agent,
            _createdAt: schema.createdAt,
            _notified: !!schema.notified,
        })

        return model
    }

    serialize(model: IReminderModel): IReminderSchema {
        return {
            _id: !_.isNil(model.getId()) ? new ObjectId(model.getId()) : new ObjectId(),
            incidentNo: model.getIncidentNo(),
            registration: model.getRegistration(),
            note: model.getNote(),
            remindTime: model.getRemindTime(),
            status: model.getStatus(),
            agent: model.getAgent(),
            createdAt: model.getCreatedAt(),
            notified: model.isNotified(),
            type: !_.isNil(model.getType()) ? model.getType() : 'manual',
        }
    }
}
