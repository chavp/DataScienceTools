import { ObjectId } from 'bson'

export interface IReminderSchema {
    _id: ObjectId
    incidentNo: string
    registration: string
    note: string
    remindTime: Date
    status: 'read' | 'unread'
    agent: string
    notified: boolean
    type: 'manual' | 'appointment'
    createdAt: Date
}
