import { MongoRepository } from '../../common/mongo-repository'
import {
    IIncidentLogModel,
    IIncidentLogRepository,
} from '../../domain/incident/interface'
import {
    from,
    Observable,
    of,
} from 'rxjs'
import { Db } from 'mongodb'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IIncidentLogSchema } from './log.schema'
import {
    map,
    tap,
} from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import * as _ from 'lodash'

export class IncidentLogRepository extends MongoRepository<IIncidentLogModel> implements IIncidentLogRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<IIncidentLogModel, IIncidentLogSchema>,
    ) {
        super(db.collection('log-incident'), mapping)
    }

    public getById(id: string): Observable<IIncidentLogModel> {
        const promise = this._collection.findOne<IIncidentLogSchema>({
            _id: id,
        })
        return from(promise).pipe(
            tap((data) => {
                if (_.isNil(data)) {
                    throw new HttpException(
                        `Cannot find log ${id}`,
                        HttpStatus.NOT_FOUND,
                    )
                }

                return data
            }),
            map((schema) => {
                return this.toModel(schema)
            }),
        )
    }

    public save(model: IIncidentLogModel): Observable<{ id: string }> {
        const schema = this.toDocument(model)
        const promise = this._collection.insertOne(schema)
        return from(promise).pipe(
            map(result => {
                return {id: (result.insertedId as any)}
            }),
        )
    }

    public update(model: IIncidentLogModel): Observable<{ id: string }> {
        const id = model.getId()
        const data = this.toDocument(model)
        const promise = this._collection.updateOne({
                _id: id,
            },
            {
                $set: data,
            })
        return from(promise).pipe(
            map((result) => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot update incident`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return {
                    id: model.getId(),
                }
            }),
        )
    }

    public getReportById(id: string): Observable<any> {
        const query = {
            _id: id,
        }

        const cursor = this._collection.find(query)
        return this.toObservable(cursor)
    }

}
