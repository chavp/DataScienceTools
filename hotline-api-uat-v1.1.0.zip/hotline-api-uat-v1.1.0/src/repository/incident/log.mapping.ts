import * as _ from 'lodash'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import {
    IIncidentLogSchema,
    ILogDataSchema,
} from './log.schema'
import {
    IIncidentLogModel,
    IIncidentLogRecordModel,
} from '../../domain/incident/interface'
import {
    IncidentLogModel,
    IncidentLogRecordModel,
} from '../../domain/incident/incident-log.model'

export class IncidentLogRecordMapping implements IRepositoryMapping<IIncidentLogRecordModel, ILogDataSchema> {
    public deserialize(schema: ILogDataSchema): IIncidentLogRecordModel {
        const model = new IncidentLogRecordModel(
            schema.createdBy,
            schema.note,
        )
        _.assign(model, {
            _id: schema.id,
            _createdDate: schema.createdDate,
            _status: schema.status,
            _workFlow: schema.workFlow,
        })
        return model
    }

    public serialize(model: IIncidentLogRecordModel): ILogDataSchema {
        return {
            createdBy: model.getCreatedBy(),
            createdDate: model.getCreatedTime(),
            status: model.getStatus(),
            id: model.getId(),
            note: model.getNote() || '',
            workFlow: model.getWorkFlow(),
        }
    }

}

export class IncidentLogRepositoryMapping implements IRepositoryMapping<IIncidentLogModel, IIncidentLogSchema> {
    private readonly _recordMapping: IncidentLogRecordMapping

    constructor() {
        this._recordMapping = new IncidentLogRecordMapping()
    }

    public deserialize(schema: IIncidentLogSchema): IIncidentLogModel {
        const model = new IncidentLogModel()
        _.assign(model, {
            _id: schema._id,
            _policy: schema.policy,
            _lastUpdate: schema.lastUpdate,
            _createdDate: schema.createdDate,
            _logs: _.map(
                schema.logs,
                (item: ILogDataSchema) => this._recordMapping.deserialize(item),
            ),
        })
        return model
    }

    public serialize(model: IIncidentLogModel): IIncidentLogSchema {
        return {
            _id: model.getId(),
            createdDate: model.getCreatedTime(),
            lastUpdate: new Date(),
            logs: _.map(
                model.getLogs(),
                (item: IIncidentLogRecordModel) => this._recordMapping.serialize(item),
            ),
            policy: model.getPolicy(),
        }
    }

}
