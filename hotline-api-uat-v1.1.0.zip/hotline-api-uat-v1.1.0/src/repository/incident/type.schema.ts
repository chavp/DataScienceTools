export interface IIncidentTypeSchema {
    _id: string,
    name: string,
    subType: IIncidentTypeSchema[],
}
