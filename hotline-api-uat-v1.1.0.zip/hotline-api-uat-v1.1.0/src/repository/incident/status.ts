import * as _ from 'lodash'
import { MongoRepository } from '../../common/mongo-repository'
import { IIncidentStatusModel } from '../../domain/incident/interface/status.model.interface'
import { Db } from 'mongodb'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IIncidentStatusSchema } from './status.schema'
import { IIncidentStatusRepository } from '../../domain/incident/interface/status.repository.interface'
import { Observable } from 'rxjs'
import {
    tap,
    throwIfEmpty,
} from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'

export class IncidentStatusRepository extends MongoRepository<IIncidentStatusModel> implements IIncidentStatusRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<IIncidentStatusModel, IIncidentStatusSchema>,
    ) {
        super(db.collection('incident_status'), mapping)
    }

    public find(filter?: any): Observable<IIncidentStatusModel> {
        const cursor = this._collection.find(filter)
        return this.toObservable(cursor)
    }

    public getById(id: string): Observable<IIncidentStatusModel> {
        const promise = this._collection.find({_id: id})
        return this.toObservable(promise).pipe(
            throwIfEmpty(() => {
                throw new HttpException(`Cannot find incident status`, HttpStatus.NOT_FOUND)
            }),
        )
    }
}
