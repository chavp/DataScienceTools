import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IIncidentStatusModel } from '../../domain/incident/interface/status.model.interface'
import { IIncidentStatusSchema } from './status.schema'
import { IncidentStatusModel } from '../../domain/incident/status.model'
import * as _ from 'lodash'

export class IncidentStatusRepositoryMapping implements IRepositoryMapping<IIncidentStatusModel, IIncidentStatusSchema> {
    public deserialize(schema: IIncidentStatusSchema): IIncidentStatusModel {
        if (_.isNil(schema)) {
            return null
        }

        const model = new IncidentStatusModel(
            schema.name,
        )

        Object.assign(model, {
            _id: schema._id,
            _name: schema.name,
            _used: schema.used,
        })
        return model
    }

    public serialize(model: IIncidentStatusModel): IIncidentStatusSchema {
        return {
            _id: model.getId(),
            name: model.getName(),
            used: model.getUsed(),
        }
    }
}
