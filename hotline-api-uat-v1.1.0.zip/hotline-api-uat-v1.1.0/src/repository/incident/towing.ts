import { ITowingRepository } from '../../domain/incident/interface/towing.repository.interface'
import { ITowingModel } from '../../domain/incident/interface/towing.model.interface'
import { MongoRepository } from '../../common/mongo-repository'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { map } from 'rxjs/operators'
import { Db } from 'mongodb'
import { ObjectId } from 'bson'
import {
    from,
    Observable,
} from 'rxjs'
import {
    IIncidentTowing,
} from './incident.schema'

export class TowingRepository extends MongoRepository<ITowingModel> implements ITowingRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<ITowingModel, IIncidentTowing>,
    ) {
        super(db.collection('incident_towing'), mapping)
    }

    public getById(id: string): Observable<ITowingModel> {
        const towingId = new ObjectId(id)
        const promise = this._collection.findOne({ _id: towingId })
        return from(promise).pipe(
            map(result => {
                return this.toModel(result)
            }),
        )
    }
}
