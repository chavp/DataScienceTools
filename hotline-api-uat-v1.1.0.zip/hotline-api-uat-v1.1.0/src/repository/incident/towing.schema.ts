import { ObjectId } from 'bson'

export interface ITowingSchema {
    _id: ObjectId
    name: string
    used: boolean
}
