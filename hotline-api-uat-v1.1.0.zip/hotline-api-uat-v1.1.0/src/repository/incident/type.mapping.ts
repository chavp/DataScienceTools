import { IIncidentTypeModel } from '../../domain/incident/interface/type.model.interface'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IncidentTypeModel } from '../../domain/incident/type.model'
import { IIncidentTypeSchema } from './type.schema'
import * as _ from 'lodash'

export class IncidentTypeRepositoryMapping implements IRepositoryMapping<IIncidentTypeModel, IIncidentTypeSchema> {
    public deserialize(schema: IIncidentTypeSchema): IIncidentTypeModel {
        if (_.isNil(schema)) {
            return null
        }

        const model = new IncidentTypeModel(
            schema.name,
        )

        Object.assign(model, {
            _id: schema._id,
            _name: schema.name,
            _subType: schema.subType.map((subSchema) => {
                return this.deserialize(subSchema)
            }),
        })
        return model
    }

    public serialize(model: IIncidentTypeModel): IIncidentTypeSchema {
        return {
            _id: model.getId(),
            name: model.getName(),
            subType: model.getSubType().map((subModel) => {
                return this.serialize(subModel)
            }),
        }
    }
}
