export interface IIncidentType {
    id: string,
    name: string,
    subType: IIncidentType,
}
