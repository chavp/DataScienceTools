import { ObjectId } from 'bson'
import {
    IAs400PolicySchema,
} from '../../adapter/as400/interface/schema.interface'

export interface IIncidentType {
    id: string,
    name: string,
    subType: IIncidentType
}

export interface IIncidentCompany {
    policyNo: string,
    claimNo: string,
}

export interface IIncidentInsured {
    injured: number,
    death: number,
}

export interface IIncidentThirdInsured {
    injured: number,
    death: number,
}

export interface IIncidentLossInfo {
    detail: string,
    location: string,
    dateTime: number,
}

export interface IIncidentTowing {
    id: ObjectId,
    name: string,
    used: boolean,
}

export interface IIncidentStatus {
    id: string,
    name: string,
    used: boolean,
}

export interface ISurveyor {
    id: string,
    place: string,
    lat: number,
    long: number,
    note: string,
    province: string,
    district: string,
}

export interface IIncidentSchema {
    _id: string
    contactNo: string
    callerName: string
    incidentType: IIncidentType
    status: IIncidentStatus
    appointmentDate: Date
    claimNo: string
    companyInfo: IIncidentCompany
    lossInformation: IIncidentLossInfo
    driverName: string
    towCompany: IIncidentTowing
    note: string
    insured: IIncidentInsured
    thirdInsured: IIncidentThirdInsured
    policy: IAs400PolicySchema
    surveyor: ISurveyor
    updatedAt: Date
    updatedBy: string
    createdAt: Date
    createdBy: string
}
