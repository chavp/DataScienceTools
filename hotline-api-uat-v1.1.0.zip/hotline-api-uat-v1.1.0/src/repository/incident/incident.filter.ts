export interface IIncidentFilterSchema {
    id?: string
    contactNo?: string
    claimNo?: string
    createdAt?: string
}

export interface IIncidentDeepFilter {
    contactNo?: string
    claimNo?: string
    callerName?: string
    type?: string
    subType?: string
    status?: string
    agent?: string
    open?: {
        from: number
        to: number
    }
    appointment?: {
        from: number
        to: number
    }
    query?: string
}

export interface IIncidentSort {
    limit: number
    page: number
    direction: 1 | -1
    sortKey: string
}
