export interface IIncidentStatusSchema {
    _id: string,
    name: string,
    used: boolean,
}
