import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { ITowingModel } from '../../domain/incident/interface/towing.model.interface'
import { ITowingSchema } from './towing.schema'
import { ObjectId } from 'bson'
import * as _ from 'lodash'
import { TowingModel } from '../../domain/incident/towing.model'

export class TowingRepositoryMapping implements IRepositoryMapping<ITowingModel, ITowingSchema> {
    public deserialize(schema: ITowingSchema): ITowingModel {
        if (_.isNil(schema)) {
            return null
        }
        const model = new TowingModel(
            schema.name,
        )

        Object.assign(model, {
            _id: schema._id,
            _name: schema.name,
            _used: schema.used,
        })
        return model
    }

    public serialize(model: ITowingModel): ITowingSchema {
        return {
            _id: _.isNil(model.getId()) ? undefined : new ObjectId(model.getId()),
            name: model.getName(),
            used: model.getUsed(),
        }
    }
}
