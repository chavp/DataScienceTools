import { MongoRepository } from '../../common/mongo-repository'
import { IIncidentModel } from '../../domain/incident/interface/model.interface'
import { IIncidentTypeRepository } from '../../domain/incident/interface/type.repository.interface'
import { Db } from 'mongodb'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import {
    Observable,
} from 'rxjs'
import { IIncidentType } from './incident.type'

export class IncidentTypeRepository extends MongoRepository<IIncidentModel> implements IIncidentTypeRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<IIncidentModel, IIncidentType>,
    ) {
        super(db.collection('incident_type'), mapping)
    }

    public find(): Observable<any> {
        const cursor = this._collection.find()
        return this.toObservable(cursor)
    }

    public getById(id: string): Observable<any> {
        const promise = this._collection.find({ _id: id })
        return this.toObservable(promise)
    }
}
