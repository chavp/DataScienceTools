import * as _ from 'lodash'
import { MongoRepository } from '../../common/mongo-repository'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IIncidentSchema } from './incident.schema'
import { IIncidentModel } from '../../domain/incident/interface/model.interface'
import {
    IIncidentRepository,
    IIncidentRepositoryFilter,
} from '../../domain/incident/interface/repository.interface'
import {
    Observable,
    from,
} from 'rxjs'
import {
    Db,
} from 'mongodb'
import {
    map,
    tap,
} from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
    NotFoundException,
} from '@nestjs/common'
import {
    IIncidentDeepFilter,
    IIncidentSort,
} from './incident.filter'
import { ISurveyorModel } from '../../domain/surveyor/interface/model.interface'

export class IncidentRepository extends MongoRepository<IIncidentModel> implements IIncidentRepository {

    constructor(
        db: Db,
        mapping: IRepositoryMapping<IIncidentModel, IIncidentSchema>,
    ) {
        super(db.collection('incident'), mapping)
    }

    public getById(id: string): Observable<IIncidentModel> {
        const promise = this._collection.findOne({
            _id: id,
        })
        return from(promise).pipe(
            tap((schema: ISurveyorModel) => {
                if (_.isNil(schema)) {
                    throw new NotFoundException(`Cannot find incident ${id}`)
                }
            }),
            map(schema => {
                return this.toModel(schema)
            }),
        )
    }

    public find(filter?: any): Observable<IIncidentModel> {
        const cursor = this._collection.find(filter).sort({ createdAt: -1 })
        return this.toObservable(cursor)
    }

    public save(model: IIncidentModel): Observable<any> {
        const data = this.toDocument(model)
        const promise = this._collection.insertOne(data)

        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot save incident`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }

                return {
                    id: (result.insertedId),
                }
            }),
        )
    }

    public update(model: IIncidentModel): Observable<{ id: string }> {
        const id = model.getId()
        const data = this.toDocument(model)
        const promise = this._collection.updateOne({
                _id: id,
            },
            {
                $set: data,
            })
        return from(promise).pipe(
            map((result) => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot update incident`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return {
                    id: model.getId(),
                }
            }),
        )
    }

    public findAll(filter?: IIncidentRepositoryFilter): Observable<IIncidentModel> {
        const andFilter: any[] = []

        if (!_.isNil(filter.appointmentDateRange)) {
            andFilter.push({
                appointmentDate: {
                    $gte: _.get(filter, 'appointmentDateRange.from'),
                    $lte: _.get(filter, 'appointmentDateRange.to'),
                },
            })
        }

        if (!_.isNil(filter.incidentDateRange)) {
            andFilter.push({
                createdAt: {
                    $gte: _.get(filter, 'incidentDateRange.from'),
                    $lte: _.get(filter, 'incidentDateRange.to'),
                },
            })
        }

        if (!_.isNil(filter.agent)) {
            andFilter.push({
                // $or: [
                //     { createdBy: filter.agent },
                //     { updatedBy: filter.agent },
                // ],
                createdBy: filter.agent,
            })
        }

        if (!_.isNil(filter.type)) {
            andFilter.push({
                'incidentType.id': filter.type,
            })
        }

        if (!_.isNil(filter.subType)) {
            andFilter.push({
                'incidentType.subType.id': filter.subType,
            })
        }

        if (!_.isNil(filter.status)) {
            andFilter.push({
                'status.id': filter.status,
            })
        }

        const mongoFilter = {
            $and: andFilter,
        }

        const cursor = this._collection.find(mongoFilter)

        return this.toObservable(cursor)
    }

    public findByReport(filter?: IIncidentRepositoryFilter): Observable<IIncidentModel> {

        const andFilter: any[] = []

        if (!_.isNil(filter.appointmentDateRange)) {
            andFilter.push({
                appointmentDate: {
                    $gte: _.get(filter, 'appointmentDateRange.from'),
                    $lte: _.get(filter, 'appointmentDateRange.to'),
                },
            })
        }

        if (!_.isNil(filter.incidentDateRange)) {
            andFilter.push({
                createdAt: {
                    $gte: _.get(filter, 'incidentDateRange.from'),
                    $lte: _.get(filter, 'incidentDateRange.to'),
                },
            })
        }

        if (!_.isNil(filter.agent)) {
            andFilter.push({
                // $or: [
                //     { createdBy: filter.agent },
                //     { updatedBy: filter.agent },
                // ],
                createdBy: filter.agent,
            })
        }

        if (!_.isNil(filter.type)) {
            andFilter.push({
                'incidentType.id': filter.type,
            })
        }

        if (!_.isNil(filter.status)) {
            andFilter.push({
                'status.id': filter.status,
            })
        }

        const mongoFilter = {
            $and: andFilter,
        }

        const cursor = this._collection.find(mongoFilter)

        return this.toObservable(cursor)
    }

    public filter(filter: IIncidentDeepFilter, sorting?: IIncidentSort): Observable<IIncidentModel> {
        const andFilter: any[] = []

        if (!_.isEmpty(filter.appointment)) {
            andFilter.push({
                appointmentDate: {
                    $gte: new Date(_.get(filter, 'appointment.from')),
                    $lte: new Date(_.get(filter, 'appointment.to')),
                },
            })
        }
        if (!_.isEmpty(filter.open)) {
            andFilter.push({
                createdAt: {
                    $gte: new Date(_.get(filter, 'open.from')),
                    $lte: new Date(_.get(filter, 'open.to')),
                },
            })
        }
        if (!_.isNil(filter.agent)) {
            andFilter.push({
                // $or: [
                //     { createdBy: filter.agent },
                //     { updatedBy: filter.agent },
                // ],
                'createdBy': filter.agent,
            })
        }
        if (!_.isNil(filter.type)) {
            andFilter.push({
                'incidentType.id': filter.type,
            })
        }
        if (!_.isNil(filter.subType)) {
            andFilter.push({
                'incidentType.subType.id': filter.subType,
            })
        }
        if (!_.isNil(filter.status)) {
            andFilter.push({
                'status.id': filter.status,
            })
        }
        if (!_.isNil(filter.query)) {
            const regExp = new RegExp(filter.query)
            andFilter.push({
                $or: [ // field ที่แสดงหน้า front ไม่ใช่ drop down
                    { contactNo: regExp },
                    { claimNo: regExp },
                    { callerName: regExp },
                    { 'policy.registration': regExp },
                ],
            })
        }

        let mongoFilter = {}

        if (andFilter.length > 0) {
            mongoFilter = {
                $and: andFilter,
            }
        }

        const cursor = this._collection.find(mongoFilter)

        if (!_.isNil(sorting.limit)) {
            cursor.limit(sorting.limit)
        }
        if (!_.isNil(sorting.page) && !_.isNil(sorting.limit)) {
            const skip = (sorting.page - 1) * sorting.limit
            cursor.skip(skip)
        }
        if (!_.isNil(sorting.sortKey) && !_.isNil(sorting.direction)) {
            const key = _.get(sorting, 'sortKey')
            const objSort: any = {}
            objSort[key] = _.toNumber(sorting.direction)
            cursor.sort(objSort)
        }

        return this.toObservable(cursor)
    }

    public reportFindAll(): Observable<IIncidentModel> {
        const cursor = this._collection.find()
        return this.toObservable(cursor)
    }

}
