import { IInputStatus } from '../../domain/incident/interface'
import { IAs400PolicySchema } from '../../adapter/as400/interface/schema.interface'

export enum WorkFlowEnum {
    CUSTOMER_CALLED_AGENT = 'customer-called-agent',
    AGENT_RESPONDED_CUSTOMER = 'agent-responded-customer',
    SURVEYOR_ACCEPTED_JOB = 'surveyor-accepted-job',
    SURVEYOR_ARRIVED = 'surveyor-arrived',
    AGENT_ASSIGNED_SURVEYOR = 'agent-assigned-surveyor',
}

export interface IIncidentLogSchema {
    _id: string
    policy: IAs400PolicySchema
    createdDate: Date
    lastUpdate: Date
    logs: ILogDataSchema[]
}

export interface ILogDataSchema {
    id: string
    createdBy: string
    note: string
    status: IInputStatus
    createdDate: Date
    workFlow: WorkFlowEnum
}
