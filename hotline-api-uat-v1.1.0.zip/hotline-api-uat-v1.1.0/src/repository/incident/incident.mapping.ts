import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IIncidentModel } from '../../domain/incident/interface/model.interface'
import { IIncidentSchema } from './incident.schema'
import { IncidentModel } from '../../domain/incident/incident.model'
import { ObjectId } from 'bson'
import * as _ from 'lodash'

export class IncidentRepositoryMapping implements IRepositoryMapping<IIncidentModel, IIncidentSchema> {
    public deserialize(schema: IIncidentSchema): IIncidentModel {
        if (_.isNil(schema)) {
            return null
        }

        const model = new IncidentModel(
            schema.contactNo,
            schema.callerName,
        )
        Object.assign(model, {
            _id: schema._id,
            _contactNo: schema.contactNo,
            _callerName: schema.callerName,
            _incidentType: schema.incidentType,
            _status: schema.status,
            _appointmentDate: schema.appointmentDate,
            _claimNo: schema.claimNo,
            _companyInfo: schema.companyInfo,
            _lossInformation: schema.lossInformation,
            _driverName: schema.driverName,
            _towCompany: schema.towCompany,
            _note: schema.note,
            _insured: schema.insured,
            _thirdInsured: schema.thirdInsured,
            _policy: schema.policy,
            _surveyor: schema.surveyor,
            _updatedAt: schema.updatedAt,
            _updatedBy: schema.updatedBy,
            _createdAt: schema.createdAt,
            _createdBy: schema.createdBy,
        })
        return model
    }

    public serialize(model: IIncidentModel): IIncidentSchema {
        let towing
        if (!_.isNil(model.getTowCompany())) {
            towing = {
                id: new ObjectId(model.getTowCompany().id),
                name: model.getTowCompany().name,
            }
        }

        let surveyor
        if (!_.isNil(model.getSurveyor())) {
            surveyor = {
                id: model.getSurveyor().id,
                name: model.getSurveyor().name,
                phone: model.getSurveyor().phone,
                place: model.getSurveyor().place,
                lat: model.getSurveyor().lat,
                long: model.getSurveyor().long,
                note: model.getSurveyor().note,
                province: model.getSurveyor().province,
                district: model.getSurveyor().district,
            }
        }

        let createdAt
        if (!_.isNil(model.getCreatedAt())) {
            createdAt = model.getCreatedAt()
        } else {
            createdAt = null
        }

        let updatedAt
        if (!_.isNil(model.getUpdatedAt())) {
            updatedAt = model.getUpdatedAt()
        } else {
            updatedAt = null
        }

        return {
            _id: model.getId(),
            contactNo: model.getContactNo(),
            callerName: model.getCallerName(),
            incidentType: model.getIncidentType(),
            status: model.getStatus(),
            appointmentDate: model.getAppointmentDate(),
            claimNo: model.getClaimNo(),
            companyInfo: model.getCompanyInfo(),
            lossInformation: model.getLossInformation(),
            driverName: model.getDriverName(),
            towCompany: towing,
            note: model.getNote(),
            insured: model.getInsured(),
            thirdInsured: model.getThirdInsured(),
            policy: model.getPolicy(),
            surveyor,
            updatedAt,
            updatedBy: model.getUpdatedBy(),
            createdAt,
            createdBy: model.getCreatedBy(),
        } as IIncidentSchema
    }
}
