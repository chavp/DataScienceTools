import { PermissionEnum } from '../../domain/common/interface/permission-enum'

export interface IPermissionSchema {
    _id: string
    permission: PermissionEnum[]
}
