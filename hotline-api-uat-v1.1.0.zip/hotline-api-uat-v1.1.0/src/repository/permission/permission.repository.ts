import { MongoRepository } from '../../common/mongo-repository'
import { IPermissionModel } from '../../domain/permission/interface/model.interface'
import { IPermissionRepository } from '../../domain/permission/interface/repository.interface'
import { Db } from 'mongodb'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IPermissionSchema } from './permission.schema'
import {
    from,
    Observable,
} from 'rxjs'
import { PermissionEnum } from '../../domain/common/interface/permission-enum'
import {
    map,
    mergeMap,
    tap,
} from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import * as _ from 'lodash'

export class PermissionRepository extends MongoRepository<IPermissionModel> implements IPermissionRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<IPermissionModel, IPermissionSchema>,
    ) {
        super(
            db.collection<IPermissionSchema>('permission'),
            mapping,
        )
    }

    public find(filter?: any): Observable<IPermissionModel> {
        const cursor = this._collection.find(filter)
        return this.toObservable(cursor)
    }

    public update(model: IPermissionModel): Observable<boolean> {
        const schema = this.toDocument(model)
        const id = schema._id
        delete schema._id
        const promise = this._collection.updateOne({
            _id: id,
        }, {
            $set: schema,
        })

        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot update permission`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }

                return result.modifiedCount === 1
            }),
        )
    }

}
