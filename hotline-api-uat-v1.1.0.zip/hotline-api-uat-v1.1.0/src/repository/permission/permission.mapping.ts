import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IPermissionModel } from '../../domain/permission/interface/model.interface'
import { IPermissionSchema } from './permission.schema'
import { PermissionModel } from '../../domain/permission/permission.model'

export class PermissionMapping implements IRepositoryMapping<IPermissionModel, IPermissionSchema> {
    public deserialize(schema: IPermissionSchema): IPermissionModel {
        const model = new PermissionModel()
        Object.assign(model, {
            _id: schema._id,
            _permission: schema.permission,
        })
        return model
    }

    public serialize(model: IPermissionModel): IPermissionSchema {
        return {
            _id: model.getId(),
            permission: model.getPermission(),
        }
    }
}
