import { MongoRepository } from '../../common/mongo-repository'
import { ISurveyorLineModel } from '../../domain/surveyor-line/interface/model.interface'
import { ISurveyorLineRepository } from '../../domain/surveyor-line/interface/repository.interface'
import { Db } from 'mongodb'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { ISurveyorLineSchema } from './surveyor-line.schema'
import {
    from,
    Observable,
} from 'rxjs'
import {
    map,
    tap,
} from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import * as _ from 'lodash'

export class SurveyorLineMongoRepository extends MongoRepository<ISurveyorLineModel> implements ISurveyorLineRepository {

    constructor(
        db: Db,
        mapping: IRepositoryMapping<ISurveyorLineModel, ISurveyorLineSchema>,
    ) {
        super(
            db.collection<ISurveyorLineSchema>('surveyor-line'),
            mapping,
        )
    }

    public find(filter?: any): Observable<ISurveyorLineModel> {
        const cursor = this._collection.find(filter)
        return this.toObservable(cursor)
    }

    public save(model: ISurveyorLineModel): Observable<any> {
        const doc = this.toDocument(model)
        const promise = this._collection.insertOne(doc)
        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot Save Surveyor-Line`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
            }),
        )
    }

    public update(model: ISurveyorLineModel): Observable<boolean> {
        const schema = this.toDocument(model)
        const id = schema._id
        delete schema._id
        const promise = this._collection.updateOne({
                _id: id,
            },
            {
                $set: schema,
            })
        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot update surveyor-line`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return result.modifiedCount === 1
            }),
        )
    }

    public getById(id: string): Observable<ISurveyorLineModel> {
        const promise = this._collection.findOne({
            _id: id,
        })
        return from(promise).pipe(
            tap((schema: ISurveyorLineModel) => {
                if (_.isNil(schema)) {
                    throw new HttpException(`Cannot find surveyor ${id}`, HttpStatus.NOT_FOUND)
                }
            }),
            map(schema => this.toModel(schema)),
        )
    }

    public getBySurveyorId(id: string): Observable<ISurveyorLineModel> {
        const promise = this._collection.findOne({
            surveyorId: id,
        })
        return from(promise).pipe(
            tap((schema: ISurveyorLineModel) => {
                if (_.isNil(schema)) {
                    throw new HttpException(`Cannot find surveyor code ${id}`, HttpStatus.NOT_FOUND)
                }
            }),
            map(schema => this.toModel(schema)),
        )
    }
}
