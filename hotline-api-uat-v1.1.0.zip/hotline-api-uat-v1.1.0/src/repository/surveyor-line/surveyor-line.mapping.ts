import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { ISurveyorLineModel } from '../../domain/surveyor-line/interface/model.interface'
import { ISurveyorLineSchema } from './surveyor-line.schema'
import { SurveyorLineModel } from '../../domain/surveyor-line/surveyor-line.model'

export class SurveyorLineMapping implements IRepositoryMapping<ISurveyorLineModel, ISurveyorLineSchema> {
    public deserialize(schema: ISurveyorLineSchema): ISurveyorLineModel {
        const model = new SurveyorLineModel()
        Object.assign(model, {
            _id: schema._id,
            _address: schema.address,
            _companyName: schema.companyName,
            _companyPhone: schema.companyPhone,
            _groupName: schema.groupName,
            _partnerCompany: schema.partnerCompany,
            _serviceArea: schema.serviceArea,
            _status: schema.botStatus,
            _surveyor: schema.surveyorId,
            _createdDate: schema.createdDate,
            _updatedDate: schema.updatedDate,
        })
        return model
    }

    public serialize(model: ISurveyorLineModel): ISurveyorLineSchema {
        return {
            _id: model.getId(),
            address: model.getAddress(),
            companyName: model.getCompanyName(),
            companyPhone: model.getCompanyPhone(),
            groupName: model.getGroupName(),
            partnerCompany: model.getPartnerCompany(),
            serviceArea: model.getServiceArea(),
            botStatus: model.getStatus(),
            surveyorId: model.getSurveyorId(),
            createdDate: model.getCreatedDate(),
            updatedDate: model.getUpdatedDate(),
        }
    }
}
