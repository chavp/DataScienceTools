import { IServiceAreaSchema } from '../../domain/surveyor-line/interface/model.interface'

export interface ISurveyorLineSchema {
    _id: string
    surveyorId: string
    address: string
    companyName: string
    companyPhone: string
    groupName: string
    partnerCompany: string
    serviceArea: IServiceAreaSchema
    botStatus: string
    createdDate: Date
    updatedDate: Date
}
