import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IGuaranteeZoneModel } from '../../domain/surveyor/interface/model.interface'
import { IGuaranteeZoneSchema } from './guarantee-zone.schema'
import { ObjectId } from 'mongodb'
import { GuaranteeZoneModel } from '../../domain/surveyor/guarantee-zone.model'
import { plainToClass } from 'class-transformer'

export class GuaranteeZoneMapping implements IRepositoryMapping<IGuaranteeZoneModel, IGuaranteeZoneSchema> {

    public deserialize(schema: IGuaranteeZoneSchema): IGuaranteeZoneModel {
        return plainToClass(GuaranteeZoneModel, {
            _id: schema._id.toHexString(),
            _guaranteeMinute: schema.guaranteeMinute,
            _provinceEN: schema.provinceEN,
            _provinceTH: schema.provinceTH,
            _districtEN: schema.districtEN,
            _districtTH: schema.districtTH,
        })
    }

    public serialize(model: IGuaranteeZoneModel): IGuaranteeZoneSchema {
        return {
            _id: new ObjectId(model.getId()),
            districtEN: model.getDistrictEN(),
            districtTH: model.getDistrictTH(),
            provinceEN: model.getProvinceEN(),
            provinceTH: model.getProvinceTH(),
            guaranteeMinute: model.getGuaranteeMinute(),
        }
    }

}
