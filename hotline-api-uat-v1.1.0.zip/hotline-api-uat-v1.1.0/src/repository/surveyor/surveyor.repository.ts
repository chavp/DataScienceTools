import { MongoRepository } from '../../common/mongo-repository'
import { ISurveyorModel } from '../../domain/surveyor/interface/model.interface'
import {
    ISurveyorFilterSchema,
    ISurveyorRepository,
} from '../../domain/surveyor/interface/repository.interface'
import {
    from,
    Observable,
} from 'rxjs'
import {
    Db,
    ObjectId,
} from 'mongodb'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { ISurveyorSchema } from './surveyor.schema'
import {
    map,
    tap,
    throwIfEmpty,
} from 'rxjs/operators'
import * as _ from 'lodash'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'

export class SurveyorRepository extends MongoRepository<ISurveyorModel> implements ISurveyorRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<ISurveyorModel, ISurveyorSchema>,
    ) {
        super(
            db.collection<ISurveyorSchema>('surveyorZone'),
            mapping,
        )
    }

    public listByLocation(filter: ISurveyorFilterSchema): Observable<ISurveyorModel> {
        const mongoFilter = {
            serviceArea: {
                $elemMatch: {
                    province: new RegExp(filter.province),
                    district: new RegExp(filter.district),
                },
            },
        }
        const cursor = this._collection.find(mongoFilter)
        return this.toObservable(cursor).pipe(
            throwIfEmpty(() => {
                throw new HttpException(`Cannot find surveyor`, HttpStatus.NOT_FOUND)
            }),
        )
    }

    public update(model: ISurveyorModel): Observable<boolean> {
        const schema = this.toDocument(model)
        const id = schema._id
        delete schema._id
        const promise = this._collection.updateOne({
            _id: id,
        }, {
            $set: schema,
        })

        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot update surveyor`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return result.modifiedCount === 1
            }),
        )
    }

    public upsert(model: ISurveyorModel): Observable<boolean> {
        const schema = this.toDocument(model)
        const id = schema._id
        delete schema._id
        const promise = this._collection.updateOne({
            _id: id,
        }, {
            $set: schema,
        }, {
            upsert: true,
        })

        return from(promise).pipe(
            map(result => {
                if (result.result.ok === 0) {
                    throw new HttpException(
                        `Cannot update surveyor`,
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    )
                }
                return result.modifiedCount === 1 || result.upsertedCount === 1
            }),
        )
    }

    public getById(id: string): Observable<ISurveyorModel> {
        // const objectId = new ObjectId(id)
        const promise = this._collection.findOne({
            _id: id,
        })
        return from(promise).pipe(
            tap((schema: ISurveyorModel) => {
                if (_.isNil(schema)) {
                    throw new HttpException(`Cannot find surveyor ${id}`, HttpStatus.NOT_FOUND)
                }
            }),
            map(schema => this.toModel(schema)),
        )
    }

    public getByAssignJob(jobId: string): Observable<ISurveyorModel> {
        const promise = this._collection.findOne({
            'jobs.assigned': jobId,
        })
        return from(promise).pipe(
            tap((schema: ISurveyorModel) => {
                if (_.isNil(schema)) {
                    throw new HttpException(`Cannot find job ${jobId} by incidentID`, HttpStatus.NOT_FOUND)
                }
            }),
            map(schema => this.toModel(schema)),
        )
    }

    public removeById(id: string): Observable<boolean> {
        const promise = this._collection.deleteOne({_id: id})
        return from(promise)
            .pipe(
                map(result => {
                    if (result.result.ok === 0) {
                        throw new HttpException(
                            `Cannot delete surveyor`,
                            HttpStatus.INTERNAL_SERVER_ERROR,
                        )
                    }
                    return result.deletedCount === 1
                }),
            )
    }

}
