import { ObjectId } from 'mongodb'

export interface IGuaranteeZoneSchema {
    _id: ObjectId
    provinceTH: string
    provinceEN: string
    districtTH: string
    districtEN: string
    guaranteeMinute: number
}
