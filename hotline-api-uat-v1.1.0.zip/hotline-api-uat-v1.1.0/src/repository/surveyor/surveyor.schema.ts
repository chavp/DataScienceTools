export interface ISurveyorSchema {
    _id: string,
    partnerCompany: string
    serviceTypeDesc: string
    condition: string
    companyName: string
    companyPhone: string
    address: string
    ownerName: string
    ownerPhone: string
    remark: string
    groupName: string
    companyInitial: string
    serviceArea: Array<{
        province: string
        district: string[]
    }>,
    jobs: {
        assigned: string[]
        closed: string[]
    }
}
