import { ObjectId } from 'mongodb'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import {
    IServiceAreaSchema,
    ISurveyorModel,
} from '../../domain/surveyor/interface/model.interface'
import { ISurveyorSchema } from './surveyor.schema'
import {
    classToPlain,
    plainToClass,
} from 'class-transformer'
import { SurveyorModel } from '../../domain/surveyor/surveyor.model'
import * as _ from 'lodash'

export class SurveyorRepositoryMapping implements IRepositoryMapping<ISurveyorModel, ISurveyorSchema> {
    public deserialize(schema: ISurveyorSchema): ISurveyorModel {

        const serviceArea: Map<string, IServiceAreaSchema> = new Map<string, IServiceAreaSchema>()
        const areaSchema = schema.serviceArea
        _.forEach(areaSchema, value => {
            serviceArea.set(value.province, value)
        })

        let assigned
        let closed
        if (!_.isNil(schema.jobs)) {
            assigned = schema.jobs.assigned || []
            closed = schema.jobs.closed || []
        }

        return plainToClass(SurveyorModel, {
            _id: schema._id,
            _name: schema.companyName,
            _address: schema.address,
            _phone: schema.companyPhone,
            _condition: schema.condition,
            _groupName: schema.groupName,
            _assignedJob: assigned,
            _closedJob: closed,
            _ownerName: schema.ownerName,
            _ownerPhone: schema.ownerPhone,
            _partnerCompany: schema.partnerCompany,
            _remark: schema.remark,
            _serviceTypeDesc: schema.serviceTypeDesc,
            _companyInitial: schema.companyInitial,
            _serviceArea: serviceArea,
        })
    }

    public serialize(model: ISurveyorModel): ISurveyorSchema {
        const plain: any = classToPlain(model)
        const serviceAreaMap: Map<string, IServiceAreaSchema> = model.getServiceArea()
        const serviceArea = []
        serviceAreaMap.forEach((value => {
            serviceArea.push(value)
        }))

        return {
            _id: plain._id,
            address: _.get(plain, '_address'),
            companyName: _.get(plain, '_name'),
            companyPhone: _.get(plain, '_phone'),
            condition: _.get(plain, '_condition'),
            groupName: _.get(plain, '_groupName'),
            jobs: {
                assigned: _.get(plain, '_assignedJob'),
                closed: _.get(plain, '_closedJob'),
            },
            ownerName: _.get(plain, '_ownerName'),
            ownerPhone: _.get(plain, '_ownerPhone'),
            partnerCompany: _.get(plain, '_partnerCompany'),
            remark: _.get(plain, '_remark'),
            serviceArea,
            serviceTypeDesc: _.get(plain, '_serviceTypeDesc'),
            companyInitial: _.get(plain, '_companyInitial'),
        }
    }

}
