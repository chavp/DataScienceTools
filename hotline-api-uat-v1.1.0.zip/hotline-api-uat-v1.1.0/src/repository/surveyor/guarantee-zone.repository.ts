import { MongoRepository } from '../../common/mongo-repository'
import { IGuaranteeZoneRepository } from '../../domain/surveyor/interface/repository.interface'
import {
    IGuaranteeZoneModel,
    ISurveyorModel,
} from '../../domain/surveyor/interface/model.interface'
import {
    from,
    Observable,
    of,
} from 'rxjs'
import {
    Db,
    ObjectId,
} from 'mongodb'
import { IRepositoryMapping } from '../../common/interface/repository.interface'
import { IGuaranteeZoneSchema } from './guarantee-zone.schema'
import {
    map,
    mergeMap,
    tap,
} from 'rxjs/operators'
import {
    BadRequestException,
    NotFoundException,
} from '@nestjs/common'
import * as _ from 'lodash'
import * as FileSystem from 'fs'
import * as Path from 'path'

export class GuaranteeZoneRepository extends MongoRepository<IGuaranteeZoneModel> implements IGuaranteeZoneRepository {
    constructor(
        db: Db,
        mapping: IRepositoryMapping<IGuaranteeZoneModel, IGuaranteeZoneSchema>,
    ) {
        super(
            db.collection('guarantee-zone'),
            mapping,
        )
        this._collection.deleteMany({})
            .then(() => {
                const absPath = Path.resolve('./resource/guarantee-zone.json')
                return FileSystem.promises.readFile(absPath)
            })
            .then((fileBuffer: Buffer) => {
                const json = JSON.parse(fileBuffer.toString('utf-8'))
                return this._collection.insertMany(json)
            })
    }

    public getById(id: string): Observable<IGuaranteeZoneModel> {
        return of(id).pipe(
            tap(expectedId => {
                if (!ObjectId.isValid(expectedId)) {
                    throw  new BadRequestException(`Invalid Id`)
                }
            }),
            mergeMap(expected => {
                const promise = this._collection.findOne({
                    _id: new ObjectId(expected),
                })
                return from(promise)
            }),
            tap((schema) => {
                if (_.isNil(schema)) {
                    throw new NotFoundException(`Cannot find zone ${id}`)
                }
            }),
            map(schema => {
                return this.toModel(schema)
            }),
        )
    }

    public listByProvinceEN(provinceNameEN: string): Observable<IGuaranteeZoneModel> {
        const cursor = this._collection.find({
            provinceEN: provinceNameEN,
        })
        return this.toObservable(cursor)
    }

    public listByProvinceTH(provinceNameTH: string): Observable<IGuaranteeZoneModel> {
        const cursor = this._collection.find({
            provinceTH: provinceNameTH,
        })
        return this.toObservable(cursor)
    }

}
