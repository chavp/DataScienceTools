import { ProviderName } from './index'
import {
    Db,
    MongoClient,
} from 'mongodb'
import { IConfig } from '../common/interface/config.interface'
import { Provider as NestProviderInterface } from '@nestjs/common'
import {
    config as MsSqlConfig,
    ConnectionPool,
} from 'mssql'
import * as _ from 'lodash'
import * as qs from 'qs'
import * as mysql from 'mysql'
import * as odbc from 'odbc'
import * as odbcConnection from 'odbc'
import * as connectMongo from 'connect-mongo'
import * as session from 'express-session'

const {
    MONGO_CONNECTION,
    CONFIG,
    MSSQL_CONNECTION,
    ODBC_CONNECTION,
    MYSQL_CONNECTION,
    MONGO_CLIENT,
    MONGO_SESSION_STORE,
} = ProviderName
export const databaseProviders: NestProviderInterface[] = [
    {
        provide: MONGO_CLIENT,
        useFactory: async (config: IConfig): Promise<MongoClient> => {
            if (config && config.mongodb) {
                const mongoConfig = config.mongodb
                const servers = process.env.MONGO_URL || mongoConfig.servers
                let auth = ''
                if (mongoConfig.username || mongoConfig.password) {
                    auth = `${mongoConfig.username}:${mongoConfig.password}@`
                }
                let url: string = 'mongodb://' + auth + servers
                    .split(',')
                    .map((server: string) => {
                        return server + ':' + mongoConfig.port
                    })
                    .toString() + '/' + mongoConfig.dbName

                const queryString: any = {}

                if (!_.isNil(mongoConfig.authSource)) {
                    queryString.authSource = mongoConfig.authSource
                }

                if (!_.isNil(mongoConfig.replicaSetName)) {
                    queryString.replicaSet = mongoConfig.replicaSetName
                }

                url += `?${qs.stringify(queryString)}`
                return await MongoClient.connect(url, {
                    useNewUrlParser: true,
                    useUnifiedTopology: true,
                })
            }

            return Promise.reject('Cannot connect MongoDB')
        },
        inject: [ CONFIG ],
    },
    {
        provide: MONGO_CONNECTION,
        useFactory: (client: MongoClient, config: IConfig): Db => {
            return client.db(config.mongodb.dbName)
        },
        inject: [
            MONGO_CLIENT,
            CONFIG,
        ],
    },
    {
        provide: MONGO_SESSION_STORE,
        inject: [
            MONGO_CLIENT,
            CONFIG,
        ],
        useFactory: (mongoClient: MongoClient, config: IConfig) => {
            const mongoStoreOpts = {
                client: mongoClient,
                dbName: config.mongodb.dbName,
                collection: 'sessions',
                autoRemove: 'interval',
                autoRemoveInterval: 60 * 24,
            }
            const MongoStore = connectMongo(session)
            return new MongoStore(mongoStoreOpts)
        },
    },
    {
        provide: MSSQL_CONNECTION,
        inject: [
            CONFIG,
        ],
        useFactory: (envConfig: IConfig): Promise<ConnectionPool> => {
            const mssqlConfig: MsSqlConfig = {
                database: envConfig.MssqlDB.dbName,
                parseJSON: true,
                password: envConfig.MssqlDB.password,
                port: envConfig.MssqlDB.port,
                server: envConfig.MssqlDB.servers,
                stream: false,
                user: envConfig.MssqlDB.username,
            }

            const pool = new ConnectionPool(mssqlConfig)
            return pool.connect().catch(err => {
                console.log('Cannot connect MSSQL DB:' + err)
                return Promise.resolve(null)
            })
        },
    },
    {
        provide: ODBC_CONNECTION,
        inject: [
            CONFIG,
        ],
        useFactory: async (envConfig: IConfig): Promise<odbcConnection> => {
            return await odbc.pool(envConfig.OdbcDB.connectionString).catch(err => {
                console.log('Cannot connect Cisco ODBC:' + err)
                return Promise.resolve(null)
            })
        },
    },
    {
        provide: MYSQL_CONNECTION,
        inject: [
            CONFIG,
        ],
        useFactory: async (config: IConfig): Promise<any> => {
            const connection: mysql.Connection = mysql.createConnection({
                host: config.MySqlDB.host,
                database: config.MySqlDB.database,
                user: config.MySqlDB.user,
                password: config.MySqlDB.password,
                port: config.MySqlDB.port,
            })
            await connection.connect((err) => {
                if (err) {
                    console.error('error connecting mysql: ' + err.stack)
                    return
                }

                console.log('connected mysql as id ' + connection.threadId)
            })
            return connection
        },
    },
]
