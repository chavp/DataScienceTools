import { FactoryProvider } from '@nestjs/common/interfaces'
import { ProviderName } from './index'
import { DomainEventPublisher } from '../pubsub/domain-event.publisher'
import { IncidentSurveyorAssignedSubscriber } from '../domain/surveyor-case/pubsub/subscriber/incident-surveyor-assigned-subscriber'
import { IConfig } from '../common/interface/config.interface'
import {
    IGuaranteeZoneRepository,
    ISurveyorRepository,
} from '../domain/surveyor/interface/repository.interface'
import { IIncidentRepository } from '../domain/incident/interface'
import { ISurveyorCaseRepository } from '../domain/surveyor-case/interface/repository.interface'
import {
    ManagementQAQuerySubscriber,
    SaveManagementQAQuerySubscriber,
} from '../domain/recorderQA/pubsub/subscriber/managementQA.query.subscriber'
import { IRecorderQARepository } from '../domain/recorderQA/interface/recorderQA.repository.interface'
import { IManagementQARepository } from '../domain/managementQA/interface/repository.interface'
import { IMessageRepository } from '../domain/message/interface'
import { MessageLocationSubscriber } from '../domain/message/pubsub/subscriber/message.location.subscriber'
import { MessageImageSubscriber } from '../domain/message/pubsub/subscriber/message.image.subscriber'
import { MessageTextSubscriber } from '../domain/message/pubsub/subscriber/message.text.subscriber'
import { MessageStickerSubscriber } from '../domain/message/pubsub/subscriber/message.sticker.subscriber'
import { IWebSocketAdapter } from '../adapter/notification/interfaces/socket.interface'
import { UpdateSurveyorAssignmentSubscriber } from '../domain/message/pubsub/subscriber/surveyor.assignment.subscriber'
import { ILineAdapter } from '../adapter/line/interface/line.interface'
import { IAuthService } from '../common/interface/auth.interface'
import { ISurveyorLineRepository } from '../domain/surveyor-line/interface/repository.interface'
import { ILineProfileRepository } from '../domain/line/interface'
import { LineUserFollowedSubscriber } from '../domain/message/pubsub/subscriber/line-user-followed.subscriber'
import { LineUserUnfollowedSubscriber } from '../domain/message/pubsub/subscriber/line-user-unfollowed.subscriber'
import { ISurveyorCaseArriveBuilder } from '../domain/surveyor-case/interface/builder.confirmArrive.interface'
import { ScheduleSubscriber } from '../domain/scheduler/pubsub/subscriber/schedule-subscriber'
import { ISchedulerTasksRepository } from '../domain/scheduler/interface/repository.interface'
import { IScheduleManager } from '../domain/scheduler/interface/service.interface'
import { ILoggerService } from '../common/interface/logger.interface'

export const eventBusProvider: FactoryProvider = {
    provide: ProviderName.EVENT_BUS,
    useFactory: () => {
        return new DomainEventPublisher()
    },

}

export const domainEventSubscribers: FactoryProvider[] = [
    {
        provide: ProviderName.INCIDENT_SURVEYOR_ASSIGNED,
        inject: [
            ProviderName.CONFIG,
            ProviderName.SURVEYOR_REPOSITORY,
            ProviderName.SURVEYOR_CASE_REPOSITORY,
            ProviderName.INCIDENT_REPOSITORY,
            ProviderName.LINE_ADAPTER,
            ProviderName.WEB_SOCKET_ADAPTER,
            ProviderName.AUTH_SERVICE,
            ProviderName.SURVEYOR_LINE_REPOSITORY,
            ProviderName.MESSAGE_REPOSITORY,
            ProviderName.LOGGER_SERVICE,
        ],
        useFactory: (
            config: IConfig,
            surveyor: ISurveyorRepository,
            surveyorCase: ISurveyorCaseRepository,
            incident: IIncidentRepository,
            lineAdapter: ILineAdapter,
            socketAdapter: IWebSocketAdapter,
            auth: IAuthService,
            surveyorLineRepo: ISurveyorLineRepository,
            message: IMessageRepository,
            logger: ILoggerService,
        ) => new IncidentSurveyorAssignedSubscriber(
            config,
            surveyor,
            surveyorCase,
            incident,
            lineAdapter,
            socketAdapter,
            auth,
            surveyorLineRepo,
            message,
            logger,
        ),
    },
    {
        provide: ProviderName.RECORDER_QA_MANAGEMENT,
        inject: [
            ProviderName.RECORDER_QA_REPOSITORY,
        ],
        useFactory: (
            recorder: IRecorderQARepository,
        ) => new ManagementQAQuerySubscriber(recorder),
    },
    {
        provide: ProviderName.SAVE_QA_MANAGEMENT,
        inject: [
            ProviderName.RECORDER_QA_REPOSITORY,
            ProviderName.MANAGEMENT_QA_REPOSITORY,
        ],
        useFactory: (
            recorder: IRecorderQARepository,
            management: IManagementQARepository,
        ) => new SaveManagementQAQuerySubscriber(recorder, management),
    },
    {
        provide: ProviderName.MESSAGE_LOCATION_SUBSCRIBER,
        inject: [
            ProviderName.MESSAGE_REPOSITORY,
            ProviderName.WEB_SOCKET_ADAPTER,
        ],
        useFactory: (
            messageRepository: IMessageRepository,
            socketAdapter: IWebSocketAdapter,
        ) => {
            return new MessageLocationSubscriber(messageRepository, socketAdapter)
        },
    },
    {
        provide: ProviderName.MESSAGE_IMAGE_SUBSCRIBER,
        inject: [
            ProviderName.MESSAGE_REPOSITORY,
            ProviderName.WEB_SOCKET_ADAPTER,
        ],
        useFactory: (
            messageRepository: IMessageRepository,
            socketAdapter: IWebSocketAdapter,
        ) => {
            return new MessageImageSubscriber(messageRepository, socketAdapter)
        },
    },
    {
        provide: ProviderName.MESSAGE_TEXT_SUBSCRIBER,
        inject: [
            ProviderName.MESSAGE_REPOSITORY,
            ProviderName.WEB_SOCKET_ADAPTER,
        ],
        useFactory: (
            messageRepository: IMessageRepository,
            socketAdapter: IWebSocketAdapter,
        ) => {
            return new MessageTextSubscriber(messageRepository, socketAdapter)
        },
    },
    {
        provide: ProviderName.MESSAGE_STICKER_SUBSCRIBER,
        inject: [
            ProviderName.MESSAGE_REPOSITORY,
            ProviderName.WEB_SOCKET_ADAPTER,
        ],
        useFactory: (
            messageRepository: IMessageRepository,
            socketAdapter: IWebSocketAdapter,
        ) => {
            return new MessageStickerSubscriber(messageRepository, socketAdapter)
        },
    },
    {
        provide: ProviderName.UPDATE_SURVEYOR_ASSIGNMENT_SUBSCRIBER,
        inject: [
            ProviderName.CONFIG,
            ProviderName.WEB_SOCKET_ADAPTER,
            ProviderName.LINE_ADAPTER,
            ProviderName.AUTH_SERVICE,
            ProviderName.MESSAGE_REPOSITORY,
            ProviderName.SURVEYOR_LINE_REPOSITORY,
            ProviderName.LINE_PROFILE_REPOSITORY,
            ProviderName.CONFIRM_SURVEYOR_ARRIVE_BUILDER,
            ProviderName.GUARANTEE_ZONE_REPOSITORY,
        ],
        useFactory: (
            config: IConfig,
            socketAdapter: IWebSocketAdapter,
            lineAdapter: ILineAdapter,
            auth: IAuthService,
            messageRepository: IMessageRepository,
            surveyorLineRepository: ISurveyorLineRepository,
            lineProfileRepository: ILineProfileRepository,
            surveyorCaseArriveBuilder: ISurveyorCaseArriveBuilder,
            guaranteeZoneRepository: IGuaranteeZoneRepository,
        ) => {
            return new UpdateSurveyorAssignmentSubscriber(
                config,
                socketAdapter,
                lineAdapter,
                auth,
                messageRepository,
                surveyorLineRepository,
                lineProfileRepository,
                surveyorCaseArriveBuilder,
                guaranteeZoneRepository,
            )
        },
    },
    {
        provide: ProviderName.MESSAGE_LINE_BOT_FOLLOWED_SUBSCRIBER,
        inject: [
            ProviderName.WEB_SOCKET_ADAPTER,
        ],
        useFactory: (socket: IWebSocketAdapter) => {
            return new LineUserFollowedSubscriber(socket)
        },
    },
    {
        provide: ProviderName.MESSAGE_LINE_BOT_UNFOLLOWED_SUBSCRIBER,
        inject: [
            ProviderName.WEB_SOCKET_ADAPTER,
        ],
        useFactory: (socket: IWebSocketAdapter) => {
            return new LineUserUnfollowedSubscriber(socket)
        },
    },
    {
        provide: ProviderName.CASE_NOT_ARRIVE_SUBSCRIBER,
        inject: [
            ProviderName.SCHEDULER_TASK_MANAGER,
            ProviderName.SCHEDULER_REPOSITORY,
        ],
        useFactory: (
            taskManager: IScheduleManager,
            schedulerRepository: ISchedulerTasksRepository,
        ) => {
            return new ScheduleSubscriber(taskManager, schedulerRepository)
        },
    },

]
