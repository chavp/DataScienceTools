import { Provider } from '@nestjs/common'
import { ProviderName } from './index'
import { IConfig } from '../common/interface/config.interface'
import { ImageStorage } from '../common/image-storage'
import * as _ from 'lodash'

export const imageStorageProviders: Provider[] = [
    {
        provide: ProviderName.SURVEYOR_CASE_IMAGE_STORAGE,
        inject: [
            ProviderName.CONFIG,
        ],
        useFactory: (config: IConfig) => {
            const imagePrefix: string = _.get(config, 'imageStorage.surveyorCase.prefix', '')
            const fileDirPath: string = _.get(config, 'imageStorage.surveyorCase.path', )
            return new ImageStorage(
                imagePrefix,
                fileDirPath,
            )

        },
    },
]
