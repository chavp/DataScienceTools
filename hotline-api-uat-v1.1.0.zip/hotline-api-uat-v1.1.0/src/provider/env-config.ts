import { Provider as NestProviderInterface } from '@nestjs/common'

import { ProviderName } from '.'
import * as Config from 'config'
import { IConfig } from '../common/interface/config.interface'

const {
    CONFIG,
} = ProviderName

export const environmentConfig: NestProviderInterface[] = [
    {
        provide: CONFIG,
        useFactory: (): IConfig => Config.util.toObject(),
    },
]
