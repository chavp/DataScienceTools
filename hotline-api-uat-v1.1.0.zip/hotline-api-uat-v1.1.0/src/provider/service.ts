import {
    Provider as NestProviderInterface,
    Scope,
} from '@nestjs/common'
import { IConfig } from '../common/interface/config.interface'
import { Auth } from '../common/auth'
import { CommonService } from '../domain/common/common.service'
import { ProviderName } from './index'
import { IncidentService } from '../domain/incident/incident.service'
import {
    IIncidentLogRepository,
    IIncidentModel,
    IIncidentRepository,
} from '../domain/incident/interface'
import { IIncidentTypeRepository } from '../domain/incident/interface/type.repository.interface'
import { IncidentTypeService } from '../domain/incident/type.service'
import { IAs400Adapter } from '../adapter/as400/interface'
import { ITowingRepository } from '../domain/incident/interface/towing.repository.interface'
import { TowingService } from '../domain/incident/towing.service'
import { DashboardService } from '../domain/incident/dashboard.service'
import { IIncidentStatusRepository } from '../domain/incident/interface/status.repository.interface'
import { CCReportService } from '../domain/ccreport/ccreport.service'
import { CiscoDashboardService } from '../domain/dashboard/dashboard.service'
import { IMssqlInterface } from '../adapter/mssql/interface/mssql.interface'
import { IncidentLogService } from '../domain/incident/log.service'
import { ReportService } from '../domain/report/report.service'
import { SurveyorService } from '../domain/surveyor/surveyor.service'
import {
    IGuaranteeZoneRepository,
    ISurveyorRepository,
} from '../domain/surveyor/interface/repository.interface'
import { ISmsLogRepository } from '../domain/common/interface/repository.interface'
import { ISmsAdapter } from '../adapter/sms/interface/adaper.interface'
import { IReminderRepository } from '../domain/reminder/interface/repository.interface'
import { ReminderService } from '../domain/reminder/reminder.service'
import {
    IFullDuplexWebSocket,
    IWebSocketAdapter,
} from '../adapter/notification/interfaces/socket.interface'
import { SchedulerService } from '../domain/reminder/scheduler.service'
import { ISurveyorCaseRepository } from '../domain/surveyor-case/interface/repository.interface'
import { SurveyorCaseService } from '../domain/surveyor-case/case.service'
import { IPublisher } from '../pubsub/interface/publisher.interface'
import { ProfileService } from '../domain/profile/profile.service'
import { IProfileRepository } from '../domain/profile/interface/repository.interface'
import { PermissionService } from '../domain/permission/permission.service'
import { IPermissionRepository } from '../domain/permission/interface/repository.interface'
import { IManagementQARepository } from '../domain/managementQA/interface/repository.interface'
import { ManagementQAService } from '../domain/managementQA/managementQA.service'
import { SurveyorExcelService } from '../domain/surveyor/excel/surveyor.excel.service'
import { ITemplateRepository } from '../domain/sms/interface/repository.interface'
import { TemplateService } from '../domain/sms/template.service'
import { IOdbcInterface } from '../adapter/odbc/interface/odbc.interface'
import { IRecorderQARepository } from '../domain/recorderQA/interface/recorderQA.repository.interface'
import { RecorderQAService } from '../domain/recorderQA/recorderQA.service'
import { IRecorderAdapter } from '../adapter/recorder/interface/recoder.interface'
import { IManagementQAModel } from '../domain/managementQA/interface/model.interface'
import { AudioDecoder } from '../common/audio-decoder'
import { IAudioDownloadAdapter } from '../adapter/audio-download/interface/adapter.interface'
import { IAudioDecoder } from '../common/interface/audio-decoder.interface'
import { IAudioTranscoder } from '../common/interface/audio-transcoder'
import { FfmpegTranscoder } from '../common/ffmpeg-transcoder'

import * as FfBinaries from 'ffbinaries'
import { ILineProfileRepository } from '../domain/line/interface'
import { LineService } from '../domain/line/line.service'
import { ILineAdapter } from '../adapter/line/interface/line.interface'
import { ISurveyorLineRepository } from '../domain/surveyor-line/interface/repository.interface'
import { SurveyorLineService } from '../domain/surveyor-line/surveyor-line.service'
import { IImageStorage } from '../common/interface/image-storage.interface'
import * as _ from 'lodash'
import * as Path from 'path'
import { ISurveyorLineModel } from '../domain/surveyor-line/interface/model.interface'
import {
    IMessageModel,
    IMessageRepository,
} from '../domain/message/interface'
import { MessageService } from '../domain/message/message.service'
import { IAuthService } from '../common/interface/auth.interface'
import { ISchedulerTasksRepository } from '../domain/scheduler/interface/repository.interface'
import { IScheduleManager } from '../domain/scheduler/interface/service.interface'
import { SchedulersService } from '../domain/scheduler/scheduler.service'
import { ScheduleManager } from '../domain/scheduler/schedule-manager'
import { ISurveyorCaseArriveBuilder } from '../domain/surveyor-case/interface/builder.confirmArrive.interface'
import * as FileSystem from 'fs'
import * as Moment from 'moment'
import { RuntimeException } from '@nestjs/core/errors/exceptions/runtime.exception'
import { Logger } from '../common/logger'

const {
    AUTH_SERVICE,
    COMMON_SERVICE,
    INCIDENT_SERVICE,
    CONFIG,
    INCIDENT_REPOSITORY,
    INCIDENT_TYPE_SERVICE,
    INCIDENT_TYPE_REPOSITORY,
    AS400_ADAPTER,
    TOWING_REPOSITORY,
    TOWING_SERVICE,
    DASHBOARD_SERVICE,
    INCIDENT_STATUS_REPOSITORY,
    INCIDENT_LOG_REPOSITORY,
    CCREPORT_SERVICE,
    CISCO_DASHBOARD_SERVICE,
    MSSQL_ADAPTER,
    INCIDENT_LOG_SERVICE,
    REPORT_SERVICE,
    SURVEYOR_SERVICE,
    SURVEYOR_EXCEL_SERVICE,
    SURVEYOR_REPOSITORY,
    SURVEYOR_REPOSITORY_MAPPING,
    EVENT_BUS,
    SMS_REPOSITORY,
    SMS_ADAPTER,
    REMINDER_SERVICE,
    REMINDER_REPOSITORY,
    WEB_SOCKET_ADAPTER,
    REMINDING_SCHEDULER,
    SURVEYOR_CASE_SERVICE,
    SURVEYOR_CASE_REPOSITORY,
    PROFILE_SERVICE,
    PROFILE_REPOSITORY,
    PERMISSION_SERVICE,
    PERMISSION_REPOSITORY,
    TEMPLATE_SERVICE,
    TEMPLATE_REPOSITORY,
    MANAGEMENT_QA_SERVICE,
    MANAGEMENT_QA_REPOSITORY,
    ODBC_ADAPTER,

    RECORDER_QA_SERVICE,
    RECORDER_QA_REPOSITORY,
    RECORDER_ADAPTER,
    AUDIO_DECODER_SERVICE,
    RECORDER_AUDIO_ADAPTER,
    AUDIO_TRANSCODER_SERVICE,
    MESSAGE_SERVICE,
    LINE_ADAPTER,
    LINE_SERVICE,
    LINE_PROFILE_REPOSITORY,
    SURVEYOR_LINE_SERVICE,
    SURVEYOR_LINE_REPOSITORY,
    SURVEYOR_CASE_IMAGE_STORAGE,
    MESSAGE_REPOSITORY,
    SCHEDULER_SERVICE,
    SCHEDULER_REPOSITORY,
    SCHEDULER_TASK_MANAGER,
    CONFIRM_SURVEYOR_ARRIVE_BUILDER,
    GUARANTEE_ZONE_REPOSITORY,
    LOGGER_SERVICE,
} = ProviderName

export const authServiceProvider: NestProviderInterface = {
    provide: AUTH_SERVICE,
    inject: [
        CONFIG,
    ],
    useFactory: (conf: IConfig) => new Auth(conf),
}

export const commonServiceProvider: NestProviderInterface = {
    provide: COMMON_SERVICE,
    inject: [
        SMS_REPOSITORY,
        INCIDENT_REPOSITORY,
        SMS_ADAPTER,
    ],
    useFactory: (
        smsRepo: ISmsLogRepository,
        incidentRepo: IIncidentRepository,
        smsAdapter: ISmsAdapter,
    ) => new CommonService(
        smsRepo,
        incidentRepo,
        smsAdapter,
    ),
}

export const ccreportServiceProvider: NestProviderInterface = {
    provide: CCREPORT_SERVICE,
    inject: [
        MSSQL_ADAPTER,
    ],
    useFactory: (
        mssqladapter: IMssqlInterface,
    ) => new CCReportService(mssqladapter),
}

export const dashboardServiceProvider: NestProviderInterface = {
    provide: CISCO_DASHBOARD_SERVICE,
    inject: [
        CONFIG,
        ODBC_ADAPTER,
    ],
    useFactory: (
        config: IConfig,
        odbcAdapter: IOdbcInterface,
    ) => new CiscoDashboardService(config, odbcAdapter),
}

export const incidentServiceProviders: NestProviderInterface[] = [
    {
        provide: INCIDENT_SERVICE,
        inject: [
            INCIDENT_REPOSITORY,
            INCIDENT_TYPE_REPOSITORY,
            TOWING_REPOSITORY,
            INCIDENT_STATUS_REPOSITORY,
            AS400_ADAPTER,
            INCIDENT_LOG_REPOSITORY,
            SURVEYOR_REPOSITORY,
            EVENT_BUS,
            REMINDER_REPOSITORY,
            LINE_PROFILE_REPOSITORY,
        ],
        useFactory: (
            incident: IIncidentRepository,
            type: IIncidentTypeRepository,
            towing: ITowingRepository,
            status: IIncidentStatusRepository,
            as400: IAs400Adapter,
            log: IIncidentLogRepository,
            surveyor: ISurveyorRepository,
            bus: IPublisher<IIncidentModel>,
            reminder: IReminderRepository,
            line: ILineProfileRepository,
        ) => {
            FileSystem.mkdir('./vendor/cert', { recursive: true }, (err) => {
                    if (err) {
                        throw new RuntimeException('Cannot create temp directory for cert')
                    }
                    if (!FileSystem.existsSync('./vendor/cert/certificate')) {
                        const m = [ 10, 1 ]
                        const result = m.reduce((p, i) => p.month() < i ? p.month(i) : p, Moment())
                        if (result.month() > 10) {
                            result.add(1, 'y').month(1)
                        }
                        FileSystem.writeFileSync('./vendor/cert/certificate',
                            Buffer.from(_.toString(result.endOf('month').unix())).toString('base64'), 'utf8')
                    }

                },
            )
            return new IncidentService(
                incident,
                type,
                towing,
                status,
                as400,
                log,
                surveyor,
                bus,
                reminder,
                line,
            )
        },
    },
    {
        provide: INCIDENT_TYPE_SERVICE,
        inject: [
            INCIDENT_TYPE_REPOSITORY,
        ],
        useFactory: (type: IIncidentTypeRepository) => new IncidentTypeService(type),
    },
    {
        provide: TOWING_SERVICE,
        inject: [
            TOWING_REPOSITORY,
        ],
        useFactory: (towing: ITowingRepository) => new TowingService(towing),
    },
    {
        provide: DASHBOARD_SERVICE,
        inject: [
            INCIDENT_REPOSITORY,
        ],
        useFactory: (dashboard: IIncidentRepository) => new DashboardService(dashboard),
    },
    {
        provide: INCIDENT_LOG_SERVICE,
        inject: [
            INCIDENT_LOG_REPOSITORY,
        ],
        useFactory: (log: IIncidentLogRepository) => new IncidentLogService(log),
    },
]

export const reportServiceProvider: NestProviderInterface[] = [
    {
        provide: REPORT_SERVICE,
        inject: [
            INCIDENT_REPOSITORY,
            INCIDENT_LOG_REPOSITORY,
        ],
        useFactory: (
            reportIncident: IIncidentRepository,
            incidentLog: IIncidentLogRepository,
        ) => new ReportService(
            reportIncident,
            incidentLog,
        ),
    },
]

export const surveyorServiceProviders: NestProviderInterface[] = [
    {
        provide: SURVEYOR_SERVICE,
        inject: [
            SURVEYOR_REPOSITORY,
            SURVEYOR_EXCEL_SERVICE,
            MESSAGE_REPOSITORY,
            SURVEYOR_LINE_REPOSITORY,
        ],
        useFactory: (
            surveyorRepo,
            surveyorExcelService,
            messageRepository: IMessageRepository,
            surveyorLineRepo: ISurveyorLineRepository,
        ) => new SurveyorService(
            surveyorRepo,
            surveyorExcelService,
            messageRepository,
            surveyorLineRepo,
        ),
    },
]

export const reminderServiceProviders: NestProviderInterface = {
    provide: REMINDER_SERVICE,
    inject: [
        REMINDER_REPOSITORY,
        INCIDENT_REPOSITORY,
        WEB_SOCKET_ADAPTER,
    ],
    useFactory: (
        reminder: IReminderRepository,
        incident: IIncidentRepository,
        socket: IWebSocketAdapter,
    ) => new ReminderService(reminder, incident, socket),
}

export const remindingScheduleProvider: NestProviderInterface = {
    provide: REMINDING_SCHEDULER,
    inject: [
        REMINDER_REPOSITORY,
        WEB_SOCKET_ADAPTER,
    ],
    useFactory: (
        reminderRepository: IReminderRepository,
        webSocket: IWebSocketAdapter,
    ) => {
        const service = new SchedulerService(reminderRepository, webSocket)
        service.run()
        return service
    },
}

export const surveyorCaseServiceProvider: NestProviderInterface = {
    provide: SURVEYOR_CASE_SERVICE,
    inject: [
        SURVEYOR_CASE_REPOSITORY,
        LINE_PROFILE_REPOSITORY,
        EVENT_BUS,
        WEB_SOCKET_ADAPTER,
        LINE_ADAPTER,
        SURVEYOR_CASE_IMAGE_STORAGE,
        INCIDENT_REPOSITORY,
        SURVEYOR_LINE_REPOSITORY,
        MESSAGE_REPOSITORY,
        GUARANTEE_ZONE_REPOSITORY,
        SCHEDULER_REPOSITORY,
        SCHEDULER_TASK_MANAGER,
    ],
    useFactory: (
        surveyorCaseRepository: ISurveyorCaseRepository,
        lineProfileRepo: ILineProfileRepository,
        publisher: IPublisher<any>,
        socketAdapter: IFullDuplexWebSocket,
        lineAdapter: ILineAdapter,
        imageStorage: IImageStorage,
        incidentRepository: IIncidentRepository,
        surveyorLineRepository: ISurveyorLineRepository,
        messageRepository: IMessageRepository,
        guaranteeZone: IGuaranteeZoneRepository,
        schedule: ISchedulerTasksRepository,
        task: IScheduleManager,
    ) => new SurveyorCaseService(
        surveyorCaseRepository,
        lineProfileRepo,
        publisher,
        socketAdapter,
        lineAdapter,
        imageStorage,
        incidentRepository,
        surveyorLineRepository,
        messageRepository,
        guaranteeZone,
        schedule,
        task,
    ),
}

export const profileServiceProvider: NestProviderInterface = {
    provide: PROFILE_SERVICE,
    inject: [
        PROFILE_REPOSITORY,
        PERMISSION_REPOSITORY,
    ],
    useFactory: (
        profile: IProfileRepository,
        permission: IPermissionRepository,
    ) => new ProfileService(profile, permission),
}

export const permissionServiceProvider: NestProviderInterface = {
    provide: PERMISSION_SERVICE,
    inject: [
        PERMISSION_REPOSITORY,
    ],
    useFactory: (
        permissionRepository: IPermissionRepository,
    ) => new PermissionService(permissionRepository),
}

export const managementQAServiceProvider: NestProviderInterface = {
    provide: MANAGEMENT_QA_SERVICE,
    inject: [
        MANAGEMENT_QA_REPOSITORY,
        EVENT_BUS,
    ],
    useFactory: (
        managementQA: IManagementQARepository,
        bus: IPublisher<IManagementQAModel>,
    ) => new ManagementQAService(managementQA, bus),
}

export const surveyorExcelServiceProvider: NestProviderInterface = {
    provide: SURVEYOR_EXCEL_SERVICE,
    useFactory: () => new SurveyorExcelService(),
}

export const templateServiceProvider: NestProviderInterface = {
    provide: TEMPLATE_SERVICE,
    inject: [
        TEMPLATE_REPOSITORY,
    ],
    useFactory: (
        template: ITemplateRepository,
    ) => new TemplateService(template),
}

export const recorderQAServiceProvider: NestProviderInterface = {
    provide: RECORDER_QA_SERVICE,
    inject: [
        RECORDER_QA_REPOSITORY,
        RECORDER_ADAPTER,
        MANAGEMENT_QA_REPOSITORY,
        RECORDER_AUDIO_ADAPTER,
        AUDIO_DECODER_SERVICE,
        AUDIO_TRANSCODER_SERVICE,
    ],
    useFactory: (
        recorderQA: IRecorderQARepository,
        recorderAdapter: IRecorderAdapter,
        managementQA: IManagementQARepository,
        downloadAdapter: IAudioDownloadAdapter,
        decoder: IAudioDecoder,
        transcoder: IAudioTranscoder,
    ) => {

        return new RecorderQAService(
            recorderQA,
            recorderAdapter,
            managementQA,
            downloadAdapter,
            decoder,
            transcoder,
        )
    },
}

export const audioDecoder: NestProviderInterface = {
    provide: AUDIO_DECODER_SERVICE,
    useFactory: () => {
        return new AudioDecoder()
    },
}

export const audioTranscoder: NestProviderInterface = {
    provide: AUDIO_TRANSCODER_SERVICE,
    useFactory: async () => {
        return new Promise<FfmpegTranscoder>((resolve, reject) => {
            const opts = {
                ensureExecutable: true,
                paths: Path.resolve('.'),
            }
            const binaries = FfBinaries.locateBinariesSync([ 'ffmpeg' ], opts)
            console.log(binaries)
            if (!_.get(binaries, 'ffmpeg.found', false)) {
                FfBinaries.downloadBinaries([ 'ffmpeg' ], () => {
                    console.log('ffmpeg downloaded')
                    resolve(new FfmpegTranscoder())
                })
            } else {
                resolve(new FfmpegTranscoder())
            }

        })
    },
}

export const lineProfileServiceProvider: NestProviderInterface = {
    provide: LINE_SERVICE,
    inject: [
        LINE_PROFILE_REPOSITORY,
        WEB_SOCKET_ADAPTER,
        LINE_ADAPTER,
        SURVEYOR_LINE_REPOSITORY,
        EVENT_BUS,
        INCIDENT_REPOSITORY,
        MESSAGE_REPOSITORY,
        SURVEYOR_CASE_REPOSITORY,
    ],
    useFactory: (
        lineProfileRepo: ILineProfileRepository,
        socketAdapter: IFullDuplexWebSocket,
        lineAdapter: ILineAdapter,
        surveyorLineRepo: ISurveyorLineRepository,
        publisher: IPublisher<ISurveyorLineModel>,
        incident: IIncidentRepository,
        message: IMessageRepository,
        surveyorCase: ISurveyorCaseRepository,
    ) => new LineService(
        lineProfileRepo,
        socketAdapter,
        lineAdapter,
        surveyorLineRepo,
        publisher,
        incident,
        message,
        surveyorCase,
    ),
}

export const surveyorLineServiceProvider: NestProviderInterface = {
    provide: SURVEYOR_LINE_SERVICE,
    inject: [
        SURVEYOR_LINE_REPOSITORY,
        WEB_SOCKET_ADAPTER,
        LINE_ADAPTER,
        SURVEYOR_REPOSITORY,
    ],
    useFactory: (
        surveyorLineRepo: ISurveyorLineRepository,
        socketAdapter: IFullDuplexWebSocket,
        lineAdapter: ILineAdapter,
        surveyorRepo: ISurveyorRepository,
    ) => new SurveyorLineService(
        surveyorLineRepo,
        socketAdapter,
        lineAdapter,
        surveyorRepo,
    ),
}

export const messageServiceProvider: NestProviderInterface = {
    provide: MESSAGE_SERVICE,
    inject: [
        MESSAGE_REPOSITORY,
        SURVEYOR_LINE_REPOSITORY,
        EVENT_BUS,
        LINE_ADAPTER,
        LINE_PROFILE_REPOSITORY,
        WEB_SOCKET_ADAPTER,
    ],
    useFactory: (
        messageRepository: IMessageRepository,
        surveyorLine: ISurveyorLineRepository,
        bus: IPublisher<IMessageModel>,
        lineAdapter: ILineAdapter,
        lineProfileRepo: ILineProfileRepository,
        socket: IWebSocketAdapter,
    ) => new MessageService(
        messageRepository,
        surveyorLine,
        bus,
        lineAdapter,
        lineProfileRepo,
        socket,
    ),
}

export const schedulerServiceProviders: NestProviderInterface = {
    provide: SCHEDULER_SERVICE,
    inject: [
        SCHEDULER_REPOSITORY,
        SCHEDULER_TASK_MANAGER,
    ],
    useFactory: (
        schedulerRepository: ISchedulerTasksRepository,
        manager: IScheduleManager,
    ) => {
        return new SchedulersService(
            schedulerRepository,
            manager,
        )
    },
}

export const schedulerTackServiceProviders: NestProviderInterface = {
    provide: SCHEDULER_TASK_MANAGER,
    inject: [
        SCHEDULER_REPOSITORY,
        LINE_ADAPTER,
        CONFIRM_SURVEYOR_ARRIVE_BUILDER,

    ],
    useFactory: (
        taskRepo: ISchedulerTasksRepository,
        lineAdapter: ILineAdapter,
        flex: ISurveyorCaseArriveBuilder,
    ) => {
        return new ScheduleManager(taskRepo, lineAdapter, flex)
    },
}

export const confirmArriveBuilder: NestProviderInterface = {
    provide: CONFIRM_SURVEYOR_ARRIVE_BUILDER,
    inject: [
        CONFIG,
        AUTH_SERVICE,
    ],
    useFactory: (
        config: IConfig,
        auth: IAuthService,
    ) => {
        return new ISurveyorCaseArriveBuilder(config, auth)
    },
}

export const loggerServiceProvider: NestProviderInterface = {
    provide: LOGGER_SERVICE,
    useClass: Logger,
    // useFactory: (context: string) => {
    //     return new Logger(context)
    // },
    scope: Scope.TRANSIENT,
}
