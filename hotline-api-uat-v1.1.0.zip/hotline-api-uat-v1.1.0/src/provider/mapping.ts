import { Provider as NestProviderInterface } from '@nestjs/common'
import { ProviderName } from './index'
import { IncidentRepositoryMapping } from '../repository/incident/incident.mapping'
import { IncidentTypeRepositoryMapping } from '../repository/incident/type.mapping'
import { TowingRepositoryMapping } from '../repository/incident/towing.mapping'
import { IncidentLogRepositoryMapping } from '../repository/incident/log.mapping'
import { IncidentStatusRepositoryMapping } from '../repository/incident/status.mapping'
import { SurveyorRepositoryMapping } from '../repository/surveyor/surveyor.mapping'
import { SmsMapping } from '../repository/sms/sms.mapping'
import { ReminderMapping } from '../repository/reminder/reminder.mapping'
import { SurveyorCaseMapping } from '../repository/surveyor-case/case.mapping'
import { ProfileRepositoryMapping } from '../repository/profile/profile.mapping'
import { PermissionMapping } from '../repository/permission/permission.mapping'
import { TemplateRepositoryMapping } from '../repository/sms/template.mapping'
import { ManagementQARepositoryMapping } from '../repository/managementQA/mapping'
import { RecorderQAMapping } from '../repository/recorderQA/recorderQA.mapping'
import { LineProfileRepositoryMapping } from '../repository/line/line.mapping'
import { SurveyorLineMapping } from '../repository/surveyor-line/surveyor-line.mapping'
import { MessageRepositoryMapping } from '../repository/message/message.mapping'
import { SchedulerRepositoryMapping } from '../repository/scheduler/scheduler.mapping'
import { GuaranteeZoneMapping } from '../repository/surveyor/guarantee-zone.mapping'

const {
    INCIDENT_REPOSITORY_MAPPING,
    INCIDENT_TYPE_REPOSITORY_MAPPING,
    TOWING_REPOSITORY_MAPPING,
    INCIDENT_LOG_REPOSITORY_MAPPING,
    INCIDENT_STATUS_REPOSITORY_MAPPING,
    PROFILE_REPOSITORY_MAPPING,
    SURVEYOR_REPOSITORY_MAPPING,
    SMS_REPOSITORY_MAPPING,
    REMINDER_REPOSITORY_MAPPING,
    SURVEYOR_CASE_REPOSITORY_MAPPING,
    PERMISSION_REPOSITORY_MAPPING,
    MANAGEMENT_QA_REPOSITORY_MAPPING,
    TEMPLATE_REPOSITORY_MAPPING,
    RECORDER_QA_REPOSITORY_MAPPING,
    LINE_PROFILE_REPOSITORY_MAPPING,
    SURVEYOR_LINE_REPOSITORY_MAPPING,
    MESSAGE_REPOSITORY_MAPPING,
    SCHEDULER_REPOSITORY_MAPPING,
    GUARANTEE_ZONE_REPOSITORY_MAPPING,
} = ProviderName

export const repositoryMappingProviders: NestProviderInterface[] = [
    {
        provide: INCIDENT_REPOSITORY_MAPPING,
        useClass: IncidentRepositoryMapping,
    },
    {
        provide: INCIDENT_TYPE_REPOSITORY_MAPPING,
        useClass: IncidentTypeRepositoryMapping,
    },
    {
        provide: TOWING_REPOSITORY_MAPPING,
        useClass: TowingRepositoryMapping,
    },
    {
        provide: INCIDENT_LOG_REPOSITORY_MAPPING,
        useClass: IncidentLogRepositoryMapping,
    },
    {
        provide: INCIDENT_STATUS_REPOSITORY_MAPPING,
        useClass: IncidentStatusRepositoryMapping,
    },
    {
        provide: PROFILE_REPOSITORY_MAPPING,
        useClass: ProfileRepositoryMapping,
    },
    {
        provide: SURVEYOR_REPOSITORY_MAPPING,
        useClass: SurveyorRepositoryMapping,
    },
    {
        provide: SMS_REPOSITORY_MAPPING,
        useClass: SmsMapping,
    },
    {
        provide: REMINDER_REPOSITORY_MAPPING,
        useClass: ReminderMapping,
    },
    {
        provide: SURVEYOR_CASE_REPOSITORY_MAPPING,
        useClass: SurveyorCaseMapping,
    },
    {
        provide: PERMISSION_REPOSITORY_MAPPING,
        useClass: PermissionMapping,
    },
    {
        provide: MANAGEMENT_QA_REPOSITORY_MAPPING,
        useClass: ManagementQARepositoryMapping,
    },

    {
        provide: TEMPLATE_REPOSITORY_MAPPING,
        useClass: TemplateRepositoryMapping,
    },
    {
        provide: RECORDER_QA_REPOSITORY_MAPPING,
        useClass: RecorderQAMapping,
    },
    {
        provide: LINE_PROFILE_REPOSITORY_MAPPING,
        useClass: LineProfileRepositoryMapping,
    },
    {
        provide: SURVEYOR_LINE_REPOSITORY_MAPPING,
        useClass: SurveyorLineMapping,
    },
    {
        provide: MESSAGE_REPOSITORY_MAPPING,
        useClass: MessageRepositoryMapping,
    },
    {
        provide: SCHEDULER_REPOSITORY_MAPPING,
        useClass: SchedulerRepositoryMapping,
    },
    {
        provide: GUARANTEE_ZONE_REPOSITORY_MAPPING,
        useClass: GuaranteeZoneMapping,
    },

]
