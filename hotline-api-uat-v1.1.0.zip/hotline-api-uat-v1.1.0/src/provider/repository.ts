import { ProviderName } from './index'
import { Db } from 'mongodb'
import { Provider as NestProviderInterface } from '@nestjs/common/interfaces'
import { IRepositoryMapping } from '../common/interface/repository.interface'
import {
    IIncidentLogModel,
    IIncidentModel,
} from '../domain/incident/interface'
import { IncidentRepository } from '../repository/incident/incident'
import {
    IIncidentSchema,
    IIncidentTowing,
} from '../repository/incident/incident.schema'
import { IncidentTypeRepository } from '../repository/incident/type'
import { ITowingModel } from '../domain/incident/interface/towing.model.interface'
import { TowingRepository } from '../repository/incident/towing'
import { IIncidentLogSchema } from '../repository/incident/log.schema'
import { IncidentLogRepository } from '../repository/incident/log'
import { IIncidentType } from '../repository/incident/incident.type'
import { IIncidentStatusModel } from '../domain/incident/interface/status.model.interface'
import { IIncidentStatusSchema } from '../repository/incident/status.schema'
import { IncidentStatusRepository } from '../repository/incident/status'
import { IProfileModel } from '../domain/profile/interface/model.interface'
import { SurveyorRepository } from '../repository/surveyor/surveyor.repository'
import {
    IGuaranteeZoneModel,
    ISurveyorModel,
} from '../domain/surveyor/interface/model.interface'
import { ISurveyorSchema } from '../repository/surveyor/surveyor.schema'
import { ISmsLogModel } from '../domain/common/interface/common.interface'
import { ISmsSchema } from '../repository/sms/sms.schema'
import { SmsRepository } from '../repository/sms/sms.repository'
import { IReminderModel } from '../domain/reminder/interface/model.interface'
import { IReminderSchema } from '../repository/reminder/reminder.schema'
import { ReminderRepository } from '../repository/reminder/reminder.repository'
import { ISurveyorCaseModel } from '../domain/surveyor-case/interface/model.interface'
import { ISurveyorCaseSchema } from '../repository/surveyor-case/case.schema'
import { SurveyorCaseMongoRepository } from '../repository/surveyor-case/case.repository'
import { IProfileSchema } from '../repository/profile/profile.schema'
import { ProfileMongoRepository } from '../repository/profile/profile.repository'
import { IPermissionModel } from '../domain/permission/interface/model.interface'
import { IPermissionSchema } from '../repository/permission/permission.schema'
import { PermissionRepository } from '../repository/permission/permission.repository'
import { IManagementQAModel } from '../domain/managementQA/interface/model.interface'
import { IManagementQASchema } from '../repository/managementQA/schema'
import { ManagementQAMongoRepository } from '../repository/managementQA/repository'
import { ITemplateModel } from '../domain/sms/interface/model.interface'
import { ITemplateSchema } from '../repository/sms/template.schema'
import { TemplateMongoRepository } from '../repository/sms/template'

import { IRecorderQAModel } from '../domain/recorderQA/interface/recorderQA.model.interface'
import { IRecorderQASchema } from '../repository/recorderQA/recorderQA.schema'
import { RecorderQARepository } from '../repository/recorderQA/recorderQA.repository'

import { ILineProfileModel } from '../domain/line/interface'
import { ILineProfileSchema } from '../repository/line/line.schema'
import { LineProfileRepository } from '../repository/line/line.repository'
import { ISurveyorLineModel } from '../domain/surveyor-line/interface/model.interface'
import { ISurveyorLineSchema } from '../repository/surveyor-line/surveyor-line.schema'
import { SurveyorLineMongoRepository } from '../repository/surveyor-line/surveyor-line.repository'
import { IMessageModel } from '../domain/message/interface'
import { IMessageSchema } from '../repository/message/message.schema'
import { MessageRepository } from '../repository/message/message.repository'
import { SchedulerRepositoryMapping } from '../repository/scheduler/scheduler.mapping'
import { ISchedulerConfigModel } from '../domain/scheduler/interface/model.interface'
import { ISchedulerTaskSchema } from '../repository/scheduler/scheduler.schema'
import { SchedulerRepository } from '../repository/scheduler'
import { IGuaranteeZoneSchema } from '../repository/surveyor/guarantee-zone.schema'
import { GuaranteeZoneRepository } from '../repository/surveyor/guarantee-zone.repository'

const {
    MONGO_CONNECTION,
    INCIDENT_REPOSITORY,
    INCIDENT_REPOSITORY_MAPPING,
    INCIDENT_TYPE_REPOSITORY,
    INCIDENT_TYPE_REPOSITORY_MAPPING,
    TOWING_REPOSITORY,
    TOWING_REPOSITORY_MAPPING,
    INCIDENT_LOG_REPOSITORY,
    INCIDENT_LOG_REPOSITORY_MAPPING,
    INCIDENT_STATUS_REPOSITORY,
    INCIDENT_STATUS_REPOSITORY_MAPPING,
    PROFILE_REPOSITORY,
    PROFILE_REPOSITORY_MAPPING,
    SURVEYOR_REPOSITORY,
    SURVEYOR_REPOSITORY_MAPPING,
    SMS_REPOSITORY,
    SMS_REPOSITORY_MAPPING,
    REMINDER_REPOSITORY,
    REMINDER_REPOSITORY_MAPPING,
    SURVEYOR_CASE_REPOSITORY,
    SURVEYOR_CASE_REPOSITORY_MAPPING,
    PERMISSION_REPOSITORY,
    PERMISSION_REPOSITORY_MAPPING,
    MANAGEMENT_QA_REPOSITORY,
    MANAGEMENT_QA_REPOSITORY_MAPPING,
    TEMPLATE_REPOSITORY,
    TEMPLATE_REPOSITORY_MAPPING,
    RECORDER_QA_REPOSITORY,
    RECORDER_QA_REPOSITORY_MAPPING,
    LINE_ADAPTER,
    LINE_PROFILE_REPOSITORY,
    LINE_PROFILE_REPOSITORY_MAPPING,
    SURVEYOR_LINE_REPOSITORY,
    SURVEYOR_LINE_REPOSITORY_MAPPING,
    MESSAGE_REPOSITORY,
    MESSAGE_REPOSITORY_MAPPING,
    SCHEDULER_REPOSITORY,
    SCHEDULER_REPOSITORY_MAPPING,
    GUARANTEE_ZONE_REPOSITORY_MAPPING,
    GUARANTEE_ZONE_REPOSITORY,
} = ProviderName

export const repositoryProviders: NestProviderInterface[] = [
    {
        provide: INCIDENT_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            INCIDENT_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<IIncidentModel, IIncidentSchema>,
        ) => new IncidentRepository(db, mapping),
    },
    {
        provide: INCIDENT_TYPE_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            INCIDENT_TYPE_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<IIncidentModel, IIncidentType>,
        ) => new IncidentTypeRepository(db, mapping),
    },
    {
        provide: TOWING_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            TOWING_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<ITowingModel, IIncidentTowing>,
        ) => new TowingRepository(db, mapping),
    },
    {
        provide: INCIDENT_LOG_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            INCIDENT_LOG_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<IIncidentLogModel, IIncidentLogSchema>,
        ) => {
            return new IncidentLogRepository(db, mapping)
        },
    },
    {
        provide: INCIDENT_STATUS_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            INCIDENT_STATUS_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<IIncidentStatusModel, IIncidentStatusSchema>,
        ) => {
            return new IncidentStatusRepository(db, mapping)
        },
    },
    {
        provide: SURVEYOR_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            SURVEYOR_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<ISurveyorModel, ISurveyorSchema>,
        ) => new SurveyorRepository(db, mapping),

    },
    {
        provide: SMS_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            SMS_REPOSITORY_MAPPING,
        ],
        useFactory: (db: Db, mapping: IRepositoryMapping<ISmsLogModel, ISmsSchema>,
        ) => new SmsRepository(db, mapping),
    },
    {
        provide: REMINDER_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            REMINDER_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<IReminderModel, IReminderSchema>,
        ) => new ReminderRepository(db, mapping),
    },
    {
        provide: SURVEYOR_CASE_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            SURVEYOR_CASE_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<ISurveyorCaseModel, ISurveyorCaseSchema>,
        ) => new SurveyorCaseMongoRepository(db, mapping),
    },
    {
        provide: PROFILE_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            PROFILE_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<IProfileModel, IProfileSchema>,
        ) => new ProfileMongoRepository(db, mapping),
    },
    {
        provide: PERMISSION_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            PERMISSION_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<IPermissionModel, IPermissionSchema>,
        ) => new PermissionRepository(db, mapping),
    },
    {
        provide: MANAGEMENT_QA_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            MANAGEMENT_QA_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<IManagementQAModel, IManagementQASchema>,
        ) => new ManagementQAMongoRepository(db, mapping),
    },
    {
        provide: TEMPLATE_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            TEMPLATE_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<ITemplateModel, ITemplateSchema>,
        ) => new TemplateMongoRepository(db, mapping),
    },
    {
        provide: RECORDER_QA_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            RECORDER_QA_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<IRecorderQAModel, IRecorderQASchema>,
        ) => new RecorderQARepository(db, mapping),
    },
    {
        provide: LINE_PROFILE_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            LINE_PROFILE_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<ILineProfileModel, ILineProfileSchema>,
        ) => new LineProfileRepository(db, mapping),
    },
    {
        provide: SURVEYOR_LINE_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            SURVEYOR_LINE_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<ISurveyorLineModel, ISurveyorLineSchema>,
        ) => new SurveyorLineMongoRepository(db, mapping),
    },
    {
        provide: MESSAGE_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            MESSAGE_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<IMessageModel, IMessageSchema>,
        ) => new MessageRepository(db, mapping),
    },
    {
        provide: SCHEDULER_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            SCHEDULER_REPOSITORY_MAPPING,
        ],
        useFactory: (db: Db, mapping: IRepositoryMapping<ISchedulerConfigModel, ISchedulerTaskSchema>) => {
            return new SchedulerRepository(db, mapping)
        },
    },
    {
        provide: GUARANTEE_ZONE_REPOSITORY,
        inject: [
            MONGO_CONNECTION,
            GUARANTEE_ZONE_REPOSITORY_MAPPING,
        ],
        useFactory: (
            db: Db,
            mapping: IRepositoryMapping<IGuaranteeZoneModel, IGuaranteeZoneSchema>,
        ) => {
            return new GuaranteeZoneRepository(db, mapping)
        },
    },
]
