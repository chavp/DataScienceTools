import { Provider as NestProviderInterface } from '@nestjs/common'
import { ProviderName } from './index'
import {
    As400Adapter,
} from '../adapter/as400/as400.adapter'
import { IConfig } from '../common/interface/config.interface'
import { As400AdapterUat } from '../adapter/as400/as400.adapter.uat'
import { ConnectionPool } from 'mssql'
import { MssqlAdapter } from '../adapter/mssql/mssql.adapter'
import { OdbcAdapter } from '../adapter/odbc/odbc.adapter'
import { SmsAdapter } from '../adapter/sms/sms.adapter'
import { ActiveDirectoryAdapter } from '../adapter/active-directory/active-directory.adapter'
import { Issuer } from 'openid-client'
import * as _ from 'lodash'
import * as odbcConnection from 'odbc'
import * as mysql from 'mysql'
import { SocketAdapter } from '../adapter/notification/socket.adapter'
import { RecorderAdapter } from '../adapter/recorder/recorder.adapter'
import { AudioDownloadAdapter } from '../adapter/audio-download/audio-download-adapter'
import { LineAdapter } from '../adapter/line/line.adapter'

const {
    AD_ADAPTER,
    AS400_ADAPTER,
    CONFIG,
    MSSQL_ADAPTER,
    MSSQL_CONNECTION,
    ODBC_ADAPTER,
    ODBC_CONNECTION,
    SMS_ADAPTER,
    WEB_SOCKET_ADAPTER,
    MYSQL_CONNECTION,
    RECORDER_ADAPTER,
    RECORDER_AUDIO_ADAPTER,
    LINE_ADAPTER,
} = ProviderName
export const adapterProvider: NestProviderInterface[] = [
    {
        provide: AS400_ADAPTER,
        inject: [CONFIG],
        useFactory: (
            config: IConfig,
        ) => {
            if (process.env.NODE_ENV === 'production') {
                return new As400AdapterUat(
                    config,
                )
            } else if (process.env.NODE_ENV === 'uat') {
                console.log('USING UAT ADAPTER')
                return new As400AdapterUat(config)
            } else {
                return new As400Adapter(
                    config,
                )
            }
        },
    },
    {
        provide: MSSQL_ADAPTER,
        inject: [
            MSSQL_CONNECTION,
        ],
        useFactory: (pool: ConnectionPool) => {
            if (_.isNil(process.env.NODE_ENV)) {
                return {}
            }
            return new MssqlAdapter(pool)
        },
    },
    {
        provide: ODBC_ADAPTER,
        inject: [
            ODBC_CONNECTION,
        ],
        useFactory: (connect: odbcConnection) => {
            if (_.isNil(process.env.NODE_ENV)) {
                return {}
            }
            return new OdbcAdapter(connect)
        },
    },
    {
        provide: RECORDER_ADAPTER,
        inject: [
            MYSQL_CONNECTION,
        ],
        useFactory: (connection: any) => {
            return new RecorderAdapter(connection)
        },
    },
    {
        provide: SMS_ADAPTER,
        inject: [
            CONFIG,
        ],
        useFactory: (config: IConfig) => {
            return new SmsAdapter(config)
        },
    },
    {
        provide: AD_ADAPTER,
        inject: [
            CONFIG,
        ],
        useFactory: async (config: IConfig) => {
            if (_.isNil(process.env.NODE_ENV)) {
                return {}
            }

            const knownServer = _.get(config, 'adapter.ad.issuer')
            const responseType = _.get(config, 'adapter.ad.responseType')
            const clientId = _.get(config, 'adapter.ad.clientId')
            const secret = _.get(config, 'adapter.ad.clientSecret')
            const issuer = await Issuer.discover(knownServer)
            const client = new issuer.Client({
                response_types: responseType,
                client_id: clientId,
                client_secret: secret,
            })
            return new ActiveDirectoryAdapter(config, issuer, client)
        },
    },
    {
        provide: WEB_SOCKET_ADAPTER,
        useClass: SocketAdapter,
    },
    {
        provide: RECORDER_AUDIO_ADAPTER,
        inject: [
            CONFIG,
        ],
        useFactory: (config: IConfig) => {
            const endpoint = _.get(config, 'recorderAudio.path', '')
            return new AudioDownloadAdapter(endpoint)
        },
    },
    {
        provide: LINE_ADAPTER,
        inject: [
            CONFIG,
        ],
        useFactory: (config: IConfig) => {
            return new LineAdapter(config)
        },
    },
]
