import {Observable} from 'rxjs'

export interface ISmsAdapter {
    send(sender: string, toNumber: string, message: string): Observable<any>
}
