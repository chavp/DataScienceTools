import * as _ from 'lodash'
import {Client, Issuer, TokenSet} from 'openid-client'
import {ISmsAdapter} from './interface/adaper.interface'
import {IConfig} from '../../common/interface/config.interface'
import {from, Observable, of} from 'rxjs'

import Axios, {AxiosInstance} from 'axios'
import {mergeMap} from 'rxjs/operators'

export class SmsAdapter implements ISmsAdapter {

    private _tokenSet: TokenSet
    private readonly _client: Client
    private readonly _axios: AxiosInstance

    constructor(
        private readonly _config: IConfig,
    ) {

        const clientId = _.get(_config, 'adapter.sms.auth.clientId', '')
        const clientSecret = _.get(_config, 'adapter.sms.auth.clientSecret', '')
        const tokenHost = _.get(_config, 'adapter.sms.auth.host', '')
        const tokenPath = _.get(_config, 'adapter.sms.auth.path', '')

        const issuer = new Issuer({
            issuer: 'identity-server',
            token_endpoint: `${tokenHost}${tokenPath}`,
        })
        this._client = new issuer.Client({
            client_id: clientId,
            client_secret: clientSecret,
            response_types: ['code'],
        })

        const host = _.get(this._config, 'adapter.sms.endpoint.host', '')
        const path = _.get(this._config, 'adapter.sms.endpoint.path', '')
        const baseURL = `${host}${path}`
        this._axios = Axios.create({
            baseURL,
            responseType: 'json',
        })
    }

    private _createToken(): Promise<TokenSet> {
        const scope = _.get(this._config, 'adapter.sms.auth.scope', '')
        return this._client.grant({
            grant_type: 'client_credentials',
            scope,
        }).then(result => {
            this._tokenSet = result
            return result
        })
    }

    private _preflight(): Observable<TokenSet> {
        if (_.isNil(this._tokenSet) || this._tokenSet.expired()) {
            return from(this._createToken())
        }
        return of(this._tokenSet)
    }

    public send(sender: string, toNumber: string, message: string): Observable<any> {

        const _sendMessage = (tokensSet: TokenSet) => {
            const body = {
                from: sender,
                to: toNumber,
                text: message,
            }
            console.log(this._axios)
            return this._axios.request({
                method: 'POST',
                url: '/single',
                headers: {
                    Authorization: `${tokensSet.token_type} ${tokensSet.access_token}`,
                },
                data: body,
            }).then(result => {
                console.log(result)
                return _.get(result, 'data', {})
            }).catch(err => {
                console.error(err)
            })

        }

        return this._preflight().pipe(
            mergeMap(tokenSet => {
                return from(_sendMessage(tokenSet))
            }),
        )

    }

}
