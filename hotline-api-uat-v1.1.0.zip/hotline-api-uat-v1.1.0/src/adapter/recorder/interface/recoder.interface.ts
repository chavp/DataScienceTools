import { Observable } from 'rxjs'

export interface IRecorderAdapter {
    getRecorder(): Observable<any>
}
