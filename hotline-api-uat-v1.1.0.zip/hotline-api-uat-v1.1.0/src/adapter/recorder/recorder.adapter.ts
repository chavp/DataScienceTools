import { IRecorderAdapter } from './interface/recoder.interface'
import * as mysql from 'mysql'
import {
    EMPTY,
    from,
    Observable,
} from 'rxjs'
import { catchError } from 'rxjs/operators'

export class RecorderAdapter implements IRecorderAdapter {
    constructor(
        private readonly _mysql: mysql.Connection,
    ) {

    }

    public getRecorder(): Observable<any> {
        // const queryMysql = 'SELECT * FROM `orktape` WHERE expiryTimestamp BETWEEN NOW() - 5 AND NOW() - 10'
        // const queryMysql = 'SELECT * FROM `orktape` WHERE expiryTimestamp BETWEEN \'2014-04-13 03:43:26\' AND \'2015-07-09 00:00:00\''
        const queryMysql = 'SELECT * FROM orktape WHERE expiryTimestamp >= NOW() - INTERVAL 10 MINUTE'

        return new Observable(subscriber => {
            this._mysql.query(queryMysql)
                .on('error', (err) => {
                    subscriber.error(err)
                })
                .on('result', (row) => {
                    subscriber.next({
                        row,
                    })
                })
                .on('end', () => {
                    console.log(`subscribe complete`)
                    subscriber.complete()
                })
        }).pipe(
            catchError(() => EMPTY),
        )
    }

}
