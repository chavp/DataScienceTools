import {
    IWebSocketAdapter,
    ReminderEvent,
} from './interfaces/socket.interface'
import { SocketSchema } from './interfaces/schema.interface'
import {
    WebSocketGateway,
    WebSocketServer,
} from '@nestjs/websockets'
import {
    Client,
    Server,
} from 'socket.io'
import {
    Observable,
    of,
} from 'rxjs'
import * as _ from 'lodash'

@WebSocketGateway()
export class SocketAdapter implements IWebSocketAdapter {
    @WebSocketServer()
    server: Server

    public handleConnection(client: Client) {
        console.log(`client connected: ${client.request.connection.remoteAddress}`)
    }

    public sendMessage(channel: ReminderEvent, payload: SocketSchema): Observable<boolean> {
        console.log(`sending message: ${channel}`)
        console.log(`payload: ${_.map(payload, obj => obj)}`)
        return of(this.server.sockets.emit(channel, payload))
    }
}
