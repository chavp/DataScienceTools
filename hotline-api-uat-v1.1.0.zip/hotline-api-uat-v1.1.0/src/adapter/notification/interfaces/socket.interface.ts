import { Client } from 'socket.io'
import { Observable } from 'rxjs'

export enum ReminderEvent {
    NEW_MESSAGE = 'reminder-new-message',
    MESSAGE_READ = 'reminder-message-read',
    MESSAGE_TOTAL = 'reminder-message-total',
    LINE_NEW_MESSAGE_USER = 'line-new-message-user',
    LINE_NEW_MESSAGE_GROUP = 'line-new-message-group',
    LINE_BOT_FOLLOWED = 'line-bot-followed',
    LINE_BOT_UNFOLLOWED = 'line-bot-unfollowed',
}

export interface IReceiveMessageSchema {
    uid: string
    message: string
    group: string
}

export interface IWebSocketHandler {
    onWebSocketMessage(data: IReceiveMessageSchema): Observable<any>
}

export interface IWebSocketAdapter {
    sendMessage(channel: ReminderEvent, payload: any): Observable<boolean>
}

export interface IFullDuplexWebSocket extends IWebSocketAdapter {
    onMessageReceived(client: Client, data: IReceiveMessageSchema): Observable<boolean>
    registerHandler(handler: IWebSocketHandler): void
}
