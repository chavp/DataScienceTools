import { EventSource } from '@line/bot-sdk'

export interface IMessageSchema {
    id: string
    incidentNo: string
    registration: string
    note: string
    remindTime: number
    status: 'read' | 'unread'
    agent: string
    createdAt: number
}

export interface IMessageTotalSchema {
    total: number
}

export interface IMessageLineSchema {
    sender: string
    group: string
    content: any
    timeStamp: number
    incidentNo: string,
    senderName: string,
}

export type SocketSchema = IMessageSchema | IMessageTotalSchema | IMessageSurveyor | IMessageLineSchema

export interface IMessageSurveyor {
    id: string
    isRegister?: boolean
    type: string
    conversation: {
        source?: EventSource
        destination: string
        groupId: string
        pictureUrl: string
        displayName: string
        createDate: number
    },
    content: IFlexMessage | ILocationMessage | string
}

export interface IFlexMessage {
    id: string,
    messageType: string,
    caller: ICaller,
    surveyor?: ISurveyor
}

export interface ILocationMessage {
    id: string,
    address: string,
    messageType: string,
    lat: number,
    lng: number,
}

export interface ISurveyor {
    id: string,
    name: string,
    phone: string,
    companyNo: string
}

export interface ICaller {
    name: string,
    phone: string
}
