import {
    IFullDuplexWebSocket,
    IReceiveMessageSchema,
    IWebSocketHandler,
} from './interfaces/socket.interface'
import {
    Client,
    Server,
} from 'socket.io'
import {
    SubscribeMessage,
    WebSocketGateway,
    WebSocketServer,
} from '@nestjs/websockets'
import { SocketAdapter } from './socket.adapter'
import {
    from,
    Observable,
} from 'rxjs'
import {
    mergeMap,
    tap,
} from 'rxjs/operators'

@WebSocketGateway()
export class FullDuplexSocketAdapter extends SocketAdapter implements IFullDuplexWebSocket {
    @WebSocketServer()
    public server: Server
    protected _handlers: IWebSocketHandler[]

    constructor() {
        super()
        this._handlers = []
    }

    @SubscribeMessage('reply')
    public onMessageReceived(client: Client, data: IReceiveMessageSchema): Observable<any> {
        return from(this._handlers).pipe(
            tap((handler: IWebSocketHandler) => {
                handler.onWebSocketMessage(data).subscribe()
            }),
        )

    }

    public registerHandler(handler: IWebSocketHandler) {
        this._handlers.push(handler)
    }
}
