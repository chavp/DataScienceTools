import {Observable} from 'rxjs'

export interface IOdbcInterface {
    getAgent(filter: any): Observable<any>
    getAgentQueue(filter: any): Observable<any>
    getQueue(): Observable<any>
}
