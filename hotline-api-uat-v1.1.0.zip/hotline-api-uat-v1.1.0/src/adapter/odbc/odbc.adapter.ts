import {from, Observable} from 'rxjs'
import {IOdbcInterface} from './interface/odbc.interface'
import * as odbc from 'odbc'
import * as odbcConnection from 'odbc'

export class OdbcAdapter implements IOdbcInterface {
    constructor(
        private readonly _connectionPool: odbcConnection,
    ) {
    }

    public getAgent(team: any): Observable<any> {
        const sql = 'SELECT a1.resourceloginid ,a1.resourcename ,a2.eventdatetime ,a2.eventtype ,a2.reasoncode FROM ' +

            '(SELECT agentID ,resourcename ,MAX(eventdatetime) as eventdatetime ,resource.resourceloginid ' +
            'FROM agentstatedetail ' +
            'INNER JOIN resource on agentstatedetail.agentID = resource.resourceid ' +
            'WHERE resource.active = \'t\' AND resource.assignedteamid = ' + team + ' ' +
            'group by agentID,resourcename,resourceloginid) as a1 ' +

            'INNER JOIN agentstatedetail as a2 ON ((a1.agentID = a2.agentID) and (a1.eventdatetime = a2.eventdatetime)) ' +
            'order by a2.eventdatetime '
        const data = new Promise(resolve => {
            this._connectionPool.query(sql, (err, result) => {
                if (err) {
                    throw err
                }
                resolve(JSON.parse(JSON.stringify(result)))
            })
        })

        return from(data)
    }

    public getAgentQueue(team: any): Observable<any> {
        const sql = 'SELECT r.resourceLoginID,s.skillname ' +
            'from skill s ' +
            'inner join resourceskillmapping rsm on s.skillid = rsm.skillid ' +
            'inner join resource r on rsm.resourceskillmapid = r.resourceskillmapid ' +
            'where s.active = \'t\' and r.active = \'t\' and r.assignedteamid = ' + team + ' ' +
            'order by r.resourceloginid ,s.skillid'
        const data = new Promise(resolve => {
            this._connectionPool.query(sql, (err, result) => {
                if (err) {
                    throw err
                }
                resolve(JSON.parse(JSON.stringify(result)))
            })
        })

        return from(data)
    }

    public getQueue(): Observable<any> {
        const sql = 'SELECT CSQNAME ,CALLSWAITING ,CALLSABANDONED ,CALLSHANDLED ,OLDESTCONTACT ,AVGTALKDURATION from rtcsqssummary'
        const data = new Promise(resolve => {
            this._connectionPool.query(sql, (err, result) => {
                if (err) {
                    throw err
                }
                resolve(JSON.parse(JSON.stringify(result)))
            })
        })

        return from(data)
    }

}
