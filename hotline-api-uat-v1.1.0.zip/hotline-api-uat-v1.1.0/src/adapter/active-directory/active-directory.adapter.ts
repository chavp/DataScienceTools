import { IActiveDirectoryAdapter } from './interface/adapter.interface'
import {
    Observable,
    of,
} from 'rxjs'
import { IConfig } from '../../common/interface/config.interface'
import {
    Client,
    generators,
    Issuer,
} from 'openid-client'
import * as _ from 'lodash'

export class ActiveDirectoryAdapter implements IActiveDirectoryAdapter {
    constructor(
        private readonly _config: IConfig,
        private readonly _issuer: Issuer<Client>,
        private readonly _client: Client,
    ) {
    }

    public generateLink(): Observable<string> {

        const redirectUri = _.get(this._config, 'adapter.ad.redirectUri')
        const responseType = _.get(this._config, 'adapter.ad.responseType')
        const app = _.get(this._config, 'adapter.ad.app')
        const secret = _.get(this._config, 'adapter.ad.clientSecret')
        const scope = _.get(this._config, 'adapter.ad.scope')
        const nonce = generators.nonce()

        const url = this._client.authorizationUrl({
            redirect_uri: redirectUri,
            response_type: responseType,
            app,
            secret,
            scope,
            nonce,
        })
        return of(url)
    }

}
