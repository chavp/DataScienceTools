import { Observable } from 'rxjs'

export interface IActiveDirectoryAdapter {
    generateLink(): Observable<string>
}
