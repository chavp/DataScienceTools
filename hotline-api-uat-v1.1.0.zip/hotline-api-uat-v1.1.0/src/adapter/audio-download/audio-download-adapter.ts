import { IAudioDownloadAdapter } from './interface/adapter.interface'
import Axios from 'axios'
import { Observable } from 'rxjs'
import * as FileSystem from 'fs'
import { RuntimeException } from '@nestjs/core/errors/exceptions/runtime.exception'
import * as Crypto from 'crypto'
import { FileCleanser } from '../../common/file-cleanser'

export class AudioDownloadAdapter implements IAudioDownloadAdapter {
    private readonly _tmpDir: string = './temp/audio-downloader'

    constructor(
        private readonly _endpoint: string,
    ) {
        FileSystem.mkdir(this._tmpDir, {recursive: true}, (err) => {
            if (err) {
                throw new RuntimeException('Cannot create temp directory for decoder')
            }
        })

        const every3hours = 1000 * 60 * 60 * 3
        const cleanser = new FileCleanser(this._tmpDir, every3hours)
        cleanser.start()
    }

    public getFile(path: string): Observable<Buffer> {

        return new Observable<Buffer>(subscriber => {
            const resource = `${this._endpoint}${path}`
            const hash = Crypto.createHash('sha256')
            const uniqueId = hash.update(resource).digest('hex')

            if (FileSystem.existsSync(`${this._tmpDir}/${uniqueId}.wav`)) {
                console.log('use existing buffer')
                const buffer = FileSystem.readFileSync(`${this._tmpDir}/${uniqueId}.wav`)
                console.log('got buffer')
                subscriber.next(buffer)
                subscriber.complete()
            } else {
                console.log('create new raw file download')
                Axios.request({
                    method: 'get',
                    url: resource,
                    responseType: 'stream',
                }).then(response => {
                    const source = response.data
                    const arr = []
                    source
                        .on('data', (chunk: any) => {
                            arr.push(chunk)
                        })
                        .on('close', () => {
                            const concatBuffer = Buffer.concat(arr)
                            FileSystem.writeFileSync(`${this._tmpDir}/${uniqueId}.wav`, concatBuffer)
                            subscriber.next(concatBuffer)
                            subscriber.complete()
                        })
                        .on('error', (err: Error) => {
                            subscriber.error('Streaming error')
                        })
                })
            }

        })

    }

}
