import { Observable } from 'rxjs'

export interface IAudioDownloadAdapter {
    getFile(path: string): Observable<Buffer>
}
