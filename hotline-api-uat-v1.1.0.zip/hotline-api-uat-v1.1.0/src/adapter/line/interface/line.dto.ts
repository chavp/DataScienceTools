import { EventSource } from '@line/bot-sdk'
import {
    ICaller,
    ISurveyor,
} from '../../../repository/line/line.schema'

export interface IMessageDto {
    id: string
    isRegister?: boolean
    type: string
    conversation: {
        source?: EventSource
        destination: string
        groupId: string
        pictureUrl: string
        displayName: string
        createDate: number
    },
    content: IFlexMessage | ILocationMessage | string
}

export interface IFlexMessage {
    id: string,
    messageType: string,
    caller: ICaller,
    surveyor?: ISurveyor
}

export interface ILocationMessage {
    id: string,
    address: string,
    messageType: string,
    lat: number,
    lng: number,
}
