import { Observable } from 'rxjs'
import { Profile } from '@line/bot-sdk'
import { IMessage } from '../../../repository/line/line.schema'

export interface ILineAdapter {

    pushMessage(receiver: string, message: string): Observable<IResultSchema>

    replyMessage(replyToken: string, message: string[]): Observable<any>

    createMainRichMenuForUser(uid): Observable<any>

    getProfile(lineId): Observable<ILineProfile>

    getProfileFromGroup(lineId: string, groupId: string): Observable<ILineProfile>

    getMessageContent(messageId: string, messageType: string): Observable<ILineMessageContentSchema>

    pushFlexMessage(lineId: string, schema: any): Observable<any>

    deleteRichMenuOfUser(lineId: string): Observable<any>
}

export interface IResultSchema {
    id: string,
    result: boolean
}

export interface ILineProfile extends Profile {
    messages: IMessage[],
}

export interface ILineMessageContentSchema {
    buffer: Buffer
    path: string
    fileName: string
}
