import {
    forkJoin,
    from,
    Observable,
    of,
    throwError,
} from 'rxjs'
import {
    catchError,
    map,
    mergeMap,
    tap,
} from 'rxjs/operators'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import Axios from 'axios'
import * as LineSdk from '@line/bot-sdk'
import {
    Profile,
    RichMenu,
    TextMessage,
} from '@line/bot-sdk'
import * as FileSystem from 'fs'
import * as _ from 'lodash'
import {
    ILineAdapter,
    ILineMessageContentSchema,
    ILineProfile,
    IResultSchema,
} from './interface/line.interface'
import { IConfig } from '../../common/interface/config.interface'
import { LineMessageType } from '../../common/interface/line-message.interface'
import * as Path from 'path'
import * as Types from '@line/bot-sdk/lib/types'
import { RuntimeException } from '@nestjs/core/errors/exceptions/runtime.exception'

export class LineAdapter implements ILineAdapter {
    private readonly _client: LineSdk.Client
    private readonly _profileMap: Map<string, ILineProfile>

    constructor(
        private readonly _config: IConfig,
    ) {

        this._client = new LineSdk.Client({
            channelAccessToken: this._config.lineApi.accessToken,
            channelSecret: this._config.lineApi.channelSecret,
        })
        this._profileMap = new Map()

        FileSystem.mkdir(Path.resolve(this._config.static.lineMessageImages), {recursive: true}, (err) => {
            if (err) {
                throw new RuntimeException('Cannot create temp directory for decoder')
            }
        })
        FileSystem.mkdir(Path.resolve(this._config.static.lineMessageVideo), {recursive: true}, (err) => {
            if (err) {
                throw new RuntimeException('Cannot create temp directory for decoder')
            }
        })
        FileSystem.mkdir(Path.resolve(this._config.static.lineMessageAudio), {recursive: true}, (err) => {
            if (err) {
                throw new RuntimeException('Cannot create temp directory for decoder')
            }
        })
        FileSystem.mkdir(Path.resolve(this._config.static.lineProfile), {recursive: true}, (err) => {
            if (err) {
                throw new RuntimeException('Cannot create temp directory for decoder')
            }
        })
        FileSystem.mkdir(Path.resolve(this._config.static.uploads), {recursive: true}, (err) => {
            if (err) {
                throw new RuntimeException('Cannot create temp directory for decoder')
            }
        })

    }

    public pushMessage(receiver: string, message: string): Observable<any> {
        const textMessage: TextMessage = {
            type: 'text',
            text: message,
        }
        const promise = this._client.pushMessage(receiver, textMessage)
        return from(promise).pipe(
            catchError(() => {
                throw new HttpException(`Cannot push message`, HttpStatus.INTERNAL_SERVER_ERROR)
            }),
        )
    }

    public replyMessage(replyToken: string, message: string[]): Observable<IResultSchema> {
        const promise = this._client.replyMessage(
            replyToken,
            message.map((msg) => {
                return {
                    type: LineMessageType.TEXT,
                    text: msg,
                }
            }) as any[])

        return from(promise).pipe(
            catchError(() => {
                throw new HttpException(`Cannot reply message`, HttpStatus.INTERNAL_SERVER_ERROR)
            }),
            map(result => {
                return {
                    id: '0',
                    result: true,
                }
            }),
        )
    }

    public getProfile(lineId: string): Observable<ILineProfile> {
        const profile = this._profileMap.get(lineId)
        if (_.isNil(profile)) {
            const promise = this._client.getProfile(lineId)
            return from(promise).pipe(
                catchError(err => {
                    throw new HttpException(`Profile not found`,
                        HttpStatus.NOT_FOUND)
                }),
                mergeMap(newProfile => {
                    return forkJoin([
                        this._createProfileSchema(newProfile),
                        this._imageSave(newProfile),
                    ])

                }),
                map((results: any[]) => {
                    return _.first(results)
                }),
            )
        }
        return of(profile)
    }

    public getMessageContent(messageId: string, messageType: string): Observable<ILineMessageContentSchema> {
        return new Observable<ILineMessageContentSchema>(subscriber => {
            this._client.getMessageContent(messageId)
                .then((stream) => {
                    const arr = []
                    stream.on('data', (chunk: any) => {
                        arr.push(chunk)
                    })
                    stream.on('close', () => {
                        const concatBuffer = Buffer.concat(arr)
                        let fileName = ''
                        switch (messageType) {
                            case 'image':
                                fileName = this._createMessageImagePath(`${messageId}`)
                                break

                            case 'video':
                                fileName = this._createMessageVideoPath(`${messageId}`)
                                break

                            case 'audio':
                                fileName = this._createMessageAudioPath(`${messageId}`)
                                break
                        }
                        const fullPath = Path.resolve(fileName)
                        FileSystem.writeFileSync(fullPath, concatBuffer)
                        subscriber.next({
                            buffer: concatBuffer,
                            path: fullPath,
                            fileName,
                        })
                        subscriber.complete()
                    })
                    stream.on('error', (err: Error) => {
                        subscriber.error('Streaming error')
                    })
                })
        })
    }

    private _createMessageImagePath(nameFlie: string): string {
        return `${this._config.static.lineMessageImages}/${nameFlie}${'.jpeg'}`
    }

    private _createMessageVideoPath(nameFlie: string): string {
        return `${this._config.static.lineMessageVideo}/${nameFlie}${'.mp4'}`
    }

    private _createMessageAudioPath(nameFlie: string): string {
        return `${this._config.static.lineMessageAudio}/${nameFlie}${'.m4a'}`
    }

    private _imageSave(profile: Profile): Observable<any> {
        const promise = Axios.get(profile.pictureUrl, {
            responseType: 'arraybuffer',
        })
        return from(promise).pipe(
            tap((resp: any) => {
                FileSystem.writeFileSync(this._createProfileImagePath(profile.userId), resp.data)
            }),
        )
    }

    private _createProfileSchema(profile: Profile): Observable<ILineProfile> {
        return of(profile).pipe(
            map(source => {
                const id = profile.userId
                const lineProfile: ILineProfile = {
                    ...source,
                    pictureUrl: this._createProfileImagePath(id),
                    messages: [],
                }
                this._profileMap.set(id, lineProfile)
                return lineProfile
            }),
        )
    }

    private _createProfileImagePath(id: string): string {
        return `${this._config.static.lineProfile}/${id}.jpeg`
    }

    public createMainRichMenuForUser(uid: string): Observable<any> {
        const path = this._config.application.host
        const userRichMenu = this._client.getRichMenuIdOfUser(uid)
        return from(userRichMenu).pipe(
            mergeMap((richId) => {
                const promise = this._client.deleteRichMenu(richId)
                return from(promise).pipe(
                    mergeMap(() => {
                        return throwError(`delete existing rich menu`)
                    }),
                )
            }),
            catchError(() => {
                const richMenu: RichMenu = {
                    areas: [
                        {
                            bounds: {
                                x: 0,
                                y: 0,
                                width: 266,
                                height: 270,
                            },
                            action: {
                                type: 'message',
                                text: 'คำถามที่พบบ่อย',
                            },
                        },
                        {
                            bounds: {
                                x: 267,
                                y: 0,
                                width: 267,
                                height: 270,
                            },
                            action: {
                                type: 'message',
                                text: 'จัดการข้อมูลตัวแทน',
                            },
                        },
                        {
                            bounds: {
                                x: 533,
                                y: 0,
                                width: 267,
                                height: 270,
                            },
                            action: {
                                type: 'message',
                                text: 'จัดการกรมธรรม์',
                            },

                        },
                    ],
                    chatBarText: 'เมนูหลัก',
                    name: 'Default User Rich Menu',
                    selected: false,
                    size: {
                        width: 800,
                        height: 270,
                    },
                }
                return from(this._client.createRichMenu(richMenu)).pipe(
                    mergeMap(richId => {
                        const promise = this._client.setRichMenuImage(richId, FileSystem.readFileSync('./vendor/images/linerichmenu.png'))
                        return from(promise).pipe(
                            map(() => richId),
                        )
                    }),
                )
            }),
        ).pipe(
            mergeMap(richId => from(this._client.linkRichMenuToUser(uid, richId))),
        )
    }

    public getProfileFromGroup(lineId: string, groupId: string): Observable<ILineProfile> {
        const profile = this._profileMap.get(lineId)
        if (_.isNil(profile)) {
            const promise = this._client.getGroupMemberProfile(groupId, lineId)
            return from(promise).pipe(
                catchError(err => {
                    throw new HttpException(`Profile not found`,
                        HttpStatus.NOT_FOUND)
                }),
                mergeMap(newProfile => {
                    return forkJoin([
                        this._createProfileSchema(newProfile),
                        this._imageSave(newProfile),
                    ])

                }),
                map((results: any[]) => {
                    return _.first(results)
                }),
            )
        }
        return of(profile)
    }

    public pushFlexMessage(lineId: string, schema: Types.Message | Types.Message[]): Observable<any> {
        const promise = this._client.pushMessage(lineId, schema)
        return from(promise).pipe(
            catchError(() => {
                throw new HttpException(`Cannot push flex message`, HttpStatus.INTERNAL_SERVER_ERROR)
            }),
        )
    }

    public deleteRichMenuOfUser(lineId: string): Observable<any> {
        const userRichMenu = this._client.getRichMenuIdOfUser(lineId)
        return from(userRichMenu).pipe(
            mergeMap((richId) => {
                const promise = this._client.deleteRichMenu(richId)
                return from(promise).pipe(
                    mergeMap(() => {
                        return throwError(`delete existing rich menu`)
                    }),
                )
            }),
        )
    }

}
