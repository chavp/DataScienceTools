import {Observable} from 'rxjs'

export interface IMssqlInterface {
    getCallabck(filter: any): Observable<any>
    getSurvey(filter: any): Observable<any>
    getPSurvey(filter: any): Observable<any>
}
