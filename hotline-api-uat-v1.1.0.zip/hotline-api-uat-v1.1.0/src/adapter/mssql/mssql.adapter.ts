import {ConnectionPool} from 'mssql'
import {from, Observable, of} from 'rxjs'
import {IMssqlInterface} from './interface/mssql.interface'
import * as sql from 'mssql'

export class MssqlAdapter implements IMssqlInterface {
    constructor(
        private readonly _connectionPool: ConnectionPool,
    ) {
    }

    public getCallabck(filter: any): Observable<any> {
        return from(this._connectionPool.request()
            .query('EXEC report_callback_hotline \''
                + filter.startdate + '\',\''
                + filter.enddate + '\',\''
                + filter.type + '\',\'0\',\''
                + filter.phone + '\'')
            .then(result => {
                return result.recordset
            }),
        )
    }

    public getSurvey(filter: any): Observable<any> {
        return from(this._connectionPool.request()
            .query('EXEC report_survey_hotline \''
                  + filter.startdate + '\',\''
                  + filter.enddate + '\',\''
                  + filter.type + '\',\''
                  + filter.user + '\'')
            .then(result => {
                return result.recordset
            }),
        )
    }

    public getPSurvey(filter: any): Observable<any> {
        return from(this._connectionPool.request()
            .query('EXEC dashboard_psurvey_hotline \'' + filter.date + '\'')
            .then(result => {
                // console.log('reportICF: ', result)
                return result.recordset
            }),
        )
    }

}
