import * as _ from 'lodash'
import * as QueryString from 'qs'
import { IAs400Adapter } from './interface'
import {
    EMPTY,
    from,
    Observable,
    of,
} from 'rxjs'
import {
    IAs400AdapterEndpoint,
    IConfig,
} from '../../common/interface/config.interface'
import * as OAuth2 from 'simple-oauth2'
import {
    HttpException,
    HttpStatus,
} from '@nestjs/common'
import {
    map,
    mergeMap,
    tap,
    catchError,
} from 'rxjs/operators'
import Axios, { AxiosInstance } from 'axios'
import {
    IAs400PolicyMeta,
    IAs400PolicySchema,
    IAs400RiskMeta,
} from './interface/schema.interface'
import * as fs from 'fs'

export class As400AdapterUat implements IAs400Adapter {
    private readonly _credentials: any
    private readonly _tokenConfig: any

    private _oAuthClient: OAuth2.OAuthClient
    private _accessToken: OAuth2.AccessToken
    private readonly _axios: AxiosInstance
    private readonly _coverageMap: Map<string, string>

    constructor(
        private readonly _config: IConfig,
    ) {
        this._credentials = {
            client: {
                id: _.get(this._config, 'adapter.as400.auth.clientId'),
                secret: _.get(this._config, 'adapter.as400.auth.clientSecret'),
            },
            auth: {
                tokenHost: _.get(this._config, 'adapter.as400.auth.host'),
                tokenPath: _.get(this._config, 'adapter.as400.auth.path'),
            },
        }

        this._tokenConfig = {
            scope: _.get(this._config, 'adapter.as400.auth.scope', []),
        }

        console.log('UAT ADApter init')
        this._getNewToken()

        const host = _.get(this._config, 'adapter.as400.endpoint.host', '')
        const path = _.get(this._config, 'adapter.as400.endpoint.path', '')
        const baseURL = `${host}${path}`
        this._axios = Axios.create({
            baseURL,
            responseType: 'json',
        })
        const jsonMapping: { [key: string]: string } = JSON.parse(fs.readFileSync('resource/coverage-logic.json').toString('utf8'))
        this._coverageMap = new Map<string, string>(Object.entries(jsonMapping))
    }

    private _getNewToken(): Promise<any> {
        this._oAuthClient = OAuth2.create(this._credentials)

        return this._oAuthClient.clientCredentials.getToken(
            this._tokenConfig,
        ).then((token) => {
            this._accessToken = this._oAuthClient.accessToken.create(token)
        }).catch(e => {
            throw new HttpException(
                `Cannot Authenticated AS400 Adapter`,
                HttpStatus.INTERNAL_SERVER_ERROR,
            )
        })
    }

    private _preFlight(): Observable<{}> {
        return of({}).pipe(
            mergeMap(() => {
                try {
                    if (this._accessToken.expired()) {
                        // get new access token
                        return from(this._getNewToken())
                    }
                    return of({})
                } catch (e) {
                    return from(this._getNewToken())
                }

            }),
            map(() => ({})),
        )
    }

    private _coverageMapping(item: IAs400PolicyMeta | IAs400PolicySchema): IAs400PolicyMeta | IAs400PolicySchema {
        const key = `${item.cover}${item.contract_type}${item.risk_type}`
        item.coverage_type = this._coverageMap.get(key) || ''
        return item
    }

    public getAs400ByChassis(chassis: string): Observable<IAs400PolicyMeta> {
        const accessToken = _.get(this._accessToken, 'token.access_token')

        const queryObject = {
            chassis,
            limit: 30,
        }
        const promise = this._axios.request({
            method: 'GET',
            url: `/policies?${QueryString.stringify(queryObject)}`,
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        })
        return this._preFlight().pipe(
            mergeMap(() => {
                return from(promise)
            }),
            catchError(() => EMPTY),
            mergeMap((result) => {
                const data = _.get(
                    result,
                    'data.data',
                    [],
                ) as IAs400PolicyMeta[]
                return from(data)
            }),
            map(item => this._coverageMapping(item)),
        )
    }

    public getAs400ByInsured(name: string): Observable<IAs400PolicyMeta> {
        const accessToken = _.get(this._accessToken, 'token.access_token')

        const queryObject = {
            insured: name,
            limit: 30,
        }

        const promise = this._axios.request({
            method: 'GET',
            url: `/policies?${QueryString.stringify(queryObject)}`,
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        })
        return this._preFlight().pipe(
            mergeMap(() => {
                return from(promise)
            }),
            catchError(() => EMPTY),
            mergeMap((result) => {
                const data = _.get(
                    result,
                    'data.data',
                    [],
                ) as IAs400PolicyMeta[]
                return from(data)
            }),
            map(item => this._coverageMapping(item)),
        )
    }

    public getAs400ByPolicyNo(policyNo: string): Observable<IAs400PolicyMeta> {
        const accessToken = _.get(this._accessToken, 'token.access_token')

        const promise = this._axios.request({
            method: 'GET',
            url: `/policies?policyNo=${policyNo}`,
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        })
        return this._preFlight().pipe(
            mergeMap(() => {
                return from(promise)
            }),
            catchError(() => EMPTY),
            mergeMap((result) => {
                const data = _.get(
                    result,
                    'data.data',
                    [],
                ) as IAs400PolicyMeta[]
                return from(data)
            }),
            map(item => this._coverageMapping(item)),
        )
    }

    public getAs400ByRegistration(registration: string): Observable<IAs400PolicyMeta> {
        const accessToken = _.get(this._accessToken, 'token.access_token')

        const queryObject = {
            registration,
            limit: 30,
        }
        const promise = this._axios.request({
            method: 'GET',
            url: `/policies?${QueryString.stringify(queryObject)}`,
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        })
        return this._preFlight().pipe(
            mergeMap(() => {
                return from(promise)
            }),
            catchError(() => EMPTY),
            mergeMap((result) => {
                const data = _.get(
                    result,
                    'data.data',
                    [],
                ) as IAs400PolicyMeta[]
                return from(data)
            }),
            map(item => this._coverageMapping(item)),
        )
    }

    public getPolicyDetail(policyId: string, riskId: string): Observable<IAs400PolicySchema> {
        const accessToken = _.get(this._accessToken, 'token.access_token')
        const promise = this._axios.request({
            method: 'GET',
            url: `/policies/${policyId}/risks/${riskId}`,
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        })
        return this._preFlight().pipe(
            mergeMap(() => {
                return from(promise)
            }),
            catchError(() => EMPTY),
            mergeMap((result) => {
                const data = _.get(
                    result,
                    'data',
                    {},
                ) as IAs400PolicySchema
                return of(data)
            }),
            map(item => this._coverageMapping(item) as IAs400PolicySchema),
        )
    }

    public getRisksMetaByPolicyId(policyId: string): Observable<IAs400RiskMeta> {
        const accessToken = _.get(this._accessToken, 'token.access_token')
        const promise = this._axios.request({
            method: 'GET',
            url: `/policies/${policyId}/risks`,
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        })
        return this._preFlight().pipe(
            mergeMap(() => {
                return from(promise)
            }),
            catchError(() => EMPTY),
            mergeMap((result) => {
                const data = _.get(
                    result,
                    'data.data',
                    [],
                ) as IAs400RiskMeta[]
                return from(data)
            }),
        )
    }
}
