import { Observable } from 'rxjs'
import {
    IAs400PolicyMeta,
    IAs400RiskMeta,
    IAs400PolicySchema,
} from './schema.interface'

export interface IAs400Adapter {

    getAs400ByPolicyNo(policyNo: string): Observable<IAs400PolicyMeta>

    getAs400ByInsured(name: string): Observable<IAs400PolicyMeta>

    getAs400ByRegistration(registration: string): Observable<IAs400PolicyMeta>

    getAs400ByChassis(chassis: string): Observable<IAs400PolicyMeta>

    getRisksMetaByPolicyId(policyId: string): Observable<IAs400RiskMeta>

    getPolicyDetail(policyId: string, riskId: string): Observable<IAs400PolicySchema>

}
