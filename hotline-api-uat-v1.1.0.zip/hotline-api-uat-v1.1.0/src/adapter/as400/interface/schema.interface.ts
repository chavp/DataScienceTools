export interface IAs400PolicySchema {
    policy_no: string
    policy_status: string
    insured: string
    branch: string
    agent_code: string
    agent_name: string
    coverage_period: string
    product_name: string
    coverage_type: string
    contract_type: string
    reference: string
    long_name: string
    named_driver: string
    genpage1: string
    end_note: string
    period_from: string
    period_to: string
    risk_id: string
    risk_no: number
    risk_type: string
    attachment_date: string
    termination_date: string
    cover: string
    registration: string
    chassis: string
    make_model: string
    cosi: number,
    tfsi: number,
    excess: string
    genpage2: string
    commencement_date: string
}

export interface IAs400PolicyMeta {
    policy_no: string
    policy_status: string
    insured: string
    branch: string
    agent_code: string
    agent_name: string
    product_name: string
    coverage_type: string
    contract_type: string
    reference: string
    long_name: string
    named_driver: string
    genpage1: string
    period_from: string
    period_to: string
    risk_no: number
    risk_type: string
    attachment_date: string
    termination_date: string
    cover: string
    registration: string
    chassis: string
    make_model: string
    cosi: number,
    tfsi: number,
    excess: string
    genpage2: string
    commencement_date: string
}
export interface IAs400RiskMeta {
    risk_id: string
    risk_no: number
    risk_type: string
    attachment_date: string
    termination_date: string
    make_model: string
    registration: string
    chassis: string
    situation: string
}
