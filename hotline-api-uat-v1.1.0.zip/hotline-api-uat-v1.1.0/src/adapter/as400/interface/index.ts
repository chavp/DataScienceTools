export * from './adapter.interface'
