import { IAs400Adapter } from './interface'
import {
    from,
    Observable,
} from 'rxjs'
import { Inject } from '@nestjs/common'
import { ProviderName } from '../../provider'
import { IConfig } from '../../common/interface/config.interface'
import * as fs from 'fs'
import * as _ from 'lodash'
import { map } from 'rxjs/operators'
import {
    IAs400PolicySchema,
    IAs400RiskMeta,
} from './interface/schema.interface'

const {
    CONFIG,
} = ProviderName

export class As400Adapter implements IAs400Adapter {

    private readonly _coverageLogic: any
    private readonly _as400: any

    constructor(
        @Inject(CONFIG)
        private readonly _config: IConfig,
    ) {
        this._as400 = JSON.parse(fs.readFileSync('src/adapter/as400/interface/example.json').toString())
        this._coverageLogic = JSON.parse(fs.readFileSync('src/adapter/as400/interface/coverageLogic.json').toString())
    }

    public getAs400ByPolicyNo(policyNo: string): Observable<any> {
        const content = _.filter(this._as400.data, {policy_no: policyNo})
        const coverage = []
        content.forEach((res) => {
            const cover = res.cover
            const contactType = res.contract_type
            const riskType = res.risk_type
            coverage.push(cover + contactType + riskType)
        })
        const coverageSearch = coverage.toString()
        const resultCoverage = this._coverageLogic[coverageSearch]

        return from(content).pipe(
            map((record) => ({
                policy_no: record.policy_no,
                policy_status: record.policy_status,
                insured: record.insured,
                transaction_no: record.transactio_no,
                branch: record.branch,
                agent_code: record.agent_code,
                agent_name: record.agent_name,
                coverage_period: record.coverage_period,
                product_name: record.product_name,
                coverage_type: resultCoverage,
                sum_insured: record.sum_insured,
                contract_type: record.contract_type,
                reference: record.reference,
                long_name: record.long_name,
                named_driver: record.named_driver,
                genpage1: record.genpage1,
                end_note: record.endn_note,
                period_from: record.period_from,
                period_to: record.period_to,
                risk_no: record.risk_no,
                risk_type: record.risk_type,
                attachment_date: record.attachment_date,
                termination_date: record.termination_date,
                cover: record.cover,
                registration: record.registration,
                chassis: record.chassis,
                make_model: record.make_model,
                cosi: record.cosi,
                tfsi: record.tfsi,
                deductible: record.deductible,
                genpage2: record.genpage2,
            })),
        )
    }

    public getAs400ByInsured(name: string): Observable<any> {
        const regexp = new RegExp(name)
        const content = _.filter(this._as400.data, o => {
            return regexp.test(o.insured)
        })
        return from(content)
    }

    public getAs400ByRegistration(registration: string): Observable<any> {
        const regexp = new RegExp(registration)
        const content = _.filter(this._as400.data, o => {
            return regexp.test(o.registration)
        })
        return from(content)
    }

    public getAs400ByChassis(chassis: string): Observable<any> {
        const regexp = new RegExp(chassis)
        const content = _.filter(this._as400.data, o => {
            return regexp.test(o.chassis)
        })
        return from(content)
    }

    public getRisksMetaByPolicyId(policyId: string): Observable<IAs400RiskMeta> {
        throw new Error('Method not implemented.')
    }

    public getPolicyDetail(policyId: string, riskId: string): Observable<IAs400PolicySchema> {
        throw new Error('Method not implemented.')
    }

}
