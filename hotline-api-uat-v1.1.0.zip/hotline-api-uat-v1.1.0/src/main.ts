import { NestFactory } from '@nestjs/core'
import { MainModule } from './module/main-module'
import * as Config from 'config'
import { ValidationPipe } from '@nestjs/common'
import * as _ from 'lodash'
import * as Morgan from 'morgan'
import * as session from 'express-session'
import { ProviderName } from './provider'
import * as  connectMongo from 'connect-mongo'

async function bootstrap() {
    const port: number = _.toNumber(process.env.PORT) || Config.get('application.port')
    const app = await NestFactory.create(MainModule)

    const customLog = (req, res, next) => {
        console.log(req.headers)
        next()
    }

    const mongoSessionStore: connectMongo.MongoStore = app.get(ProviderName.MONGO_SESSION_STORE)
    app.use(session({
        secret: Config.get('sessions.secretKey'),
        cookie: {
            maxAge: 1000 * 60 * 60,
            httpOnly: true,
        },
        name: 'axa-hotline',
        resave: true,
        saveUninitialized: true,
        store: mongoSessionStore,
    }))

    app.use(Morgan('combined'), customLog)
    app.enableCors({
        credentials: true,
        origin: [/^(.*)/],
        methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
        preflightContinue: false,
        optionsSuccessStatus: 204,
    })
    app.useGlobalPipes(
        new ValidationPipe({
            transform: true,
        }),
    )
    await app.listen(port)
    return port
}

bootstrap().then(port => {
    console.log(`application started on port ${port}`)
})
