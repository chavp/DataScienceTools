import { classToPlain } from 'class-transformer'

export class ClassStringify {
    public static fromClass(cls: any) {
        return JSON.stringify(classToPlain(cls))
    }
}
