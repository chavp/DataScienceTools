import {
    IDomainEvent,
    IDomainEventPayload,
} from './interface/domain-event.interface'
import { classToClass } from 'class-transformer'

export abstract class AbstractDomainEvent<Model, Schema> implements IDomainEvent<Model> {
    protected _topic: string
    protected _data: Model

    protected constructor(topic: string, data: Model) {
        this._topic = topic
        this._data = data
    }

    public getPayload(): IDomainEventPayload {
        const schema = this.serialize(this._data)
        return {
            topic: this._topic,
            data: Buffer.from(JSON.stringify(schema)),
        }
    }

    public getTopic(): string {
        return this._topic
    }

    public setTopic(topic: string): void {
        this._topic = topic
    }

    public getData(): Model {
        return classToClass(this._data)
    }

    public setData(data: Model): void {
        this._data = data
    }

    abstract serialize(model: Model): Schema

}
