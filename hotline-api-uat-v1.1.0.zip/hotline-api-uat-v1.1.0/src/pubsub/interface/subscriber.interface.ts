import { IDomainEventPayload } from './domain-event.interface'
import { Observable } from 'rxjs'

export interface ISubscriber {
    onEventPublished(topic: string, data: Buffer): Observable<any>
}
