import { IDomainEvent } from './domain-event.interface'

export interface IPublisher<T> {
    publish(domainEvent: IDomainEvent<T>): void
}
