export interface IDomainEventPayload {
    topic: string
    data: Buffer
}

export interface IDomainEvent<T> {
    getTopic(): string

    getPayload(): IDomainEventPayload

    setTopic(topic: string): void

    setData(data: T): void

    getData(): T
}
