import { ISubscriber } from './interface/subscriber.interface'
import * as zmq from 'zeromq'
import { IDomainEventPayload } from './interface/domain-event.interface'
import { Observable } from 'rxjs'
import { DomainEvent } from './event.enum'

export abstract class AbstractSubscriber implements ISubscriber {
    private readonly _socket: zmq.Socket

    protected constructor(eventName: DomainEvent) {
        this._socket = zmq
            .socket('sub')
            .connect('tcp://127.0.0.1:4000')
            .subscribe(eventName)
            .on('message', (topic: Buffer, data: Buffer) => {
                this.onEventPublished(
                    topic.toString() as DomainEvent,
                    data,
                ).subscribe()
            })
    }

    abstract onEventPublished(topic: DomainEvent, buffer: Buffer): Observable<any>
}
