export enum IncidentEvent {
    INCIDENT_SURVEYOR_ASSIGNED = 'incident-surveyor-assigned',
}

export enum MessagingEvent {
    MESSAGE_AGENT_SENT_TO_GROUP = 'message-agent-sent-to-group',
    MESSAGE_AGENT_SENT_TO_USER = 'message-agent-sent-to-user',
}

export enum LineEvent {
    LINE_BOT_JOINED = 'line-bot-joined',
    LINE_BOT_FOLLOWED = 'line-bot-followed',
    LINE_BOT_UNFOLLOWED = 'line-bot-unfollowed',
    LINE_MESSAGE_RECEIVED = 'line-message-received',
    LINE_RECEIVE_TEXT = 'line-receive-text',
    LINE_RECEIVE_IMAGE = 'line-receive-image',
    LINE_RECEIVE_STICKER = 'line-receive-sticker',
    LINE_RECEIVE_LOCATION = 'line-receive-location',
}

export enum QaRecorder {
    RECORDER_QA_MANAGEMENT = 'recorder-qa-management',
    RECORDER_SAVE_QA_MANAGEMENT = 'save-qa-management',
}

export type DomainEvent = IncidentEvent | LineEvent | QaRecorder | SurveyorEvent

export enum SurveyorEvent {
    UPDATE_SURVEYOR_ASSIGNMENT = 'update-surveyor-assignment',
    RECONFIRM_SURVEYOR_ARRIVED = 'reconfirm-surveyor-arrived',
    CASE_NOT_ARRIVE = 'case-not-arrive',
}
