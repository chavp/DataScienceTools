import { IPublisher } from './interface/publisher.interface'
import * as zmq from 'zeromq'
import { IDomainEvent } from './interface/domain-event.interface'
import { Entity } from '../common/entity'

export class DomainEventPublisher<Model extends Entity> implements IPublisher<Model> {
    private readonly _socket: zmq.Socket

    constructor() {
        console.log('publisher init')
        this._socket = zmq
            .socket('pub')
            .bindSync('tcp://127.0.0.1:4000')
    }

    public publish(domainEvent: IDomainEvent<Model>): void {
        const payload = domainEvent.getPayload()
        this._socket.send([
            payload.topic,
            payload.data,
        ])
    }

}
