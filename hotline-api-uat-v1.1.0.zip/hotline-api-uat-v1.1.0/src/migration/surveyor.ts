import {
    Inject,
    Injectable,
} from '@nestjs/common'
import * as _ from 'lodash'
import {
    Collection,
    Cursor,
    Db,
} from 'mongodb'
import {
    from,
    Observable,
    Observer,
    of,
} from 'rxjs'
import {
    concatMap,
    delay,
    filter,
    mergeMap,
    reduce,
    tap,
} from 'rxjs/operators'
import { IConfig } from '../common/interface/config.interface'
import { ProviderName } from '../provider'
import { IMigrationTask } from './interface/migration.interface'

@Injectable()
export class SurveyorMigration implements IMigrationTask {

    constructor() {
        //
    }

    public run(): void {
        // TODO run migration script
    }

}
