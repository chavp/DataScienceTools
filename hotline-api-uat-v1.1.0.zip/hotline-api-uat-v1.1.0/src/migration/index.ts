import { SurveyorMigration } from './surveyor'

const migrationTasks = [
    // TODO add migration task here
    SurveyorMigration,
]

export { migrationTasks }
