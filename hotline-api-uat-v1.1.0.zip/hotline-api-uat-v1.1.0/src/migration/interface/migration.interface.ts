export interface IMigrationTask {
    run(): void
}
